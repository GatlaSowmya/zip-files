// ************************************************ new schema **************************************************

// const express = require('express');
// const { Pool } = require('pg');
// const cors = require('cors');
// const multer = require('multer');
// const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
// const nodemailer = require('nodemailer');
// const cron = require('node-cron');


// const app = express();

// // PostgreSQL connection
// const pool = new Pool({
//   user: 'visys',
//   host: '156.67.104.162',
//   database: 'ai4tstudb',
//   password: 'mahi@321',
//   port: 5432,
// });

// // AWS S3 Configuration
// const s3Client = new S3Client({
//   region: 'ap-south-2',
//   credentials: {
//     accessKeyId: 'AKIA47CRWL6GZWBHVKNE',
//     secretAccessKey: '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',
//   },
// });
// const S3_BUCKET = 'visys-web';
// const upload = multer({ storage: multer.memoryStorage() });

// // Middleware
// app.use(cors());
// app.use(express.json());

const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const multer = require('multer');
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const nodemailer = require('nodemailer');
const cron = require('node-cron');

require('dotenv').config();

const app = express();

// PostgreSQL connection
const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

// AWS S3 Configuration
const s3Client = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});
const S3_BUCKET = process.env.AWS_BUCKET;

const upload = multer({ storage: multer.memoryStorage() });

// Middleware
app.use(cors());
app.use(express.json());



// Upload avatar to S3
app.post('/api/upload-avatar', upload.single('avatar'), async (req, res) => {
  const file = req.file;
  if (!file) return res.status(400).send('No file uploaded.');

  if (!file.mimetype.startsWith('image/')) {
    return res.status(400).json({ error: 'Only image files are allowed.' });
  }

  const extension = file.originalname.split('.').pop();
  const timestamp = Date.now();
  const fileKey = `employee-test/${timestamp}.${extension}`;

  try {
    await s3Client.send(new PutObjectCommand({
      Bucket: S3_BUCKET,
      Key: fileKey,
      Body: file.buffer,
      ContentType: file.mimetype,
    }));

    const url = `https://${S3_BUCKET}.s3.ap-south-2.amazonaws.com/${fileKey}`;
    res.json({ url });
  } catch (err) {
    console.error('S3 Upload Error:', err);
    res.status(500).json({ error: 'Failed to upload image to S3' });
  }
});





// Login endpoint
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const result = await pool.query(
      'SELECT id, name, email, role, avatar FROM ems_test.test WHERE email = $1 AND password = $2',
      [email.toLowerCase(), password]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const user = result.rows[0];
    res.json({ user });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Server error during login' });
  }
});




// Add user 
app.post('/api/add-user', async (req, res) => {
  const {
    name, email, password, role, avatar,
    fullName, dateOfBirth, dateOfJoining, gender, nationality, maritalStatus,
    permanentAddress, currentAddress, phoneNumber, alternatePhoneNumber, personalEmail,
    teamLead, manager, position, department,
    aadhar, panCard, passport, drivingLicense,
    bankName, bankBranch, accountNumber, ifscCode
  } = req.body;

  try {
    if (!name || !email || !password || !role) {
      return res.status(400).json({ error: 'Name, email, password, and role are required' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ error: 'Invalid email format' });
    }

    const validRoles = ['Admin', 'HR', 'Manager','Director', 'Team Lead', 'Employee'];
    if (!validRoles.includes(role)) {
      return res.status(400).json({ error: 'Invalid role' });
    }

    if (role === 'Manager' && teamLead) {
      return res.status(400).json({ error: 'Managers cannot have a Team Lead' });
    }

    if (role === 'Team Lead' && !manager) {
      return res.status(400).json({ error: 'Team Leads must have a Manager' });
    }

    if (role === 'Employee' && (!teamLead || !manager)) {
      return res.status(400).json({ error: 'Employee must have both Team Lead and Manager' });
    }

    const validDepartments = ['Management', 'IT', 'Human Resources', 'Operations & Development', 'Finance'];
    if (department && !validDepartments.includes(department)) {
      return res.status(400).json({ error: 'Invalid department' });
    }

    if (bankName || bankBranch || accountNumber || ifscCode) {
      if (!bankName || !bankBranch || !accountNumber || !ifscCode) {
        return res.status(400).json({ error: 'All bank details must be provided if any are included' });
      }
    }

    if (personalEmail && !emailRegex.test(personalEmail)) {
      return res.status(400).json({ error: 'Invalid personal email format' });
    }

    if (phoneNumber && !/^\+?\d{10,15}$/.test(phoneNumber)) {
      return res.status(400).json({ error: 'Invalid phone number format' });
    }

    if (alternatePhoneNumber && !/^\+?\d{10,15}$/.test(alternatePhoneNumber)) {
      return res.status(400).json({ error: 'Invalid alternate phone number format' });
    }

    if (aadhar && !/^\d{12}$/.test(aadhar)) {
      return res.status(400).json({ error: 'Invalid Aadhar number format' });
    }

    if (panCard && !/^[A-Z]{5}\d{4}[A-Z]{1}$/.test(panCard)) {
      return res.status(400).json({ error: 'Invalid PAN card format' });
    }

    const result = await pool.query(
      `INSERT INTO ems_test.test (
        name, email, password, role, avatar,
        full_name, date_of_birth, date_of_joining, gender, nationality, marital_status,
        permanent_address, current_address, phone_number, alternate_phone_number, personal_email,
        team_lead, manager, position, department,
        aadhar, pan_card, passport, driving_license,
        bank_name, bank_branch, account_number, ifsc_code
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28)
      RETURNING id, name, email, role`,
      [
        name, email.toLowerCase(), password, role, avatar || null,
        fullName || null, dateOfBirth || null, dateOfJoining || null, gender || null, nationality || null, maritalStatus || null,
        permanentAddress || null, currentAddress || null, phoneNumber || null, alternatePhoneNumber || null, personalEmail || null,
        role === 'Employee' ? teamLead : null,
        ['Employee', 'Team Lead'].includes(role) ? manager : null,
        position || null, department || null,
        aadhar || null, panCard || null, passport || null, drivingLicense || null,
        bankName || null, bankBranch || null, accountNumber || null, ifscCode || null
      ]
    );

    // Send welcome email
    const user = result.rows[0];
    try {
      const mailOptions = {
        from: '"HR Team" <ai4bazaarquotation@gmail.com>',
        to: email,
        subject: `Welcome to the Team, ${name}!`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0;">
            <h2 style="color: #2c3e50;">Welcome to the Team!</h2>
            <p>Dear ${name},</p>
            
            <p>We are excited to have you join our team as ${position} in the ${department} department.</p>
            
            <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;">
              <h3 style="margin-top: 0;">Your Login Credentials:</h3>
              <p><strong>Employee ID:</strong> ${user.id}</p>
              <p><strong>Email:</strong> ${email}</p>
              <p><strong>Password:</strong> ${password}</p>
              <p><strong>Login URL:</strong> <a href="http://your-ems-website.com/login">http://your-ems-website.com/login</a></p>
            </div>
            
            <p>Please keep these credentials secure and change your password after your first login.</p>
            
            <p>If you have any questions, please don't hesitate to contact HR.</p>
            
            <p>Best regards,<br>
            HR Team</p>
            
            <div style="margin-top: 30px; font-size: 12px; color: #777;">
              <p>This is an automated message. Please do not reply.</p>
            </div>
          </div>
        `
      };

      await transporter.sendMail(mailOptions);
      console.log(`Welcome email sent to ${email}`);
    } catch (emailError) {
      console.error('Error sending welcome email:', emailError);
      // Don't fail the whole request if email fails
    }

    res.status(201).json({
      message: 'User added successfully',
      user: user
    });
  } catch (err) {
    console.error('Error adding user:', err);
    if (err.code === '23505') {
      res.status(400).json({ error: 'Email already exists' });
    } else {
      res.status(500).json({ error: err.message || 'Server error while adding user' });
    }
  }
});



// Get employees 
app.get('/api/employees', async (req, res) => {
  const { role, name, userId } = req.query;

  try {
    if (!role) {
      return res.status(400).json({ error: 'Role query parameter is required' });
    }

    let query = `
      SELECT id, name, email, role, department, position,
             avatar, team_lead AS "teamLead", manager, status
      FROM ems_test.test
    `;
    const params = [];

    if (role === 'Admin' || role === 'HR' || role === 'Director') {
      // Admin, HR, and Directors see all employees
    } else if (role === 'Manager') {
      // Managers see employees and team leads they manage
      query += ` WHERE manager = $1 OR team_lead = $1`;
      params.push(name);
    } else if (role === 'Team Lead') {
      // Team leads see employees they lead
      query += ` WHERE team_lead = $1`;
      params.push(name);
    } else if (role === 'Employee') {
      // Employees see only their own record, using userId
      query += ` WHERE id = $1`;
      params.push(userId || name); // Fallback to name for backward compatibility
    } else {
      return res.status(400).json({ error: 'Invalid role' });
    }

    query += ` ORDER BY name`;

    const result = await pool.query(query, params);
    console.log(`Employees fetched for role=${role}, name=${name}, userId=${userId}:`, result.rows);
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching employees:', err);
    res.status(500).json({ error: 'Server error fetching employees' });
  }
});


// Update employee or update user
app.put('/api/employees/:id', async (req, res) => {
  const { id } = req.params;
  const {
    name, email, role, department, position, avatar,
    teamLead, manager
  } = req.body;

  try {
    if (role === 'Manager' && teamLead) {
      return res.status(400).json({ error: 'Managers cannot have a Team Lead' });
    }

    const result = await pool.query(
      `UPDATE ems_test.test SET
        name = $1, email = $2, role = $3,
        department = $4, position = $5,
        avatar = $6,
        team_lead = CASE WHEN $3 = 'Employee' THEN $7 ELSE NULL END,
        manager = CASE WHEN $3 IN ('Employee', 'Team Lead') THEN $8 ELSE NULL END
      WHERE id = $9
      RETURNING id, name, email, role, department, position, avatar,
                team_lead AS "teamLead", manager, status`,
      [
        name, email, role, department, position,
        avatar, teamLead, manager, id
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error('Error updating employee:', err);
    res.status(500).json({ error: 'Server error updating employee' });
  }
});



// Delete employee
app.delete('/api/employees/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const checkResult = await pool.query(
      'SELECT id FROM ems_test.test WHERE id = $1',
      [id]
    );

    if (checkResult.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    const subordinatesCheck = await pool.query(
      `SELECT COUNT(*) FROM ems_test.test 
       WHERE manager = $1 OR team_lead = $1`,
      [id]
    );

    if (subordinatesCheck.rows[0].count > 0) {
      return res.status(400).json({
        error: 'Cannot delete user who has team members assigned'
      });
    }

    await pool.query(
      'DELETE FROM ems_test.test WHERE id = $1',
      [id]
    );

    res.json({ message: 'Employee deleted successfully' });
  } catch (err) {
    console.error('Error deleting employee:', err);
    res.status(500).json({ error: 'Server error deleting employee' });
  }
});



// Get team leads and managers for dropdowns
app.get('/api/leads-managers', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT id, name, role
      FROM ems_test.test
      WHERE role IN ('Team Lead', 'Manager','Director')
      ORDER BY role DESC, name
    `);
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching leads/managers:', err);
    res.status(500).json({ error: 'Server error fetching leads/managers' });
  }
});



// Get user by ID
app.get('/api/user/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(`
      SELECT 
        id, name, email, password, role, avatar,
        full_name AS "fullName", date_of_birth AS "dateOfBirth", date_of_joining AS "dateOfJoining", gender, nationality, marital_status AS "maritalStatus",
        permanent_address AS "permanentAddress", current_address AS "currentAddress",
        phone_number AS "phoneNumber", alternate_phone_number AS "alternatePhoneNumber", personal_email AS "personalEmail",
        team_lead AS "teamLead", manager, position, department,
        aadhar, pan_card AS "panCard", passport, driving_license AS "drivingLicense",
        bank_name AS "bankName", bank_branch AS "bankBranch", account_number AS "accountNumber", ifsc_code AS "ifscCode"
      FROM ems_test.test
      WHERE id = $1
    `, [(id)]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error('Error fetching user:', err);
    res.status(500).json({ error: 'Server error fetching user' });
  }
});



// Update user by ID
app.put('/api/user/:id', async (req, res) => {
  const { id } = req.params;
  const {
    name, email, password, role, avatar,
    fullName, dateOfBirth, dateOfJoining, gender, nationality, maritalStatus,
    permanentAddress, currentAddress, phoneNumber, alternatePhoneNumber, personalEmail,
    teamLead, manager, position, department,
    aadhar, panCard, passport, drivingLicense,
    bankName, bankBranch, accountNumber, ifscCode
  } = req.body;

  try {
    const result = await pool.query(`
      UPDATE ems_test.test SET
        name=$1, email=$2, password=$3, role=$4, avatar=$5,
        full_name=$6, date_of_birth=$7, date_of_joining=$8, gender=$9, nationality=$10, marital_status=$11,
        permanent_address=$12, current_address=$13,
        phone_number=$14, alternate_phone_number=$15, personal_email=$16,
        team_lead=$17, manager=$18, position=$19, department=$20,
        aadhar=$21, pan_card=$22, passport=$23, driving_license=$24,
        bank_name=$25, bank_branch=$26, account_number=$27, ifsc_code=$28
      WHERE id = $29
      RETURNING *
    `, [
      name, email, password, role, avatar,
      fullName, dateOfBirth, dateOfJoining, gender, nationality, maritalStatus,
      permanentAddress, currentAddress, phoneNumber, alternatePhoneNumber, personalEmail,
      teamLead, manager, position, department,
      aadhar, panCard, passport, drivingLicense,
      bankName, bankBranch, accountNumber, ifscCode,
      id
    ]);

    if (result.rows.length === 0) return res.status(404).json({ error: 'User not found' });
    res.json({ message: 'User updated', user: result.rows[0] });
  } catch (err) {
    console.error('Update user error:', err);
    res.status(500).json({ error: 'Error updating user' });
  }
});


// ================================ Backend: Leave Routes (Express + PostgreSQL) =======================

// // GET /api/leaves - Get leaves by role and filters
app.get('/api/leaves', async (req, res) => {
  const { role, userId, name } = req.query;

  try {
    if (!role || (!userId && !name)) {
      return res.status(400).json({ error: 'Role and either userId or name are required' });
    }

    let query = `
      SELECT id, user_id AS "userId", type, date, reason, status,
             accepted_by AS "acceptedBy", accepted_at AS "acceptedAt", created_at AS "createdAt"
      FROM ems_test.leaves
    `;
    const params = [];

    if (role === 'Admin' || role === 'HR') {
      // Admin and HR see all requests (unchanged, but note this might need restriction)
    } else if (role === 'Manager') {
      // Managers see requests from employees and team leads they manage
      query += ` WHERE user_id IN (
        SELECT id FROM ems_test.test WHERE manager = $1 OR team_lead = $1
      )`;
      params.push(name);
    } else if (role === 'Director') {
      // Directors see requests from HR, Admin, and Manager roles
      query += ` WHERE user_id IN (
        SELECT id FROM ems_test.test WHERE role IN ('HR', 'Admin', 'Manager')
      )`;
    } else if (role === 'Team Lead') {
      // Team leads see only their own requests
      query += ` WHERE user_id = $1`;
      params.push(userId);
    } else if (role === 'Employee') {
      // Employees see only their own requests
      query += ` WHERE user_id = $1`;
      params.push(userId);
    } else {
      return res.status(400).json({ error: 'Invalid role' });
    }

    query += ' ORDER BY date DESC';

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching leave requests:', err);
    res.status(500).json({ error: 'Server error fetching leave requests' });
  }
});

// POST /api/leaves - Submit leave request
app.post('/api/leaves', async (req, res) => {
  const { userId, type, date, reason, status, acceptedBy } = req.body;

  try {
    if (!userId || !type || !date || !reason) {
      return res.status(400).json({ error: 'userId, type, date, and reason are required' });
    }

    const validTypes = ['Leave', 'WFH'];
    if (!validTypes.includes(type)) {
      return res.status(400).json({ error: 'Invalid leave type. Must be "Leave" or "WFH"' });
    }

    const userCheck = await pool.query('SELECT id, name FROM ems_test.test WHERE id = $1', [userId]);
    if (userCheck.rows.length === 0) {
      return res.status(400).json({ error: 'Invalid userId' });
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ error: 'Invalid date format (YYYY-MM-DD)' });
    }

    const existing = await pool.query(
      `SELECT id FROM ems_test.leaves WHERE user_id = $1 AND date = $2`,
      [userId, date]
    );
    if (existing.rows.length > 0) {
      return res.status(400).json({ error: `You have already applied for leave on ${date}` });
    }

    const result = await pool.query(
      `INSERT INTO ems_test.leaves (user_id, type, date, reason, status, accepted_by, accepted_at, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING id, user_id AS "userId", type, date, reason, status,
                 accepted_by AS "acceptedBy", accepted_at AS "acceptedAt", created_at AS "createdAt"`,
      [userId, type, date, reason, status || 'pending', acceptedBy || null, acceptedBy ? new Date().toISOString() : null, new Date().toISOString()]
    );

    const userName = userCheck.rows[0].name;
    await pool.query(
      `INSERT INTO ems_test.status_logs ("user", action, timestamp, date)
       VALUES ($1, $2, $3, $4)`,
      [userName, 'Submitted', new Date().toISOString(), date]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('Error submitting leave request:', err);
    if (err.code === '23505') {
      return res.status(400).json({ error: 'Duplicate leave entry for the same date' });
    }
    res.status(500).json({ error: err.message || 'Server error submitting leave request' });
  }
});

// PATCH /api/leaves/:id/:action - Approve or Reject leave request
app.patch('/api/leaves/:leaveId/:action', async (req, res) => {
  const { leaveId, action } = req.params;
  const { acceptedBy } = req.body;
  const { role } = req.query;

  try {
    const leave = await pool.query('SELECT user_id FROM ems_test.leaves WHERE id = $1', [leaveId]);
    if (!leave.rows[0]) {
      return res.status(404).json({ error: 'Leave request not found' });
    }

    const user = await pool.query('SELECT role FROM ems_test.test WHERE id = $1', [leave.rows[0].user_id]);
    if (!user.rows[0]) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (role === 'Manager' && ['Employee', 'Team Lead'].includes(user.rows[0].role)) {
      // Allow managers to approve employee/team lead requests
    } else if (role === 'Director' && ['HR', 'Admin', 'Manager'].includes(user.rows[0].role)) {
      // Allow directors to approve HR/Admin/Manager requests
    } else {
      return res.status(403).json({ error: 'Unauthorized to perform this action' });
    }

    const status = action === 'approve' ? 'approved' : 'rejected';
    const result = await pool.query(
      `UPDATE ems_test.leaves SET status = $1, accepted_by = $2, accepted_at = NOW()
       WHERE id = $3 RETURNING *`,
      [status, acceptedBy, leaveId]
    );

    res.json(result.rows[0]);
  } catch (err) {
    console.error('Error updating leave request:', err);
    res.status(500).json({ error: 'Server error updating leave request' });
  }
});


// Check-in endpoint
app.post('/api/attendance/checkin', async (req, res) => {
  const { userId, timestamp, shiftTimings } = req.body;

  try {
    if (!userId) {
      console.log('Check-in failed: User ID is required');
      return res.status(400).json({ error: 'User ID is required' });
    }

    if (!shiftTimings) {
      return res.status(400).json({ error: 'Shift timing is required' });
    }

    const clientTime = timestamp ? new Date(timestamp) : new Date();
    const today = clientTime.toISOString().split('T')[0];
    
    // Check if user already checked in today
    const existingRecord = await pool.query(
      'SELECT * FROM ems_test.attendance WHERE user_id = $1 AND date = $2 AND check_out_time IS NULL',
      [userId, today]
    );

    if (existingRecord.rows.length > 0) {
      console.log(`Check-in failed: User ${userId} already checked in today`);
      return res.status(400).json({ error: 'Already checked in today' });
    }

    // Start a transaction to ensure both operations succeed
    await pool.query('BEGIN');

    try {
      // Insert attendance record
      const result = await pool.query(
        'INSERT INTO ems_test.attendance (user_id, date, check_in_time, shift_timings, created_at) VALUES ($1, $2, $3, $4, $5) RETURNING *',
        [userId, today, clientTime, shiftTimings, clientTime]
      );

      // Update user status to 'active'
      await pool.query(
        'UPDATE ems_test.test SET status = $1 WHERE id = $2',
        ['Online', userId]
      );

      // Commit the transaction
      await pool.query('COMMIT');

      console.log(`User ${userId} checked in successfully at ${clientTime}`);
      res.json({ 
        message: 'Checked in successfully',
        record: result.rows[0]
      });
    } catch (error) {
      // Rollback on error
      await pool.query('ROLLBACK');
      throw error;
    }
  } catch (err) {
    console.error('Check-in error:', err);
    res.status(500).json({ error: 'Server error during check-in' });
  }
});

// ----------- checkout endpoint
app.post('/api/attendance/checkout', async (req, res) => {
  const { userId, workUpdate } = req.body;

  try {
    if (!userId) {
      return res.status(400).json({ error: 'User ID is required' });
    }

    if (!workUpdate || workUpdate.trim() === '') {
      return res.status(400).json({ error: 'Work update is required for checkout' });
    }

    const today = new Date().toISOString().split('T')[0];
    
    // Find today's check-in record
    const checkInRecord = await pool.query(
      'SELECT * FROM ems_test.attendance WHERE user_id = $1 AND date = $2 AND check_out_time IS NULL',
      [userId, today]
    );

    if (checkInRecord.rows.length === 0) {
      return res.status(400).json({ error: 'No check-in record found for today' });
    }

    const record = checkInRecord.rows[0];
    const checkOutTime = new Date();
    const checkInTime = new Date(record.check_in_time);
    
    // Calculate work hours
    const workHours = ((checkOutTime - checkInTime) / (1000 * 60 * 60)).toFixed(2);

    // Start a transaction to ensure both operations succeed
    await pool.query('BEGIN');

    try {
      // Update attendance record
      const result = await pool.query(
        `UPDATE ems_test.attendance 
         SET check_out_time = $1, work_update = $2, work_hours = $3 
         WHERE id = $4 
         RETURNING *`,
        [checkOutTime, workUpdate.trim(), parseFloat(workHours), record.id]
      );

      // Update user status to 'Offline'
      await pool.query(
        'UPDATE ems_test.test SET status = $1 WHERE id = $2',
        ['Offline', userId]
      );

      // Commit the transaction
      await pool.query('COMMIT');

      res.json({ 
        message: 'Checked out successfully',
        record: result.rows[0]
      });
    } catch (error) {
      // Rollback on error
      await pool.query('ROLLBACK');
      throw error;
    }
  } catch (err) {
    console.error('Check-out error:', err);
    res.status(500).json({ error: 'Server error during check-out' });
  }
});

// Get today's attendance status
app.get('/api/attendance/today/:userId', async (req, res) => {
  const { userId } = req.params;

  try {
    const today = new Date().toISOString().split('T')[0];
    const result = await pool.query(
      `SELECT * FROM ems_test.attendance 
       WHERE user_id = $1 AND date = $2 
       ORDER BY check_in_time DESC`,
      [userId, today]
    );

    let status = null;
    if (result.rows.length > 0) {
      const latestRecord = result.rows[0];
      if (latestRecord.check_out_time) {
        status = 'checked-out';
      } else {
        status = 'checked-in';
      }
    }

    res.json({
      status,
      records: result.rows
    });
  } catch (err) {
    console.error('Error fetching attendance status:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get attendance history for a user
app.get('/api/attendance/history/:userId', async (req, res) => {
  const { userId } = req.params;
  const { page = 1, limit = 10 } = req.query;

  try {
    const offset = (page - 1) * limit;
    const result = await pool.query(
      `SELECT a.*, u.name as user_name
       FROM ems_test.attendance a
       JOIN ems_test.test u ON a.user_id = u.id
       WHERE a.user_id = $1
       ORDER BY a.date DESC, a.check_in_time DESC
       LIMIT $2 OFFSET $3`,
      [userId, limit, offset]
    );

    const countResult = await pool.query(
      'SELECT COUNT(*) FROM ems_test.attendance WHERE user_id = $1',
      [userId]
    );

    res.json({
      records: result.rows,
      total: parseInt(countResult.rows[0].count),
      page: parseInt(page),
      totalPages: Math.ceil(countResult.rows[0].count / limit)
    });
  } catch (err) {
    console.error('Error fetching attendance history:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update work update for existing attendance record
app.put('/api/attendance/:id/work-update', async (req, res) => {
  const { id } = req.params;
  const { workUpdate } = req.body;

  try {
    if (!workUpdate || workUpdate.trim() === '') {
      return res.status(400).json({ error: 'Work update cannot be empty' });
    }

    const result = await pool.query(
      'UPDATE ems_test.attendance SET work_update = $1 WHERE id = $2 RETURNING *',
      [workUpdate.trim(), id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Attendance record not found' });
    }

    res.json({
      message: 'Work update saved successfully',
      record: result.rows[0]
    });
  } catch (err) {
    console.error('Error updating work update:', err);
    res.status(500).json({ error: 'Server error' });
  }
});



// Replace your existing monthly endpoint with this fixed version
app.get('/api/attendance/monthly/:userId', async (req, res) => {
  const { userId } = req.params;
  const { month, year } = req.query;

  try {
    // First, let's get the basic records
    const result = await pool.query(
      `SELECT a.*, u.name as user_name
       FROM ems_test.attendance a
       JOIN ems_test.test u ON a.user_id = u.id
       WHERE a.user_id = $1 
       AND EXTRACT(MONTH FROM a.date) = $2 
       AND EXTRACT(YEAR FROM a.date) = $3
       ORDER BY a.date DESC`,
      [userId, month, year]
    );

    // Process each record to calculate work hours properly
    const processedRecords = result.rows.map(record => {
      let workHoursFormatted = '--';
      
      if (record.check_in_time && record.check_out_time) {
        const checkInTime = new Date(record.check_in_time);
        const checkOutTime = new Date(record.check_out_time);
        const diffMs = checkOutTime - checkInTime;
        const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
        const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
        workHoursFormatted = `${diffHours}h ${diffMinutes}m`;
      }
      
      return {
        ...record,
        work_hours: workHoursFormatted
      };
    });

    console.log(`Fetched ${processedRecords.length} monthly records for user ${userId}, month ${month}, year ${year}`);
    
    res.json({
      records: processedRecords
    });
  } catch (err) {
    console.error('Error fetching monthly records:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get ALL attendance records for a user (for download purposes)
app.get('/api/attendance/all/:userId', async (req, res) => {
  const { userId } = req.params;

  try {
    const result = await pool.query(
      `SELECT a.*, u.name as user_name
       FROM ems_test.attendance a
       JOIN ems_test.test u ON a.user_id = u.id
       WHERE a.user_id = $1
       ORDER BY a.date DESC, a.check_in_time DESC`,
      [userId]
    );

    // Process each record to calculate work hours properly
    const processedRecords = result.rows.map(record => {
      let workHoursFormatted = '--';
      
      if (record.check_in_time && record.check_out_time) {
        const checkInTime = new Date(record.check_in_time);
        const checkOutTime = new Date(record.check_out_time);
        const diffMs = checkOutTime - checkInTime;
        const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
        const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
        workHoursFormatted = `${diffHours}h ${diffMinutes}m`;
      }
      
      return {
        ...record,
        work_hours: workHoursFormatted
      };
    });

    console.log(`Fetched ${processedRecords.length} total records for user ${userId}`);
    
    res.json({
      records: processedRecords
    });
  } catch (err) {
    console.error('Error fetching all attendance records:', err);
    res.status(500).json({ error: 'Server error' });
  }
});


  // reports page 
  // Add these endpoints to your server.js file

  // Fetch all attendance records with user details
  app.get('/api/reports/attendance', async (req, res) => {
    try {
      const query = `
        SELECT 
          a.id,
          a.user_id,
          a.check_in_time,
          a.check_out_time,
          a.work_update,
          a.work_hours,
          a.shift_timings,
          a.date,
          a.created_at,
          u.name as employee_name,
          u.full_name,
          u.team_lead,
          u.manager,
          u.department,
          u.position,
          u.email
        FROM ems_test.attendance a
        LEFT JOIN ems_test.test u ON a.user_id = u.id
        ORDER BY a.date DESC, a.check_in_time DESC
      `;
      
      const result = await pool.query(query);
      
      // Add work hours formatting here
      const processedData = result.rows.map(record => {
        let workHoursFormatted = record.work_hours;
        
        if (record.check_in_time && record.check_out_time && !record.work_hours) {
          const checkInTime = new Date(record.check_in_time);
          const checkOutTime = new Date(record.check_out_time);
          const diffMs = checkOutTime - checkInTime;
          const diffHours = (diffMs / (1000 * 60 * 60)).toFixed(2);
          workHoursFormatted = diffHours;
        }
        
        return {
          ...record,
          work_hours: workHoursFormatted
        };
      });
      
      console.log(`Fetched ${processedData.length} attendance records for reports`);
      res.json(processedData);
    } catch (error) {
      console.error('Error fetching attendance data:', error);
      res.status(500).json({ error: 'Failed to fetch attendance data' });
    }
  });

  // Fetch filter options (team leads and managers)
  app.get('/api/reports/filter-options', async (req, res) => {
    try {
      const teamLeadsQuery = `
        SELECT DISTINCT team_lead 
        FROM ems_test.test 
        WHERE team_lead IS NOT NULL AND team_lead != '' 
        ORDER BY team_lead
      `;
      
      const managersQuery = `
        SELECT DISTINCT manager 
        FROM ems_test.test 
        WHERE manager IS NOT NULL AND manager != '' 
        ORDER BY manager
      `;
      
      const departmentsQuery = `
        SELECT DISTINCT department 
        FROM ems_test.test 
        WHERE department IS NOT NULL AND department != '' 
        ORDER BY department
      `;
      
      const [teamLeadsResult, managersResult, departmentsResult] = await Promise.all([
        pool.query(teamLeadsQuery),
        pool.query(managersQuery),
        pool.query(departmentsQuery)
      ]);
      
      const teamLeads = teamLeadsResult.rows.map(row => row.team_lead);
      const managers = managersResult.rows.map(row => row.manager);
      const departments = departmentsResult.rows.map(row => row.department);
      
      console.log(`Filter options: ${teamLeads.length} team leads, ${managers.length} managers, ${departments.length} departments`);
      
      res.json({
        teamLeads,
        managers,
        departments
      });
    } catch (error) {
      console.error('Error fetching filter options:', error);
      res.status(500).json({ error: 'Failed to fetch filter options' });
    }
  });

  // Fetch attendance records with advanced filtering
  app.post('/api/reports/attendance/filter', async (req, res) => {
    try {
      const { teamLead, manager, dateFrom, dateTo, department, position } = req.body;
      
      let query = `
        SELECT 
          a.id,
          a.user_id,
          a.check_in_time,
          a.check_out_time,
          a.work_update,
          a.work_hours,
          a.shift_timings,
          a.date,
          a.created_at,
          u.name as employee_name,
          u.full_name,
          u.team_lead,
          u.manager,
          u.department,
          u.position,
          u.email
        FROM ems_test.attendance a
        LEFT JOIN ems_test.test u ON a.user_id = u.id
        WHERE 1=1
      `;
      
      const queryParams = [];
      let paramCount = 0;
      
      if (teamLead) {
        paramCount++;
        query += ` AND LOWER(u.team_lead) LIKE LOWER($${paramCount})`;
        queryParams.push(`%${teamLead}%`);
      }
      
      if (manager) {
        paramCount++;
        query += ` AND LOWER(u.manager) LIKE LOWER($${paramCount})`;
        queryParams.push(`%${manager}%`);
      }
      
      if (dateFrom) {
        paramCount++;
        query += ` AND a.date >= $${paramCount}`;
        queryParams.push(dateFrom);
      }
      
      if (dateTo) {
        paramCount++;
        query += ` AND a.date <= $${paramCount}`;
        queryParams.push(dateTo);
      }
      
      if (department) {
        paramCount++;
        query += ` AND LOWER(u.department) LIKE LOWER($${paramCount})`;
        queryParams.push(`%${department}%`);
      }
      
      if (position) {
        paramCount++;
        query += ` AND LOWER(u.position) LIKE LOWER($${paramCount})`;
        queryParams.push(`%${position}%`);
      }
      
      query += ` ORDER BY a.date DESC, a.check_in_time DESC`;
      
      const result = await pool.query(query, queryParams);
      res.json(result.rows);
    } catch (error) {
      console.error('Error fetching filtered attendance data:', error);
      res.status(500).json({ error: 'Failed to fetch filtered attendance data' });
    }
  });

  // Get attendance summary statistics
  app.get('/api/reports/attendance/stats', async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      
      let dateFilter = '';
      const queryParams = [];
      
      if (startDate && endDate) {
        dateFilter = 'WHERE a.date BETWEEN $1 AND $2';
        queryParams.push(startDate, endDate);
      }
      
      const statsQuery = `
        SELECT 
          COUNT(*) as total_records,
          COUNT(DISTINCT a.user_id) as unique_employees,
          AVG(a.work_hours) as avg_work_hours,
          COUNT(CASE WHEN a.check_out_time IS NULL THEN 1 END) as pending_checkouts,
          COUNT(CASE WHEN a.work_hours >= 8 THEN 1 END) as full_day_attendance,
          COUNT(CASE WHEN a.work_hours < 8 AND a.work_hours > 0 THEN 1 END) as partial_day_attendance
        FROM ems_test.attendance a
        LEFT JOIN ems_test.test u ON a.user_id = u.id
        ${dateFilter}
      `;
      
      const departmentStatsQuery = `
        SELECT 
          u.department,
          COUNT(*) as attendance_count,
          AVG(a.work_hours) as avg_hours
        FROM ems_test.attendance a
        LEFT JOIN ems_test.test u ON a.user_id = u.id
        ${dateFilter}
        GROUP BY u.department
        ORDER BY attendance_count DESC
      `;
      
      const [statsResult, deptStatsResult] = await Promise.all([
        pool.query(statsQuery, queryParams),
        pool.query(departmentStatsQuery, queryParams)
      ]);
      
      res.json({
        overview: statsResult.rows[0],
        departmentStats: deptStatsResult.rows
      });
    } catch (error) {
      console.error('Error fetching attendance statistics:', error);
      res.status(500).json({ error: 'Failed to fetch attendance statistics' });
    }
  })

  // Get individual employee attendance report
app.get('/api/reports/attendance/employee/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const { startDate, endDate } = req.query;
    
    let dateFilter = '';
    const queryParams = [userId];
    
    if (startDate && endDate) {
      dateFilter = 'AND a.date BETWEEN $2 AND $3';
      queryParams.push(startDate, endDate);
    }
    
    const query = `
      SELECT 
        a.*,
        u.name as employee_name,
        u.full_name,
        u.team_lead,
        u.manager,
        u.department,
        u.position
      FROM ems_test.attendance a
      LEFT JOIN ems_test.test u ON a.user_id = u.id
      WHERE a.user_id = $1 ${dateFilter}
      ORDER BY a.date DESC
    `;
    
    const result = await pool.query(query, queryParams);
    
    // Calculate summary for this employee
    const summary = {
      totalDays: result.rows.length,
      totalHours: result.rows.reduce((sum, row) => sum + (parseFloat(row.work_hours) || 0), 0),
      avgHours: result.rows.length > 0 ? 
        result.rows.reduce((sum, row) => sum + (parseFloat(row.work_hours) || 0), 0) / result.rows.length : 0,
      fullDays: result.rows.filter(row => parseFloat(row.work_hours) >= 8).length,
      partialDays: result.rows.filter(row => parseFloat(row.work_hours) < 8 && parseFloat(row.work_hours) > 0).length,
      pendingCheckouts: result.rows.filter(row => !row.check_out_time).length
    };
    
    res.json({
      attendance: result.rows,
      summary
    });
  } catch (error) {
    console.error('Error fetching employee attendance:', error);
    res.status(500).json({ error: 'Failed to fetch employee attendance data' });
  }
});

// Export attendance data to CSV format (server-side generation)
app.post('/api/reports/attendance/export', async (req, res) => {
  try {
    const { filters } = req.body;
    
    let query = `
      SELECT 
        u.name as employee_name,
        u.full_name,
        u.id as employee_id,
        a.date,
        a.check_in_time,
        a.check_out_time,
        a.work_hours,
        u.team_lead,
        u.manager,
        u.department,
        u.position,
        a.shift_timings,
        a.work_update
      FROM ems_test.attendance a
      LEFT JOIN ems_test.test u ON a.user_id = u.id
      WHERE 1=1
    `;
    
    const queryParams = [];
    let paramCount = 0;
    
    // Apply filters similar to the filter endpoint
    if (filters?.teamLead) {
      paramCount++;
      query += ` AND LOWER(u.team_lead) LIKE LOWER($${paramCount})`;
      queryParams.push(`%${filters.teamLead}%`);
    }
    
    if (filters?.manager) {
      paramCount++;
      query += ` AND LOWER(u.manager) LIKE LOWER($${paramCount})`;
      queryParams.push(`%${filters.manager}%`);
    }
    
    if (filters?.dateFrom) {
      paramCount++;
      query += ` AND a.date >= $${paramCount}`;
      queryParams.push(filters.dateFrom);
    }
    
    if (filters?.dateTo) {
      paramCount++;
      query += ` AND a.date <= $${paramCount}`;
      queryParams.push(filters.dateTo);
    }
    
    query += ` ORDER BY a.date DESC, u.name ASC`;
    
    const result = await pool.query(query, queryParams);
    
    // Convert to CSV format
    const headers = [
      'Employee Name', 'Full Name', 'Employee ID', 'Date', 'Check In', 'Check Out', 
      'Work Hours', 'Team Lead', 'Manager', 'Department', 'Position', 'Shift Timings', 'Work Update'
    ];
    
    const csvData = result.rows.map(row => [
      row.employee_name || '',
      row.full_name || '',
      row.employee_id || '',
      row.date ? new Date(row.date).toLocaleDateString() : '',
      row.check_in_time ? new Date(row.check_in_time).toLocaleTimeString() : '',
      row.check_out_time ? new Date(row.check_out_time).toLocaleTimeString() : '',
      row.work_hours || '0',
      row.team_lead || '',
      row.manager || '',
      row.department || '',
      row.position || '',
      row.shift_timings || '',
      row.work_update || ''
    ]);
    
    const csv = [headers, ...csvData]
      .map(row => row.map(cell => `"${cell}"`).join(','))
      .join('\n');
    
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="attendance_report_${new Date().toISOString().split('T')[0]}.csv"`);
    res.send(csv);
  } catch (error) {
    console.error('Error exporting attendance data:', error);
    res.status(500).json({ error: 'Failed to export attendance data' });
  }
});

// Get employees filtered by team lead/manager
app.get('/api/reports/employees', async (req, res) => {
  try {
    const { teamLead, manager } = req.query;
    
    let query = `
      SELECT DISTINCT
        u.id,
        u.name,
        u.full_name,
        u.id as employee_id,
        u.email,
        u.team_lead,
        u.manager,
        u.department,
        u.position,
        u.phone_number,
        u.date_of_joining,
        u.status,
        COUNT(a.id) as total_attendance_records,
        AVG(a.work_hours) as avg_work_hours,
        MAX(a.date) as last_attendance_date
      FROM ems_test.user u
      LEFT JOIN ems_test.attendance a ON u.id = a.user_id
      WHERE u.status = 'ACTIVE'
    `;
    
    const queryParams = [];
    let paramCount = 0;
    
    // if (teamLead) {
    //   paramCount++;
    //   query += ` AND LOWER(u.team_lead) = LOWER($${paramCount})`;
    //   queryParams.push(teamLead);
    // }
    
    // if (manager) {
    //   paramCount++;
    //   query += ` AND LOWER(u.manager) = LOWER($${paramCount})`;
    //   queryParams.push(manager);
    // }
    if (teamLead) {
  paramCount++;
  query += ` AND LOWER(u.team_lead) LIKE LOWER($${paramCount})`;
  queryParams.push(`%${teamLead}%`);
}

if (manager) {
  paramCount++;
  query += ` AND LOWER(u.manager) LIKE LOWER($${paramCount})`;
  queryParams.push(`%${manager}%`);
}
    
    query += `
      GROUP BY u.id, u.name, u.full_name, u.email, u.team_lead, 
               u.manager, u.department, u.position, u.phone_number, u.date_of_joining, u.status
      ORDER BY u.name ASC
    `;
    
    const result = await pool.query(query, queryParams);
    
    console.log(`Fetched ${result.rows.length} employees with filters: teamLead=${teamLead}, manager=${manager}`);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching employees:', error);
    res.status(500).json({ error: 'Failed to fetch employees' });
  }
});

// Get detailed employee analytics
app.get('/api/reports/employee-analytics/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const currentDate = new Date();
    const thirtyDaysAgo = new Date(currentDate.getTime() - (30 * 24 * 60 * 60 * 1000));
    const sevenDaysAgo = new Date(currentDate.getTime() - (7 * 24 * 60 * 60 * 1000));
    
    // Basic employee info
    const employeeQuery = `
      SELECT * FROM ems_test.test WHERE id = $1
    `;
    
    // Overall attendance stats
    const statsQuery = `
      SELECT 
        COUNT(*) as total_days,
        SUM(work_hours) as total_hours,
        AVG(work_hours) as avg_hours,
        COUNT(CASE WHEN work_hours >= 8 THEN 1 END) as full_days,
        COUNT(CASE WHEN work_hours < 8 AND work_hours > 0 THEN 1 END) as partial_days,
        COUNT(CASE WHEN check_out_time IS NULL THEN 1 END) as pending_checkouts,
        MIN(date) as first_attendance,
        MAX(date) as last_attendance
      FROM ems_test.attendance 
      WHERE user_id = $1
    `;
    
    // Last 30 days attendance for chart
    const chartDataQuery = `
      SELECT 
        date,
        work_hours,
        check_in_time,
        check_out_time,
        EXTRACT(DOW FROM date) as day_of_week
      FROM ems_test.attendance 
      WHERE user_id = $1 AND date >= $2
      ORDER BY date ASC
    `;
    
    // Attendance pattern analysis
    const patternQuery = `
      SELECT 
        CASE 
          WHEN EXTRACT(HOUR FROM check_in_time) <= 9 THEN 'On Time'
          WHEN EXTRACT(HOUR FROM check_in_time) > 9 AND EXTRACT(HOUR FROM check_in_time) <= 10 THEN 'Late'
          ELSE 'Very Late'
        END as arrival_pattern,
        COUNT(*) as count
      FROM ems_test.attendance 
      WHERE user_id = $1 AND check_in_time IS NOT NULL
      GROUP BY arrival_pattern
    `;
    
    // Weekly attendance summary
    const weeklyQuery = `
      SELECT 
        DATE_TRUNC('week', date) as week_start,
        COUNT(*) as days_present, 
        SUM(work_hours) as total_hours,
        AVG(work_hours) as avg_hours
      FROM ems_test.attendance 
      WHERE user_id = $1 AND date >= $2
      GROUP BY DATE_TRUNC('week', date)
      ORDER BY week_start DESC
      LIMIT 8
    `;
    
    // Recent attendance records
    const recentQuery = `
      SELECT 
        date,
        check_in_time,
        check_out_time,
        work_hours,
        work_update,
        shift_timings
      FROM ems_test.attendance 
      WHERE user_id = $1
      ORDER BY date DESC
      LIMIT 10
    `;
    
    // Monthly summary
    const monthlyQuery = `
      SELECT 
        DATE_TRUNC('month', date) as month,
        COUNT(*) as days_present,
        SUM(work_hours) as total_hours,
        AVG(work_hours) as avg_hours
      FROM ems_test.attendance 
      WHERE user_id = $1
      GROUP BY DATE_TRUNC('month', date)
      ORDER BY month DESC
      LIMIT 6
    `;
    
    const [
      employeeResult,
      statsResult,
      chartDataResult,
      patternResult,
      weeklyResult,
      recentResult,
      monthlyResult
    ] = await Promise.all([
      pool.query(employeeQuery, [userId]),
      pool.query(statsQuery, [userId]),
      pool.query(chartDataQuery, [userId, thirtyDaysAgo.toISOString().split('T')[0]]),
      pool.query(patternQuery, [userId]),
      pool.query(weeklyQuery, [userId, sevenDaysAgo.toISOString().split('T')[0]]),
      pool.query(recentQuery, [userId]),
      pool.query(monthlyQuery, [userId])
    ]);
    
    // Process chart data for frontend
    const processedChartData = chartDataResult.rows.map(row => ({
      date: new Date(row.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      hours: parseFloat(row.work_hours) || 0,
      checkIn: row.check_in_time ? new Date(row.check_in_time).toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false 
      }) : null,
      dayOfWeek: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][row.day_of_week]
    }));
    
    // Process attendance pattern for pie chart
    const processedPattern = patternResult.rows.map(row => ({
      name: row.arrival_pattern,
      value: parseInt(row.count),
      percentage: 0 // Will be calculated in frontend
    }));
    
    const totalPatternCount = processedPattern.reduce((sum, item) => sum + item.value, 0);
    processedPattern.forEach(item => {
      item.percentage = ((item.value / totalPatternCount) * 100).toFixed(1);
    });
    
    const responseData = {
      employee: employeeResult.rows[0],
      stats: statsResult.rows[0],
      chartData: processedChartData,
      attendancePattern: processedPattern,
      weeklyData: weeklyResult.rows,
      recentAttendance: recentResult.rows,
      monthlyData: monthlyResult.rows,
      performance: {
        consistency: calculateConsistencyScore(chartDataResult.rows),
        punctuality: calculatePunctualityScore(patternResult.rows),
        productivity: calculateProductivityScore(statsResult.rows[0])
      }
    };
    
    console.log(`Generated analytics for employee ${userId}`);
    res.json(responseData);
    
  } catch (error) {
    console.error('Error fetching employee analytics:', error);
    res.status(500).json({ error: 'Failed to fetch employee analytics' });
  }
});


// Search employees by name
app.get('/api/reports/employees/search', async (req, res) => {
  try {
    const { name } = req.query;
    
    if (!name || name.trim().length < 2) {
      return res.status(400).json({ error: 'Search term must be at least 2 characters' });
    }
    
    const query = `
      SELECT DISTINCT
        u.id,
        u.name,
        u.full_name,
        u.id as employee_id,
        u.email,
        u.team_lead,
        u.manager,
        u.department,
        u.position,
        COUNT(a.id) as total_attendance_records
      FROM ems_test.test u
      LEFT JOIN ems_test.attendance a ON u.id = a.user_id
      WHERE u.status = 'ACTIVE' 
        AND (LOWER(u.name) LIKE LOWER($1) OR LOWER(u.full_name) LIKE LOWER($1))
      GROUP BY u.id, u.name, u.full_name, u.email, u.team_lead, 
               u.manager, u.department, u.position
      ORDER BY u.name ASC
      LIMIT 20
    `;
    
    const searchTerm = `%${name.trim()}%`;
    const result = await pool.query(query, [searchTerm]);
    
    console.log(`Found ${result.rows.length} employees matching "${name}"`);
    res.json(result.rows);
  } catch (error) {
    console.error('Error searching employees by name:', error);
    res.status(500).json({ error: 'Failed to search employees' });
  }
});

// Helper functions for performance calculations
function calculateConsistencyScore(attendanceData) {
  if (attendanceData.length === 0) return 0;
  
  const workHours = attendanceData.map(row => parseFloat(row.work_hours) || 0);
  const avgHours = workHours.reduce((sum, hours) => sum + hours, 0) / workHours.length;
  const variance = workHours.reduce((sum, hours) => sum + Math.pow(hours - avgHours, 2), 0) / workHours.length;
  const standardDeviation = Math.sqrt(variance);
  
  // Lower standard deviation = higher consistency (scale 0-100)
  const consistencyScore = Math.max(0, 100 - (standardDeviation * 20));
  return Math.round(consistencyScore);
}

function calculatePunctualityScore(patternData) {
  const totalDays = patternData.reduce((sum, row) => sum + parseInt(row.count), 0);
  if (totalDays === 0) return 0;
  
  const onTimeCount = patternData.find(row => row.arrival_pattern === 'On Time')?.count || 0;
  return Math.round((onTimeCount / totalDays) * 100);
}

function calculateProductivityScore(stats) {
  if (!stats || !stats.total_days) return 0;
  
  const avgHours = parseFloat(stats.avg_hours) || 0;
  const attendanceRate = (stats.total_days / 30) * 100; // Assuming 30 working days per month
  const hoursScore = (avgHours / 8) * 100; // Assuming 8 hours is ideal
  
  return Math.round((attendanceRate * 0.4) + (hoursScore * 0.6));
}




// ===================== Work anniverary mail and Announcements =========================== 

// Email transporter config (Use your SMTP credentials)
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'ai4mahila.info@gmail.com',     // ✅ Use your Gmail
    pass: 'uiwj mnuc gidi warv',        // ✅ Use an App Password (not regular password)
  },
});

// Scheduler: Runs daily at 9 AM
cron.schedule('48 01 * * *', async () => {
  // cron.schdule('minuties hours * * *', async () =>
  try {
    const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

    const result = await pool.query(`
      SELECT name, email, date_of_joining, position, department, avatar
      FROM ems_test.test
      WHERE DATE_PART('year', AGE(current_date, date_of_joining)) >= 1 
        AND TO_CHAR(date_of_joining, 'MM-DD') = TO_CHAR(current_date, 'MM-DD')
    `);


    for (const employee of result.rows) {
      const mailOptions = {
  from: '"HR Team" <your-email@gmail.com>',
  to: employee.email,
  subject: `🎉 Congratulations ${employee.name} on Your Work Anniversary!`,
  html: `
  <div style="
    background: url('https://i.pinimg.com/736x/90/ca/d0/90cad025ef0e470b264ea8204919f093.jpg') no-repeat center center;
    background-size: cover;
    width: 600px;
    height: 300px;
    margin: auto;
    border-radius: 10px;
    font-family: 'Segoe UI', sans-serif;
    color: #ffffff;
    position: relative;
    overflow: hidden;
  ">
    <table width="100%" height="100%" cellpadding="0" cellspacing="0" style="width: 100%; height: 100%;">
      <tr>
        <td style="padding: 30px;">
          <table width="100%" cellpadding="0" cellspacing="0" style="width: 100%;">
            <tr>
              <td style="vertical-align: middle;">
                <h2 style="margin: 0 0 10px 0; font-size: 24px;">Happy Work Anniversary</h2>
                <h3 style="margin: 0 0 10px 0;">${employee.name}</h3>
                <p style="margin: 0 0 10px 0; font-size: 14px;">
                  ${employee.position || 'Team Member'} ${employee.department ? `| ${employee.department}` : ''}
                </p>
                <p style="font-size: 13px; line-height: 1.5; max-width: 320px;">
                  We truly appreciate your hard work and dedication.<br>
                  Thank you for being an important part of our journey!
                </p>
                <p style="margin-top: 15px; font-size: 12px;">— HR Team</p>
              </td>
              <td style="width: 120px; text-align: center;">
                <img src="${employee.avatar || 'https://yourdomain.com/images/default-avatar.png'}" 
                     alt="${employee.name}" 
                     style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 3px solid #fff;" />
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </div>
  `
};



      await transporter.sendMail(mailOptions);
      console.log(`✅ Anniversary email sent to ${employee.email}`);
    }
  } catch (err) {
    console.error('❌ Error sending anniversary emails:', err.message);
  }
});

// Get today's anniversary users
app.get('/api/anniversary-notifications', async (req, res) => {
  try {
    const today = new Date();
    const todayStr = today.toISOString().slice(5, 10); // 'MM-DD'

    const result = await pool.query(`
      SELECT name, email, date_of_joining
      FROM ems_test.test
      WHERE TO_CHAR(date_of_joining, 'MM-DD') = $1
    `, [todayStr]);

    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching anniversaries:', err);
    res.status(500).json({ error: 'Server error fetching anniversaries' });
  }
});

// birthday mails
cron.schedule('45 14 * * *', async () => {
  console.log('🎂 Running daily birthday email job...');

  try {
    const today = new Date();
    const month = today.getMonth() + 1;
    const day = today.getDate();

    const result = await pool.query(`
      SELECT id, name, email, position, department, avatar, date_of_birth
      FROM ems_test.test
      WHERE EXTRACT(MONTH FROM date_of_birth) = $1
        AND EXTRACT(DAY FROM date_of_birth) = $2
    `, [month, day]);

    const birthdayUsers = result.rows;

    for (const employee of birthdayUsers) {
      const mailOptions = {
        from: '"HR Team" <ai4bazaarquotation@gmail.com>',
        to: employee.email,
        subject: `🎉 Happy Birthday ${employee.name}!`,
        html: `
        <div style="
          background: url('https://corp-backend.brevo.com/wp-content/uploads/2024/07/birthday_email_twitter-min.png') no-repeat center center;
          background-size: cover;
          width: 600px;
          height: 300px;
          margin: auto;
          border-radius: 10px;
          font-family: 'Segoe UI', sans-serif;
          color: #ffffff;
          position: relative;
          overflow: hidden;
        ">
          <table width="100%" height="100%" cellpadding="0" cellspacing="0" style="width: 100%; height: 100%;">
            <tr>
              <td style="padding: 30px;">
                <table width="100%" cellpadding="0" cellspacing="0" style="width: 100%;">
                  <tr>
                    <td style="vertical-align: middle;">
                      <h2 style="margin: 0 0 10px 0; font-size: 24px;">🎉 Happy Birthday</h2>
                      <h3 style="margin: 0 0 10px 0;">${employee.name}</h3>
                      <p style="margin: 0 0 10px 0; font-size: 14px;">
                        ${employee.position || 'Team Member'} ${employee.department ? `| ${employee.department}` : ''}
                      </p>
                      <p style="font-size: 13px; line-height: 1.5; max-width: 320px;">
                        May your day be filled with joy, success, and celebration.<br>
                        Thank you for being part of our team!
                      </p>
                      <p style="margin-top: 15px; font-size: 12px;">— HR Team</p>
                    </td>
                    <td style="width: 120px; text-align: center;">
                      <img src="${employee.avatar || 'https://yourdomain.com/images/default-avatar.png'}" 
                           alt="${employee.name}" 
                           style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 3px solid #fff;" />
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </div>
        `
      };

      await transporter.sendMail(mailOptions);
      console.log(`✅ Birthday email sent to ${employee.email}`);
    }

  } catch (error) {
    console.error('❌ Error sending birthday emails:', error);
  }
});






// ================================ Daily work summary email to managers (runs at 6 PM) ============================
cron.schedule('07 05 * * *', async () => {
  try {
    const managers = await pool.query(
      `SELECT id, name, email FROM ems_test.test WHERE role = 'Manager'`
    );

    for (const manager of managers.rows) {
      const teamUpdates = await pool.query(
        `SELECT 
          u.name AS employee_name,
          u.id AS employee_id,
          a.check_in_time,
          a.check_out_time,
          a.work_update,
          a.work_hours
        FROM ems_test.test u
        LEFT JOIN ems_test.attendance a 
          ON u.id = a.user_id AND a.date = CURRENT_DATE
        WHERE u.manager = $1 OR u.team_lead = $1`,
        [manager.name]
      );

      if (teamUpdates.rows.length === 0) continue;

      let htmlTable = `
        <table style="
    border-collapse: collapse; 
    width: 100%; 
    font-family: Arial, sans-serif; 
    font-size: 14px; 
    color: #333;
  ">
    <thead>
      <tr style="background-color: #007BFF; color: white;">
        <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Employee</th>
        <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Check-In</th>
        <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Check-Out</th>
        <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Work Hours</th>
        <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Work Update</th>
      </tr>
    </thead>
    <tbody>
`;

teamUpdates.rows.forEach(member => {
  htmlTable += `
    <tr style="background-color: #f9f9f9;">
      <td style="padding: 8px; border: 1px solid #ddd;">${member.employee_name}</td>
      <td style="padding: 8px; border: 1px solid #ddd;">${member.check_in_time ? new Date(member.check_in_time).toLocaleTimeString() : 'N/A'}</td>
      <td style="padding: 8px; border: 1px solid #ddd;">${member.check_out_time ? new Date(member.check_out_time).toLocaleTimeString() : 'N/A'}</td>
      <td style="padding: 8px; border: 1px solid #ddd;">${member.work_hours || 'N/A'}</td>
      <td style="padding: 8px; border: 1px solid #ddd;">${member.work_update || 'No update'}</td>
    </tr>
  `;
});

htmlTable += `</tbody></table>`;


      // ✅ mailOptions should be declared inside the same loop
      const mailOptions = {
        from: '"Work Updates" <ai4mahila.info@gmail.com>',
        to: manager.email,
        subject: `Daily Team Update - ${new Date().toDateString()}`,
        html: `
          <div style="font-family: Arial, sans-serif;">
            <h2>Team Work Summary</h2>
            <p>Hello ${manager.name},</p>
            <p>Here's your team's activity for today:</p>
            ${htmlTable}
            <p><br>Best regards,<br>HR System</p>
          </div>
        `
      };

      // ✅ Send the email using configured transporter
      await transporter.sendMail(mailOptions);
      console.log(`✅ Sent daily update to ${manager.email}`);
    }
  } catch (err) {
    console.error('❌ Error sending team updates:', err);
  }
});


// ====================================== tasks ===========================

app.post("/api/tasks", async (req, res) => {
  const {
    title,
    description,
    assignedTo,
    assignedBy,
    priority,
    dueDate,
  } = req.body;

  try {
    const result = await pool.query(
      `INSERT INTO ems_test.tasks 
        (id_uuid, title, description, assigned_to, assigned_by, priority, duedate, created_at, progress, comments, updated_stamp)
       VALUES (
         gen_random_uuid(), $1, $2, $3, $4, $5, $6, NOW(), 0, ARRAY[]::TEXT[], NOW()
       )
       RETURNING *`,
      [title, description, assignedTo, assignedBy, priority, dueDate]
    );
    res.status(201).json({ task: result.rows[0] });
  } catch (err) {
    console.error("Error creating task:", err);
    res.status(500).json({ error: "Error creating task" });
  }
});


// 2. Get all tasks
app.get("/api/tasks", async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM ems_test.tasks ORDER BY created_at DESC");
    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching tasks:", err);
    res.status(500).json({ error: "Error fetching tasks" });
  }
});


// 4. Update task progress
app.put("/api/tasks/:id/progress", async (req, res) => {
  const { id } = req.params;
  const { progress } = req.body;
  try {
    const result = await pool.query(
      `UPDATE ems_test.tasks SET progress = $1, updated_stamp = NOW() WHERE id_uuid = $2 RETURNING *`,
      [progress, id]
    );
    res.json({ task: result.rows[0] });
  } catch (err) {
    console.error("Error updating progress:", err);
    res.status(500).json({ error: "Error updating progress" });
  }
});

// 5. Add a comment (store only latest content in `comments` column)
app.post("/api/tasks/:id/comments", async (req, res) => {
  const { id } = req.params;
  const { content, userId } = req.body;

  if (!content || !userId) {
    return res.status(400).json({ error: "Content and userId are required" });
  }

  try {
    const result = await pool.query(
      `UPDATE ems_test.tasks 
       SET comments = array_append(comments, $1), updated_stamp = NOW() 
       WHERE id_uuid = $2 
       RETURNING id_uuid, title, description, assigned_to, assigned_by, priority, duedate, created_at, progress, comments, updated_stamp`,
      [`${userId}: ${content}`, id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Task not found" });
    }

    res.status(201).json({ message: "Comment added", task: result.rows[0] });
  } catch (err) {
    console.error("Error saving comment:", err);
    res.status(500).json({ error: "Error saving comment" });
  }
});

// Reassign a task
app.put("/api/tasks/:id/reassign", async (req, res) => {
  const { id } = req.params;
  const { newAssigneeId, reason } = req.body;
  const { userId, role } = req.query;

  try {
    // Validate userId and role
    if (!userId || !role) {
      return res.status(401).json({ error: "User ID and role are required" });
    }

    // Check if user has permission to reassign (Admin, Manager, HR)
    const allowedRoles = ["Admin", "Manager", "HR","Team Lead"];
    if (!allowedRoles.includes(role)) {
      return res.status(403).json({ error: "You do not have permission to reassign tasks" });
    }

    // Validate current user exists
    const userCheck = await pool.query("SELECT id FROM ems_test.test WHERE id = $1", [userId]);
    if (userCheck.rowCount === 0) {
      return res.status(400).json({ error: "Invalid user ID" });
    }

    // Validate new assignee exists
    const assigneeCheck = await pool.query("SELECT id FROM ems_test.test WHERE id = $1", [newAssigneeId]);
    if (assigneeCheck.rowCount === 0) {
      return res.status(400).json({ error: "Invalid assignee ID" });
    }

    // Fetch current task to get assigned_by and original_assigned_by
    const taskCheck = await pool.query(
      "SELECT assigned_by, original_assigned_by FROM ems_test.tasks WHERE id_uuid = $1",
      [id]
    );
    if (taskCheck.rowCount === 0) {
      return res.status(404).json({ error: "Task not found" });
    }

    const task = taskCheck.rows[0];
    const originalAssignedBy = task.original_assigned_by || task.assigned_by;

    // Update task with new assignee, reason, and updated timestamp
    const result = await pool.query(
      `UPDATE ems_test.tasks 
       SET assigned_to = $1, 
           reassign_reason = $2, 
           original_assigned_by = $3, 
           updated_stamp = NOW() 
       WHERE id_uuid = $4 
       RETURNING *`,
      [newAssigneeId, reason || null, originalAssignedBy, id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Task not found" });
    }

    res.json({ task: result.rows[0], message: "Task reassigned successfully" });
  } catch (err) {
    console.error("Error reassigning task:", err);
    res.status(500).json({ error: "Error reassigning task" });
  }
});

// Fetch all users for the dropdown
app.get("/api/user", async (req, res) => {
  try {
    const result = await pool.query("SELECT id, name, role FROM ems_test.test ORDER BY name");
    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching users:", err);
    res.status(500).json({ error: "Error fetching users" });
  }
});

//Upload Documents
app.post('/api/upload-documents', upload.fields([
  { name: 'aadhar', maxCount: 1 },
  { name: 'panCard', maxCount: 1 },
  { name: 'passport', maxCount: 1 },
  { name: 'drivingLicense', maxCount: 1 },
  { name: 'otherDocuments', maxCount: 10 } // Allow up to 10 other documents
]), async (req, res) => {
  const { employeeId } = req.body;
  const files = req.files;

  if (!employeeId) {
    return res.status(400).json({ error: 'Employee ID is required' });
  }

  // Validate employee exists
  try {
    const employeeCheck = await pool.query('SELECT id, role FROM ems_test.test WHERE id = $1', [employeeId]);
    if (employeeCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    // Check if the requesting user is Admin or HR (assuming user info is passed via headers or middleware)
    // Note: Since AuthContext is used in frontend, assume user role is sent in headers
    const userRole = req.headers['x-user-role']; // Adjust based on how you pass user data
    if (!['Admin', 'HR'].includes(userRole)) {
      return res.status(403).json({ error: 'Only Admin or HR can upload documents' });
    }

    const documentUrls = {
      aadhar: null,
      panCard: null,
      passport: null,
      drivingLicense: null,
      otherDocuments: [],
    };

    // Helper function to upload a file to S3
    const uploadToS3 = async (file, docType) => {
      if (!file.mimetype.match(/(pdf|jpg|jpeg|png|doc|docx)$/)) {
        throw new Error(`Invalid file type for ${docType}`);
      }
      const extension = file.originalname.split('.').pop();
      const fileKey = `employee-documents/${employeeId}/${docType}-${Date.now()}.${extension}`;
      await s3Client.send(new PutObjectCommand({
        Bucket: S3_BUCKET,
        Key: fileKey,
        Body: file.buffer,
        ContentType: file.mimetype,
      }));
      return `https://${S3_BUCKET}.s3.ap-south-2.amazonaws.com/${fileKey}`;
    };

    // Upload each document if provided
    for (const field in files) {
      if (field === 'otherDocuments') {
        for (const file of files[field]) {
          const url = await uploadToS3(file, `other-${files[field].indexOf(file)}`);
          documentUrls.otherDocuments.push(url);
        }
      } else {
        const file = files[field][0];
        documentUrls[field] = await uploadToS3(file, field);
      }
    }

    // Update employee record with document URLs
    const result = await pool.query(
      `UPDATE ems_test.test 
       SET 
         aadhar_document = COALESCE($1, aadhar_document),
         pancard_document = COALESCE($2, pancard_document),
         passport_document = COALESCE($3, passport_document),
         driving_license_document = COALESCE($4, driving_license_document),
         other_documents = array_cat(other_documents, $5::text[])
       WHERE id = $6
       RETURNING id, name, aadhar_document, pancard_document, passport_document, driving_license_document, other_documents`,
      [
        documentUrls.aadhar,
        documentUrls.panCard,
        documentUrls.passport,
        documentUrls.drivingLicense,
        documentUrls.otherDocuments,
        employeeId
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    res.status(200).json({ message: 'Documents uploaded successfully', employee: result.rows[0] });
  } catch (err) {
    console.error('Document upload error:', err);
    res.status(500).json({ error: `Failed to upload documents: ${err.message}` });
  }
});

app.get('/api/all-documents', async (req, res) => {
  const userRole = req.headers['x-user-role'];

  try {
    // Validate user role
    if (!userRole || !['Admin', 'HR'].includes(userRole)) {
      return res.status(403).json({ error: 'Only Admin or HR can view documents' });
    }

    // Fetch all employees and their documents
    const result = await pool.query(
      `SELECT id, name, aadhar_document, pancard_document, passport_document, driving_license_document, other_documents
       FROM ems_test.test`
    );

    const employees = result.rows.map(employee => ({
      id: employee.id,
      name: employee.name,
      documents: {
        aadhar: employee.aadhar_document || null,
        panCard: employee.pancard_document || null,
        passport: employee.passport_document || null,
        drivingLicense: employee.driving_license_document || null,
        otherDocuments: employee.other_documents || [],
      },
    }));

    res.status(200).json({ employees });
  } catch (err) {
    console.error('Fetch all documents error:', err);
    res.status(500).json({ error: 'Failed to fetch documents' });
  }
});

// Start server
app.listen(5033, () => {
  console.log('✅ Server running on http://localhost:5033');
});