// import { useLocation } from 'react-router-dom';
// import { useAuth } from '../contexts/AuthContext';
// import { Button } from '../components/ui/button';
// import { LogOut, Menu, User } from 'lucide-react';
// import {
//   DropdownMenu,
//   DropdownMenuContent,
//   DropdownMenuItem,
//   DropdownMenuLabel,
//   DropdownMenuSeparator,
//   DropdownMenuTrigger,
// } from "../components/ui/dropdown-menu";
// import { cn } from '../lib/utils';

// /**
//  * Navbar component for the application header
//  * @param {Object} props
//  * @param {boolean} props.collapsed - Whether the sidebar is collapsed
//  * @param {Function} props.setCollapsed - Function to toggle sidebar collapse state
//  * @param {boolean} props.isMobileSidebarOpen - Whether the mobile sidebar is open
//  * @param {Function} props.setIsMobileSidebarOpen - Function to toggle mobile sidebar state
//  * @returns {JSX.Element}
//  */
// const Navbar = ({ collapsed, setCollapsed, isMobileSidebarOpen, setIsMobileSidebarOpen }) => {
//   const { user, logout } = useAuth();
//   const location = useLocation();

//   const getPageTitle = () => {
//     const path = location.pathname;
//     if (path === '/dashboard') return 'Dashboard';
//     if (path === '/employees') return 'Employees';
//     if (path === '/add-user') return 'Add User';
//     if (path === '/leaves') return 'Leave Requests';
//     if (path === '/reports') return 'Reports';
//     if (path === '/settings') return 'Settings';
//     if (path === '/tasks') return 'Tasks';
//     if (path === '/checkin-checkout') return 'Check In / Check Out';
//     if (path === '/Update-user') return 'Update Users';
//     if (path === '/unauthorized') return 'Unauthorized';
//     return '';
//   };

//   const handleHamburgerClick = () => {
//     setIsMobileSidebarOpen(!isMobileSidebarOpen);
//     // Toggle collapsed state only for desktop
//     if (window.innerWidth >= 768) {
//       setCollapsed(!collapsed);
//     }
//   };

//   return (
//     <div className={cn(
//       "fixed top-0 right-0 z-30 bg-white shadow-sm border-b",
//       collapsed ? "left-[70px]" : "left-[240px]",
//       isMobileSidebarOpen ? "left-0" : "left-0",
//       "transition-all duration-300",
//       collapsed ? "md:left-[70px]" : "md:left-[240px]"
//     )}>
//       <div className="h-16 px-4 flex items-center justify-between">
//         <div className="flex items-center">
//           <Button 
//             variant="ghost" 
//             size="icon" 
//             onClick={handleHamburgerClick}
//             className="mr-2 text-gray-600 md:hidden"
//           >
//             <Menu size={20} />
//           </Button>
//           <h2 className="text-xl font-semibold text-gray-800">
//             {getPageTitle()}
//           </h2>
//         </div>

//         <div className="flex items-center space-x-2">
//           {user && (
//             <DropdownMenu>
//               <DropdownMenuTrigger asChild>
//                 <Button 
//                   variant="ghost" 
//                   size="sm"
//                   className="flex items-center gap-2 hover:bg-gray-100"
//                 >
//                   {user.avatar ? (
//                     <img 
//                       src={user.avatar} 
//                       alt={user.name} 
//                       className="w-8 h-8 rounded-full object-cover"
//                     />
//                   ) : (
//                     <User size={18} className="text-gray-600" />
//                   )}
//                   <span className="hidden md:inline text-sm font-medium">
//                     {user.name}
//                   </span>
//                   <span className="text-xs px-2 py-1 rounded-full text-white bg-[hsl(var(--secondary))]">
//                     {user.role}
//                   </span>
//                 </Button>
//               </DropdownMenuTrigger>
//               <DropdownMenuContent align="end" className="bg-white shadow-md rounded-md p-2 min-w-[150px] z-50">
//                 <DropdownMenuLabel>My Account</DropdownMenuLabel>
//                 <DropdownMenuSeparator />
//                 <DropdownMenuItem onClick={() => {}} className="hover:bg-gray-100">Profile</DropdownMenuItem>
//                 <DropdownMenuItem onClick={logout} className="hover:bg-gray-100">
//                   <LogOut size={16} className="mr-2" />
//                   Logout
//                 </DropdownMenuItem>
//               </DropdownMenuContent>
//             </DropdownMenu>
//           )}

//           <Button 
//             onClick={logout} 
//             variant="ghost"
//             size="sm"
//             className="hidden md:flex hover:bg-gray-100"
//           >
//             <LogOut size={18} className="mr-2" />
//             Logout
//           </Button>
//         </div>
//       </div>
//       {isMobileSidebarOpen && (
//         <div 
//           className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden" 
//           onClick={() => setIsMobileSidebarOpen(false)}
//         />
//       )}
//     </div>
//   );
// };

// export default Navbar;
// Navbar.jsx
import { useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/button';
import { LogOut, Menu, User } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../components/ui/dropdown-menu";
import { cn } from '../lib/utils';

const Navbar = ({ collapsed, setCollapsed, isMobileSidebarOpen, setIsMobileSidebarOpen }) => {
  const { user, logout } = useAuth();
  const location = useLocation();

  const getPageTitle = () => {
    const path = location.pathname;
    if (path === '/dashboard') return 'Dashboard';
    if (path === '/employees') return 'Employees';
    if (path === '/add-user') return 'Add User';
    if (path === '/leaves') return 'Leave Requests';
    if (path === '/reports') return 'Reports';
    if (path === '/settings') return 'Settings';
    if (path === '/tasks') return 'Tasks';
    if (path === '/checkin-checkout') return 'Check In / Check Out';
    if (path === '/Update-user') return 'Update Users';
    if (path === '/unauthorized') return 'Unauthorized';
    return '';
  };

  const handleHamburgerClick = () => {
    setIsMobileSidebarOpen(!isMobileSidebarOpen);
    if (window.innerWidth >= 768) {
      setCollapsed(!collapsed);
    }
  };

  return (
    <div className={cn(
      "fixed top-0 right-0 z-30 bg-white shadow-sm border-b",
      collapsed ? "left-[70px]" : "left-[240px]",
      isMobileSidebarOpen ? "left-0" : "left-0",
      "transition-all duration-300",
      collapsed ? "md:left-[70px]" : "md:left-[240px]"
    )}>
      <div className="h-16 px-4 flex items-center justify-between">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={handleHamburgerClick}
            className="mr-2 text-gray-600 md:hidden"
          >
            <Menu size={20} />
          </Button>
          <h2 className="text-xl font-semibold text-gray-800">
            {getPageTitle()}
          </h2>
        </div>

        <div className="flex items-center space-x-2">
          {user && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="flex items-center gap-2 hover:bg-gray-100"
                >
                  {user.avatar ? (
                    <img 
                      src={user.avatar} 
                      alt={user.name} 
                      className="w-8 h-8 rounded-full object-cover"
                    />
                  ) : (
                    <User size={18} className="text-gray-600" />
                  )}
                  <span className="hidden md:inline text-sm font-medium">
                    {user.name}
                  </span>
                  <span className="text-xs px-2 py-1 rounded-full text-white bg-[hsl(var(--secondary))]">
                    {user.role}
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-white shadow-md rounded-md p-2 min-w-[150px] z-50">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => {}} className="hover:bg-gray-100">Profile</DropdownMenuItem>
                <DropdownMenuItem onClick={logout} className="hover:bg-gray-100">
                  <LogOut size={16} className="mr-2" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}

          <Button 
            onClick={logout} 
            variant="ghost"
            size="sm"
            className="hidden md:flex hover:bg-gray-100"
          >
            <LogOut size={18} className="mr-2" />
            Logout
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
