
import { useEffect, useState } from "react";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { useTask } from "../../contexts/TaskContext";
import { useUser } from "../../contexts/UserContext";
import { useAuth } from "../../contexts/AuthContext";
import { format, isValid } from "date-fns";
import { Textarea } from "../ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import { Slider } from "../ui/slider";
import { UserCheck } from "lucide-react";
import TaskReassign from "./TaskReassign";
import { toast } from "sonner";

export default function TaskDetail({ task: initialTask, onClose, onUpdate }) {
  const { updateTaskProgress, addTaskComment, getTaskById } = useTask();
  const { getUserById } = useUser();
  const { user } = useAuth();

  const [task, setTask] = useState(initialTask);
  const [progress, setProgress] = useState(task.progress || 0);
  const [comment, setComment] = useState("");
  const [showReassignDialog, setShowReassignDialog] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  const syncTask = () => {
    const updatedTask = getTaskById(initialTask.id);
    if (updatedTask) {
      setTask(updatedTask);
      setProgress(updatedTask.progress || 0);
    }
  };

  useEffect(() => {
    syncTask();
  }, [initialTask.id, getTaskById]);

  const assignedUser = getUserById(task.assigned_to);
  const assignedByUser = getUserById(task.assigned_by);
  const originalAssignedByUser = task.original_assigned_by
    ? getUserById(task.original_assigned_by)
    : null;

  const safeFormatDate = (dateString, dateFormat) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    if (!isValid(date)) return "N/A";
    return format(date, dateFormat);
  };

  const formattedDueDate = safeFormatDate(task.due_date, "MMM d, yyyy");
  const formattedCreatedDate = safeFormatDate(task.created_at, "MMM d, yyyy");

  const isDelayed =
    isValid(new Date(task.due_date)) &&
    new Date(task.due_date) < new Date() &&
    task.status !== "Completed";

  const priorityColor = {
    High: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
    Medium: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
    Low: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  };

  const status = task.status || "Not Started";

  const canReassignTask = () => {
    if (!user) return false;
    const allowedRoles = ["Admin", "Manager", "HR","Team Lead"];
    return allowedRoles.includes(user.role);
  };

  const canUpdateTask = () => {
    if (!user) return false;
    if (user.role === "Admin" || user.role === "Manager") return true;
    if (task.assigned_to === user.id) return true;
    return false;
  };

  const handleProgressChange = (newProgress) => {
    if (!canUpdateTask()) {
      toast.error("You do not have permission to update progress");
      return;
    }
    const value = Math.max(0, Math.min(100, newProgress[0]));
    setProgress(value);
    setHasChanges(true);
  };

  const handleCommentSubmit = async () => {
    if (!comment.trim()) {
      toast.error("Comment cannot be empty");
      return;
    }
    try {
      setIsSubmitting(true);
      await addTaskComment(task.id, comment);
      setTask((prev) => ({
        ...prev,
        comments: [...(prev.comments || []), comment],
      }));
      toast.success("Comment added");
      setComment("");
    } catch (err) {
      toast.error("Failed to add comment");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateAllChanges = async () => {
    if (!hasChanges) {
      onClose();
      return;
    }
    setIsSubmitting(true);
    try {
      if (progress !== task.progress) {
        await updateTaskProgress(task.id, progress);
      }
      syncTask();
      setHasChanges(false);
      toast.success("Changes updated successfully");
      onUpdate?.();
      onClose();
    } catch (error) {
      toast.error(`Failed to update changes: ${error.message || 'Unknown error'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-white dark:bg-gray-900 shadow-lg rounded-lg p-6 h-[calc(100vh-4rem)] max-h-[800px] overflow-y-auto">
      <div className="md:col-span-2 space-y-6 h-full flex flex-col">
        <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
          <div className="space-y-2">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
              {task.title || "Untitled"}
            </h3>
            {task.reassigned_from && (
              <p className="text-sm text-blue-600 dark:text-blue-400">
                ↳ Reassigned from{" "}
                {getUserById(task.reassigned_from)?.name || "Unknown"}
              </p>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Badge
              variant="outline"
              className={
                priorityColor[task.priority] ||
                "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
              }
            >
              {task.priority || "N/A"}
            </Badge>
            {canReassignTask() && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowReassignDialog(true)}
                className="flex items-center gap-1 border-gray-300 dark:border-gray-600"
              >
                <UserCheck className="w-4 h-4" />
                Reassign
              </Button>
            )}
          </div>
        </div>
        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700 flex-1 max-h-[200px] overflow-y-auto">
          <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-2">
            Description
          </h4>
          <p className="text-gray-700 dark:text-gray-300 whitespace-pre-line">
            {task.description || (
              <span className="text-gray-400 italic">No description provided</span>
            )}
          </p>
        </div>
        <div>
          <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-2">
            Progress: {progress}%
          </h4>
          <Slider
            value={[progress]}
            onValueChange={handleProgressChange}
            max={100}
            min={0}
            step={1}
            className="w-full"
            disabled={!canUpdateTask()}
          />
        </div>
        <div className="space-y-3">
          <h4 className="font-medium text-gray-700 dark:text-gray-300">Comments</h4>
          {(!Array.isArray(task.comments) || task.comments.length === 0) ? (
            <p className="text-gray-500 italic text-sm">No comments yet</p>
          ) : (
            task.comments.map((comment, index) => (
              <div
                key={index}
                className="bg-white dark:bg-gray-700 p-3 rounded-md border border-gray-200 dark:border-gray-600"
              >
                <p className="text-sm text-gray-700 dark:text-gray-300">{comment}</p>
              </div>
            ))
          )}
          <div className="mt-3 flex flex-col sm:flex-row gap-2">
            <Textarea
              placeholder="Add a comment..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={2}
              className="flex-1 bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-gray-100"
              disabled={isSubmitting}
            />
            <Button
              onClick={handleCommentSubmit}
              disabled={isSubmitting || !comment.trim()}
              className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800 text-white"
            >
              Add Comment
            </Button>
          </div>
        </div>
        <div className="mt-4">
          <Button
            onClick={handleUpdateAllChanges}
            disabled={isSubmitting}
            className="w-full bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-800 text-white"
          >
            {isSubmitting ? "Updating..." : "Update Changes"}
          </Button>
        </div>
      </div>
      <div className="space-y-4 h-full overflow-y-auto">
        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-3">
            Due Date
          </h4>
          <p
            className={`font-semibold ${
              isDelayed
                ? "text-red-600 dark:text-red-400"
                : "text-gray-700 dark:text-gray-300"
            }`}
          >
            {formattedDueDate}
          </p>
        </div>
        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-3">
            Created At
          </h4>
          <p className="text-gray-700 dark:text-gray-300">{formattedCreatedDate}</p>
        </div>
        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-3">
            Assigned To
          </h4>
          <p className="text-gray-700 dark:text-gray-300">
            {assignedUser?.name || "Unassigned"}
          </p>
        </div>
        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-3">
            Assigned By
          </h4>
          <p className="text-gray-700 dark:text-gray-300">
            {assignedByUser?.name || "Unknown"}
          </p>
        </div>
        {originalAssignedByUser && (
          <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
            <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-3">
              Original Assigned By
            </h4>
            <p className="text-gray-700 dark:text-gray-300">
              {originalAssignedByUser?.name || "Unknown"}
            </p>
          </div>
        )}
      </div>
      {showReassignDialog && (
        <TaskReassign
          task={task}
          isOpen={showReassignDialog}
          onClose={() => setShowReassignDialog(false)}
          onSuccess={() => {
            setShowReassignDialog(false);
            toast.success("Task reassigned successfully");
            onUpdate?.();
          }}
        />
      )}
    </div>
  );
}