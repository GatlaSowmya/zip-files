import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Progress } from "../ui/progress";
import { Slider } from "../ui/slider";
import { useState } from "react";
import { useTask } from "../../context/TaskContext";
import { useUser } from "../../context/UserContext";
import { useAuth } from "../../context/AuthContext";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import { toast } from "sonner";
import TaskDetail from "./TaskDetail";

export default function TaskCard({ task }) {
  const { updateTaskProgress } = useTask();
  const { getUserById } = useUser();
  const { user } = useAuth();
  const [showDetail, setShowDetail] = useState(false);
  const [progress, setProgress] = useState(task.progress || 0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const assignedUser = getUserById(task.assignedTo || task.assigned_to);

  // Safe date parsing
  let formattedDueDate = 'N/A';
  let isDelayed = false;

  try {
    const rawDueDate = task.dueDate || task.due_date;
    if (rawDueDate) {
      const date = new Date(rawDueDate);
      if (!isNaN(date.getTime())) {
        formattedDueDate = format(date, 'MMM d, yyyy');
        isDelayed = date < new Date() && task.progress !== 100;
      } else {
        console.warn('Invalid task.dueDate:', rawDueDate, task);
      }
    }
  } catch (err) {
    console.error('Error formatting dueDate:', err, task);
  }

  const priorityColor = {
    'High': 'bg-priority-high',
    'Medium': 'bg-priority-medium',
    'Low': 'bg-priority-low',
  };

  const getDerivedStatus = () => {
    if (progress === 0) return "Not Started";
    if (progress === 100) return "Completed";
    return "In Progress";
  };

  const statusColor = {
    'Not Started': 'bg-gray-500',
    'In Progress': 'bg-blue-500',
    'Completed': 'bg-green-500',
  };

  const canUpdateTask = () => {
    if (!user) return false;
    if (user.role === "Admin" || user.role === "Manager") return true;
    if (task.assigned_to === user.id) return true;
    return false;
  };

  const handleProgressChange = (newProgress) => {
    if (!canUpdateTask()) {
      toast.error("You do not have permission to update progress");
      return;
    }
    const value = Math.max(0, Math.min(100, newProgress[0]));
    setProgress(value);
  };

  const handleProgressCommit = async () => {
    if (progress === task.progress) return;
    setIsSubmitting(true);
    try {
      await updateTaskProgress(task.id, progress);
      toast.success(`Progress updated to ${progress}%`);
    } catch (error) {
      toast.error(`Failed to update progress: ${error.message || 'Unknown error'}`);
      setProgress(task.progress || 0); // Revert on error
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <div className={`bg-white dark:bg-gray-800 rounded-lg shadow p-4 border-l-4 ${
        isDelayed 
          ? 'border-red-500' 
          : progress === 100
            ? 'border-green-500'
            : 'border-blue-500'
      }`}>
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-medium text-gray-900 dark:text-gray-100">{task.title}</h3>
          <div className="flex gap-2">
            <Badge className={priorityColor[task.priority]}>
              {task.priority}
            </Badge>
            <Badge variant="outline" className={`${statusColor[getDerivedStatus()]} bg-opacity-20 border-0`}>
              {getDerivedStatus()}
            </Badge>
          </div>
        </div>

        <div className="text-sm text-gray-500 dark:text-gray-400 mb-3 line-clamp-2">
          {task.description}
        </div>

        <div className="mb-2">
          <div className="flex items-center mb-1">
            <span className="text-xs text-gray-500 dark:text-gray-400">Progress:</span>
            <span className="ml-2 text-xs text-gray-500 dark:text-gray-400">
              {progress}%
            </span>
          </div>
          <Slider
            value={[progress]}
            onValueChange={handleProgressChange}
            onValueCommit={handleProgressCommit}
            max={100}
            min={0}
            step={1}
            className="h-2"
            disabled={isSubmitting || !canUpdateTask()}
          />
        </div>

        <div className="flex justify-between items-center mt-4">
          <div>
            <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              Due: {formattedDueDate}
              {isDelayed && progress !== 100 && (
                <span className="text-red-500 ml-1">(Overdue)</span>
              )}
            </div>
          </div>

          <div className="flex items-center">
            {assignedUser?.avatarUrl && (
              <div className="mr-2 relative">
                <img 
                  src={assignedUser.avatarUrl} 
                  alt={assignedUser.name} 
                  className="w-6 h-6 rounded-full"
                  title={assignedUser.name}
                />
              </div>
            )}
            <Button variant="outline" size="sm" onClick={() => setShowDetail(true)}>
              View
            </Button>
          </div>
        </div>
      </div>

      <Dialog open={showDetail} onOpenChange={setShowDetail}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Task Details</DialogTitle>
          </DialogHeader>
          <TaskDetail task={{ ...task, progress }} onClose={() => setShowDetail(false)} />
        </DialogContent>
      </Dialog>
    </>
  );
}