
import { useState, useEffect } from "react";
import { useTask } from "../../contexts/TaskContext";
import { useUser } from "../../contexts/UserContext";
import { useAuth } from "../../contexts/AuthContext";
import { DialogDescription } from "@/components/ui/dialog";
import { Button } from "../ui/button";
import { Textarea } from "../ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../ui/dialog";
import { toast } from "sonner";

export default function TaskReassign({ task, isOpen, onClose, onSuccess }) {
  const { reassignTask } = useTask();
  const { getAllUsers } = useUser(); // Remove setUsers
  const { user } = useAuth();

  const [selectedUserId, setSelectedUserId] = useState("");
  const [reason, setReason] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [users, setUsers] = useState([]); // Local state for users

  // Fetch users on component mount
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/user`);
        const data = await res.json();
        if (!res.ok) throw new Error(data?.error || "Failed to fetch users");
        setUsers(data); // Update local state
      } catch (error) {
        console.error("Error fetching users:", error);
        toast.error(error.message || "Failed to load users");
      }
    };
    fetchUsers();
  }, []);

  const assignableUsers = users.filter((u) => u.id !== task.assigned_to);

  const handleReassign = async () => {
    if (!selectedUserId) {
      toast.error("Please select a new assignee");
      return;
    }

    try {
      setIsSubmitting(true);
      await reassignTask(task.id, selectedUserId, reason);
      setSelectedUserId("");
      setReason("");
      onSuccess?.();
      onClose();
    } catch (error) {
      toast.error(error.message || "Failed to reassign task");
    } finally {
      setIsSubmitting(false);
    }
  };

  const canReassignTask = () => {
    if (!user) return false;
    const allowedRoles = ["Admin", "Manager", "HR","Team Lead"];
    return allowedRoles.includes(user.role);
  };

  if (!canReassignTask()) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-white dark:bg-gray-800 rounded-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold text-gray-900 dark:text-white">
            Reassign Task
          </DialogTitle>
          <DialogDescription className="text-sm text-gray-600 dark:text-gray-400">
            Please select a new assignee for the task.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Current Assignee
            </label>
            <p className="text-sm text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-700 p-2 rounded-md">
              {getAllUsers().find((u) => u.id === task.assigned_to)?.name || "Unknown"}
            </p>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Reassign To
            </label>
            <Select value={selectedUserId} onValueChange={setSelectedUserId}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select new assignee" />
              </SelectTrigger>
              <SelectContent className="bg-white dark:bg-gray-800">
                {assignableUsers.map((user) => (
                  <SelectItem
                    key={user.id}
                    value={user.id}
                    className="hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <div className="flex items-center gap-2">
                      <span>{user.name}</span>
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        ({user.role})
                      </span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Reason (Optional)
            </label>
            <Textarea
              placeholder="Why are you reassigning this task?"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={3}
              className="bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600"
              disabled={isSubmitting}
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2">
            <Button
              variant="outline"
              onClick={onClose}
              className="border-gray-300 dark:border-gray-600"
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              onClick={handleReassign}
              disabled={!selectedUserId || isSubmitting}
              className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800 text-white"
            >
              {isSubmitting ? "Reassigning..." : "Reassign Task"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
