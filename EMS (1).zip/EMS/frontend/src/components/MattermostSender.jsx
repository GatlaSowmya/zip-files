// src/components/MattermostSender.jsx
import React, { useState } from 'react';

const MattermostSender = () => {
  const [message, setMessage] = useState('');

  const sendMessage = async () => {
    const token = 'YOUR_ACCESS_TOKEN'; // Never expose this in real production apps!
    const channelId = 'YOUR_CHANNEL_ID';
    const mattermostUrl = 'https://your-mattermost-url.com';

    try {
      const response = await fetch(`${mattermostUrl}/api/v4/posts`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          channel_id: channelId,
          message: message,
        }),
      });

      const data = await response.json();
      console.log('Message sent:', data);
      alert('Message sent successfully!');
      setMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
      alert('Failed to send message');
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Send Message to Mattermost</h2>
      <textarea
        rows="4"
        style={{ width: '100%' }}
        placeholder="Type your message"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
      />
      <button onClick={sendMessage} style={{ marginTop: '10px' }}>
        Send
      </button>
    </div>
  );
};

export default MattermostSender;
