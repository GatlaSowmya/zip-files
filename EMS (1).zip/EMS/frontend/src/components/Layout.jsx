import { useState, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Sidebar from './Sidebar';
import Navbar from './Navbar';
import { cn } from '../lib/utils';

/**
 * Main layout component that wraps authenticated pages
 * @returns {JSX.Element}
 */
const Layout = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const { isAuthenticated } = useAuth();

  // Check window size on initial render and update sidebar collapse state
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setCollapsed(true);
        setIsMobileSidebarOpen(false);
      } else {
        setCollapsed(false);
        setIsMobileSidebarOpen(false);
      }
    };

    // Set initial state
    handleResize();

    // Add event listener
    window.addEventListener('resize', handleResize);

    // Clean up
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  if (!isAuthenticated) {
    return <Outlet />;
  }

  return (
    <div className="h-screen flex bg-gray-50 relative">
      <Sidebar
        collapsed={collapsed}
        setCollapsed={setCollapsed}
        isMobileSidebarOpen={isMobileSidebarOpen}
        setIsMobileSidebarOpen={setIsMobileSidebarOpen}
      />
      <div
        className={cn(
          "flex-1 transition-none h-full",
          isMobileSidebarOpen ? "ml-0" : "ml-0 md:ml-[70px]",
          !isMobileSidebarOpen && !collapsed && "md:ml-[240px]"
        )}
      >
        <Navbar
          collapsed={collapsed}
          setCollapsed={setCollapsed}
          isMobileSidebarOpen={isMobileSidebarOpen}
          setIsMobileSidebarOpen={setIsMobileSidebarOpen}
        />
        <main className="pt-16 px-4 pb-4 h-full overflow-auto">
          <div className="max-w-7xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;