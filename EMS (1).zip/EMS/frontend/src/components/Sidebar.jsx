
import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '../lib/utils';
import { useAuth } from '../contexts/AuthContext';
import {
  Calendar,
  Home,
  Settings,
  Users,
  FileText,
  ChevronDown,
  ChevronRight,
  Plus,
  X
} from 'lucide-react';
import { Button } from '../components/ui/button';

const Sidebar = ({ collapsed, setCollapsed, isMobileSidebarOpen, setIsMobileSidebarOpen }) => {
  const { user } = useAuth();
  const location = useLocation();
  const [mounted, setMounted] = useState(false);
  const [openDropdown, setOpenDropdown] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    // Prevent body scroll when sidebar is open on mobile
    document.body.style.overflow = isMobileSidebarOpen ? 'hidden' : 'auto';
    return () => (document.body.style.overflow = 'auto');
  }, [isMobileSidebarOpen]);

  const menuItems = [
    {
      title: 'Dashboard',
      path: '/dashboard',
      icon: <Home size={20} />,
      roles: ['Admin', 'HR', 'Manager', 'Team Lead', 'Employee', 'Director']
    },
    {
      title: 'Employees',
      icon: <Users size={20} />,
      roles: ['Admin', 'HR', 'Manager', 'Team Lead', 'Director'],
      subItems: [
        {
          title: 'Employee List',
          path: '/employees',
          icon: <Users size={16} />,
          roles: ['Admin', 'HR', 'Manager', 'Team Lead', 'Director']
        },
        {
          title: 'Add New',
          path: '/add-user',
          icon: <Plus size={16} />,
          roles: ['Admin', 'HR', 'Director']
        },
        {
          title: 'Update User',
          path: '/Update-user',
          icon: <Plus size={16} />,
          roles: ['Admin', 'HR', 'Director']
        },
        {
          title: 'Upload Documents',
          path: '/Upload-documents',
          icon: <Plus size={16} />,
          roles: ['Admin', 'HR', 'Director', 'Team Lead', 'Employee']
        }
      ]
    },
    {
      title: 'Leave Requests',
      path: '/leaves',
      icon: <Calendar size={20} />,
      roles: ['Admin', 'HR', 'Manager', 'Team Lead', 'Employee', 'Director']
    },
    {
      title: 'Reports',
      path: '/reports',
      icon: <FileText size={20} />,
      roles: ['Admin', 'HR', 'Manager', 'Director']
    },
    {
      title: 'Tasks',
      path: '/tasks',
      icon: <FileText size={20} />,
      roles: ['Admin', 'HR', 'Manager', 'Team Lead', 'Employee', 'Director']
    },
    {
      title: 'Check In/Out',
      path: '/checkin-checkout',
      icon: <Calendar size={20} />,
      roles: ['Admin', 'HR', 'Manager', 'Team Lead', 'Employee', 'Director']
    },
    {
      title: 'Settings',
      path: '/settings',
      icon: <Settings size={20} />,
      roles: ['Admin', 'Director']
    }
  ];

  const filteredMenuItems = menuItems.filter(item => user && item.roles.includes(user.role));
  if (!user || !mounted) return null;

  return (
    <div
      className={cn(
        'fixed inset-y-0 left-0 z-50 flex flex-col transition-transform duration-300',
        'bg-[hsl(var(--sidebar-background))] text-[hsl(var(--sidebar-foreground))] shadow-lg',
        isMobileSidebarOpen ? 'w-[240px] translate-x-0' : 'w-[240px] -translate-x-full md:translate-x-0 md:w-[70px]',
        collapsed && !isMobileSidebarOpen ? 'md:w-[70px]' : 'md:w-[240px]'
      )}
    >
      <div className="flex items-center justify-between p-4 border-b border-[hsl(var(--sidebar-border))]">
        {(!collapsed || isMobileSidebarOpen) && (
          <h1 className="font-bold text-lg">EMS Portal</h1>
        )}
        {isMobileSidebarOpen && (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMobileSidebarOpen(false)}
            className="text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))] hover:text-[hsl(var(--sidebar-accent-foreground))] md:hidden"
          >
            <X size={20} />
          </Button>
        )}
      </div>

      <div className="flex-grow overflow-y-auto max-h-[calc(100vh-120px)] sidebar-scrollbar">
        <nav className="mt-2 px-2">
          <ul className="space-y-2">
            {filteredMenuItems.map((item) => {
              const isActive = location.pathname === item.path;
              const hasSubItems = item.subItems && item.subItems.length > 0;

              if (hasSubItems) {
                const subItemsVisible = item.subItems.some(
                  subItem => user && subItem.roles.includes(user.role)
                );

                if (!subItemsVisible) return null;

                return (
                  <li key={item.title}>
                    <button
                      onClick={() => setOpenDropdown(!openDropdown)}
                      className={cn(
                        'flex items-center w-full py-2 px-3 rounded transition-colors duration-200',
                        'text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))] hover:text-[hsl(var(--sidebar-accent-foreground))]',
                        collapsed && !isMobileSidebarOpen ? 'justify-center' : 'justify-between'
                      )}
                    >
                      <div className="flex items-center">
                        <span className="flex-shrink-0">{item.icon}</span>
                        {(!collapsed || isMobileSidebarOpen) && (
                          <span className="ml-3 text-sm">{item.title}</span>
                        )}
                      </div>
                      {(!collapsed || isMobileSidebarOpen) && (
                        <span>
                          {openDropdown ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                        </span>
                      )}
                    </button>

                    {openDropdown && (!collapsed || isMobileSidebarOpen) && (
                      <ul className="ml-4 space-y-1">
                        {item.subItems
                          .filter(subItem => user && subItem.roles.includes(user.role))
                          .map((subItem) => {
                            const isSubActive = location.pathname === subItem.path;
                            return (
                              <li key={subItem.path}>
                                <Link
                                  to={subItem.path}
                                  onClick={() => setIsMobileSidebarOpen(false)}
                                  className={cn(
                                    'flex items-center py-1.5 px-3 rounded text-sm transition-colors duration-200',
                                    isSubActive
                                      ? 'bg-white text-[hsl(var(--sidebar-primary))] font-medium'
                                      : 'text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))] hover:text-[hsl(var(--sidebar-accent-foreground))]'
                                  )}
                                >
                                  <span className="flex-shrink-0 mr-2">{subItem.icon}</span>
                                  <span>{subItem.title}</span>
                                </Link>
                              </li>
                            );
                          })}
                      </ul>
                    )}
                  </li>
                );
              }

              return (
                <li key={item.path}>
                  <Link
                    to={item.path}
                    onClick={() => setIsMobileSidebarOpen(false)}
                    className={cn(
                      'flex items-center py-2 px-3 rounded transition-colors duration-200',
                      isActive
                        ? 'bg-white text-[hsl(var(--sidebar-primary))] font-medium'
                        : 'text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))] hover:text-[hsl(var(--sidebar-accent-foreground))]',
                      collapsed && !isMobileSidebarOpen ? 'justify-center' : 'justify-start'
                    )}
                  >
                    <span className="flex-shrink-0">{item.icon}</span>
                    {(!collapsed || isMobileSidebarOpen) && (
                      <span className="ml-3 text-sm">{item.title}</span>
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      </div>

      <div className="p-4 border-t border-[hsl(var(--sidebar-border))]">
        {(!collapsed || isMobileSidebarOpen) && (
          <div className="text-center text-xs opacity-70">© 2025 EMS Portal</div>
        )}
      </div>
    </div>
  );
};

export default Sidebar;