import React, { useEffect, useState } from 'react';
import { CheckCircle, XCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const CheckInOutCompact = () => {
  const { user } = useAuth();
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const [shift, setShift] = useState('General');
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (user) {
      fetchStatus();
    }
  }, [user]);

  const fetchStatus = async () => {
    try {
      const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/attendance/today/${user.id}`);
      const data = await res.json();
      setStatus(data?.status);
      if (data?.shift) setShift(data.shift);
    } catch (err) {
      console.error('Failed to fetch status:', err);
    }
  };

  const handleCheck = async (type) => {
    setLoading(true);
    try {
      await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/attendance/${type}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          shift,
          timestamp: new Date().toISOString(),
        }),
      });
      await fetchStatus();
    } catch (err) {
      console.error(`${type} failed`, err);
    }
    setLoading(false);
  };

  if (!user) return null;

  return (
    <div className="bg-white border p-3 rounded-md shadow w-72 text-sm space-y-2">
      <div className="flex justify-between">
        <span className="text-gray-600 font-medium">Time</span>
        <span className="font-mono text-blue-700">{currentTime}</span>
      </div>

      <div className="flex justify-between items-center">
        <label htmlFor="shift" className="text-gray-600 font-medium">Shift</label>
        <select
          id="shift"
          value={shift}
          onChange={(e) => setShift(e.target.value)}
          className="border px-2 py-1 rounded text-sm"
        >
          <option value="General">General</option>
          <option value="Day">Day</option>
          <option value="Night">Night</option>
          <option value="Evening">Evening</option>
        </select>
      </div>

      <div className="flex justify-center space-x-3 mt-2">
        <button
          onClick={() => handleCheck('checkin')}
          disabled={loading || status === 'checked-in'}
          className="flex items-center px-3 py-1 text-green-600 border border-green-600 rounded hover:bg-green-50 disabled:opacity-50"
        >
          <CheckCircle size={16} className="mr-1" /> In
        </button>
        <button
          onClick={() => handleCheck('checkout')}
          disabled={loading || status === 'checked-out'}
          className="flex items-center px-3 py-1 text-red-600 border border-red-600 rounded hover:bg-red-50 disabled:opacity-50"
        >
          <XCircle size={16} className="mr-1" /> Out
        </button>
      </div>
    </div>
  );
};

export default CheckInOutCompact;
