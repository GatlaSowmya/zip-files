// import React, { createContext, useState, useContext, useEffect } from 'react';
// import { useAuth } from './AuthContext';

// const UserContext = createContext(undefined);

// // Mock data for development
// const MOCK_USERS = [
//   {
//     id: '1',
//     name: 'Admin User',
//     email: 'admin@example.com',
//     role: 'Admin',
//     avatarUrl: 'https://ui-avatars.com/api/?name=Admin+User&background=2563eb&color=fff',
//     department: 'Executive',
//   },
//   {
//     id: '2',
//     name: 'HR Manager',
//     email: 'hr@example.com',
//     role: 'HR',
//     avatarUrl: 'https://ui-avatars.com/api/?name=HR+Manager&background=6366f1&color=fff',
//     department: 'Human Resources',
//   },
//   {
//     id: '3',
//     name: 'Project Manager',
//     email: 'manager@example.com',
//     role: 'Manager',
//     avatarUrl: 'https://ui-avatars.com/api/?name=Project+Manager&background=8b5cf6&color=fff',
//     department: 'Product Development',
//   },
//   {
//     id: '4',
//     name: 'Team Leader',
//     email: 'teamlead@example.com',
//     role: 'Team Lead',
//     avatarUrl: 'https://ui-avatars.com/api/?name=Team+Leader&background=a855f7&color=fff',
//     department: 'Engineering',
//   },
//   {
//     id: '5',
//     name: 'Employee One',
//     email: 'employee1@example.com',
//     role: 'Employee',
//     avatarUrl: 'https://ui-avatars.com/api/?name=Employee+One&background=d946ef&color=fff',
//     department: 'Engineering',
//   },
//   {
//     id: '6',
//     name: 'Employee Two',
//     email: 'employee2@example.com',
//     role: 'Employee',
//     avatarUrl: 'https://ui-avatars.com/api/?name=Employee+Two&background=ec4899&color=fff',
//     department: 'Design',
//   },
// ];

// const MOCK_DEPARTMENTS = [
//   { id: 'd1', name: 'Executive', managerId: '1' },
//   { id: 'd2', name: 'Human Resources', managerId: '2' },
//   { id: 'd3', name: 'Product Development', managerId: '3' },
//   { id: 'd4', name: 'Engineering', managerId: '4' },
//   { id: 'd5', name: 'Design', managerId: '3' },
// ];

// export const UserProvider = ({ children }) => {
//   const { user } = useAuth();
//   const [users, setUsers] = useState(MOCK_USERS);
//   const [departments, setDepartments] = useState(MOCK_DEPARTMENTS);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     // In a real app, this would fetch from an API
//     setLoading(false);
//   }, []);

//   const getUserById = (id) => {
//     return users.find((u) => u.id === id);
//   };

//   const getUsersByRole = (role) => {
//     return users.filter((u) => u.role === role);
//   };

//   const getUsersByDepartment = (departmentName) => {
//     return users.filter((u) => u.department === departmentName);
//   };

//   const getDepartmentById = (id) => {
//     return departments.find((d) => d.id === id);
//   };

//   const getAllUsers = () => {
//     return users;
//   };

//   // Check if current user can access features of a specific role
//   const isUserAuthorizedForRole = (checkingRole) => {
//     if (!user) return false;
    
//     // Role hierarchy for permissions
//     const roleHierarchy = {
//       'Admin': 5,
//       'HR': 4,
//       'Manager': 3,
//       'Team Lead': 2,
//       'Employee': 1,
//     };
    
//     // Current user's role level
//     const currentRoleLevel = roleHierarchy[user.role];
    
//     // Required role level to access this feature
//     const requiredRoleLevel = roleHierarchy[checkingRole];
    
//     return currentRoleLevel >= requiredRoleLevel;
//   };

//   return (
//     <UserContext.Provider 
//       value={{ 
//         users, 
//         departments, 
//         loading, 
//         getUserById, 
//         getUsersByRole, 
//         getUsersByDepartment, 
//         getDepartmentById,
//         getAllUsers,
//         isUserAuthorizedForRole
//       }}
//     >
//       {children}
//     </UserContext.Provider>
//   );
// };

// export const useUser = () => {
//   const context = useContext(UserContext);
//   if (context === undefined) {
//     throw new Error('useUser must be used within a UserProvider');
//   }
//   return context;
// };

import React, { createContext, useState, useContext, useEffect } from 'react';
import { useAuth } from './AuthContext';

const UserContext = createContext(undefined);

export const UserProvider = ({ children }) => {
  const { user } = useAuth();
  const [users, setUsers] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        if (!user) return;

        const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/employees?role=${user.role}&name=${user.name}`);
        const usersData = await res.json();
        setUsers(usersData);

        const deptRes = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/reports/filter-options`);
        const deptData = await deptRes.json();
        setDepartments(deptData.departments || []);
      } catch (err) {
        console.error('Failed to fetch user or department data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const getUserById = (id) => users.find((u) => u.id === id);
  const getUsersByRole = (role) => users.filter((u) => u.role === role);
  const getUsersByDepartment = (departmentName) => users.filter((u) => u.department === departmentName);
  const getDepartmentById = (id) => departments.find((d) => d.id === id);
  const getAllUsers = () => users;

  const isUserAuthorizedForRole = (checkingRole) => {
    if (!user) return false;
    const roleHierarchy = { Admin: 5, HR: 4, Manager: 3, 'Team Lead': 2, Employee: 1 };
    return roleHierarchy[user.role] >= roleHierarchy[checkingRole];
  };

  return (
    <UserContext.Provider
      value={{
        users,
        departments,
        loading,
        getUserById,
        getUsersByRole,
        getUsersByDepartment,
        getDepartmentById,
        getAllUsers,
        isUserAuthorizedForRole,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};
