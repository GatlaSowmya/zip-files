
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { toast } from 'sonner';

const TaskContext = createContext(undefined);

export const TaskProvider = ({ children }) => {
  const { user } = useAuth(); // Remove token from useAuth
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  const normalizeTask = (task) => ({
    ...task,
    id: task.id_uuid,
    due_date: task.due_date || task.duedate || null,
    created_at: task.created_at || task.createdat || null,
    updated_stamp: task.updated_stamp || task.updatedat || null,
    comments: Array.isArray(task.comments) ? task.comments : [],
    reassign_reason: task.reassign_reason || null,
    original_assigned_by: task.original_assigned_by || null,
  });

  const fetchTasks = async () => {
    try {
      if (!user?.id || !user?.role) return;
      const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/tasks?userId=${user.id}&role=${user.role}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to fetch tasks');
      if (!Array.isArray(data)) throw new Error('Invalid task data from server');
      setTasks(data.map(normalizeTask));
    } catch (error) {
      console.error('Fetch error:', error);
      toast.error(error.message || 'Failed to load tasks');
      setTasks([]);
    } finally {
      setLoading(false);
    }
  };

  const updateTaskProgress = async (taskId, progress) => {
    try {
      const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/tasks/${taskId}/progress`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ progress }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to update progress');
      const updatedTask = normalizeTask(data.task);
      setTasks((prev) =>
        prev.map((task) =>
          task.id === taskId
            ? { ...task, ...updatedTask, updated_stamp: new Date().toISOString() }
            : task
        )
      );
      toast.success(`Progress updated to ${progress}%`);
    } catch (error) {
      console.error('Progress error:', error);
      toast.error(error.message || 'Error updating progress');
    }
  };

  const addTaskComment = async (taskId, content) => {
    if (!user) {
      toast.error('User not authenticated');
      return;
    }
    try {
      const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/tasks/${taskId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, userId: user.id }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to add comment');
      const updatedTask = normalizeTask(data.task);
      setTasks((prev) =>
        prev.map((task) =>
          task.id === taskId
            ? {
                ...task,
                comments: updatedTask.comments || [...(task.comments || []), content],
                updated_stamp: new Date().toISOString(),
              }
            : task
        )
      );
      toast.success('Comment added');
    } catch (error) {
      console.error('Comment error:', error);
      toast.error(error.message || 'Error adding comment');
    }
  };

  const deleteTask = async (taskId) => {
    try {
      const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/tasks/${taskId}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to delete task');
      setTasks((prev) => prev.filter((task) => task.id !== taskId));
      toast.success('Task deleted');
    } catch (error) {
      console.error('Delete error:', error);
      toast.error(error.message || 'Error deleting task');
    }
  };

  const reassignTask = async (taskId, newAssigneeId, reason) => {
    try {
      if (!user?.id || !user?.role) {
        throw new Error('User not authenticated');
      }
      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/tasks/${taskId}/reassign?userId=${user.id}&role=${user.role}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ newAssigneeId, reason }),
        }
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || `Failed to reassign task (HTTP ${res.status})`);
      const updatedTask = normalizeTask(data.task);
      setTasks((prev) =>
        prev.map((task) =>
          task.id === taskId
            ? {
                ...task,
                ...updatedTask,
                assigned_to: newAssigneeId,
                reassign_reason: reason || null,
                updated_stamp: new Date().toISOString(),
              }
            : task
        )
      );
      toast.success('Task reassigned successfully');
    } catch (error) {
      console.error('Reassign error:', error.message);
      toast.error(error.message || 'Error reassigning task');
      throw error;
    }
  };

  useEffect(() => {
    if (user?.id && user?.role) {
      fetchTasks();
    }
  }, [user]);

  const getAssignedTasks = () => tasks.filter((t) => t.assigned_to === user?.id);
  const getCreatedTasks = () => tasks.filter((t) => t.assigned_by === user?.id);
  const getAllTasks = () => tasks;
  const getTaskById = (id) => tasks.find((task) => task.id === id);

  return (
    <TaskContext.Provider
      value={{
        tasks,
        loading,
        fetchTasks,
        updateTaskProgress,
        addTaskComment,
        getAssignedTasks,
        getCreatedTasks,
        getAllTasks,
        getTaskById,
        deleteTask,
        reassignTask,
      }}
    >
      {children}
    </TaskContext.Provider>
  );
};

export const useTask = () => {
  const context = useContext(TaskContext);
  if (context === undefined) {
    throw new Error('useTask must be used within a TaskProvider');
  }
  return context;
};
