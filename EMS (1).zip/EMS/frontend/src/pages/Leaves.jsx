// import React, { useState, useEffect } from 'react';
// import { useAuth } from '../contexts/AuthContext';
// import axios from 'axios';
// import { toast } from 'sonner';

// const LeaveManagement = () => {
//   const { user } = useAuth();
//   const [leaveRequests, setLeaveRequests] = useState([]);
//   const [employees, setEmployees] = useState([]);
//   const [leaveForm, setLeaveForm] = useState({ type: '', date: '', reason: '' });
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [isDialogOpen, setIsDialogOpen] = useState(false);
//   const [activeTab, setActiveTab] = useState('self-requests');

//   const totalLeaves = 12;
//   const [usedLeaves, setUsedLeaves] = useState(0);
//   const [wfhLeaves, setWfhLeaves] = useState(0);
//   const [sickLeaves, setSickLeaves] = useState(0);

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         setLoading(true);
//         setError(null);

//         if (!user?.role || !user?.id) {
//           throw new Error('User role or ID is missing');
//         }

//         const employeeParams = { role: user.role, name: user.role === 'Employee' ? user.id : user.name || user.id };
//         const leaveParams = { role: user.role, userId: user.id, name: user.name || user.id };

//         const employeesResponse = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/employees`, { params: employeeParams });
//         setEmployees(employeesResponse.data || []);

//         const leaveResponse = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/leaves`, { params: leaveParams });
//         setLeaveRequests(leaveResponse.data || []);

//         const userApprovedLeaves = leaveResponse.data.filter(req => req.userId === user.id && req.status === 'approved');
//         setUsedLeaves(userApprovedLeaves.length);
//         setWfhLeaves(userApprovedLeaves.filter(req => req.type === 'WFH').length);
//         setSickLeaves(userApprovedLeaves.filter(req => req.type === 'Leave' && req.reason.toLowerCase().includes('sick')).length);
//       } catch (err) {
//         setError('Failed to load leave data');
//         toast.error(`Failed to load leave data: ${err.response?.data?.message || err.message}`);
//       } finally {
//         setLoading(false);
//       }
//     };

//     if (user?.role && user?.id) {
//       fetchData();
//     } else {
//       setError('Invalid user data');
//       toast.error('Invalid user data');
//       setLoading(false);
//     }
//   }, [user]);

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const newRequest = {
//         userId: user.id,
//         type: leaveForm.type,
//         date: leaveForm.date,
//         reason: leaveForm.reason,
//       };

//       const response = await axios.post(`${import.meta.env.VITE_API_BASE_URL}/api/leaves`, newRequest);
//       setLeaveRequests([...leaveRequests, response.data]);
//       setLeaveForm({ type: '', date: '', reason: '' });
//       setIsDialogOpen(false);
//       toast.success('Leave request submitted successfully');
//     } catch (err) {
//       toast.error(`Failed to submit leave request: ${err.response?.data?.error || err.message}`);
//     }
//   };

//   const handleLeaveAction = async (leaveId, action) => {
//     try {
//       const response = await axios.patch(
//         `${import.meta.env.VITE_API_BASE_URL}/api/leaves/${leaveId}/${action}?role=${user.role}`,
//         { acceptedBy: user.name || user.id }
//       );

//       setLeaveRequests(leaveRequests.map(req => (req.id === leaveId ? response.data : req)));

//       if (response.data.userId === user.id) {
//         const userApprovedLeaves = leaveRequests
//           .filter(req => req.id !== leaveId)
//           .concat(response.data)
//           .filter(req => req.userId === user.id && req.status === 'approved');
//         setUsedLeaves(userApprovedLeaves.length);
//         setWfhLeaves(userApprovedLeaves.filter(req => req.type === 'WFH').length);
//         setSickLeaves(userApprovedLeaves.filter(req => req.type === 'Leave' && req.reason.toLowerCase().includes('sick')).length);
//       }

//       toast.success(`Leave request ${action} successfully`);
//     } catch (err) {
//       toast.error(`Failed to ${action} leave request: ${err.response?.data?.message || err.message}`);
//     }
//   };

//   const getFilteredRequests = () => {
//     if (activeTab === 'self-requests') {
//       return leaveRequests.filter(req => req.userId === user.id);
//     }

//     if (user.role === 'Manager') {
//       return leaveRequests.filter(
//         req =>
//           employees.find(emp => emp.id === req.userId)?.manager === user.name ||
//           employees.find(emp => emp.id === req.userId)?.team_lead === user.name
//       );
//     }

//     if (user.role === 'Director') {
//       return leaveRequests.filter(
//         req => {
//           const employee = employees.find(emp => emp.id === req.userId);
//           return employee && ['HR', 'Admin', 'Manager'].includes(employee.role);
//         }
//       );
//     }

//     return [];
//   };

//   const renderLeaveForm = () => (
//     <div className={`fixed inset-0 bg-gray-900 bg-opacity-60 flex items-center justify-center z-50 transition-opacity duration-300 ${isDialogOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
//       <div className="bg-white rounded-lg shadow-lg p-4 w-full max-w-xs sm:max-w-sm mx-2 overflow-y-auto max-h-[90vh]">
//         <h3 className="text-base sm:text-lg font-semibold text-gray-800 mb-3">Apply for Leave</h3>
//         <form onSubmit={handleSubmit} className="space-y-3">
//           <div>
//             <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Type</label>
//             <select
//               value={leaveForm.type}
//               onChange={(e) => setLeaveForm({ ...leaveForm, type: e.target.value })}
//               required
//               className="block w-full rounded-md border border-gray-200 py-1.5 px-2 text-xs sm:text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-400"
//             >
//               <option value="" disabled>Select Type</option>
//               <option value="Leave">Leave</option>
//               <option value="WFH">Work From Home</option>
//             </select>
//           </div>
//           <div>
//             <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Date</label>
//             <input
//               type="date"
//               value={leaveForm.date}
//               onChange={(e) => setLeaveForm({ ...leaveForm, date: e.target.value })}
//               required
//               className="block w-full rounded-md border border-gray-200 py-1.5 px-2 text-xs sm:text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-400"
//             />
//           </div>
//           <div>
//             <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Reason</label>
//             <input
//               type="text"
//               value={leaveForm.reason}
//               onChange={(e) => setLeaveForm({ ...leaveForm, reason: e.target.value })}
//               required
//               className="block w-full rounded-md border border-gray-200 py-1.5 px-2 text-xs sm:text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-400"
//             />
//           </div>
//           <div className="flex justify-end space-x-2">
//             <button type="button" onClick={() => setIsDialogOpen(false)} className="px-2 sm:px-3 py-1 sm:py-1.5 text-xs sm:text-sm text-gray-600 bg-gray-100 rounded-md hover:bg-gray-200">Cancel</button>
//             <button type="submit" className="px-2 sm:px-3 py-1 sm:py-1.5 text-xs sm:text-sm text-white bg-indigo-600 rounded-md hover:bg-indigo-700">Submit Request</button>
//           </div>
//         </form>
//       </div>
//     </div>
//   );

//   const renderLeaveCounts = () => (
//     <div className="grid grid-cols-2 gap-2 sm:gap-4 md:grid-cols-4">
//       {[
//         { title: 'Total Leaves', count: totalLeaves, bg: 'bg-blue-100', text: 'text-blue-800' },
//         { title: 'Used Leaves', count: usedLeaves, bg: 'bg-red-100', text: 'text-red-800' },
//         { title: 'WFH Leaves', count: wfhLeaves, bg: 'bg-green-100', text: 'text-green-800' },
//         { title: 'Sick Leaves', count: sickLeaves, bg: 'bg-yellow-100', text: 'text-yellow-800' },
//       ].map(item => (
//         <div key={item.title} className={`rounded-lg shadow-sm p-3 ${item.bg}`}>
//           <h3 className="text-xs font-medium sm:text-sm ${item.text}">{item.title}</h3>
//           <p className="text-lg font-semibold sm:text-xl ${item.text}">{item.count}</p>
//         </div>
//       ))}
//     </div>
//   );

//   const renderLeaveRequests = () => (
//     <div className="bg-white rounded-lg shadow-sm p-4 sm:p-6">
//       <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 space-y-2 sm:space-y-0">
//         <h2 className="text-base font-semibold sm:text-lg text-gray-800">{activeTab === 'self-requests' ? 'My Leave Requests' : 'Team Leave Requests'}</h2>
//         <nav className="flex space-x-2">
//           <button onClick={() => setActiveTab('self-requests')} className={`px-3 py-1 text-xs sm:text-sm font-medium rounded-md ${activeTab === 'self-requests' ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>Self Requests</button>
//           {(user.role === 'Manager' || user.role === 'Admin' || user.role === 'Director') && (
//             <button onClick={() => setActiveTab('team-requests')} className={`px-3 py-1 text-xs sm:text-sm font-medium rounded-md ${activeTab === 'team-requests' ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>Team Requests</button>
//           )}
//         </nav>
//       </div>
//       <div className="space-y-4 md:overflow-x-auto">
//         {/* Mobile: Card Layout */}
//         <div className="md:hidden space-y-4">
//           {getFilteredRequests().length > 0 ? (
//             getFilteredRequests().map(request => (
//               <div key={request.id} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
//                 <div className="space-y-2 text-xs">
//                   <div><span className="font-medium">ID:</span> {request.id}</div>
//                   <div><span className="font-medium">User:</span> {employees.find(emp => emp.id === request.userId)?.name || 'Unknown'}</div>
//                   <div><span className="font-medium">Type:</span> {request.type}</div>
//                   <div><span className="font-medium">Date:</span> {request.date}</div>
//                   <div><span className="font-medium">Reason:</span> {request.reason}</div>
//                   <div><span className="font-medium">Status:</span> {request.status}</div>
//                   <div><span className="font-medium">Approved By:</span> {request.acceptedBy || '-'}</div>
//                   {(user.role === 'Manager' || user.role === 'Admin' || user.role === 'Director') && activeTab === 'team-requests' && request.status === 'pending' && (
//                     <div className="flex space-x-2 pt-2">
//                       <button onClick={() => handleLeaveAction(request.id, 'approve')} className="px-3 py-1 text-xs text-white bg-green-500 rounded-md hover:bg-green-600">Approve</button>
//                       <button onClick={() => handleLeaveAction(request.id, 'reject')} className="px-3 py-1 text-xs text-white bg-red-500 rounded-md hover:bg-red-600">Reject</button>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             ))
//           ) : (
//             <div className="text-center text-gray-500 text-xs">No leave requests</div>
//           )}
//         </div>
//         {/* Desktop: Table Layout */}
//         <table className="hidden md:table w-full text-xs text-left text-gray-600">
//           <thead className="bg-gray-50">
//             <tr>
//               <th className="py-2 px-3">ID</th>
//               <th className="py-2 px-3">User</th>
//               <th className="py-2 px-3">Type</th>
//               <th className="py-2 px-3">Date</th>
//               <th className="py-2 px-3">Reason</th>
//               <th className="py-2 px-3">Status</th>
//               <th className="py-2 px-3">Approved By</th>
//               {(user.role === 'Manager' || user.role === 'Admin' || user.role === 'Director') && activeTab === 'team-requests' && (
//                 <th className="py-2 px-3">Actions</th>
//               )}
//             </tr>
//           </thead>
//           <tbody className="divide-y divide-gray-100">
//             {getFilteredRequests().length > 0 ? (
//               getFilteredRequests().map(request => (
//                 <tr key={request.id}>
//                   <td className="py-2 px-3">{request.id}</td>
//                   <td className="py-2 px-3">{employees.find(emp => emp.id === request.userId)?.name || 'Unknown'}</td>
//                   <td className="py-2 px-3">{request.type}</td>
//                   <td className="py-2 px-3">{request.date}</td>
//                   <td className="py-2 px-3">{request.reason}</td>
//                   <td className="py-2 px-3">{request.status}</td>
//                   <td className="py-2 px-3">{request.acceptedBy || '-'}</td>
//                   {(user.role === 'Manager' || user.role === 'Admin' || user.role === 'Director') && activeTab === 'team-requests' && request.status === 'pending' ? (
//                     <td className="py-2 px-3 flex space-x-2">
//                       <button onClick={() => handleLeaveAction(request.id, 'approve')} className="px-3 py-1 text-xs text-white bg-green-500 rounded-md hover:bg-green-600">Approve</button>
//                       <button onClick={() => handleLeaveAction(request.id, 'reject')} className="px-3 py-1 text-xs text-white bg-red-500 rounded-md hover:bg-red-600">Reject</button>
//                     </td>
//                   ) : (
//                     <td className="py-2 px-3">-</td>
//                   )}
//                 </tr>
//               ))
//             ) : (
//               <tr>
//                 <td colSpan={(user.role === 'Manager' || user.role === 'Admin' || user.role === 'Director') && activeTab === 'team-requests' ? 8 : 7} className="py-2 px-3 text-center text-gray-500">No leave requests</td>
//               </tr>
//             )}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );

//   if (loading) return <div className="flex items-center justify-center h-screen text-gray-600">Loading...</div>;
//   if (error) return <div className="flex items-center justify-center h-screen text-red-600 text-sm">{error}</div>;

//   return (
//     <div className="min-h-screen bg-gray-50 p-2 sm:p-4">
//       <div className="max-w-full sm:max-w-6xl mx-auto space-y-4 sm:space-y-6">
//         <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-2 sm:space-y-0">
//           <h3 className="text-base sm:text-lg font-semibold text-gray-800">Leave Management</h3>
//           <button onClick={() => setIsDialogOpen(true)} className="px-3 py-1 text-xs sm:text-sm text-white bg-indigo-600 rounded-md hover:bg-indigo-700 w-full sm:w-auto">Apply for Leave</button>
//         </div>
//         {renderLeaveForm()}
//         {renderLeaveCounts()}
//         {renderLeaveRequests()}
//       </div>
//     </div>
//   );
// };

// export default LeaveManagement;
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';
import { toast } from 'sonner';

const LeaveManagement = () => {
  const { user } = useAuth();
  const [leaveRequests, setLeaveRequests] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [leaveForm, setLeaveForm] = useState({ type: '', date: '', reason: '' });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('self-requests');

  const totalLeaves = 12;
  const [usedLeaves, setUsedLeaves] = useState(0);
  const [wfhLeaves, setWfhLeaves] = useState(0);
  const [sickLeaves, setSickLeaves] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        if (!user?.role || !user?.id) {
          throw new Error('User role or ID is missing');
        }

        const employeeParams = { role: user.role, name: user.role === 'Employee' ? user.id : user.name || user.id };
        const leaveParams = { role: user.role, userId: user.id, name: user.name || user.id };

        const employeesResponse = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/employees`, { params: employeeParams });
        setEmployees(employeesResponse.data || []);

        const leaveResponse = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/leaves`, { params: leaveParams });
        setLeaveRequests(leaveResponse.data || []);

        const userApprovedLeaves = leaveResponse.data.filter(req => req.userId === user.id && req.status === 'approved');
        setUsedLeaves(userApprovedLeaves.length);
        setWfhLeaves(userApprovedLeaves.filter(req => req.type === 'WFH').length);
        setSickLeaves(userApprovedLeaves.filter(req => req.type === 'Leave' && req.reason.toLowerCase().includes('sick')).length);
      } catch (err) {
        setError('Failed to load leave data');
        toast.error(`Failed to load leave data: ${err.response?.data?.message || err.message}`);
      } finally {
        setLoading(false);
      }
    };

    if (user?.role && user?.id) {
      fetchData();
    } else {
      setError('Invalid user data');
      toast.error('Invalid user data');
      setLoading(false);
    }
  }, [user]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const newRequest = {
        userId: user.id,
        type: leaveForm.type,
        date: leaveForm.date,
        reason: leaveForm.reason,
      };

      const response = await axios.post(`${import.meta.env.VITE_API_BASE_URL}/api/leaves`, newRequest);
      setLeaveRequests([...leaveRequests, response.data]);
      setLeaveForm({ type: '', date: '', reason: '' });
      setIsDialogOpen(false);
      toast.success('Leave request submitted successfully');
    } catch (err) {
      toast.error(`Failed to submit leave request: ${err.response?.data?.error || err.message}`);
    }
  };

  const handleLeaveAction = async (leaveId, action) => {
    try {
      const response = await axios.patch(
        `${import.meta.env.VITE_API_BASE_URL}/api/leaves/${leaveId}/${action}?role=${user.role}`,
        { acceptedBy: user.name || user.id }
      );

      setLeaveRequests(leaveRequests.map(req => (req.id === leaveId ? response.data : req)));

      if (response.data.userId === user.id) {
        const userApprovedLeaves = leaveRequests
          .filter(req => req.id !== leaveId)
          .concat(response.data)
          .filter(req => req.userId === user.id && req.status === 'approved');
        setUsedLeaves(userApprovedLeaves.length);
        setWfhLeaves(userApprovedLeaves.filter(req => req.type === 'WFH').length);
        setSickLeaves(userApprovedLeaves.filter(req => req.type === 'Leave' && req.reason.toLowerCase().includes('sick')).length);
      }

      toast.success(`Leave request ${action} successfully`);
    } catch (err) {
      toast.error(`Failed to ${action} leave request: ${err.response?.data?.message || err.message}`);
    }
  };

  const getFilteredRequests = () => {
    if (activeTab === 'self-requests') {
      return leaveRequests.filter(req => req.userId === user.id);
    }

    if (user.role === 'Manager') {
      return leaveRequests.filter(
        req =>
          employees.find(emp => emp.id === req.userId)?.manager === user.name ||
          employees.find(emp => emp.id === req.userId)?.team_lead === user.name
      );
    }

    if (user.role === 'Director') {
      return leaveRequests.filter(
        req => {
          const employee = employees.find(emp => emp.id === req.userId);
          return employee && ['HR', 'Admin', 'Manager'].includes(employee.role);
        }
      );
    }

    return [];
  };

  const renderLeaveForm = () => (
    <div className={`fixed inset-0 bg-gray-900 bg-opacity-60 flex items-center justify-center z-50 transition-opacity duration-300 ${isDialogOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
      <div className="bg-white rounded-lg shadow-lg p-4 w-full max-w-xs sm:max-w-sm mx-2 overflow-y-auto max-h-[90vh]">
        <h3 className="text-base sm:text-lg font-semibold text-gray-800 mb-3">Apply for Leave</h3>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Type</label>
            <select
              value={leaveForm.type}
              onChange={(e) => setLeaveForm({ ...leaveForm, type: e.target.value })}
              required
              className="block w-full rounded-md border border-gray-200 py-1.5 px-2 text-xs sm:text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            >
              <option value="" disabled>Select Type</option>
              <option value="Leave">Leave</option>
              <option value="WFH">Work From Home</option>
            </select>
          </div>
          <div>
            <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Date</label>
            <input
              type="date"
              value={leaveForm.date}
              onChange={(e) => setLeaveForm({ ...leaveForm, date: e.target.value })}
              required
              className="block w-full rounded-md border border-gray-200 py-1.5 px-2 text-xs sm:text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </div>
          <div>
            <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Reason</label>
            <input
              type="text"
              value={leaveForm.reason}
              onChange={(e) => {
                const value = e.target.value;
                // Allow only alphabetic characters and spaces, no numbers
                if (/^[A-Za-z\s]*$/.test(value)) {
                  setLeaveForm({ ...leaveForm, reason: value });
                } else {
                  toast.error('Reason can only contain letters and spaces');
                }
              }}
              required
              pattern="[A-Za-z\s]+"
              title="Reason can only contain letters and spaces"
              className="block w-full rounded-md border border-gray-200 py-1.5 px-2 text-xs sm:text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </div>
          <div className="flex justify-end space-x-2">
            <button
              type="button"
              onClick={() => setIsDialogOpen(false)}
              className="px-2 sm:px-3 py-1 sm:py-1.5 text-xs sm:text-sm text-gray-600 bg-gray-100 rounded-md hover:bg-gray-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-2 sm:px-3 py-1 sm:py-1.5 text-xs sm:text-sm text-white bg-indigo-600 rounded-md hover:bg-indigo-700"
            >
              Submit Request
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  const renderLeaveCounts = () => (
    <div className="grid grid-cols-2 gap-2 sm:gap-4 md:grid-cols-4">
      {[
        { title: 'Total Leaves', count: totalLeaves, bg: 'bg-blue-100', text: 'text-blue-800' },
        { title: 'Used Leaves', count: usedLeaves, bg: 'bg-red-100', text: 'text-red-800' },
        { title: 'WFH Leaves', count: wfhLeaves, bg: 'bg-green-100', text: 'text-green-800' },
        { title: 'Sick Leaves', count: sickLeaves, bg: 'bg-yellow-100', text: 'text-yellow-800' },
      ].map(item => (
        <div key={item.title} className={`rounded-lg shadow-sm p-3 ${item.bg}`}>
          <h3 className="text-xs font-medium sm:text-sm ${item.text}">{item.title}</h3>
          <p className="text-lg font-semibold sm:text-xl ${item.text}">{item.count}</p>
        </div>
      ))}
    </div>
  );

  const renderLeaveRequests = () => (
    <div className="bg-white rounded-lg shadow-sm p-4 sm:p-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 space-y-2 sm:space-y-0">
        <h2 className="text-base font-semibold sm:text-lg text-gray-800">{activeTab === 'self-requests' ? 'My Leave Requests' : 'Team Leave Requests'}</h2>
        <nav className="flex space-x-2">
          <button
            onClick={() => setActiveTab('self-requests')}
            className={`px-3 py-1 text-xs sm:text-sm font-medium rounded-md ${activeTab === 'self-requests' ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
          >
            Self Requests
          </button>
          {(user.role === 'Manager' || user.role === 'Admin' || user.role === 'Director') && (
            <button
              onClick={() => setActiveTab('team-requests')}
              className={`px-3 py-1 text-xs sm:text-sm font-medium rounded-md ${activeTab === 'team-requests' ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
            >
              Team Requests
            </button>
          )}
        </nav>
      </div>
      <div className="space-y-4 md:overflow-x-auto">
        {/* Mobile: Card Layout */}
        <div className="md:hidden space-y-4">
          {getFilteredRequests().length > 0 ? (
            getFilteredRequests().map(request => (
              <div key={request.id} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                <div className="space-y-2 text-xs">
                  <div><span className="font-medium">ID:</span> {request.id}</div>
                  <div><span className="font-medium">User:</span> {employees.find(emp => emp.id === request.userId)?.name || 'Unknown'}</div>
                  <div><span className="font-medium">Type:</span> {request.type}</div>
                  <div><span className="font-medium">Date:</span> {request.date}</div>
                  <div><span className="font-medium">Reason:</span> {request.reason}</div>
                  <div><span className="font-medium">Status:</span> {request.status}</div>
                  <div><span className="font-medium">Approved By:</span> {request.acceptedBy || '-'}</div>
                  {(user.role === 'Manager' || user.role === 'Admin' || user.role === 'Director') && activeTab === 'team-requests' && request.status === 'pending' && (
                    <div className="flex space-x-2 pt-2">
                      <button
                        onClick={() => handleLeaveAction(request.id, 'approve')}
                        className="px-3 py-1 text-xs text-white bg-green-500 rounded-md hover:bg-green-600"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => handleLeaveAction(request.id, 'reject')}
                        className="px-3 py-1 text-xs text-white bg-red-500 rounded-md hover:bg-red-600"
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))
          ) : (
            <div className="text-center text-gray-500 text-xs">No leave requests</div>
          )}
        </div>
        {/* Desktop: Table Layout */}
        <table className="hidden md:table w-full text-xs text-left text-gray-600">
          <thead className="bg-gray-50">
            <tr>
              <th className="py-2 px-3">ID</th>
              <th className="py-2 px-3">User</th>
              <th className="py-2 px-3">Type</th>
              <th className="py-2 px-3">Date</th>
              <th className="py-2 px-3">Reason</th>
              <th className="py-2 px-3">Status</th>
              <th className="py-2 px-3">Approved By</th>
              {(user.role === 'Manager' || user.role === 'Admin' || user.role === 'Director') && activeTab === 'team-requests' && (
                <th className="py-2 px-3">Actions</th>
              )}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {getFilteredRequests().length > 0 ? (
              getFilteredRequests().map(request => (
                <tr key={request.id}>
                  <td className="py-2 px-3">{request.id}</td>
                  <td className="py-2 px-3">{employees.find(emp => emp.id === request.userId)?.name || 'Unknown'}</td>
                  <td className="py-2 px-3">{request.type}</td>
                  <td className="py-2 px-3">{request.date}</td>
                  <td className="py-2 px-3">{request.reason}</td>
                  <td className="py-2 px-3">{request.status}</td>
                  <td className="py-2 px-3">{request.acceptedBy || '-'}</td>
                  {(user.role === 'Manager' || user.role === 'Admin' || user.role === 'Director') && activeTab === 'team-requests' && request.status === 'pending' ? (
                    <td className="py-2 px-3 flex space-x-2">
                      <button
                        onClick={() => handleLeaveAction(request.id, 'approve')}
                        className="px-3 py-1 text-xs text-white bg-green-500 rounded-md hover:bg-green-600"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => handleLeaveAction(request.id, 'reject')}
                        className="px-3 py-1 text-xs text-white bg-red-500 rounded-md hover:bg-red-600"
                      >
                        Reject
                      </button>
                    </td>
                  ) : (
                    <td className="py-2 px-3">-</td>
                  )}
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan={(user.role === 'Manager' || user.role === 'Admin' || user.role === 'Director') && activeTab === 'team-requests' ? 8 : 7}
                  className="py-2 px-3 text-center text-gray-500"
                >
                  No leave requests
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  if (loading) return <div className="flex items-center justify-center h-screen text-gray-600">Loading...</div>;
  if (error) return <div className="flex items-center justify-center h-screen text-red-600 text-sm">{error}</div>;

  return (
    <div className="min-h-screen bg-gray-50 p-2 sm:p-4">
      <div className="max-w-full sm:max-w-6xl mx-auto space-y-4 sm:space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-2 sm:space-y-0">
          <h3 className="text-base sm:text-lg font-semibold text-gray-800">Leave Management</h3>
          <button
            onClick={() => setIsDialogOpen(true)}
            className="px-3 py-1 text-xs sm:text-sm text-white bg-indigo-600 rounded-md hover:bg-indigo-700 w-full sm:w-auto"
          >
            Apply for Leave
          </button>
        </div>
        {renderLeaveForm()}
        {renderLeaveCounts()}
        {renderLeaveRequests()}
      </div>
    </div>
  );
};

export default LeaveManagement;