import React, { useState, useEffect } from 'react';
import { Clock, CheckCircle, XCircle, Save, AlertCircle, Calendar, BarChart3, Filter, X, Download, Eye } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import * as XLSX from 'xlsx';

const CheckInCheckOut = () => {
  const { user, logout } = useAuth();
  const [currentStatus, setCurrentStatus] = useState(null);
  const [workUpdate, setWorkUpdate] = useState('');
  const [showWorkUpdateModal, setShowWorkUpdateModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [todayRecords, setTodayRecords] = useState([]);
  const [monthlyRecords, setMonthlyRecords] = useState([]);
  const [filteredRecords, setFilteredRecords] = useState([]);
  const [error, setError] = useState('');
  const [showDateFilter, setShowDateFilter] = useState(false);
  const [dateFilter, setDateFilter] = useState({
    startDate: '',
    endDate: ''
  });
  const [hoveredWorkUpdate, setHoveredWorkUpdate] = useState(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [showDownloadDropdown, setShowDownloadDropdown] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [previewData, setPreviewData] = useState([]);
  const [downloadType, setDownloadType] = useState('');
  const [selectedShift, setSelectedShift] = useState('');
  const [showLocationErrorModal, setShowLocationErrorModal] = useState(false);
  const [locationErrorMessage, setLocationErrorMessage] = useState('');
  const [currentAction, setCurrentAction] = useState(null);
  const [userLocation, setUserLocation] = useState({ latitude: null, longitude: null });

  const shiftOptions = [
    { value: '6.00AM-2.00PM', label: '6:00 AM - 2:00 PM' },
    { value: '9.00AM-6.00PM', label: '9:00 AM - 6:00 PM' },
    { value: '2.00PM-10.00PM', label: '2:00 PM - 10:00 PM' }
  ];

  const TARGET_LOCATION = {
    latitude: 17.4343250,
    longitude: 78.4449292,
    radius: 100 // 100 meters
  };

  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371e3; // Earth's radius in meters
    const φ1 = (lat1 * Math.PI) / 180;
    const φ2 = (lat2 * Math.PI) / 180;
    const Δφ = ((lat2 - lat1) * Math.PI) / 180;
    const Δλ = ((lon2 - lon1) * Math.PI) / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const checkUserLocation = async () => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported by your browser. Please use a device that supports geolocation.'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLocation({ latitude, longitude });
          const distance = calculateDistance(
            latitude,
            longitude,
            TARGET_LOCATION.latitude,
            TARGET_LOCATION.longitude
          );

          if (distance <= TARGET_LOCATION.radius) {
            resolve(true);
          } else {
            reject(new Error('You are not within the allowed location (100m radius) to check in or out.'));
          }
        },
        (error) => {
          if (error.code === error.PERMISSION_DENIED) {
            reject(new Error('Location access denied. Please enable location services in your browser settings to check in or out.'));
          } else if (error.code === error.POSITION_UNAVAILABLE) {
            reject(new Error('Location information is unavailable. Please ensure your device has a clear GPS signal.'));
          } else if (error.code === error.TIMEOUT) {
            reject(new Error('Location request timed out. Please try again.'));
          } else {
            reject(new Error('Unable to retrieve location. Please try again.'));
          }
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    });
  };

  useEffect(() => {
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth() + 1;
    
    if (selectedYear === currentYear && selectedMonth > currentMonth) {
      setSelectedMonth(currentMonth);
    }
  }, [selectedYear]);

  useEffect(() => {
    if (user) {
      fetchTodayStatus();
      fetchMonthlyRecords(selectedMonth, selectedYear);
    }
  }, [user]);

  useEffect(() => {
    if (user && selectedMonth && selectedYear) {
      fetchMonthlyRecords(selectedMonth, selectedYear);
    }
  }, [selectedMonth, selectedYear, user]);

  useEffect(() => {
    applyDateFilter();
  }, [monthlyRecords, dateFilter]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (showDownloadDropdown && !event.target.closest('.relative')) {
        setShowDownloadDropdown(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showDownloadDropdown]);

  const fetchTodayStatus = async () => {
    if (!user) return;
    
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/attendance/today/${user.id}`);
      if (response.ok) {
        const data = await response.json();
        setCurrentStatus(data.status);
        setTodayRecords(data.records || []);
        setError('');
      } else {
        const errorText = await response.text();
        setError(`Failed to fetch today's status: ${errorText || response.statusText}`);
      }
    } catch (error) {
      setError('Unable to fetch today\'s status. Please check your connection.');
    }
  };

  const fetchMonthlyRecords = async (month, year) => {
    if (!user) return;
    
    try {
      const targetMonth = parseInt(month) || selectedMonth;
      const targetYear = parseInt(year) || selectedYear;
      const url = `${import.meta.env.VITE_API_BASE_URL}/api/attendance/monthly/${user.id}?month=${encodeURIComponent(targetMonth)}&year=${encodeURIComponent(targetYear)}`;
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setMonthlyRecords(data.records || []);
        setError('');
      } else {
        const errorText = await response.text();
        setError(`Failed to fetch monthly records: ${errorText || response.statusText}`);
      }
    } catch (error) {
      setError('Unable to fetch monthly records. Please check your connection.');
    }
  };

  const handleCheckIn = async () => {
    if (!user) return;
    
    const hasCheckedOut = todayRecords.some(record => record.check_out_time);
    if (hasCheckedOut) {
      setError('You have already completed your work for today. Check-in is only allowed once per day.');
      return;
    }

    if (!selectedShift) {
      setError('Please select a shift timing before checking in.');
      return;
    }

    setLoading(true);
    setCurrentAction('check-in');

    try {
      await checkUserLocation();
      const currentTime = new Date();
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/attendance/checkin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          timestamp: currentTime.toISOString(),
          timezone: 'Asia/Kolkata',
          shiftTimings: selectedShift,
          latitude: userLocation.latitude,
          longitude: userLocation.longitude
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Check-in failed');
      }

      setCurrentStatus('checked-in');
      setSelectedShift('');
      await Promise.all([
        fetchTodayStatus(),
        fetchMonthlyRecords(selectedMonth, selectedYear)
      ]);
    } catch (error) {
      setLocationErrorMessage(error.message || 'Check-in failed due to location error.');
      setShowLocationErrorModal(true);
    } finally {
      setLoading(false);
    }
  };

  const handleCheckOut = async () => {
    if (!user) return;
    
    if (!workUpdate.trim()) {
      setError('');
      setShowWorkUpdateModal(true);
      return;
    }

    setLoading(true);
    setCurrentAction('check-out');

    try {
      await checkUserLocation();
      const currentTime = new Date();
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/attendance/checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          workUpdate: workUpdate.trim(),
          timestamp: currentTime.toISOString(),
          timezone: 'Asia/Kolkata',
          latitude: userLocation.latitude,
          longitude: userLocation.longitude
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Check-out failed');
      }

      setCurrentStatus('checked-out');
      setWorkUpdate('');
      setShowWorkUpdateModal(false);
      await Promise.all([
        fetchTodayStatus(),
        fetchMonthlyRecords(selectedMonth, selectedYear)
      ]);
    } catch (error) {
      setLocationErrorMessage(error.message || 'Check-out failed due to location error.');
      setShowLocationErrorModal(true);
    } finally {
      setLoading(false);
    }
  };

  const handleLocationRetry = async () => {
    setShowLocationErrorModal(false);
    setLocationErrorMessage('');
    setLoading(true);
    if (currentAction === 'check-in') {
      await handleCheckIn();
    } else if (currentAction === 'check-out') {
      await handleCheckOut();
    }
  };

  const handleLocationCancel = () => {
    setShowLocationErrorModal(false);
    setLocationErrorMessage('');
    setCurrentAction(null);
    setLoading(false);
  };

  const renderActionButton = () => {
    const hasCheckedOutToday = todayRecords.some(record => record.check_out_time);
    
    if (currentStatus === 'checked-in') {
      return (
        <button
          onClick={handleCheckOut}
          disabled={loading}
          className="inline-flex items-center px-6 py-2 sm:px-8 sm:py-3 text-sm sm:text-base text-white bg-red-500 hover:bg-red-600 rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed transition-colors w-full sm:w-auto"
        >
          <XCircle className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
          {loading ? 'Processing...' : 'Check Out'}
        </button>
      );
    } else if (hasCheckedOutToday) {
      return (
        <div className="text-center">
          <button
            disabled={true}
            className="inline-flex items-center px-6 py-2 sm:px-8 sm:py-3 text-sm sm:text-base text-gray-500 bg-gray-200 rounded-lg font-medium cursor-not-allowed w-full sm:w-auto"
          >
            <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
            Work Completed
          </button>
          <p className="text-xs sm:text-sm text-gray-600 mt-2">
            You have already completed your work for today. Check-in is only allowed once per day.
          </p>
        </div>
      );
    } else {
      return (
        <button
          onClick={handleCheckIn}
          disabled={loading}
          className="inline-flex items-center px-6 py-2 sm:px-8 sm:py-3 text-sm sm:text-base text-white bg-green-500 hover:bg-green-600 rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed transition-colors w-full sm:w-auto"
        >
          <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
          {loading ? 'Processing...' : 'Check In'}
        </button>
      );
    }
  };

  const handleModalSubmit = () => {
    if (workUpdate.trim()) {
      handleCheckOut();
    } else {
      setError('Please enter a work update before checking out.');
    }
  };

  const handleModalCancel = () => {
    setShowWorkUpdateModal(false);
    setWorkUpdate('');
    setError('');
  };

  const applyDateFilter = () => {
    if (!dateFilter.startDate && !dateFilter.endDate) {
      setFilteredRecords(monthlyRecords);
      return;
    }

    const filtered = monthlyRecords.filter(record => {
      const recordDate = new Date(record.date);
      const startDate = dateFilter.startDate ? new Date(dateFilter.startDate) : null;
      const endDate = dateFilter.endDate ? new Date(dateFilter.endDate) : null;

      if (startDate && endDate) {
        return recordDate >= startDate && recordDate <= endDate;
      } else if (startDate) {
        return recordDate >= startDate;
      } else if (endDate) {
        return recordDate <= endDate;
      }
      return true;
    });

    setFilteredRecords(filtered);
  };

  const clearDateFilter = () => {
    setDateFilter({ startDate: '', endDate: '' });
    setShowDateFilter(false);
  };

  const getTodayDate = () => {
    return new Date().toISOString().split('T')[0];
  };

  const formatTime = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
      timeZone: 'Asia/Kolkata'
    });
  };

  const formatDate = (timestamp) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      timeZone: 'Asia/Kolkata'
    });
  };

  const formatDateShort = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      timeZone: 'Asia/Kolkata'
    });
  };

  const getCurrentTime = () => {
    return new Date().toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
      timeZone: 'Asia/Kolkata'
    });
  };

  const handleMonthYearChange = (month, year) => {
    setSelectedMonth(month);
    setSelectedYear(year);
    fetchMonthlyRecords(month, year);
  };

  const calculateMonthlyStats = () => {
    const recordsToUse = filteredRecords.length > 0 ? filteredRecords : monthlyRecords;
    
    if (!recordsToUse.length) {
      return { totalDays: 0, totalHours: '0h 0m', avgHours: '0h 0m' };
    }
    
    const totalDays = recordsToUse.length;
    let totalMinutes = 0;
    
    recordsToUse.forEach((record) => {
      if (record.work_hours && record.work_hours !== '--') {
        const match = record.work_hours.match(/(\d+)h\s*(\d+)m/);
        if (match) {
          const hours = parseInt(match[1]);
          const minutes = parseInt(match[2]);
          totalMinutes += hours * 60 + minutes;
        }
      }
    });
    
    const totalHours = Math.floor(totalMinutes / 60);
    const remainingMinutes = totalMinutes % 60;
    const avgMinutes = Math.floor(totalMinutes / totalDays);
    const avgHours = Math.floor(avgMinutes / 60);
    const avgRemainingMinutes = avgMinutes % 60;
    
    return {
      totalDays,
      totalHours: `${totalHours}h ${remainingMinutes}m`,
      avgHours: `${avgHours}h ${avgRemainingMinutes}m`
    };
  };

  const fetchAllAttendanceData = async () => {
    if (!user) return [];
    
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/attendance/all/${user.id}`);
      if (response.ok) {
        const data = await response.json();
        return data.records || [];
      }
      return [];
    } catch (error) {
      setError('Error fetching all records.');
      return [];
    }
  };

  const handleDownloadOption = async (type) => {
    setDownloadType(type);
    setShowDownloadDropdown(false);
    
    let dataToPreview = [];
    
    if (type === 'monthly') {
      dataToPreview = monthlyRecords;
    } else if (type === 'all') {
      dataToPreview = await fetchAllAttendanceData();
    }
    
    setPreviewData(dataToPreview);
    setShowPreviewModal(true);
  };

  const formatDataForExcel = (data) => {
    return data.map((record, index) => ({
      'S.No': index + 1,
      'Date': formatDateShort(record.date),
      'Check In': record.check_in_time ? formatTime(record.check_in_time) : '--',
      'Check Out': record.check_out_time ? formatTime(record.check_out_time) : '--',
      'Work Hours': record.work_hours || '--',
      'Shift Timing': record.shift_timings || '--',
      'Work Update': record.work_update || '--'
    }));
  };

  const downloadExcel = () => {
    const formattedData = formatDataForExcel(previewData);
    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    const workbook = XLSX.utils.book_new();
    
    const fileName = downloadType === 'monthly' 
      ? `attendance_${selectedMonth}_${selectedYear}.xlsx`
      : `attendance_all_data.xlsx`;
      
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Attendance');
    XLSX.writeFile(workbook, fileName);
    
    setShowPreviewModal(false);
  };

  const [currentTime, setCurrentTime] = useState(getCurrentTime());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(getCurrentTime());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (!user) return null;

  const monthlyStats = calculateMonthlyStats();
  const recordsToDisplay = filteredRecords.length > 0 || dateFilter.startDate || dateFilter.endDate ? filteredRecords : monthlyRecords;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-2 sm:p-4 md:p-6">
      <div className="max-w-full sm:max-w-4xl mx-auto space-y-4 sm:space-y-6">
        <div className="bg-white rounded-lg shadow-sm border">
          <div className="p-4 sm:p-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-0">
              <div className="space-y-1">
                <h1 className="text-lg sm:text-2xl font-bold text-gray-800">Attendance System</h1>
                <p className="text-xs sm:text-sm text-gray-600">Welcome, {user.name}</p>
                <div className="flex flex-wrap items-center gap-2 mt-1">
                  <span className="inline-flex items-center rounded-full bg-gray-100 px-2 py-0.5 text-xs font-semibold text-gray-800">
                    {user.role}
                  </span>
                  {user.department && (
                    <span className="inline-flex items-center rounded-full border border-gray-300 px-2 py-0.5 text-xs font-semibold text-gray-700">
                        {user.department}
                    </span>
                  )}
                </div>
              </div>
              <div className="text-right">
                <div className="text-xl sm:text-3xl font-mono text-blue-600">{currentTime}</div>
                <div className="text-xs sm:text-sm text-gray-500">{formatDate(new Date())}</div>
              </div>
            </div>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 sm:p-4">
            <div className="flex items-center">
              <AlertCircle className="h-4 w-4 text-red-400 mr-2" />
              <span className="text-xs sm:text-sm text-red-700">{error}</span>
            </div>
          </div>
        )}

        <div className="bg-white rounded-lg shadow-sm border">
          <div className="p-4 sm:p-6 md:p-8">
            <div className="text-center">
              {currentStatus !== 'checked-in' && (
                <div className="mb-4 sm:mb-6 flex justify-start">
                  <div className="text-left w-full max-w-xs">
                    <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1 sm:mb-2">
                      Select Shift Timing
                    </label>
                    <select
                      value={selectedShift}
                      onChange={(e) => setSelectedShift(e.target.value)}
                      className="w-full px-2 py-1.5 sm:px-3 sm:py-2 border border-gray-300 rounded-md text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    >
                      <option value="">Choose shift timing</option>
                      {shiftOptions.map((shift) => (
                        <option key={shift.value} value={shift.value}>
                          {shift.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              )}

              <div className="mb-6 sm:mb-8">
                <Clock className="w-12 h-12 sm:w-16 sm:h-16 mx-auto text-blue-500 mb-3 sm:mb-4" />
                <h2 className="text-lg sm:text-2xl font-semibold text-gray-800 mb-2">
                  {(() => {
                    const hasCheckedOutToday = todayRecords.some(record => record.check_out_time);
                    if (currentStatus === 'checked-in') {
                      return 'You are checked in';
                    } else if (hasCheckedOutToday) {
                      return 'Work completed for today';
                    } else if (currentStatus === 'checked-out') {
                      return 'You are checked out';
                    } else {
                      return 'Ready to start your day?';
                    }
                  })()}
                </h2>
                
                {currentStatus === 'checked-in' && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-3 sm:p-4 mb-4 sm:mb-6">
                    <div className="flex items-center justify-center text-green-700">
                      <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                      <span className="text-xs sm:text-sm">Checked in at {todayRecords[0]?.check_in_time ? formatTime(todayRecords[0].check_in_time) : '--'}</span>
                    </div>
                  </div>
                )}

                {(() => {
                  const hasCheckedOutToday = todayRecords.some(record => record.check_out_time);
                  const checkoutRecord = todayRecords.find(record => record.check_out_time);
                  if (hasCheckedOutToday && checkoutRecord) {
                    return (
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 sm:p-4 mb-4 sm:mb-6">
                        <div className="text-blue-700 text-center">
                          <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 mx-auto mb-2" />
                          <div className="text-xs sm:text-sm">Work completed at {formatTime(checkoutRecord.check_out_time)}</div>
                          <div className="text-xs sm:text-sm mt-1">Total work hours: {checkoutRecord.work_hours || '--'}</div>
                        </div>
                      </div>
                    );
                  }
                  return null;
                })()}
              </div>

              <div className="space-y-3 sm:space-y-4">
                {renderActionButton()}
              </div>
            </div>
          </div>
        </div>

        {todayRecords.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm border">
            <div className="p-4 sm:p-6 border-b">
              <h3 className="text-base sm:text-lg font-semibold">Today's Activity</h3>
            </div>
            <div className="p-4 sm:p-6">
              <div className="space-y-3">
                {todayRecords.map((record, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-3 sm:p-4">
                    <div className="md:hidden space-y-2 text-xs sm:text-sm">
                      <div><span className="font-medium">Check In:</span> {record.check_in_time ? formatTime(record.check_in_time) : '--'}</div>
                      <div><span className="font-medium">Check Out:</span> {record.check_out_time ? formatTime(record.check_out_time) : '--'}</div>
                      <div><span className="font-medium">Work Hours:</span> {record.work_hours || '--'}</div>
                      {record.work_update && (
                        <div className="pt-2 border-t border-gray-100">
                          <span className="font-medium">Work Update:</span> {record.work_update}
                        </div>
                      )}
                    </div>
                    <div className="hidden md:grid grid-cols-3 gap-3 sm:gap-4">
                      <div>
                        <span className="text-xs sm:text-sm text-gray-500">Check In</span>
                        <div className="font-medium text-sm">{record.check_in_time ? formatTime(record.check_in_time) : '--'}</div>
                      </div>
                      <div>
                        <span className="text-xs sm:text-sm text-gray-500">Check Out</span>
                        <div className="font-medium text-sm">{record.check_out_time ? formatTime(record.check_out_time) : '--'}</div>
                      </div>
                      <div>
                        <span className="text-xs sm:text-sm text-gray-500">Work Hours</span>
                        <div className="font-medium text-sm">{record.work_hours || '--'}</div>
                      </div>
                      {record.work_update && (
                        <div className="col-span-3 mt-3 pt-3 border-t border-gray-100">
                          <span className="text-xs sm:text-sm text-gray-500">Work Update</span>
                          <div className="text-xs sm:text-sm text-gray-700 mt-1">{record.work_update}</div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="bg-white rounded-lg shadow-sm border">
          <div className="p-4 sm:p-6 border-b">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-0">
              <div className="flex flex-wrap items-center gap-2">
                <Calendar className="w-4 h-4 sm:w-5 sm:h-5 text-blue-500 mr-2" />
                <h3 className="text-base sm:text-lg font-semibold">Monthly Report</h3>
                <select 
                  value={selectedMonth} 
                  onChange={(e) => handleMonthYearChange(parseInt(e.target.value), selectedYear)}
                  className="px-2 py-1 border border-gray-300 rounded text-xs sm:text-sm"
                >
                  {Array.from({length: 12}, (_, i) => {
                    const monthIndex = i + 1;
                    const monthName = new Date(2024, i).toLocaleDateString('en-US', { month: 'long' });
                    const currentDate = new Date();
                    const currentYear = currentDate.getFullYear();
                    const currentMonth = currentDate.getMonth() + 1;
                    const isDisabled = selectedYear === currentYear && monthIndex > currentMonth;
                    return (
                      <option key={monthIndex} value={monthIndex} disabled={isDisabled}>
                        {monthName}
                      </option>
                    );
                  })}
                </select>
                <select 
                  value={selectedYear} 
                  onChange={(e) => handleMonthYearChange(selectedMonth, parseInt(e.target.value))}
                  className="px-2 py-1 border border-gray-300 rounded text-xs sm:text-sm"
                >
                  {Array.from({length: 10}, (_, i) => {
                    const year = new Date().getFullYear() - i;
                    return <option key={year} value={year}>{year}</option>
                  })}
                </select>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowDateFilter(!showDateFilter)}
                  className="inline-flex items-center px-2 py-1 sm:px-3 sm:py-2 text-xs sm:text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  <Filter className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                  Filter by Date
                </button>
                <div className="relative">
                  <button
                    onClick={() => setShowDownloadDropdown(!showDownloadDropdown)}
                    className="inline-flex items-center px-2 py-1 sm:px-3 sm:py-2 text-xs sm:text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    <Download className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                    Download
                  </button>
                  {showDownloadDropdown && (
                    <div className="absolute right-0 mt-2 w-40 sm:w-48 bg-white border border-gray-200 rounded-md shadow-lg z-10">
                      <div className="py-1">
                        <button
                          onClick={() => handleDownloadOption('monthly')}
                          className="w-full text-left px-3 sm:px-4 py-1 sm:py-2 text-xs sm:text-sm text-gray-700 hover:bg-gray-100"
                        >
                          Download Monthly Data
                        </button>
                        <button
                          onClick={() => handleDownloadOption('all')}
                          className="w-full text-left px-3 sm:px-4 py-1 sm:py-2 text-xs sm:text-sm text-gray-700 hover:bg-gray-100"
                        >
                          Download All Data
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {showDateFilter && (
            <div className="p-4 sm:p-6 border-b bg-gray-50">
              <div className="flex items-center justify-between mb-3 sm:mb-4">
                <h4 className="text-xs sm:text-sm font-semibold text-gray-700">Filter by Date Range</h4>
                <button
                  onClick={() => setShowDateFilter(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-3 h-3 sm:w-4 sm:h-4" />
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
                <div>
                  <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">From Date</label>
                  <input
                    type="date"
                    max={getTodayDate()}
                    value={dateFilter.startDate}
                    onChange={(e) => setDateFilter(prev => ({ ...prev, startDate: e.target.value }))}
                    className="w-full px-2 py-1.5 sm:px-3 sm:py-2 border border-gray-300 rounded-md text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">To Date</label>
                  <input
                    type="date"
                    max={getTodayDate()}
                    value={dateFilter.endDate}
                    onChange={(e) => setDateFilter(prev => ({ ...prev, endDate: e.target.value }))}
                    className="w-full px-2 py-1.5 sm:px-3 sm:py-2 border border-gray-300 rounded-md text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="flex items-end">
                  <button
                    onClick={clearDateFilter}
                    className="w-full px-2 py-1.5 sm:px-4 sm:py-2 text-xs sm:text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    Clear Filter
                  </button>
                </div>
              </div>
            </div>
          )}
          
          <div className="p-4 sm:p-6 border-b bg-gray-50">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
              <div className="text-center">
                <div className="text-xl sm:text-2xl font-bold text-blue-600">{monthlyStats.totalDays}</div>
                <div className="text-xs sm:text-sm text-gray-500">Days Worked</div>
              </div>
              <div className="text-center">
                <div className="text-xl sm:text-2xl font-bold text-green-600">{monthlyStats.totalHours}</div>
                <div className="text-xs sm:text-sm text-gray-500">Total Hours</div>
              </div>
              <div className="text-center">
                <div className="text-xl sm:text-2xl font-bold text-purple-600">{monthlyStats.avgHours}</div>
                <div className="text-xs sm:text-sm text-gray-500">Average Hours/Day</div>
              </div>
            </div>
          </div>

          <div className="p-4 sm:p-6">
            {recordsToDisplay.length > 0 ? (
              <div>
                <div className="md:hidden space-y-3">
                  {recordsToDisplay.map((record, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-3 sm:p-4 bg-white">
                      <div className="space-y-2 text-xs sm:text-sm">
                        <div><span className="font-medium">Date:</span> {formatDateShort(record.date)}</div>
                        <div><span className="font-medium">Check In:</span> {record.check_in_time ? formatTime(record.check_in_time) : '--'}</div>
                        <div><span className="font-medium">Check Out:</span> {record.check_out_time ? formatTime(record.check_out_time) : '--'}</div>
                        <div><span className="font-medium">Work Hours:</span> {record.work_hours || '--'}</div>
                        <div><span className="font-medium">Shift Timing:</span> {record.shift_timings || '--'}</div>
                        <div
                          className="break-words"
                          onMouseEnter={() => record.work_update && record.work_update.length > 50 && setHoveredWorkUpdate(record.work_update)}
                          onMouseLeave={() => setHoveredWorkUpdate(null)}
                          onMouseMove={(e) => {
                            if (hoveredWorkUpdate) {
                              setMousePosition({ x: e.clientX, y: e.clientY });
                            }
                          }}
                        >
                          <span className="font-medium">Work Update:</span> {record.work_update || '--'}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <table className="hidden md:table min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-3 sm:px-6 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="px-3 sm:px-6 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Check In
                      </th>
                      <th className="px-3 sm:px-6 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Check Out
                      </th>
                      <th className="px-3 sm:px-6 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Work Hours
                      </th>
                      <th className="px-3 sm:px-6 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Work Update
                      </th>
                      <th className="px-3 sm:px-6 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Shift Timing
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {recordsToDisplay.map((record, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-3 sm:px-6 py-3 sm:py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {formatDateShort(record.date)}
                        </td>
                        <td className="px-3 sm:px-6 py-3 sm:py-4 whitespace-nowrap text-sm text-gray-500">
                          {record.check_in_time ? formatTime(record.check_in_time) : '--'}
                        </td>
                        <td className="px-3 sm:px-6 py-3 sm:py-4 whitespace-nowrap text-sm text-gray-500">
                          {record.check_out_time ? formatTime(record.check_out_time) : '--'}
                        </td>
                        <td className="px-3 sm:px-6 py-3 sm:py-4 whitespace-nowrap text-sm text-gray-500">
                          {record.work_hours || '--'}
                        </td>
                        <td className="px-3 sm:px-6 py-3 sm:py-4 text-sm text-gray-500 max-w-xs relative">
                          <div
                            className="truncate cursor-pointer hover:text-blue-600"
                            onMouseEnter={(e) => {
                              if (record.work_update && record.work_update.length > 50) {
                                setHoveredWorkUpdate(record.work_update);
                                setMousePosition({ x: e.clientX, y: e.clientY });
                              }
                            }}
                            onMouseLeave={() => setHoveredWorkUpdate(null)}
                            onMouseMove={(e) => {
                              if (hoveredWorkUpdate) {
                                setMousePosition({ x: e.clientX, y: e.clientY });
                              }
                            }}
                          >
                            {record.work_update || '--'}
                          </div>
                        </td>
                        <td className="px-3 sm:px-6 py-3 sm:py-4 whitespace-nowrap text-sm text-gray-500">
                          {record.shift_timings || '--'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-6 sm:py-8 text-gray-500">
                <Calendar className="w-10 h-10 sm:w-12 sm:h-12 mx-auto mb-3 sm:mb-4 text-gray-300" />
                <p className="text-xs sm:text-sm">
                  {(dateFilter.startDate || dateFilter.endDate) 
                    ? 'No attendance records found for the selected date range.'
                    : 'No attendance records found for this month.'}
                </p>
              </div>
            )}
          </div>
        </div>

        {hoveredWorkUpdate && (
          <div
            className="fixed z-50 pointer-events-none"
            style={{
              left: mousePosition.x + 10,
              top: mousePosition.y - 10,
              maxWidth: '250px sm:max-w-300px'
            }}
          >
            <div className="bg-gray-800 text-white text-xs sm:text-sm rounded-lg shadow-lg p-2 sm:p-3">
              <div className="break-words">{hoveredWorkUpdate}</div>
              <div className="absolute -left-1 top-3 w-2 h-2 bg-gray-800 transform rotate-45"></div>
            </div>
          </div>
        )}

        {/* Work Update Modal */}
        {showWorkUpdateModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-2 sm:p-4 z-50">
            <div className="bg-white rounded-lg shadow-lg max-w-xs sm:max-w-md w-full">
              <div className="p-4 sm:p-6 border-b">
                <div className="flex items-center">
                  <AlertCircle className="w-5 h-5 sm:w-6 sm:h-6 text-orange-500 mr-2" />
                  <h3 className="text-base sm:text-lg font-semibold">Work Update Required</h3>
                </div>
              </div>
              <div className="p-4 sm:p-6 space-y-3 sm:space-y-4">
                <p className="text-xs sm:text-sm text-gray-600">
                  Please provide a brief update about your work before checking out.
                </p>
                <textarea
                  value={workUpdate}
                  onChange={(e) => setWorkUpdate(e.target.value)}
                  placeholder="Enter your work update here..."
                  rows={4}
                  autoFocus
                  className="w-full p-2 sm:p-3 border border-gray-300 rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
                  <button
                    onClick={handleModalCancel}
                    className="flex-1 px-3 sm:px-4 py-1.5 sm:py-2 border border-gray-300 rounded-md text-xs sm:text-sm text-gray-700 hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleModalSubmit}
                    disabled={!workUpdate.trim() || loading}
                    className="flex-1 px-3 sm:px-4 py-1.5 sm:py-2 bg-blue-600 text-white rounded-md text-xs sm:text-sm hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                  >
                    <Save className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                    {loading ? 'Saving...' : 'Submit & Check Out'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Location Error Modal */}
        {showLocationErrorModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-2 sm:p-4 z-50">
            <div className="bg-white rounded-lg shadow-lg max-w-xs sm:max-w-md w-full">
              <div className="p-4 sm:p-6 border-b border-gray-200">
                <div className="flex items-center">
                  <AlertCircle className="w-5 h-5 sm:w-6 sm:h-6 text-orange-500 mr-2" />
                  <h3 className="text-base sm:text-lg font-semibold">Location Error</h3>
                </div>
              </div>
              <div className="p-4 sm:p-6 space-y-3 sm:space-y-4">
                <p className="text-xs sm:text-sm text-gray-600">{locationErrorMessage}</p>
                <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
                  <button
                    onClick={handleLocationCancel}
                    className="flex-1 px-3 sm:px-4 py-1.5 sm:py-2 border border-gray-300 rounded-md text-xs sm:text-sm text-gray-700 hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleLocationRetry}
                    disabled={loading}
                    className="flex-1 px-3 sm:px-4 py-1.5 sm:py-2 bg-blue-600 text-white rounded-md text-xs sm:text-sm hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Retry
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Preview Modal */}
        {showPreviewModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-2 sm:p-4 z-50">
            <div className="bg-white rounded-lg shadow-lg max-w-full sm:max-w-4xl w-full max-h-[80vh] overflow-hidden">
              <div className="p-4 sm:p-6 border-b flex items-center justify-between">
                <div className="flex items-center">
                  <Eye className="w-5 h-5 sm:w-6 sm:h-6 text-blue-500 mr-2" />
                  <h3 className="text-base sm:text-lg font-semibold">
                    Preview - {downloadType === 'monthly' ? 'Monthly Data' : 'All Data'} ({previewData.length})
                  </h3>
                </div>
                <button
                  onClick={() => setShowPreviewModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5 sm:w-6 sm:h-6" />
                </button>
              </div>
              <div className="p-4 sm:p-6 overflow-auto max-h-[50vh] sm:max-h-[60vh]">
                {previewData.length > 0 ? (
                  <div>
                    <div className="md:hidden space-y-3">
                      {previewData.slice(0, 10).map((record, index) => (
                        <div key={index} className="border border-gray-200 rounded-lg p-3 sm:p-4 bg-white">
                          <div className="space-y-2 text-xs sm:text-sm">
                            <div><span className="font-medium">S.No:</span> {index + 1}</div>
                            <div><span className="font-medium">Date:</span> {formatDateShort(record.date)}</div>
                            <div><span className="font-medium">Check In:</span> {record.check_in_time ? formatTime(record.check_in_time) : '--'}</div>
                            <div><span className="font-medium">Check Out:</span> {record.check_out_time ? formatTime(record.check_out_time) : '--'}</div>
                            <div><span className="font-medium">Work Hours:</span> {record.work_hours || '--'}</div>
                            <div><span className="font-medium">Shift Timing:</span> {record.shift_timings || '--'}</div>
                            <div><span className="font-medium">Work Update:</span> {record.work_update || '--'}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                    <table className="hidden md:table min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-3 sm:px-4 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase">S.No</th>
                          <th className="px-3 sm:px-4 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                          <th className="px-3 sm:px-4 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase">Check In</th>
                          <th className="px-3 sm:px-4 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase">Check Out</th>
                          <th className="px-3 sm:px-4 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase">Work Hours</th>
                          <th className="px-3 sm:px-4 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase">Shift Timing</th>
                          <th className="px-3 sm:px-4 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase">Work Update</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {previewData.slice(0, 10).map((record, index) => (
                          <tr key={index} className="hover:bg-gray-50">
                            <td className="px-3 sm:px-4 py-3 sm:py-4 text-sm text-gray-900">{index + 1}</td>
                            <td className="px-3 sm:px-4 py-3 sm:py-4 text-sm text-gray-900">{formatDateShort(record.date)}</td>
                            <td className="px-3 sm:px-4 py-3 sm:py-4 text-sm text-gray-500">{record.check_in_time ? formatTime(record.check_in_time) : '--'}</td>
                            <td className="px-3 sm:px-4 py-3 sm:py-4 text-sm text-gray-500">{record.check_out_time ? formatTime(record.check_out_time) : '--'}</td>
                            <td className="px-3 sm:px-4 py-3 sm:py-4 text-sm text-gray-500">{record.work_hours || '--'}</td>
                            <td className="px-3 sm:px-4 py-3 sm:py-4 text-sm text-gray-500">{record.shift_timings || '--'}</td>
                            <td className="px-3 sm:px-4 py-3 sm:py-4 text-sm text-gray-500 max-w-xs truncate">{record.work_update || '--'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {previewData.length > 10 && (
                      <div className="text-center py-3 sm:py-4 text-gray-500 text-xs sm:text-sm">
                        ... and {previewData.length - 10} more records
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-6 sm:py-8 text-gray-500">
                    <Calendar className="w-10 h-10 sm:w-12 sm:h-12 mx-auto mb-3 sm:mb-4 text-gray-300" />
                    <p className="text-xs sm:text-sm">No data available for download.</p>
                  </div>
                )}
              </div>
              <div className="p-4 sm:p-6 border-t bg-gray-50 flex flex-col sm:flex-row justify-end gap-2 sm:gap-3">
                <button
                  onClick={() => setShowPreviewModal(false)}
                  className="px-3 sm:px-4 py-1.5 sm:py-2 border border-gray-300 rounded-md text-xs sm:text-sm text-gray-700 hover:bg-gray-50 w-full sm:w-auto"
                >
                  Cancel
                </button>
                <button
                  onClick={downloadExcel}
                  disabled={previewData.length === 0}
                  className="px-3 sm:px-4 py-1.5 sm:py-2 bg-blue-600 text-white rounded-md text-xs sm:text-sm hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center w-full sm:w-auto justify-center"
                >
                  <Download className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                  Download Excel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CheckInCheckOut;