import { useState, useEffect, useRef } from 'react';
import {
  Card, CardContent, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Loader2, FileText, Image, File, Download, Eye } from 'lucide-react';
import { toast } from 'sonner';
import axios from 'axios';
import { useAuth } from '@/contexts/AuthContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

const steps = ['Select Employee', 'Upload Documents', 'Review & Submit'];

const InputGroup = ({ label, name, value, onChange, type = 'text', required = false, accept, multiple = false }) => (
  <div className="space-y-1">
    <Label htmlFor={name} className="text-sm">{label} {required && <span className="text-red-500">*</span>}</Label>
    <Input
      id={name}
      name={name}
      type={type}
      value={type !== 'file' ? value || '' : undefined}
      onChange={onChange}
      accept={accept}
      multiple={multiple}
      className="border-gray-300 focus:ring-2 focus:ring-blue-500 transition-colors h-10 w-full"
    />
  </div>
);

const SelectGroup = ({ label, name, value, onChange, options, required = false }) => (
  <div className="space-y-1">
    <Label htmlFor={name} className="text-sm">{label} {required && <span className="text-red-500">*</span>}</Label>
    <Select value={value || ''} onValueChange={(v) => onChange(name, v)} required={required}>
      <SelectTrigger id={name} className="border-gray-300 focus:ring-2 focus:ring-blue-500 transition-colors h-10 w-full">
        <SelectValue placeholder={`Select ${label}`} />
      </SelectTrigger>
      <SelectContent className="bg-white text-black border shadow-md rounded-md max-h-60 overflow-y-auto">
        {options.map(opt => (
          <SelectItem key={opt.id || opt} value={opt.id || opt} className="cursor-pointer hover:bg-gray-100 text-sm">
            {opt.name || opt}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  </div>
);

const UploadDocuments = () => {
  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const [employees, setEmployees] = useState([]);
  const [formData, setFormData] = useState({
    employeeId: '',
    aadhar: null,
    panCard: null,
    passport: null,
    drivingLicense: null,
    otherDocuments: [],
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [thumbnails, setThumbnails] = useState({});
  const canvasRefs = useRef({});
  const [pdfJsLoaded, setPdfJsLoaded] = useState(false);
  const [allDocuments, setAllDocuments] = useState([]);
  const [showDocumentsGrid, setShowDocumentsGrid] = useState(false);

  const isAdmin = user?.role === 'Admin';
  const isHR = user?.role === 'HR';

  useEffect(() => {
    if (!isAdmin && !isHR) {
      toast.error('Access denied. Only Admin or HR can upload documents.');
      return;
    }
    const fetchEmployees = async () => {
      try {
        setIsLoading(true);
        const response = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/employees`, {
          params: { role: user.role, name: user.name },
        });
        setEmployees(response.data);
      } catch (error) {
        toast.error('Failed to load employees');
      } finally {
        setIsLoading(false);
      }
    };
    fetchEmployees();
  }, [user, isAdmin, isHR]);

  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.7.76/pdf.min.mjs';
    script.async = true;
    script.type = 'module';
    script.onload = () => {
      if (window.pdfjsLib) {
        window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.7.76/pdf.worker.min.mjs';
        setPdfJsLoaded(true);
      } else {
        console.error('pdf.js failed to load');
      }
    };
    script.onerror = () => {
      console.error('Failed to load pdf.js script');
      setPdfJsLoaded(false);
    };
    document.body.appendChild(script);
    return () => document.body.removeChild(script);
  }, []);

  useEffect(() => {
    const generateThumbnails = async () => {
      const newThumbnails = {};
      const files = [
        { label: 'Aadhar', file: formData.aadhar },
        { label: 'PAN Card', file: formData.panCard },
        { label: 'Passport', file: formData.passport },
        { label: 'Driving License', file: formData.drivingLicense },
        ...formData.otherDocuments.map((file, idx) => ({
          label: `Other Document ${idx + 1}`,
          file,
        })),
      ].filter(({ file }) => file);

      for (const { file, label } of files) {
        const key = `${label}-${file.name}`;
        if (file.name.toLowerCase().endsWith('.pdf') && pdfJsLoaded) {
          try {
            const url = URL.createObjectURL(file);
            const pdf = await window.pdfjsLib.getDocument(url).promise;
            const page = await pdf.getPage(1);
            const viewport = page.getViewport({ scale: 0.2 });
            const canvas = canvasRefs.current[key];
            if (canvas) {
              const context = canvas.getContext('2d');
              canvas.width = viewport.width;
              canvas.height = viewport.height;
              await page.render({
                canvasContext: context,
                viewport,
              }).promise;
              newThumbnails[key] = canvas.toDataURL();
            }
            URL.revokeObjectURL(url);
          } catch (err) {
            console.error(`PDF thumbnail error for ${file.name}:`, err);
            newThumbnails[key] = null;
          }
        } else if (['jpg', 'jpeg', 'png'].includes(file.name.toLowerCase().split('.').pop())) {
          newThumbnails[key] = URL.createObjectURL(file);
        } else {
          newThumbnails[key] = null;
        }
      }
      setThumbnails(newThumbnails);
    };

    if (step === 3) {
      generateThumbnails();
    }

    return () => {
      Object.values(thumbnails).forEach(url => url && URL.revokeObjectURL(url));
    };
  }, [formData, step, pdfJsLoaded]);

  const fetchAllDocuments = async () => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/all-documents`, {
        headers: { 'x-user-role': user?.role || '' },
      });
      setAllDocuments(response.data.employees);
      setShowDocumentsGrid(true);
    } catch (err) {
      console.error('Fetch all documents error:', err);
      toast.error('Failed to fetch all documents');
    }
  };

  const handleInputChange = (e) => {
    const { name, files } = e.target;
    if (files && files[0]?.size > 5 * 1024 * 1024) {
      toast.error('File size must be under 5MB');
      return;
    }
    if (files) {
      setFormData(prev => ({
        ...prev,
        [name]: name === 'otherDocuments' ? Array.from(files) : files[0],
      }));
    }
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validateStep = (currentStep) => {
    const missingFields = [];
    if (currentStep === 1) {
      if (!formData.employeeId) missingFields.push('Employee');
    } else if (currentStep === 2) {
      if (!formData.aadhar && !formData.panCard && !formData.passport && !formData.drivingLicense && formData.otherDocuments.length === 0) {
        missingFields.push('At least one document');
      }
    }
    return missingFields;
  };

  const handleNext = () => {
    const missingFields = validateStep(step);
    if (missingFields.length > 0) {
      toast.error(`Please provide: ${missingFields.join(', ')}`);
      return;
    }
    setStep(prev => Math.min(prev + 1, steps.length));
  };

  const handleBack = () => {
    setStep(prev => Math.max(prev - 1, 1));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const missingFields = validateStep(step);
    if (missingFields.length > 0) {
      toast.error(`Please provide: ${missingFields.join(', ')}`);
      return;
    }

    setIsSubmitting(true);
    const data = new FormData();
    data.append('employeeId', formData.employeeId);
    if (formData.aadhar) data.append('aadhar', formData.aadhar);
    if (formData.panCard) data.append('panCard', formData.panCard);
    if (formData.passport) data.append('passport', formData.passport);
    if (formData.drivingLicense) data.append('drivingLicense', formData.drivingLicense);
    formData.otherDocuments.forEach((file) => {
      data.append('otherDocuments', file);
    });

    try {
      await axios.post(`${import.meta.env.VITE_API_BASE_URL}/api/upload-documents`, data, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'x-user-role': user?.role || '',
        },
      });
      toast.success('Documents uploaded successfully');
      await fetchAllDocuments();
      setFormData({
        employeeId: '',
        aadhar: null,
        panCard: null,
        passport: null,
        drivingLicense: null,
        otherDocuments: [],
      });
      setStep(1);
    } catch (err) {
      console.error('Frontend error:', err);
      toast.error(err.response?.data?.error || 'Failed to upload documents');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getFileIcon = (file) => {
    const extension = file.name.split('.').pop().toLowerCase();
    if (['jpg', 'jpeg', 'png'].includes(extension)) {
      return <Image className="w-5 h-5 text-blue-500" />;
    } else if (extension === 'pdf') {
      return <FileText className="w-5 h-5 text-red-500" />;
    } else if (['doc', 'docx'].includes(extension)) {
      return <File className="w-5 h-5 text-blue-700" />;
    }
    return <File className="w-5 h-5 text-gray-500" />;
  };

  const getFileIconByUrl = (url) => {
    const extension = url.split('.').pop().toLowerCase();
    if (['jpg', 'jpeg', 'png'].includes(extension)) {
      return <Image className="w-5 h-5 text-blue-500" />;
    } else if (extension === 'pdf') {
      return <FileText className="w-5 h-5 text-red-500" />;
    } else if (['doc', 'docx'].includes(extension)) {
      return <File className="w-5 h-5 text-blue-700" />;
    }
    return <File className="w-5 h-5 text-gray-500" />;
  };

  const handleDownload = (file) => {
    const url = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const canPreview = (file) => {
    const extension = file.name.split('.').pop().toLowerCase();
    return ['jpg', 'jpeg', 'png', 'pdf'].includes(extension);
  };

  const canPreviewByUrl = (url) => {
    const extension = url.split('.').pop().toLowerCase();
    return ['jpg', 'jpeg', 'png', 'pdf'].includes(extension);
  };

  const selectedEmployee = employees.find(emp => emp.id === formData.employeeId);

  return (
    <div className="max-w-4xl mx-auto px-4 py-4">
      <CardTitle className="text-base sm:text-lg text-gray-800 py-5">Upload Employee Documents</CardTitle>
      {/* Upload Documents Card */}
      <Card className="shadow-lg border border-gray-200 mb-6">
        <CardHeader className="border-b px-4 py-3 bg-gray-50">
          <CardTitle className="text-lg text-gray-800">{steps[step - 1]}</CardTitle>
        </CardHeader>
        <CardContent className="px-4 py-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {step === 1 && (
              <div className="grid grid-cols-1 gap-4">
                <SelectGroup
                  label="Employee"
                  name="employeeId"
                  value={formData.employeeId}
                  onChange={handleSelectChange}
                  options={employees.map(emp => ({ id: emp.id, name: emp.name }))}
                  required
                />
              </div>
            )}

            {step === 2 && (
              <div className="grid grid-cols-1 gap-4">
                <InputGroup
                  label="Aadhar"
                  name="aadhar"
                  type="file"
                  onChange={handleInputChange}
                  accept=".pdf,.jpg,.jpeg,.png"
                />
                <InputGroup
                  label="PAN Card"
                  name="panCard"
                  type="file"
                  onChange={handleInputChange}
                  accept=".pdf,.jpg,.jpeg,.png"
                />
                <InputGroup
                  label="Passport"
                  name="passport"
                  type="file"
                  onChange={handleInputChange}
                  accept=".pdf,.jpg,.jpeg,.png"
                />
                <InputGroup
                  label="Driving License"
                  name="drivingLicense"
                  type="file"
                  onChange={handleInputChange}
                  accept=".pdf,.jpg,.jpeg,.png"
                />
                <InputGroup
                  label="Other Documents"
                  name="otherDocuments"
                  type="file"
                  onChange={handleInputChange}
                  accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                  multiple
                />
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-800">Review Documents</h3>
                <p className="text-sm text-gray-600">Employee: {selectedEmployee?.name || 'Not selected'}</p>
                <div className="space-y-2">
                  {[
                    { label: 'Aadhar', file: formData.aadhar },
                    { label: 'PAN Card', file: formData.panCard },
                    { label: 'Passport', file: formData.passport },
                    { label: 'Driving License', file: formData.drivingLicense },
                    ...formData.otherDocuments.map((file, idx) => ({
                      label: `Other Document ${idx + 1}`,
                      file,
                    })),
                  ].map(({ label, file }, idx) => file ? (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-3 border rounded-md bg-white hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-center flex-1 space-x-3">
                        <div className="w-16 h-16 flex-shrink-0">
                          {thumbnails[`${label}-${file.name}`] ? (
                            <img
                              src={thumbnails[`${label}-${file.name}`]}
                              alt={`${file.name} thumbnail`}
                              className="w-full h-full object-contain rounded"
                            />
                          ) : file.name.toLowerCase().endsWith('.pdf') ? (
                            pdfJsLoaded ? (
                              <canvas
                                ref={el => (canvasRefs.current[`${label}-${file.name}`] = el)}
                                className="w-full h-full"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center bg-gray-100 rounded">
                                <FileText className="w-6 h-6 text-red-500" />
                              </div>
                            )
                          ) : (
                            <div className="w-full h-full flex items-center justify-center bg-gray-100 rounded">
                              {getFileIcon(file)}
                            </div>
                          )}
                        </div>
                        <div className="mr-3">{getFileIcon(file)}</div>
                        <div>
                          <p className="text-sm font-medium text-gray-800 break-all">{file.name}</p>
                          <p className="text-xs text-gray-500">{label}</p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              title={canPreview(file) ? 'Preview' : 'Preview not available'}
                              disabled={!canPreview(file)}
                              className={canPreview(file) ? 'text-blue-600 hover:bg-blue-100' : 'text-gray-400 cursor-not-allowed'}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          {canPreview(file) && (
                            <DialogContent className="w-[95vw] max-w-md sm:max-w-3xl">
                              <DialogHeader>
                                <DialogTitle className="text-base">{file.name}</DialogTitle>
                              </DialogHeader>
                              {file.name.toLowerCase().endsWith('.pdf') ? (
                                <iframe
                                  src={URL.createObjectURL(file)}
                                  className="w-full h-[60vh] sm:h-[70vh]"
                                  title={file.name}
                                />
                              ) : (
                                <img
                                  src={URL.createObjectURL(file)}
                                  alt={file.name}
                                  className="max-w-full max-h-[60vh] sm:max-h-[70vh] object-contain"
                                />
                              )}
                            </DialogContent>
                          )}
                        </Dialog>
                        <Button
                          variant="ghost"
                          size="icon"
                          title="Download"
                          onClick={() => handleDownload(file)}
                          className="text-green-600 hover:bg-green-100"
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ) : null)}
                </div>
                {![formData.aadhar, formData.panCard, formData.passport, formData.drivingLicense, ...formData.otherDocuments].some(Boolean) && (
                  <p className="text-sm text-gray-500">No documents selected.</p>
                )}
              </div>
            )}

            <div className="flex justify-between pt-4">
              <div>
                {step > 1 && (
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleBack}
                    className="border-2 border-blue-700 text-gray-800 h-10 px-4"
                  >
                    Back
                  </Button>
                )}
              </div>
              <div className="flex gap-2">
                {step < 3 && (
                  <Button
                    type="button"
                    onClick={handleNext}
                    className="bg-blue-700 text-white h-10 px-4"
                    disabled={isLoading}
                  >
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Next'}
                  </Button>
                )}
                {step === 3 && (
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="bg-green-600 text-white h-10 px-4"
                  >
                    {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : 'Submit'}
                  </Button>
                )}
              </div>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* All Employees Documents Card */}
      {step === 1 && (
        <Card className="shadow-lg border border-gray-200">
          <CardHeader className="border-b px-4 py-3 bg-gray-50">
            <div className="flex justify-between items-center">
              <CardTitle className="text-lg text-gray-800">All Employees' Documents</CardTitle>
              <Button
                onClick={() => {
                  if (showDocumentsGrid) {
                    setShowDocumentsGrid(false);
                  } else {
                    fetchAllDocuments();
                  }
                }}
                className="bg-blue-600 text-white h-10 px-4"
              >
                {showDocumentsGrid ? 'Hide Documents' : 'Show Documents'}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="px-4 py-6">
            {showDocumentsGrid && (
              <div className="grid grid-cols-1 gap-4">
                {allDocuments.length > 0 ? allDocuments.map(employee => (
                  <Card key={employee.id} className="shadow-md border">
                    <CardHeader className="bg-gray-50 py-3">
                      <CardTitle className="text-md text-gray-800">{employee.name} (ID: {employee.id})</CardTitle>
                    </CardHeader>
                    <CardContent className="p-3">
                      {Object.entries(employee.documents).map(([docType, docUrl]) => (
                        docUrl && (Array.isArray(docUrl) ? docUrl.map((url, idx) => (
                          <div key={`${docType}-${idx}`} className="flex items-center justify-between py-2 border-b">
                            <div className="flex items-center">
                              <div className="mr-2">{getFileIconByUrl(url)}</div>
                              <p className="text-sm text-gray-700">{`Other Document ${idx + 1}`}</p>
                            </div>
                            <div className="flex gap-2">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    title={canPreviewByUrl(url) ? 'Preview' : 'Preview not available'}
                                    disabled={!canPreviewByUrl(url)}
                                    className={canPreviewByUrl(url) ? 'text-blue-600 hover:bg-blue-100' : 'text-gray-400 cursor-not-allowed'}
                                  >
                                    <Eye className="w-4 h-4" />
                                  </Button>
                                </DialogTrigger>
                                {canPreviewByUrl(url) && (
                                  <DialogContent className="w-[95vw] max-w-md sm:max-w-3xl">
                                    <DialogHeader>
                                      <DialogTitle className="text-base">{`Other Document ${idx + 1}`}</DialogTitle>
                                    </DialogHeader>
                                    {url.toLowerCase().endsWith('.pdf') ? (
                                      <iframe src={url} className="w-full h-[60vh] sm:h-[70vh]" title={`Other Document ${idx + 1}`} />
                                    ) : (
                                      <img src={url} alt={`Other Document ${idx + 1}`} className="max-w-full max-h-[60vh] sm:max-h-[70vh] object-contain" />
                                    )}
                                  </DialogContent>
                                )}
                              </Dialog>
                              <Button
                                variant="ghost"
                                size="icon"
                                title="Download"
                                onClick={() => {
                                  const a = document.createElement('a');
                                  a.href = url;
                                  a.download = url.split('/').pop();
                                  document.body.appendChild(a);
                                  a.click();
                                  document.body.removeChild(a);
                                }}
                                className="text-green-600 hover:bg-green-100"
                              >
                                <Download className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        )) : (
                          <div key={docType} className="flex items-center justify-between py-2 border-b">
                            <div className="flex items-center">
                              <div className="mr-2">{getFileIconByUrl(docUrl)}</div>
                              <p className="text-sm text-gray-700">{docType.charAt(0).toUpperCase() + docType.slice(1)}</p>
                            </div>
                            <div className="flex gap-2">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    title={canPreviewByUrl(docUrl) ? 'Preview' : 'Preview not available'}
                                    disabled={!canPreviewByUrl(docUrl)}
                                    className={canPreviewByUrl(docUrl) ? 'text-blue-600 hover:bg-blue-100' : 'text-gray-400 cursor-not-allowed'}
                                  >
                                    <Eye className="w-4 h-4" />
                                  </Button>
                                </DialogTrigger>
                                {canPreviewByUrl(docUrl) && (
                                  <DialogContent className="w-[95vw] max-w-md sm:max-w-3xl">
                                    <DialogHeader>
                                      <DialogTitle className="text-base">{docType.charAt(0).toUpperCase() + docType.slice(1)}</DialogTitle>
                                    </DialogHeader>
                                    {docUrl.toLowerCase().endsWith('.pdf') ? (
                                      <iframe src={docUrl} className="w-full h-[60vh] sm:h-[70vh]" title={docType} />
                                    ) : (
                                      <img src={docUrl} alt={docType} className="max-w-full max-h-[60vh] sm:max-h-[70vh] object-contain" />
                                    )}
                                  </DialogContent>
                                )}
                              </Dialog>
                              <Button
                                variant="ghost"
                                size="icon"
                                title="Download"
                                onClick={() => {
                                  const a = document.createElement('a');
                                  a.href = docUrl;
                                  a.download = docUrl.split('/').pop();
                                  document.body.appendChild(a);
                                  a.click();
                                  document.body.removeChild(a);
                                }}
                                className="text-green-600 hover:bg-green-100"
                              >
                                <Download className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        ))
                      ))}
                      {Object.values(employee.documents).every(doc => !doc || (Array.isArray(doc) && doc.length === 0)) && (
                        <p className="text-sm text-gray-500">No documents available.</p>
                      )}
                    </CardContent>
                  </Card>
                )) : (
                  <p className="text-sm text-gray-500">No employees found.</p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default UploadDocuments;