import { useState } from 'react';
import { FileText, Users, Calendar, Clock } from 'lucide-react';

const Reports = () => {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Reports Dashboard</h1>
        <p className="text-gray-600">Select a report type from the sidebar to get started</p>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm border p-8 text-center">
        <FileText size={48} className="mx-auto text-gray-400 mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">
          Welcome to Reports
        </h3>
        <p className="text-gray-500">Please select a specific report from the sidebar menu.</p>
      </div>
    </div>
  );
};

export default Reports;