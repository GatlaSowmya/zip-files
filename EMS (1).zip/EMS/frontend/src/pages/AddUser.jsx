// import { useState, useEffect } from 'react';
// import {
//   Card, CardContent, CardHeader, CardTitle,
// } from '@/components/ui/card';
// import { Input } from '@/components/ui/input';
// import { Label } from '@/components/ui/label';
// import { Button } from '@/components/ui/button';
// import {
//   Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
// } from '@/components/ui/select';
// import { toast } from 'sonner';
// import axios from 'axios';

// const steps = ['Basic Info', 'Personal Info', 'Team & Role', 'Identity', 'Bank Details'];

// const InputGroup = ({ label, name, value, onChange, type = 'text', required = false }) => (
//   <div className="space-y-1">
//     <Label htmlFor={name}>{label} {required && <span className="text-red-500">*</span>}</Label>
//     <Input id={name} name={name} type={type} value={value || ''} onChange={onChange} required={required} className="text-xs sm:text-sm" />
//   </div>
// );

// const SelectGroup = ({ label, name, value, onChange, options, required = false }) => (
//   <div className="space-y-1">
//     <Label htmlFor={name}>{label} {required && <span className="text-red-500">*</span>}</Label>
//     <Select value={value || ''} onValueChange={(v) => onChange(name, v)} required={required}>
//       <SelectTrigger id={name} className="text-xs sm:text-sm"><SelectValue placeholder={`Select ${label}`} /></SelectTrigger>
//       <SelectContent className="bg-white text-black border">
//         {options.map(opt => (
//           <SelectItem key={opt} value={opt} className="text-xs sm:text-sm">{opt}</SelectItem>
//         ))}
//       </SelectContent>
//     </Select>
//   </div>
// );

// const AddUser = () => {
//   const [step, setStep] = useState(1);
//   const [leadsAndManagers, setLeadsAndManagers] = useState([]);
//   const [formData, setFormData] = useState({
//     name: '', email: '', password: '', role: '', avatar: '',
//     fullName: '', dateOfBirth: '', dateOfJoining: '', gender: '', nationality: '', maritalStatus: '',
//     permanentAddress: '', currentAddress: '', phoneNumber: '', alternatePhoneNumber: '', personalEmail: '',
//     teamLead: '', manager: '', position: '', department: '',
//     aadhar: '', panCard: '', passport: '', drivingLicense: '',
//     bankName: '', bankBranch: '', accountNumber: '', ifscCode: ''
//   });
//   const [isSubmitting, setIsSubmitting] = useState(false);

//   useEffect(() => {
//     axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/leads-managers`)
//       .then(res => {
//         console.log('Leads and Managers:', res.data);
//         setLeadsAndManagers(res.data);
//       })
//       .catch(() => toast.error('Failed to load Team Leads, Managers, and Directors'));
//   }, []);

//   const handleInputChange = e => {
//     const { name, value } = e.target;
//     setFormData(prev => ({ ...prev, [name]: value }));
//   };

//   const handleSelectChange = (name, value) => {
//     console.log(`Updating ${name} with value: ${value}`);
//     if (name === 'role') {
//       setFormData(prev => ({
//         ...prev,
//         [name]: value,
//         teamLead: value === 'Employee' ? prev.teamLead : '',
//         manager: ['Employee', 'Team Lead', 'HR', 'Manager', 'Admin'].includes(value) ? prev.manager : '',
//       }));
//     } else {
//       setFormData(prev => ({ ...prev, [name]: value }));
//     }
//   };

//   const handleAvatarUpload = async (e) => {
//     const file = e.target.files[0];
//     if (!file) return;
//     const data = new FormData();
//     data.append('avatar', file);
//     try {
//       const res = await axios.post(`${import.meta.env.VITE_API_BASE_URL}/api/upload-avatar`, data);
//       setFormData(prev => ({ ...prev, avatar: res.data.url }));
//       toast.success('Avatar uploaded');
//     } catch {
//       toast.error('Avatar upload failed');
//     }
//   };

//   const validateStep = (currentStep) => {
//     const missingFields = [];

//     if (currentStep === 1) {
//       const requiredFields = [
//         { field: 'Name', value: formData.name },
//         { field: 'Email', value: formData.email },
//         { field: 'Password', value: formData.password },
//         { field: 'Role', value: formData.role },
//       ];
//       requiredFields.forEach(({ field, value }) => {
//         if (!value) missingFields.push(field);
//       });
//     } else if (currentStep === 3) {
//       if (formData.role === 'Employee' && !formData.teamLead) {
//         missingFields.push('Team Lead');
//       }
//       if (['Employee', 'Team Lead', 'HR', 'Manager', 'Admin'].includes(formData.role) && !formData.manager) {
//         missingFields.push('Manager/Director');
//       }
//       if (!formData.position) missingFields.push('Position');
//       if (!formData.department) missingFields.push('Department');
//     } else if (currentStep === 5) {
//       if (formData.bankName || formData.bankBranch || formData.accountNumber || formData.ifscCode) {
//         if (!formData.bankName) missingFields.push('Bank Name');
//         if (!formData.bankBranch) missingFields.push('Bank Branch');
//         if (!formData.accountNumber) missingFields.push('Account Number');
//         if (!formData.ifscCode) missingFields.push('IFSC Code');
//       }
//     }

//     return missingFields;
//   };

//   const handleStepClick = (stepNumber) => {
//     const missingFields = validateStep(step);
//     if (missingFields.length > 0) {
//       toast.error(`Please fill all required fields: ${missingFields.join(', ')}`);
//       return;
//     }
//     setStep(stepNumber);
//   };

//   const handleNext = () => {
//     const missingFields = validateStep(step);
//     if (missingFields.length > 0) {
//       toast.error(`Please fill all required fields: ${missingFields.join(', ')}`);
//       return;
//     }
//     setStep(prev => Math.min(prev + 1, steps.length));
//   };

//   const handleBack = () => {
//     setStep(prev => Math.max(prev - 1, 1));
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const missingFields = validateStep(step);
//     if (missingFields.length > 0) {
//       toast.error(`Please fill all required fields: ${missingFields.join(', ')}`);
//       return;
//     }
//     setIsSubmitting(true);
//     try {
//       const payload = {
//         ...formData,
//         teamLead: formData.role === 'Employee' ? formData.teamLead : null,
//         manager: ['Employee', 'Team Lead', 'HR', 'Manager', 'Admin'].includes(formData.role) ? formData.manager : null,
//       };
//       await axios.post(`${import.meta.env.VITE_API_BASE_URL}/api/add-user`, payload);
//       toast.success(`User ${formData.name} added`);
//       setFormData({
//         name: '', email: '', password: '', role: '', avatar: '',
//         fullName: '', dateOfBirth: '', dateOfJoining: '', gender: '', nationality: '', maritalStatus: '',
//         permanentAddress: '', currentAddress: '', phoneNumber: '', alternatePhoneNumber: '', personalEmail: '',
//         teamLead: '', manager: '', position: '', department: '',
//         aadhar: '', panCard: '', passport: '', drivingLicense: '',
//         bankName: '', bankBranch: '', accountNumber: '', ifscCode: ''
//       });
//       setStep(1);
//     } catch (err) {
//       toast.error(err.response?.data?.error || 'Failed to add user');
//     } finally {
//       setIsSubmitting(false);
//     }
//   };

//   return (
//     <div className="max-w-lg sm:max-w-2xl md:max-w-4xl mx-auto px-3 sm:px-4 py-4 sm:py-6">
//       {/* Desktop Stepper */}
//       <div className="hidden sm:flex flex-col sm:flex-row justify-between items-center mb-2 sm:mb-4">
//         {steps.map((label, idx) => {
//           const active = step === idx + 1;
//           const done = step > idx + 1;
//           return (
//             <div key={idx} className="flex items-center w-full sm:w-auto mb-2 sm:mb-0">
//               <button
//                 onClick={() => handleStepClick(idx + 1)}
//                 className={`flex items-center ${done || active ? 'cursor-pointer' : 'cursor-default'}`}
//               >
//                 <div className={`w-5 h-5 sm:w-6 sm:h-6 rounded-full flex justify-center items-center text-xs sm:text-sm font-bold 
//                   ${done ? 'bg-green-500 text-white' : active ? 'bg-blue-600 text-white' : 'bg-gray-300 text-black'}`}>
//                   {done ? '✔' : idx + 1}
//                 </div>
//                 <div className={`ml-1 mr-1 sm:ml-2 sm:mr-2 text-xs sm:text-sm font-semibold ${done || active ? 'text-blue-600' : 'text-gray-500'}`}>
//                   {label}
//                 </div>
//               </button>
//               {idx < steps.length - 1 && <div className="flex-1 h-0.5 sm:h-1 bg-gray-300 hidden sm:block" />}
//             </div>
//           );
//         })}
//       </div>
      
//       {/* Mobile Stepper - Horizontal with Numbers */}
//       <div className="sm:hidden flex justify-between items-center mb-4 px-2">
//         {steps.map((label, idx) => {
//           const active = step === idx + 1;
//           const done = step > idx + 1;
//           return (
//             <button
//               key={idx}
//               onClick={() => handleStepClick(idx + 1)}
//               className={`flex flex-col items-center ${done || active ? 'cursor-pointer' : 'cursor-default'}`}
//             >
//               <div className={`w-6 h-6 rounded-full flex justify-center items-center text-xs font-bold 
//                 ${done ? 'bg-green-500 text-white' : active ? 'bg-blue-600 text-white' : 'bg-gray-300 text-black'}`}>
//                 {done ? '✔' : idx + 1}
//               </div>
//               <div className={`text-xs mt-1 ${active ? 'font-semibold text-blue-600' : 'text-gray-500'}`}>
//                 {label.split(' ')[0]}
//               </div>
//             </button>
//           );
//         })}
//       </div>

//       <Card>
//         <CardHeader className="hidden sm:block"><CardTitle className="text-lg sm:text-xl">Add New User</CardTitle></CardHeader>
//         <CardContent>
//           <div className="space-y-4 sm:space-y-6">
//             {step === 1 && (
//               <div className="grid grid-cols-1 gap-3 sm:gap-6">
//                 <InputGroup label="Name" name="name" value={formData.name} onChange={handleInputChange} required />
//                 <InputGroup label="Email" name="email" type="email" value={formData.email} onChange={handleInputChange} required />
//                 <InputGroup label="Password" name="password" type="password" value={formData.password} onChange={handleInputChange} required />
//                 <SelectGroup
//                   label="User Role"
//                   name="role"
//                   value={formData.role}
//                   onChange={handleSelectChange}
//                   options={['Admin', 'HR', 'Director', 'Manager', 'Team Lead', 'Employee']}
//                   required
//                 />
//                 <div className="space-y-1">
//                   <Label htmlFor="avatar">Avatar</Label>
//                   <Input id="avatar" name="avatar" type="file" accept="image/*" onChange={handleAvatarUpload} className="text-xs sm:text-sm" />
//                   {formData.avatar && <p className="text-xs sm:text-sm text-green-600">Uploaded: {formData.avatar}</p>}
//                 </div>
//               </div>
//             )}

//             {step === 2 && (
//               <div className="grid grid-cols-1 gap-3 sm:gap-6">
//                 <InputGroup label="Full Name" name="fullName" value={formData.fullName} onChange={handleInputChange} />
//                 <InputGroup label="Date of Birth" name="dateOfBirth" type="date" value={formData.dateOfBirth} onChange={handleInputChange} />
//                 <InputGroup label="Date of Joining" name="dateOfJoining" type="date" value={formData.dateOfJoining} onChange={handleInputChange} />
//                 <SelectGroup label="Gender" name="gender" value={formData.gender} onChange={handleSelectChange} options={['Male', 'Female', 'Other']} />
//                 <InputGroup label="Nationality" name="nationality" value={formData.nationality} onChange={handleInputChange} />
//                 <SelectGroup label="Marital Status" name="maritalStatus" value={formData.maritalStatus} onChange={handleSelectChange} options={['Single', 'Married', 'Divorced', 'Widowed']} />
//                 <InputGroup label="Permanent Address" name="permanentAddress" value={formData.permanentAddress} onChange={handleInputChange} />
//                 <InputGroup label="Current Address" name="currentAddress" value={formData.currentAddress} onChange={handleInputChange} />
//                 <InputGroup label="Phone Number" name="phoneNumber" value={formData.phoneNumber} onChange={handleInputChange} />
//                 <InputGroup label="Alternate Phone Number" name="alternatePhoneNumber" value={formData.alternatePhoneNumber} onChange={handleInputChange} />
//                 <InputGroup label="Personal Email" name="personalEmail" type="email" value={formData.personalEmail} onChange={handleInputChange} />
//               </div>
//             )}

//             {step === 3 && (
//               <div className="grid grid-cols-1 gap-3 sm:gap-6">
//                 {formData.role === 'Employee' && (
//                   <SelectGroup
//                     label="Team Lead"
//                     name="teamLead"
//                     value={formData.teamLead}
//                     onChange={handleSelectChange}
//                     options={leadsAndManagers.filter(u => u.role === 'Team Lead').map(u => u.name)}
//                     required
//                   />
//                 )}
//                 {['Employee', 'Team Lead'].includes(formData.role) && (
//                   <SelectGroup
//                     label="Manager"
//                     name="manager"
//                     value={formData.manager}
//                     onChange={handleSelectChange}
//                     options={leadsAndManagers.filter(u => u.role === 'Manager').map(u => u.name)}
//                     required
//                   />
//                 )}
//                 {['HR', 'Manager', 'Admin'].includes(formData.role) && (
//                   <div className="space-y-1">
//                     {leadsAndManagers.filter(u => u.role === 'Director').length > 0 ? (
//                       <SelectGroup
//                         label="Director"
//                         name="manager"
//                         value={formData.manager}
//                         onChange={handleSelectChange}
//                         options={leadsAndManagers.filter(u => u.role === 'Director').map(u => u.name)}
//                         required
//                       />
//                     ) : (
//                       <p className="text-red-500 text-xs sm:text-sm">No Directors available. Please add a Director first.</p>
//                     )}
//                   </div>
//                 )}
//                 <InputGroup label="Position" name="position" value={formData.position} onChange={handleInputChange} required />
//                 <SelectGroup
//                   label="Department"
//                   name="department"
//                   value={formData.department}
//                   onChange={handleSelectChange}
//                   options={['Management', 'IT', 'Human Resources', 'Operations & Development', 'Finance']}
//                   required
//                 />
//               </div>
//             )}

//             {step === 4 && (
//               <div className="grid grid-cols-1 gap-3 sm:gap-6">
//                 <InputGroup label="Aadhar" name="aadhar" value={formData.aadhar} onChange={handleInputChange} />
//                 <InputGroup label="PAN Card" name="panCard" value={formData.panCard} onChange={handleInputChange} />
//                 <InputGroup label="Passport" name="passport" value={formData.passport} onChange={handleInputChange} />
//                 <InputGroup label="Driving License" name="drivingLicense" value={formData.drivingLicense} onChange={handleInputChange} />
//               </div>
//             )}

//             {step === 5 && (
//               <div className="grid grid-cols-1 gap-3 sm:gap-6">
//                 <InputGroup label="Bank Name" name="bankName" value={formData.bankName} onChange={handleInputChange} />
//                 <InputGroup label="Bank Branch" name="bankBranch" value={formData.bankBranch} onChange={handleInputChange} />
//                 <InputGroup label="Account Number" name="accountNumber" value={formData.accountNumber} onChange={handleInputChange} />
//                 <InputGroup label="IFSC Code" name="ifscCode" value={formData.ifscCode} onChange={handleInputChange} />
//               </div>
//             )}

//             <div className="flex flex-col sm:flex-row justify-between items-center pt-2 sm:pt-4">
//               <div className="mb-2 sm:mb-0">
//                 {step > 1 && (
//                   <Button type="button" variant="outline" onClick={handleBack} className="border-2 border-blue-700 text-gray-800 text-xs sm:text-sm w-full sm:w-auto">
//                     Back
//                   </Button>
//                 )}
//               </div>
//               <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
//                 {step < 5 && (
//                   <Button type="button" onClick={handleNext} className="bg-blue-700 text-white text-xs sm:text-sm w-full sm:w-auto">
//                     Next
//                   </Button>
//                 )}
//                 {step === 5 && (
//                   <Button type="submit" disabled={isSubmitting} onClick={handleSubmit} className="bg-green-600 text-white text-xs sm:text-sm w-full sm:w-auto">
//                     {isSubmitting ? 'Adding User...' : 'Add User'}
//                   </Button>
//                 )}
//               </div>
//             </div>
//           </div>
//         </CardContent>
//       </Card>
//     </div>
//   );
// };

// export default AddUser;

import { useState, useEffect } from 'react';
import {
  Card, CardContent, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import axios from 'axios';

const steps = ['Basic Info', 'Personal Info', 'Team & Role', 'Identity', 'Bank Details'];

const InputGroup = ({ label, name, value, onChange, type = 'text', required = false }) => {
  const handleChange = (e) => {
    const inputValue = e.target.value;
    if (name === 'name' || name === 'fullName') {
      // Allow only alphabetic characters and spaces, or empty string
      if (inputValue === '' || /^[A-Za-z\s]+$/.test(inputValue)) {
        onChange(e);
      } else {
        toast.error(`${label} can only contain letters and spaces`);
      }
    } else if (name === 'phoneNumber' || name === 'alternatePhoneNumber') {
      // Allow only numbers, +, -, and spaces, or empty string
      if (inputValue === '' || /^[0-9+\-\s]+$/.test(inputValue)) {
        onChange(e);
      } else {
        toast.error(`${label} can only contain numbers, +, -, and spaces`);
      }
    } else if (name === 'accountNumber') {
      // Allow only numbers, or empty string
      if (inputValue === '' || /^[0-9]+$/.test(inputValue)) {
        onChange(e);
      } else {
        toast.error(`${label} can only contain numbers`);
      }
    } else {
      onChange(e);
    }
  };

  return (
    <div className="space-y-1">
      <Label htmlFor={name}>{label} {required && <span className="text-red-500">*</span>}</Label>
      <Input 
        id={name} 
        name={name} 
        type={type} 
        value={value || ''} 
        onChange={handleChange} 
        required={required} 
        className="text-xs sm:text-sm" 
        pattern={
          name === 'name' || name === 'fullName' ? '[A-Za-z\\s]+' :
          name === 'phoneNumber' || name === 'alternatePhoneNumber' ? '[0-9+\\-\\s]+' :
          name === 'accountNumber' ? '[0-9]+' : undefined
        }
        title={
          name === 'name' || name === 'fullName' ? 'Can only contain letters and spaces' :
          name === 'phoneNumber' || name === 'alternatePhoneNumber' ? 'Can only contain numbers, +, -, and spaces' :
          name === 'accountNumber' ? 'Can only contain numbers' : undefined
        }
      />
    </div>
  );
};

const SelectGroup = ({ label, name, value, onChange, options, required = false }) => (
  <div className="space-y-1">
    <Label htmlFor={name}>{label} {required && <span className="text-red-500">*</span>}</Label>
    <Select value={value || ''} onValueChange={(v) => onChange(name, v)} required={required}>
      <SelectTrigger id={name} className="text-xs sm:text-sm"><SelectValue placeholder={`Select ${label}`} /></SelectTrigger>
      <SelectContent className="bg-white text-black border">
        {options.map(opt => (
          <SelectItem key={opt} value={opt} className="text-xs sm:text-sm">{opt}</SelectItem>
        ))}
      </SelectContent>
    </Select>
  </div>
);

const AddUser = () => {
  const [step, setStep] = useState(1);
  const [leadsAndManagers, setLeadsAndManagers] = useState([]);
  const [formData, setFormData] = useState({
    name: '', email: '', password: '', role: '', avatar: '',
    fullName: '', dateOfBirth: '', dateOfJoining: '', gender: '', nationality: '', maritalStatus: '',
    permanentAddress: '', currentAddress: '', phoneNumber: '', alternatePhoneNumber: '', personalEmail: '',
    teamLead: '', manager: '', position: '', department: '',
    aadhar: '', panCard: '', passport: '', drivingLicense: '',
    bankName: '', bankBranch: '', accountNumber: '', ifscCode: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/leads-managers`)
      .then(res => {
        console.log('Leads and Managers:', res.data);
        setLeadsAndManagers(res.data);
      })
      .catch(() => toast.error('Failed to load Team Leads, Managers, and Directors'));
  }, []);

  const handleInputChange = e => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    console.log(`Updating ${name} with value: ${value}`);
    if (name === 'role') {
      setFormData(prev => ({
        ...prev,
        [name]: value,
        teamLead: value === 'Employee' ? prev.teamLead : '',
        manager: ['Employee', 'Team Lead', 'HR', 'Manager', 'Admin'].includes(value) ? prev.manager : '',
      }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleAvatarUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const data = new FormData();
    data.append('avatar', file);
    try {
      const res = await axios.post(`${import.meta.env.VITE_API_BASE_URL}/api/upload-avatar`, data);
      setFormData(prev => ({ ...prev, avatar: res.data.url }));
      toast.success('Avatar uploaded');
    } catch {
      toast.error('Avatar upload failed');
    }
  };

  const validateStep = (currentStep) => {
    const missingFields = [];

    if (currentStep === 1) {
      const requiredFields = [
        { field: 'Name', value: formData.name },
        { field: 'Email', value: formData.email },
        { field: 'Password', value: formData.password },
        { field: 'Role', value: formData.role },
      ];
      requiredFields.forEach(({ field, value }) => {
        if (!value) missingFields.push(field);
      });
    } else if (currentStep === 3) {
      if (formData.role === 'Employee' && !formData.teamLead) {
        missingFields.push('Team Lead');
      }
      if (['Employee', 'Team Lead', 'HR', 'Manager', 'Admin'].includes(formData.role) && !formData.manager) {
        missingFields.push('Manager/Director');
      }
      if (!formData.position) missingFields.push('Position');
      if (!formData.department) missingFields.push('Department');
    } else if (currentStep === 5) {
      if (formData.bankName || formData.bankBranch || formData.accountNumber || formData.ifscCode) {
        if (!formData.bankName) missingFields.push('Bank Name');
        if (!formData.bankBranch) missingFields.push('Bank Branch');
        if (!formData.accountNumber) missingFields.push('Account Number');
        if (!formData.ifscCode) missingFields.push('IFSC Code');
      }
    }

    return missingFields;
  };

  const handleStepClick = (stepNumber) => {
    const missingFields = validateStep(step);
    if (missingFields.length > 0) {
      toast.error(`Please fill all required fields: ${missingFields.join(', ')}`);
      return;
    }
    setStep(stepNumber);
  };

  const handleNext = () => {
    const missingFields = validateStep(step);
    if (missingFields.length > 0) {
      toast.error(`Please fill all required fields: ${missingFields.join(', ')}`);
      return;
    }
    setStep(prev => Math.min(prev + 1, steps.length));
  };

  const handleBack = () => {
    setStep(prev => Math.max(prev - 1, 1));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const missingFields = validateStep(step);
    if (missingFields.length > 0) {
      toast.error(`Please fill all required fields: ${missingFields.join(', ')}`);
      return;
    }
    setIsSubmitting(true);
    try {
      const payload = {
        ...formData,
        teamLead: formData.role === 'Employee' ? formData.teamLead : null,
        manager: ['Employee', 'Team Lead', 'HR', 'Manager', 'Admin'].includes(formData.role) ? formData.manager : null,
      };
      await axios.post(`${import.meta.env.VITE_API_BASE_URL}/api/add-user`, payload);
      toast.success(`User ${formData.name} added`);
      setFormData({
        name: '', email: '', password: '', role: '', avatar: '',
        fullName: '', dateOfBirth: '', dateOfJoining: '', gender: '', nationality: '', maritalStatus: '',
        permanentAddress: '', currentAddress: '', phoneNumber: '', alternatePhoneNumber: '', personalEmail: '',
        teamLead: '', manager: '', position: '', department: '',
        aadhar: '', panCard: '', passport: '', drivingLicense: '',
        bankName: '', bankBranch: '', accountNumber: '', ifscCode: ''
      });
      setStep(1);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to add user');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-lg sm:max-w-2xl md:max-w-4xl mx-auto px-3 sm:px-4 py-4 sm:py-6">
      {/* Desktop Stepper */}
      <div className="hidden sm:flex flex-col sm:flex-row justify-between items-center mb-2 sm:mb-4">
        {steps.map((label, idx) => {
          const active = step === idx + 1;
          const done = step > idx + 1;
          return (
            <div key={idx} className="flex items-center w-full sm:w-auto mb-2 sm:mb-0">
              <button
                onClick={() => handleStepClick(idx + 1)}
                className={`flex items-center ${done || active ? 'cursor-pointer' : 'cursor-default'}`}
              >
                <div className={`w-5 h-5 sm:w-6 sm:h-6 rounded-full flex justify-center items-center text-xs sm:text-sm font-bold 
                  ${done ? 'bg-green-500 text-white' : active ? 'bg-blue-600 text-white' : 'bg-gray-300 text-black'}`}>
                  {done ? '✔' : idx + 1}
                </div>
                <div className={`ml-1 mr-1 sm:ml-2 sm:mr-2 text-xs sm:text-sm font-semibold ${done || active ? 'text-blue-600' : 'text-gray-500'}`}>
                  {label}
                </div>
              </button>
              {idx < steps.length - 1 && <div className="flex-1 h-0.5 sm:h-1 bg-gray-300 hidden sm:block" />}
            </div>
          );
        })}
      </div>
      
      {/* Mobile Stepper - Horizontal with Numbers */}
      <div className="sm:hidden flex justify-between items-center mb-4 px-2">
        {steps.map((label, idx) => {
          const active = step === idx + 1;
          const done = step > idx + 1;
          return (
            <button
              key={idx}
              onClick={() => handleStepClick(idx + 1)}
              className={`flex flex-col items-center ${done || active ? 'cursor-pointer' : 'cursor-default'}`}
            >
              <div className={`w-6 h-6 rounded-full flex justify-center items-center text-xs font-bold 
                ${done ? 'bg-green-500 text-white' : active ? 'bg-blue-600 text-white' : 'bg-gray-300 text-black'}`}>
                {done ? '✔' : idx + 1}
              </div>
              <div className={`text-xs mt-1 ${active ? 'font-semibold text-blue-600' : 'text-gray-500'}`}>
                {label.split(' ')[0]}
              </div>
            </button>
          );
        })}
      </div>

      <Card>
        <CardHeader className="hidden sm:block"><CardTitle className="text-lg sm:text-xl">Add New User</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-4 sm:space-y-6">
            {step === 1 && (
              <div className="grid grid-cols-1 gap-3 sm:gap-6">
                <InputGroup label="Name" name="name" value={formData.name} onChange={handleInputChange} required />
                <InputGroup label="Email" name="email" type="email" value={formData.email} onChange={handleInputChange} required />
                <InputGroup label="Password" name="password" type="password" value={formData.password} onChange={handleInputChange} required />
                <SelectGroup
                  label="User Role"
                  name="role"
                  value={formData.role}
                  onChange={handleSelectChange}
                  options={['Admin', 'HR', 'Director', 'Manager', 'Team Lead', 'Employee']}
                  required
                />
                <div className="space-y-1">
                  <Label htmlFor="avatar">Avatar</Label>
                  <Input id="avatar" name="avatar" type="file" accept="image/*" onChange={handleAvatarUpload} className="text-xs sm:text-sm" />
                  {formData.avatar && <p className="text-xs sm:text-sm text-green-600">Uploaded: {formData.avatar}</p>}
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="grid grid-cols-1 gap-3 sm:gap-6">
                <InputGroup label="Full Name" name="fullName" value={formData.fullName} onChange={handleInputChange} />
                <InputGroup label="Date of Birth" name="dateOfBirth" type="date" value={formData.dateOfBirth} onChange={handleInputChange} />
                <InputGroup label="Date of Joining" name="dateOfJoining" type="date" value={formData.dateOfJoining} onChange={handleInputChange} />
                <SelectGroup label="Gender" name="gender" value={formData.gender} onChange={handleSelectChange} options={['Male', 'Female', 'Other']} />
                <InputGroup label="Nationality" name="nationality" value={formData.nationality} onChange={handleInputChange} />
                <SelectGroup label="Marital Status" name="maritalStatus" value={formData.maritalStatus} onChange={handleSelectChange} options={['Single', 'Married', 'Divorced', 'Widowed']} />
                <InputGroup label="Permanent Address" name="permanentAddress" value={formData.permanentAddress} onChange={handleInputChange} />
                <InputGroup label="Current Address" name="currentAddress" value={formData.currentAddress} onChange={handleInputChange} />
                <InputGroup label="Phone Number" name="phoneNumber" value={formData.phoneNumber} onChange={handleInputChange} />
                <InputGroup label="Alternate Phone Number" name="alternatePhoneNumber" value={formData.alternatePhoneNumber} onChange={handleInputChange} />
                <InputGroup label="Personal Email" name="personalEmail" type="email" value={formData.personalEmail} onChange={handleInputChange} />
              </div>
            )}

            {step === 3 && (
              <div className="grid grid-cols-1 gap-3 sm:gap-6">
                {formData.role === 'Employee' && (
                  <SelectGroup
                    label="Team Lead"
                    name="teamLead"
                    value={formData.teamLead}
                    onChange={handleSelectChange}
                    options={leadsAndManagers.filter(u => u.role === 'Team Lead').map(u => u.name)}
                    required
                  />
                )}
                {['Employee', 'Team Lead'].includes(formData.role) && (
                  <SelectGroup
                    label="Manager"
                    name="manager"
                    value={formData.manager}
                    onChange={handleSelectChange}
                    options={leadsAndManagers.filter(u => u.role === 'Manager').map(u => u.name)}
                    required
                  />
                )}
                {['HR', 'Manager', 'Admin'].includes(formData.role) && (
                  <div className="space-y-1">
                    {leadsAndManagers.filter(u => u.role === 'Director').length > 0 ? (
                      <SelectGroup
                        label="Director"
                        name="manager"
                        value={formData.manager}
                        onChange={handleSelectChange}
                        options={leadsAndManagers.filter(u => u.role === 'Director').map(u => u.name)}
                        required
                      />
                    ) : (
                      <p className="text-red-500 text-xs sm:text-sm">No Directors available. Please add a Director first.</p>
                    )}
                  </div>
                )}
                <InputGroup label="Position" name="position" value={formData.position} onChange={handleInputChange} required />
                <SelectGroup
                  label="Department"
                  name="department"
                  value={formData.department}
                  onChange={handleSelectChange}
                  options={['Management', 'IT', 'Human Resources', 'Operations & Development', 'Finance']}
                  required
                />
              </div>
            )}

            {step === 4 && (
              <div className="grid grid-cols-1 gap-3 sm:gap-6">
                <InputGroup label="Aadhar" name="aadhar" value={formData.aadhar} onChange={handleInputChange} />
                <InputGroup label="PAN Card" name="panCard" value={formData.panCard} onChange={handleInputChange} />
                <InputGroup label="Passport" name="passport" value={formData.passport} onChange={handleInputChange} />
                <InputGroup label="Driving License" name="drivingLicense" value={formData.drivingLicense} onChange={handleInputChange} />
              </div>
            )}

            {step === 5 && (
              <div className="grid grid-cols-1 gap-3 sm:gap-6">
                <InputGroup label="Bank Name" name="bankName" value={formData.bankName} onChange={handleInputChange} />
                <InputGroup label="Bank Branch" name="bankBranch" value={formData.bankBranch} onChange={handleInputChange} />
                <InputGroup label="Account Number" name="accountNumber" value={formData.accountNumber} onChange={handleInputChange} />
                <InputGroup label="IFSC Code" name="ifscCode" value={formData.ifscCode} onChange={handleInputChange} />
              </div>
            )}

            <div className="flex flex-col sm:flex-row justify-between items-center pt-2 sm:pt-4">
              <div className="mb-2 sm:mb-0">
                {step > 1 && (
                  <Button type="button" variant="outline" onClick={handleBack} className="border-2 border-blue-700 text-gray-800 text-xs sm:text-sm w-full sm:w-auto">
                    Back
                  </Button>
                )}
              </div>
              <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                {step < 5 && (
                  <Button type="button" onClick={handleNext} className="bg-blue-700 text-white text-xs sm:text-sm w-full sm:w-auto">
                    Next
                  </Button>
                )}
                {step === 5 && (
                  <Button type="submit" disabled={isSubmitting} onClick={handleSubmit} className="bg-green-600 text-white text-xs sm:text-sm w-full sm:w-auto">
                    {isSubmitting ? 'Adding User...' : 'Add User'}
                  </Button>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AddUser;