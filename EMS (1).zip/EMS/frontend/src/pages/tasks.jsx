import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTask } from '../contexts/TaskContext';
import { useUser } from '../contexts/UserContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Input } from '../components/ui/input';
import { Filter, Download, Grid, List, Plus, X } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '../lib/utils';
import * as XLSX from 'xlsx';
import { toast } from 'sonner';
import TaskForm from '../components/tasks/TaskForm';
import TaskDetail from '../components/tasks/TaskDetail';

// Custom Modal Component
const Modal = ({ isOpen, onClose, children, title }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-xs sm:max-w-lg mx-2 p-4 sm:p-6 relative max-h-[85vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-3 sm:mb-4">
          <h2 className="text-lg sm:text-xl font-semibold">{title}</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
          </Button>
        </div>
        {children}
      </div>
    </div>
  );
};

export default function Tasks() {
  const { user } = useAuth();
  const { getAllTasks, getAssignedTasks, getCreatedTasks, getTaskById } = useTask();
  const { isUserAuthorizedForRole, getAllUsers } = useUser();

  const [allTasks, setAllTasks] = useState([]);
  const [filteredTasks, setFilteredTasks] = useState([]);
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [viewMode, setViewMode] = useState('grid');
  const [activeTab, setActiveTab] = useState('assigned'); // 'assigned' or 'created'

  // Filter states
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [assigneeFilter, setAssigneeFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Permissions
  const canViewAllTasks = isUserAuthorizedForRole('Admin') || isUserAuthorizedForRole('HR');
  const canCreateTasks = isUserAuthorizedForRole('Admin') || isUserAuthorizedForRole('HR') || isUserAuthorizedForRole('Manager');
  const showTabs = canViewAllTasks || isUserAuthorizedForRole('Manager');
  const allUsers = getAllUsers() || [];

  // Derived status function
  const getDerivedStatus = (progress) => {
    if (progress === 0) return "Not Started";
    if (progress === 100) return "Completed";
    return "In Progress";
  };

  // Load tasks
  useEffect(() => {
    if (user) {
      let tasks = [];
      if (canViewAllTasks) {
        tasks = getAllTasks();
      } else if (isUserAuthorizedForRole('Manager')) {
        tasks = [...getAssignedTasks(), ...getCreatedTasks()];
        tasks = Array.from(new Map(tasks.map(task => [task.id, task])).values());
      } else {
        tasks = getAssignedTasks();
      }
      setAllTasks(tasks);
    }
  }, [user, getAllTasks, getAssignedTasks, getCreatedTasks, canViewAllTasks]);

  // Apply filters
  useEffect(() => {
    let filtered = [...allTasks];

    if (showTabs && user?.id) {
      if (activeTab === 'created') {
        filtered = filtered.filter(task => task.assigned_by === user.id);
      } else if (!canViewAllTasks) {
        filtered = filtered.filter(task => task.assigned_to === user.id);
      }
    } else if (user?.id) {
      filtered = filtered.filter(task => task.assigned_to === user.id);
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(task => getDerivedStatus(task.progress) === statusFilter);
    }
    if (priorityFilter !== 'all') {
      filtered = filtered.filter(task => task.priority === priorityFilter);
    }
    if (assigneeFilter !== 'all') {
      filtered = filtered.filter(task => task.assigned_to === assigneeFilter);
    }
    if (searchQuery) {
      filtered = filtered.filter(task =>
        (task.title?.toLowerCase() || '').includes(searchQuery.toLowerCase()) ||
        (task.description?.toLowerCase() || '').includes(searchQuery.toLowerCase())
      );
    }

    setFilteredTasks(filtered);
  }, [allTasks, statusFilter, priorityFilter, assigneeFilter, searchQuery, activeTab, user?.id, showTabs, canViewAllTasks]);

  // Handle task updates
  const handleTaskUpdate = () => {
    let tasks = [];
    if (canViewAllTasks) {
      tasks = getAllTasks();
    } else if (isUserAuthorizedForRole('Manager')) {
      tasks = [...getAssignedTasks(), ...getCreatedTasks()];
      tasks = Array.from(new Map(tasks.map(task => [task.id, task])).values());
    } else {
      tasks = getAssignedTasks();
    }
    setAllTasks(tasks);
  };

  const handleExportToExcel = () => {
    if (!canViewAllTasks) {
      toast.error('You do not have permission to export data');
      return;
    }

    const exportData = filteredTasks.map(task => {
      const assignedUser = allUsers.find(u => u.id === task.assigned_to);
      const createdUser = allUsers.find(u => u.id === task.assigned_by);

      return {
        'Task Title': task.title || 'Untitled',
        'Description': task.description || 'No description',
        'Assigned To': assignedUser?.name || task.assigned_to || 'Unknown',
        'Created By': createdUser?.name || task.assigned_by || 'Unknown',
        'Priority': task.priority || 'N/A',
        'Status': getDerivedStatus(task.progress),
        'Progress': `${task.progress || 0}%`,
        'Due Date': task.due_date ? format(new Date(task.due_date), 'MMM dd, yyyy') : 'N/A',
        'Created At': task.created_at ? format(new Date(task.created_at), 'MMM dd, yyyy') : 'N/A',
        'Updated At': task.updated_at ? format(new Date(task.updated_at), 'MMM dd, yyyy') : 'N/A',
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Tasks');

    const fileName = `tasks_export_${format(new Date(), 'yyyy-MM-dd')}.xlsx`;
    XLSX.writeFile(workbook, fileName);

    toast.success('Tasks exported successfully');
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'High': return 'bg-red-500';
      case 'Medium': return 'bg-yellow-500';
      case 'Low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Completed': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'In Progress': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'Not Started': return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  const TaskCard = ({ task }) => {
    const assignedUser = allUsers.find(u => u.id === task.assigned_to);
    const isOverdue = task.due_date && new Date(task.due_date) < new Date() && task.progress !== 100;

    return (
      <Card
        className={cn(
          "cursor-pointer hover:shadow-md transition-shadow border rounded-lg",
          isOverdue && "border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950"
        )}
        onClick={() => setSelectedTask(task)}
      >
        <CardHeader className="pb-2 px-3 pt-3 sm:pb-3 sm:px-4 sm:pt-4">
          <div className="flex items-start justify-between">
            <CardTitle className="text-base sm:text-lg font-medium line-clamp-2">{task.title || 'Untitled'}</CardTitle>
            <div className="flex items-center gap-1 sm:gap-2">
              <div className={cn("w-2 h-2 sm:w-3 sm:h-3 rounded-full", getPriorityColor(task.priority))} />
              <Badge variant="secondary" className={cn(getStatusColor(getDerivedStatus(task.progress)), "px-1 sm:px-2 py-0.5 text-xs")}>
                {getDerivedStatus(task.progress)}
              </Badge>
            </div>
          </div>
          <CardDescription className="text-xs sm:text-sm text-muted-foreground line-clamp-2">
            {task.description || 'No description'}
          </CardDescription>
        </CardHeader>
        <CardContent className="px-3 pb-3 sm:px-4 sm:pb-4">
          <div className="space-y-2 sm:space-y-3">
            <div className="flex items-center justify-between text-xs sm:text-sm">
              <span className="text-muted-foreground">Assigned to:</span>
              <span className="font-medium">{assignedUser?.name || task.assigned_to || 'Unassigned'}</span>
            </div>
            <div className="flex items-center justify-between text-xs sm:text-sm">
              <span className="text-muted-foreground">Due date:</span>
              <span className={cn(
                "font-medium",
                isOverdue && "text-red-600 dark:text-red-400"
              )}>
                {task.due_date && !isNaN(new Date(task.due_date).getTime())
                  ? format(new Date(task.due_date), 'MMM dd, yyyy')
                  : 'No due date'}
              </span>
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs sm:text-sm">
                <span className="text-muted-foreground">Progress:</span>
                <span className="font-medium">{task.progress || 0}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-1.5 sm:h-2 dark:bg-gray-700">
                <div
                  className="bg-blue-600 h-1.5 sm:h-2 rounded-full transition-all"
                  style={{ width: `${task.progress || 0}%` }}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-4 p-2 sm:p-4 md:p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-4">
        <div className="space-y-1">
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight">Tasks</h1>
          <p className="text-xs sm:text-sm text-muted-foreground">
            Manage and track your tasks efficiently.
          </p>
        </div>
        <div className="flex items-center gap-2 w-full sm:w-auto">
          {canViewAllTasks && (
            <Button variant="outline" onClick={handleExportToExcel} className="gap-1 sm:gap-2 text-xs sm:text-sm flex-1 sm:flex-none">
              <Download className="w-3 h-3 sm:w-4 sm:h-4" />
              Export
            </Button>
          )}
          {canCreateTasks && (
            <Button onClick={() => setShowTaskForm(true)} className="gap-1 sm:gap-2 bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm flex-1 sm:flex-none">
              <Plus className="w-3 h-3 sm:w-4 sm:h-4" />
              Create Task
            </Button>
          )}
        </div>
      </div>

      {/* Tabs */}
      {showTabs && (
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="-mb-px flex space-x-4 sm:space-x-8" aria-label="Tabs">
            <button
              onClick={() => setActiveTab('assigned')}
              className={cn(
                activeTab === 'assigned'
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300',
                'whitespace-nowrap py-2 sm:py-4 px-1 border-b-2 font-medium text-xs sm:text-sm'
              )}
            >
              {canViewAllTasks ? 'All Tasks' : 'Assigned to Me'}
            </button>
            <button
              onClick={() => setActiveTab('created')}
              className={cn(
                activeTab === 'created'
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300',
                'whitespace-nowrap py-2 sm:py-4 px-1 border-b-2 font-medium text-xs sm:text-sm'
              )}
            >
              Created by Me
            </button>
          </nav>
        </div>
      )}

      {/* Filters - Fixed with proper z-index */}
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-5 sm:gap-3 relative">
        <div className="relative z-50">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full text-xs sm:text-sm">
              <SelectValue placeholder="Filter by Status" />
            </SelectTrigger>
            <SelectContent className="z-50 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-lg">
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="Not Started">Not Started</SelectItem>
              <SelectItem value="In Progress">In Progress</SelectItem>
              <SelectItem value="Completed">Completed</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="relative z-40">
          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger className="w-full text-xs sm:text-sm">
              <SelectValue placeholder="Filter by Priority" />
            </SelectTrigger>
            <SelectContent className="z-50 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-lg">
              <SelectItem value="all">All Priorities</SelectItem>
              <SelectItem value="Low">Low</SelectItem>
              <SelectItem value="Medium">Medium</SelectItem>
              <SelectItem value="High">High</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="relative z-30">
          <Select value={assigneeFilter} onValueChange={setAssigneeFilter}>
            <SelectTrigger className="w-full text-xs sm:text-sm">
              <SelectValue placeholder="Filter by Assignee" />
            </SelectTrigger>
            <SelectContent className="z-50 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-lg max-h-60 overflow-y-auto">
              <SelectItem value="all">All Assignees</SelectItem>
              {allUsers.map(user => (
                <SelectItem key={user.id} value={user.id}>{user.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <Input
          type="search"
          placeholder="Search tasks..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="sm:col-span-2 text-xs sm:text-sm relative z-10"
        />
      </div>

      {/* View mode toggle */}
      <div className="flex justify-end gap-2">
        <Button variant={viewMode === 'grid' ? 'default' : 'outline'} onClick={() => setViewMode('grid')} size="sm">
          <Grid className="w-4 h-4 sm:w-5 sm:h-5" />
        </Button>
        <Button variant={viewMode === 'list' ? 'default' : 'outline'} onClick={() => setViewMode('list')} size="sm">
          <List className="w-4 h-4 sm:w-5 sm:h-5" />
        </Button>
      </div>

      {/* Tasks List */}
      {filteredTasks.length === 0 ? (
        <p className="text-center text-muted-foreground text-xs sm:text-sm">No tasks found.</p>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4">
          {filteredTasks.map(task => (
            <TaskCard key={task.id} task={task} />
          ))}
        </div>
      ) : (
        <div className="space-y-3 sm:space-y-4">
          {filteredTasks.map(task => (
            <TaskCard key={task.id} task={task} />
          ))}
        </div>
      )}

      {/* Task Form Modal */}
      <Modal
        isOpen={showTaskForm}
        onClose={() => setShowTaskForm(false)}
        title="Create New Task"
      >
        <TaskForm
          onClose={() => setShowTaskForm(false)}
          onSave={() => {
            setShowTaskForm(false);
            handleTaskUpdate();
          }}
        />
      </Modal>

      {/* Task Detail Modal */}
      <Modal
        isOpen={!!selectedTask}
        onClose={() => setSelectedTask(null)}
        title="Task Details"
      >
        {selectedTask && (
          <TaskDetail
            task={selectedTask}
            onClose={() => setSelectedTask(null)}
            onUpdate={handleTaskUpdate}
          />
        )}
      </Modal>
    </div>
  );
}