
// import { useState, useRef, useEffect } from 'react';
// import { useAuth } from '@/contexts/AuthContext';
// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
// import { Button } from '@/components/ui/button';
// import { Input } from '@/components/ui/input';
// import { Label } from '@/components/ui/label';
// import { Switch } from '@/components/ui/switch';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
// import { toast } from 'sonner';
// import { Camera, Upload, Trash2 } from 'lucide-react';

// const Settings = () => {
//   const { user, updateUser } = useAuth();
//   const fileInputRef = useRef(null);
//   const [showPhotoMenu, setShowPhotoMenu] = useState(false);
//   const [localAvatar, setLocalAvatar] = useState(null);
//   const [profileData, setProfileData] = useState({
//     name: '',
//     email: '',
//     phone: '',
//     department: '',
//     position: '',
//   });
  
//   const [security, setSecurity] = useState({
//     currentPassword: '',
//     newPassword: '',
//     confirmPassword: '',
//   });
  
//   const [notifications, setNotifications] = useState({
//     email: true,
//     sms: false,
//     browser: true,
//     leaveRequests: true,
//     announcements: true,
//     taskAssignments: true,
//   });
  
//   const [isSubmitting, setIsSubmitting] = useState(false);
//   const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
//   const [refreshTrigger, setRefreshTrigger] = useState(0);

//   // Fetch fresh user data from database
//   const fetchFreshUserData = async () => {
//     if (!user?.id) return null;
    
//     try {
//       const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/employees/${user.id}/debug`);
//       if (response.ok) {
//         const data = await response.json();
//         const freshUser = data.user;
        
//         // Update the user context with fresh data
//         if (updateUser) {
//           const updatedUserData = {
//             ...user,
//             name: freshUser.name,
//             email: freshUser.email,
//             avatar: freshUser.avatar,
//             phone_number: freshUser.phone_number,
//             department: freshUser.department,
//             position: freshUser.position,
//           };
//           updateUser(updatedUserData);
//         }
        
//         // Update profile form data
//         setProfileData({
//           name: freshUser.name || '',
//           email: freshUser.email || '',
//           phone: freshUser.phone_number || '',
//           department: freshUser.department || '',
//           position: freshUser.position || '',
//         });
        
//         // Update local avatar
//         setLocalAvatar(freshUser.avatar);
        
//         return freshUser;
//       } else {
//         console.error('Failed to fetch fresh user data:', response.status);
//       }
//     } catch (error) {
//       console.error('Error fetching fresh user data:', error);
//     }
//     return null;
//   };

//   // Initialize profile data when user is loaded and on refresh trigger
//   useEffect(() => {
//     if (user?.id) {
//       // Set initial data from current user context
//       setProfileData({
//         name: user.name || '',
//         email: user.email || '',
//         phone: user.phone_number || '',
//         department: user.department || '',
//         position: user.position || '',
//       });
      
//       // Initialize local avatar
//       setLocalAvatar(user.avatar);
      
//       // Always fetch fresh data from database
//       fetchFreshUserData();
//     }
//   }, [user?.id, refreshTrigger]);

//   // Add a function to force refresh data
//   const forceRefreshUserData = async () => {
//     setRefreshTrigger(prev => prev + 1);
//     await fetchFreshUserData();
//   };

//   const handleProfileChange = (e) => {
//     const { name, value } = e.target;
//     setProfileData(prev => ({
//       ...prev,
//       [name]: value
//     }));
//   };
  
//   const handleSecurityChange = (e) => {
//     const { name, value } = e.target;
//     setSecurity(prev => ({
//       ...prev,
//       [name]: value
//     }));
//   };
  
//   const handleToggleChange = (name, checked) => {
//     setNotifications(prev => ({
//       ...prev,
//       [name]: checked
//     }));
//   };

//   const handlePhotoUpload = async (file) => {
//     if (!file) return;

//     // Validate file type
//     if (!file.type.startsWith('image/')) {
//       toast.error('Please select an image file');
//       return;
//     }

//     // Validate file size (max 5MB)
//     if (file.size > 5 * 1024 * 1024) {
//       toast.error('Image size should be less than 5MB');
//       return;
//     }

//     setIsUploadingPhoto(true);

//     try {
//       // Upload to S3
//       const formData = new FormData();
//       formData.append('avatar', file);
//       formData.append('userId', user.id);

//       const uploadResponse = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/upload-avatar`, {
//         method: 'POST',
//         body: formData,
//       });

//       if (!uploadResponse.ok) {
//         throw new Error('Failed to upload image');
//       }

//       const { url } = await uploadResponse.json();

//       // Update user profile with new avatar URL
//       const updateResponse = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/employees/${user.id}`, {
//         method: 'PUT',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({
//           avatar: url,
//         }),
//       });

//       if (!updateResponse.ok) {
//         throw new Error('Failed to update profile');
//       }

//       // Immediately update local avatar state for instant UI update
//       setLocalAvatar(url);

//       // Also update the user context
//       if (updateUser) {
//         const updatedUserData = {
//           ...user,
//           avatar: url,
//         };
//         updateUser(updatedUserData);
//       }

//       // Force refresh the user data
//       await forceRefreshUserData();

//       toast.success('Profile photo updated successfully');
//       setShowPhotoMenu(false);
//     } catch (error) {
//       console.error('Error uploading photo:', error);
//       toast.error('Failed to update profile photo');
//     } finally {
//       setIsUploadingPhoto(false);
//     }
//   };

//   const handleRemovePhoto = async () => {
//     setIsUploadingPhoto(true);

//     try {
//       const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/employees/${user.id}`, {
//         method: 'PUT',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({
//           avatar: null,
//         }),
//       });

//       if (!response.ok) {
//         throw new Error('Failed to remove photo');
//       }

//       // Immediately update local avatar state for instant UI update
//       setLocalAvatar(null);

//       // Also update the user context
//       if (updateUser) {
//         const updatedUserData = {
//           ...user,
//           avatar: null,
//         };
//         updateUser(updatedUserData);
//       }

//       // Force refresh the user data
//       await forceRefreshUserData();

//       toast.success('Profile photo removed successfully');
//       setShowPhotoMenu(false);
//     } catch (error) {
//       console.error('Error removing photo:', error);
//       toast.error('Failed to remove profile photo');
//     } finally {
//       setIsUploadingPhoto(false);
//     }
//   };

//   const handleFileInputChange = (e) => {
//     const file = e.target.files[0];
//     if (file) {
//       handlePhotoUpload(file);
//     }
//   };
  
//   const handleProfileSubmit = async (e) => {
//     e.preventDefault();
//     setIsSubmitting(true);
    
//     try {
//       const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/employees/${user.id}`, {
//         method: 'PUT',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({
//           name: profileData.name,
//           phone_number: profileData.phone,
//         }),
//       });

//       if (!response.ok) {
//         throw new Error('Failed to update profile');
//       }

//       // Force refresh the user data
//       await forceRefreshUserData();

//       toast.success('Profile updated successfully');
//     } catch (error) {
//       console.error('Error updating profile:', error);
//       toast.error('Failed to update profile');
//     } finally {
//       setIsSubmitting(false);
//     }
//   };

//   const handlePasswordSubmit = async (e) => {
//     e.preventDefault();
    
//     if (security.newPassword !== security.confirmPassword) {
//       toast.error('New passwords do not match');
//       return;
//     }
    
//     setIsSubmitting(true);
    
//     try {
//       // First verify the current password
//       const verifyResponse = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/verify-password`, {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({
//           userId: user.id,
//           currentPassword: security.currentPassword,
//         }),
//       });

//       if (!verifyResponse.ok) {
//         const errorData = await verifyResponse.json();
//         toast.error(errorData.error || 'Current password is incorrect');
//         return;
//       }

//       // If verification successful, update password
//       const updateResponse = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/employees/${user.id}/password`, {
//         method: 'PUT',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({
//           newPassword: security.newPassword,
//         }),
//       });

//       if (!updateResponse.ok) {
//         throw new Error('Failed to update password');
//       }

//       toast.success('Password changed successfully');
      
//       // Reset fields
//       setSecurity({
//         currentPassword: '',
//         newPassword: '',
//         confirmPassword: '',
//       });
//     } catch (error) {
//       console.error('Error changing password:', error);
//       toast.error('Failed to change password');
//     } finally {
//       setIsSubmitting(false);
//     }
//   };
  
//   const handleNotificationsSubmit = (e) => {
//     e.preventDefault();
//     setIsSubmitting(true);
    
//     // Simulate API call
//     setTimeout(() => {
//       toast.success('Notification preferences updated');
//       setIsSubmitting(false);
//     }, 1000);
//   };
  
//   if (!user) return <div>Loading...</div>;
  
//   // Only Admin user can access all settings
//   const isAdmin = user.role === 'Admin';

//   return (
//     <div className="max-w-4xl mx-auto py-5">
//       <Tabs defaultValue="profile" className="w-full">
//         <TabsList className="mb-6">
//           <TabsTrigger value="profile">Profile</TabsTrigger>
//           <TabsTrigger value="security">Security</TabsTrigger>
//         </TabsList>

//         {/* Profile Settings */}
//         <TabsContent value="profile">
//           <Card>
//             <CardHeader>
//               <CardTitle className="text-xl">Profile Settings</CardTitle>
//               <CardDescription>Manage your personal information</CardDescription>
//             </CardHeader>
//             <CardContent>
//               <form onSubmit={handleProfileSubmit} className="space-y-6">
//                 <div className="flex justify-center mb-6">
//                   <div className="relative">
//                     {(localAvatar || user.avatar) ? (
//                       <img 
//                         src={`${localAvatar || user.avatar}?t=${Date.now()}`} 
//                         alt={user.name} 
//                         className="w-24 h-24 rounded-full object-cover border-4 border-gray-100 cursor-pointer"
//                         onClick={() => setShowPhotoMenu(!showPhotoMenu)}
//                       />
//                     ) : (
//                       <div 
//                         className="w-24 h-24 rounded-full bg-primary flex items-center justify-center text-white text-xl font-semibold cursor-pointer"
//                         onClick={() => setShowPhotoMenu(!showPhotoMenu)}
//                       >
//                         {user.name?.charAt(0)}
//                       </div>
//                     )}
                    
//                     {/* Photo Menu */}
//                     {showPhotoMenu && (
//                       <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-10 min-w-40">
//                         <div className="py-1">
//                           <button
//                             type="button"
//                             className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
//                             onClick={() => {
//                               fileInputRef.current?.click();
//                               setShowPhotoMenu(false);
//                             }}
//                             disabled={isUploadingPhoto}
//                           >
//                             <Upload className="w-4 h-4 mr-2" />
//                             {(localAvatar || user.avatar) ? 'Edit Photo' : 'Upload Photo'}
//                           </button>
//                           {(localAvatar || user.avatar) && (
//                             <button
//                               type="button"
//                               className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
//                               onClick={handleRemovePhoto}
//                               disabled={isUploadingPhoto}
//                             >
//                               <Trash2 className="w-4 h-4 mr-2" />
//                               Remove Photo
//                             </button>
//                           )}
//                         </div>
//                       </div>
//                     )}
                    
//                     {/* Camera Icon */}
//                     <Button 
//                       type="button"
//                       size="sm" 
//                       className="absolute bottom-0 right-0 rounded-full w-8 h-8 p-0"
//                       onClick={() => setShowPhotoMenu(!showPhotoMenu)}
//                       disabled={isUploadingPhoto}
//                     >
//                       <Camera className="w-4 h-4" />
//                     </Button>
                    
//                     {/* Hidden File Input */}
//                     <input
//                       ref={fileInputRef}
//                       type="file"
//                       accept="image/*"
//                       onChange={handleFileInputChange}
//                       className="hidden"
//                     />
//                   </div>
//                 </div>

//                 {/* Click outside to close menu */}
//                 {showPhotoMenu && (
//                   <div 
//                     className="fixed inset-0 z-5"
//                     onClick={() => setShowPhotoMenu(false)}
//                   />
//                 )}
              
//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//                   <div className="space-y-2">
//                     <Label htmlFor="name">Full Name</Label>
//                     <Input
//                       id="name"
//                       name="name"
//                       value={profileData.name}
//                       onChange={handleProfileChange}
//                       placeholder="Enter your full name"
//                     />
//                   </div>
                  
//                   <div className="space-y-2">
//                     <Label htmlFor="email">Email Address</Label>
//                     <Input
//                       id="email"
//                       name="email"
//                       type="email"
//                       value={profileData.email}
//                       onChange={handleProfileChange}
//                       disabled
//                       className="bg-gray-50"
//                     />
//                   </div>
                  
//                   <div className="space-y-2">
//                     <Label htmlFor="phone">Phone Number</Label>
//                     <Input
//                       id="phone"
//                       name="phone"
//                       value={profileData.phone}
//                       onChange={handleProfileChange}
//                       placeholder="Enter phone number"
//                     />
//                   </div>
                  
//                   <div className="space-y-2">
//                     <Label htmlFor="department">Department</Label>
//                     <Input
//                       id="department"
//                       name="department"
//                       value={profileData.department}
//                       onChange={handleProfileChange}
//                       placeholder="Your department"
//                       disabled
//                       className="bg-gray-50"
//                     />
//                   </div>
                  
//                   <div className="space-y-2">
//                     <Label htmlFor="position">Position</Label>
//                     <Input
//                       id="position"
//                       name="position"
//                       value={profileData.position}
//                       onChange={handleProfileChange}
//                       placeholder="Your position"
//                       disabled
//                       className="bg-gray-50"
//                     />
//                   </div>
                  
//                   <div className="space-y-2">
//                     <Label>Role</Label>
//                     <Input
//                       value={user.role}
//                       disabled
//                       className="bg-gray-50"
//                     />
//                   </div>
//                 </div>
                
//                 <div className="flex justify-end">
//                   <Button 
//                     type="submit"
//                     className="bg-primary hover:bg-primary-600"
//                     disabled={isSubmitting}
//                   >
//                     {isSubmitting ? 'Updating...' : 'Update Profile'}
//                   </Button>
//                 </div>
//               </form>
//             </CardContent>
//           </Card>
//         </TabsContent>
        
//         {/* Security Settings */}
//         <TabsContent value="security">
//           <Card>
//             <CardHeader>
//               <CardTitle className="text-xl">Security Settings</CardTitle>
//               <CardDescription>Manage your password and security settings</CardDescription>
//             </CardHeader>
//             <CardContent>
//               <form onSubmit={handlePasswordSubmit} className="space-y-6">
//                 <div className="space-y-4">
//                   <div className="space-y-2">
//                     <Label htmlFor="currentPassword">Current Password</Label>
//                     <Input
//                       id="currentPassword"
//                       name="currentPassword"
//                       type="password"
//                       value={security.currentPassword}
//                       onChange={handleSecurityChange}
//                       required
//                     />
//                   </div>
                  
//                   <div className="space-y-2">
//                     <Label htmlFor="newPassword">New Password</Label>
//                     <Input
//                       id="newPassword"
//                       name="newPassword"
//                       type="password"
//                       value={security.newPassword}
//                       onChange={handleSecurityChange}
//                       required
//                     />
//                   </div>
                  
//                   <div className="space-y-2">
//                     <Label htmlFor="confirmPassword">Confirm New Password</Label>
//                     <Input
//                       id="confirmPassword"
//                       name="confirmPassword"
//                       type="password"
//                       value={security.confirmPassword}
//                       onChange={handleSecurityChange}
//                       required
//                     />
//                   </div>
//                 </div>
                
//                 <div className="flex justify-end">
//                   <Button 
//                     type="submit"
//                     className="bg-primary hover:bg-primary-600"
//                     disabled={isSubmitting}
//                   >
//                     {isSubmitting ? 'Changing...' : 'Change Password'}
//                   </Button>
//                 </div>
//               </form>
//             </CardContent>
//           </Card>
//         </TabsContent>
        
//         {/* Notification Settings */}
//         <TabsContent value="notifications">
//           <Card>
//             <CardHeader>
//               <CardTitle className="text-xl">Notification Settings</CardTitle>
//               <CardDescription>Manage how you receive notifications</CardDescription>
//             </CardHeader>
//             <CardContent>
//               <form onSubmit={handleNotificationsSubmit} className="space-y-6">
//                 <div className="space-y-6">
//                   <div>
//                     <h3 className="text-lg font-medium">Notification Channels</h3>
//                     <div className="mt-4 space-y-4">
//                       <div className="flex items-center justify-between">
//                         <div>
//                           <Label htmlFor="email-notifications">Email Notifications</Label>
//                           <p className="text-sm text-gray-500">Receive notifications via email</p>
//                         </div>
//                         <Switch
//                           id="email-notifications"
//                           checked={notifications.email}
//                           onCheckedChange={(checked) => handleToggleChange('email', checked)}
//                         />
//                       </div>
                      
//                       <div className="flex items-center justify-between">
//                         <div>
//                           <Label htmlFor="sms-notifications">SMS Notifications</Label>
//                           <p className="text-sm text-gray-500">Receive notifications via text message</p>
//                         </div>
//                         <Switch
//                           id="sms-notifications"
//                           checked={notifications.sms}
//                           onCheckedChange={(checked) => handleToggleChange('sms', checked)}
//                         />
//                       </div>
                      
//                       <div className="flex items-center justify-between">
//                         <div>
//                           <Label htmlFor="browser-notifications">Browser Notifications</Label>
//                           <p className="text-sm text-gray-500">Receive in-app notifications</p>
//                         </div>
//                         <Switch
//                           id="browser-notifications"
//                           checked={notifications.browser}
//                           onCheckedChange={(checked) => handleToggleChange('browser', checked)}
//                         />
//                       </div>
//                     </div>
//                   </div>
                  
//                   <div>
//                     <h3 className="text-lg font-medium">Notification Types</h3>
//                     <div className="mt-4 space-y-4">
//                       <div className="flex items-center justify-between">
//                         <div>
//                           <Label htmlFor="leave-notifications">Leave Requests</Label>
//                           <p className="text-sm text-gray-500">Updates about leave requests</p>
//                         </div>
//                         <Switch
//                           id="leave-notifications"
//                           checked={notifications.leaveRequests}
//                           onCheckedChange={(checked) => handleToggleChange('leaveRequests', checked)}
//                         />
//                       </div>
                      
//                       <div className="flex items-center justify-between">
//                         <div>
//                           <Label htmlFor="announcements">Announcements</Label>
//                           <p className="text-sm text-gray-500">Company announcements and news</p>
//                         </div>
//                         <Switch
//                           id="announcements"
//                           checked={notifications.announcements}
//                           onCheckedChange={(checked) => handleToggleChange('announcements', checked)}
//                         />
//                       </div>
                      
//                       <div className="flex items-center justify-between">
//                         <div>
//                           <Label htmlFor="task-assignments">Task Assignments</Label>
//                           <p className="text-sm text-gray-500">When you're assigned new tasks</p>
//                         </div>
//                         <Switch
//                           id="task-assignments"
//                           checked={notifications.taskAssignments}
//                           onCheckedChange={(checked) => handleToggleChange('taskAssignments', checked)}
//                         />
//                       </div>
//                     </div>
//                   </div>
//                 </div>
                
//                 <div className="flex justify-end">
//                   <Button 
//                     type="submit"
//                     className="bg-primary hover:bg-primary-600"
//                     disabled={isSubmitting}
//                   >
//                     {isSubmitting ? 'Saving...' : 'Save Preferences'}
//                   </Button>
//                 </div>
//               </form>
//             </CardContent>
//           </Card>
//         </TabsContent>
        
//         {/* Admin System Settings */}
//         {isAdmin && (
//           <TabsContent value="system">
//             <Card>
//               <CardHeader>
//                 <CardTitle className="text-xl">System Settings</CardTitle>
//                 <CardDescription>Administrator-only system configuration</CardDescription>
//               </CardHeader>
//               <CardContent>
//                 <div className="space-y-6">
//                   <div>
//                     <h3 className="text-lg font-medium">General Configuration</h3>
//                     <div className="mt-4 space-y-4">
//                       <div className="flex items-center justify-between">
//                         <div>
//                           <Label htmlFor="maintenance-mode">Maintenance Mode</Label>
//                           <p className="text-sm text-gray-500">Put the system in maintenance mode</p>
//                         </div>
//                         <Switch id="maintenance-mode" />
//                       </div>
                      
//                       <div className="flex items-center justify-between">
//                         <div>
//                           <Label htmlFor="new-registrations">Allow New Registrations</Label>
//                           <p className="text-sm text-gray-500">Enable new user registrations</p>
//                         </div>
//                         <Switch id="new-registrations" defaultChecked />
//                       </div>
//                     </div>
//                   </div>
                  
//                   <div>
//                     <h3 className="text-lg font-medium">Data Management</h3>
//                     <div className="mt-4 space-y-4">
//                       <div className="flex items-center justify-between">
//                         <div>
//                           <Label htmlFor="auto-backup">Automatic Backups</Label>
//                           <p className="text-sm text-gray-500">Schedule regular data backups</p>
//                         </div>
//                         <Switch id="auto-backup" defaultChecked />
//                       </div>
                      
//                       <div>
//                         <Label htmlFor="retention-days">Data Retention (days)</Label>
//                         <Input
//                           id="retention-days"
//                           type="number"
//                           defaultValue={90}
//                           className="w-full md:w-1/3 mt-1"
//                         />
//                       </div>
//                     </div>
//                   </div>
                  
//                   <div>
//                     <h3 className="text-lg font-medium">Security Settings</h3>
//                     <div className="mt-4 space-y-4">
//                       <div className="flex items-center justify-between">
//                         <div>
//                           <Label htmlFor="2fa">Require Two-Factor Authentication</Label>
//                           <p className="text-sm text-gray-500">For all admin users</p>
//                         </div>
//                         <Switch id="2fa" />
//                       </div>
                      
//                       <div className="flex items-center justify-between">
//                         <div>
//                           <Label htmlFor="session-timeout">Session Timeout</Label>
//                           <p className="text-sm text-gray-500">Auto logout after inactivity</p>
//                         </div>
//                         <Input
//                           id="session-timeout"
//                           type="number"
//                           defaultValue={30}
//                           className="w-20"
//                           min={5}
//                         />
//                       </div>
//                     </div>
//                   </div>
//                 </div>
                
//                 <div className="flex justify-end mt-6">
//                   <Button 
//                     type="button" 
//                     className="bg-primary hover:bg-primary-600"
//                   >
//                     Save System Settings
//                   </Button>
//                 </div>
//               </CardContent>
//             </Card>
//           </TabsContent>
//         )}
//       </Tabs>
//     </div>
//   );
// };

// export default Settings;
import { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Camera, Upload, Trash2 } from 'lucide-react';

const Settings = () => {
  const { user, updateUser } = useAuth();
  const fileInputRef = useRef(null);
  const [showPhotoMenu, setShowPhotoMenu] = useState(false);
  const [localAvatar, setLocalAvatar] = useState(null);
  const [profileData, setProfileData] = useState({
    name: '',
    email: '',
    phone: '',
    department: '',
    position: '',
  });
  
  const [security, setSecurity] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  
  const [notifications, setNotifications] = useState({
    email: true,
    sms: false,
    browser: true,
    leaveRequests: true,
    announcements: true,
    taskAssignments: true,
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Fetch fresh user data from database
  const fetchFreshUserData = async () => {
    if (!user?.id) return null;
    
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/employees/${user.id}/debug`);
      if (response.ok) {
        const data = await response.json();
        const freshUser = data.user;
        
        // Update the user context with fresh data
        if (updateUser) {
          const updatedUserData = {
            ...user,
            name: freshUser.name,
            email: freshUser.email,
            avatar: freshUser.avatar,
            phone_number: freshUser.phone_number,
            department: freshUser.department,
            position: freshUser.position,
          };
          updateUser(updatedUserData);
        }
        
        // Update profile form data
        setProfileData({
          name: freshUser.name || '',
          email: freshUser.email || '',
          phone: freshUser.phone_number || '',
          department: freshUser.department || '',
          position: freshUser.position || '',
        });
        
        // Update local avatar
        setLocalAvatar(freshUser.avatar);
        
        return freshUser;
      } else {
        console.error('Failed to fetch fresh user data:', response.status);
      }
    } catch (error) {
      console.error('Error fetching fresh user data:', error);
    }
    return null;
  };

  // Initialize profile data when user is loaded and on refresh trigger
  useEffect(() => {
    if (user?.id) {
      // Set initial data from current user context
      setProfileData({
        name: user.name || '',
        email: user.email || '',
        phone: user.phone_number || '',
        department: user.department || '',
        position: user.position || '',
      });
      
      // Initialize local avatar
      setLocalAvatar(user.avatar);
      
      // Always fetch fresh data from database
      fetchFreshUserData();
    }
  }, [user?.id, refreshTrigger]);

  // Add a function to force refresh data
  const forceRefreshUserData = async () => {
    setRefreshTrigger(prev => prev + 1);
    await fetchFreshUserData();
  };

  const handleProfileChange = (e) => {
    const { name, value } = e.target;
    if (name === 'name') {
      // Allow only alphabetic characters and spaces, no numbers
      if (/^[A-Za-z\s]*$/.test(value)) {
        setProfileData(prev => ({
          ...prev,
          [name]: value
        }));
      } else {
        toast.error('Name can only contain letters and spaces');
      }
    } else if (name === 'phone') {
      // Allow only numbers, +, -, and spaces
      if (/^[0-9+\-\s]*$/.test(value)) {
        setProfileData(prev => ({
          ...prev,
          [name]: value
        }));
      } else {
        toast.error('Phone number can only contain numbers, +, -, and spaces');
      }
    } else {
      setProfileData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };
  
  const handleSecurityChange = (e) => {
    const { name, value } = e.target;
    setSecurity(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleToggleChange = (name, checked) => {
    setNotifications(prev => ({
      ...prev,
      [name]: checked
    }));
  };

  const handlePhotoUpload = async (file) => {
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image size should be less than 5MB');
      return;
    }

    setIsUploadingPhoto(true);

    try {
      // Upload to S3
      const formData = new FormData();
      formData.append('avatar', file);
      formData.append('userId', user.id);

      const uploadResponse = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/upload-avatar`, {
        method: 'POST',
        body: formData,
      });

      if (!uploadResponse.ok) {
        throw new Error('Failed to upload image');
      }

      const { url } = await uploadResponse.json();

      // Update user profile with new avatar URL
      const updateResponse = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/employees/${user.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          avatar: url,
        }),
      });

      if (!updateResponse.ok) {
        throw new Error('Failed to update profile');
      }

      // Immediately update local avatar state for instant UI update
      setLocalAvatar(url);

      // Also update the user context
      if (updateUser) {
        const updatedUserData = {
          ...user,
          avatar: url,
        };
        updateUser(updatedUserData);
      }

      // Force refresh the user data
      await forceRefreshUserData();

      toast.success('Profile photo updated successfully');
      setShowPhotoMenu(false);
    } catch (error) {
      console.error('Error uploading photo:', error);
      toast.error('Failed to update profile photo');
    } finally {
      setIsUploadingPhoto(false);
    }
  };

  const handleRemovePhoto = async () => {
    setIsUploadingPhoto(true);

    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/employees/${user.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          avatar: null,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to remove photo');
      }

      // Immediately update local avatar state for instant UI update
      setLocalAvatar(null);

      // Also update the user context
      if (updateUser) {
        const updatedUserData = {
          ...user,
          avatar: null,
        };
        updateUser(updatedUserData);
      }

      // Force refresh the user data
      await forceRefreshUserData();

      toast.success('Profile photo removed successfully');
      setShowPhotoMenu(false);
    } catch (error) {
      console.error('Error removing photo:', error);
      toast.error('Failed to remove profile photo');
    } finally {
      setIsUploadingPhoto(false);
    }
  };

  const handleFileInputChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      handlePhotoUpload(file);
    }
  };
  
  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/employees/${user.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: profileData.name,
          phone_number: profileData.phone,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to update profile');
      }

      // Force refresh the user data
      await forceRefreshUserData();

      toast.success('Profile updated successfully');
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error('Failed to update profile');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    
    if (security.newPassword !== security.confirmPassword) {
      toast.error('New passwords do not match');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // First verify the current password
      const verifyResponse = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/verify-password`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: user.id,
          currentPassword: security.currentPassword,
        }),
      });

      if (!verifyResponse.ok) {
        const errorData = await verifyResponse.json();
        toast.error(errorData.error || 'Current password is incorrect');
        return;
      }

      // If verification successful, update password
      const updateResponse = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/employees/${user.id}/password`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          newPassword: security.newPassword,
        }),
      });

      if (!updateResponse.ok) {
        throw new Error('Failed to update password');
      }

      toast.success('Password changed successfully');
      
      // Reset fields
      setSecurity({
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      });
    } catch (error) {
      console.error('Error changing password:', error);
      toast.error('Failed to change password');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleNotificationsSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      toast.success('Notification preferences updated');
      setIsSubmitting(false);
    }, 1000);
  };
  
  if (!user) return <div>Loading...</div>;
  
  // Only Admin user can access all settings
  const isAdmin = user.role === 'Admin';

  return (
    <div className="max-w-4xl mx-auto py-5">
      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          {/* <TabsTrigger value="notifications">Notifications</TabsTrigger>
          {isAdmin && <TabsTrigger value="system">System</TabsTrigger>} */}
        </TabsList>

        {/* Profile Settings */}
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Profile Settings</CardTitle>
              <CardDescription>Manage your personal information</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleProfileSubmit} className="space-y-6">
                <div className="flex justify-center mb-6">
                  <div className="relative">
                    {(localAvatar || user.avatar) ? (
                      <img 
                        src={`${localAvatar || user.avatar}?t=${Date.now()}`} 
                        alt={user.name} 
                        className="w-24 h-24 rounded-full object-cover border-4 border-gray-100 cursor-pointer"
                        onClick={() => setShowPhotoMenu(!showPhotoMenu)}
                      />
                    ) : (
                      <div 
                        className="w-24 h-24 rounded-full bg-primary flex items-center justify-center text-white text-xl font-semibold cursor-pointer"
                        onClick={() => setShowPhotoMenu(!showPhotoMenu)}
                      >
                        {user.name?.charAt(0)}
                      </div>
                    )}
                    
                    {/* Photo Menu */}
                    {showPhotoMenu && (
                      <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-10 min-w-40">
                        <div className="py-1">
                          <button
                            type="button"
                            className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                            onClick={() => {
                              fileInputRef.current?.click();
                              setShowPhotoMenu(false);
                            }}
                            disabled={isUploadingPhoto}
                          >
                            <Upload className="w-4 h-4 mr-2" />
                            {(localAvatar || user.avatar) ? 'Edit Photo' : 'Upload Photo'}
                          </button>
                          {(localAvatar || user.avatar) && (
                            <button
                              type="button"
                              className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                              onClick={handleRemovePhoto}
                              disabled={isUploadingPhoto}
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Remove Photo
                            </button>
                          )}
                        </div>
                      </div>
                    )}
                    
                    {/* Camera Icon */}
                    <Button 
                      type="button"
                      size="sm" 
                      className="absolute bottom-0 right-0 rounded-full w-8 h-8 p-0"
                      onClick={() => setShowPhotoMenu(!showPhotoMenu)}
                      disabled={isUploadingPhoto}
                    >
                      <Camera className="w-4 h-4" />
                    </Button>
                    
                    {/* Hidden File Input */}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileInputChange}
                      className="hidden"
                    />
                  </div>
                </div>

                {/* Click outside to close menu */}
                {showPhotoMenu && (
                  <div 
                    className="fixed inset-0 z-5"
                    onClick={() => setShowPhotoMenu(false)}
                  />
                )}
              
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      name="name"
                      value={profileData.name}
                      onChange={handleProfileChange}
                      placeholder="Enter your full name"
                      pattern="[A-Za-z\s]+"
                      title="Name can only contain letters and spaces"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={profileData.email}
                      onChange={handleProfileChange}
                      disabled
                      className="bg-gray-50"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      name="phone"
                      value={profileData.phone}
                      onChange={handleProfileChange}
                      placeholder="Enter phone number"
                      pattern="[0-9+\-\s]+"
                      title="Phone number can only contain numbers, +, -, and spaces"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="department">Department</Label>
                    <Input
                      id="department"
                      name="department"
                      value={profileData.department}
                      onChange={handleProfileChange}
                      placeholder="Your department"
                      disabled
                      className="bg-gray-50"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="position">Position</Label>
                    <Input
                      id="position"
                      name="position"
                      value={profileData.position}
                      onChange={handleProfileChange}
                      placeholder="Your position"
                      disabled
                      className="bg-gray-50"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Role</Label>
                    <Input
                      value={user.role}
                      disabled
                      className="bg-gray-50"
                    />
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <Button 
                    type="submit"
                    className="bg-primary hover:bg-primary-600"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? 'Updating...' : 'Update Profile'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Security Settings */}
        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Security Settings</CardTitle>
              <CardDescription>Manage your password and security settings</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePasswordSubmit} className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="currentPassword">Current Password</Label>
                    <Input
                      id="currentPassword"
                      name="currentPassword"
                      type="password"
                      value={security.currentPassword}
                      onChange={handleSecurityChange}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="newPassword">New Password</Label>
                    <Input
                      id="newPassword"
                      name="newPassword"
                      type="password"
                      value={security.newPassword}
                      onChange={handleSecurityChange}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm New Password</Label>
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      value={security.confirmPassword}
                      onChange={handleSecurityChange}
                      required
                    />
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <Button 
                    type="submit"
                    className="bg-primary hover:bg-primary-600"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? 'Changing...' : 'Change Password'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Notification Settings */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Notification Settings</CardTitle>
              <CardDescription>Manage how you receive notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleNotificationsSubmit} className="space-y-6">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium">Notification Channels</h3>
                    <div className="mt-4 space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="email-notifications">Email Notifications</Label>
                          <p className="text-sm text-gray-500">Receive notifications via email</p>
                        </div>
                        <Switch
                          id="email-notifications"
                          checked={notifications.email}
                          onCheckedChange={(checked) => handleToggleChange('email', checked)}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="sms-notifications">SMS Notifications</Label>
                          <p className="text-sm text-gray-500">Receive notifications via text message</p>
                        </div>
                        <Switch
                          id="sms-notifications"
                          checked={notifications.sms}
                          onCheckedChange={(checked) => handleToggleChange('sms', checked)}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="browser-notifications">Browser Notifications</Label>
                          <p className="text-sm text-gray-500">Receive in-app notifications</p>
                        </div>
                        <Switch
                          id="browser-notifications"
                          checked={notifications.browser}
                          onCheckedChange={(checked) => handleToggleChange('browser', checked)}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium">Notification Types</h3>
                    <div className="mt-4 space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="leave-notifications">Leave Requests</Label>
                          <p className="text-sm text-gray-500">Updates about leave requests</p>
                        </div>
                        <Switch
                          id="leave-notifications"
                          checked={notifications.leaveRequests}
                          onCheckedChange={(checked) => handleToggleChange('leaveRequests', checked)}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="announcements">Announcements</Label>
                          <p className="text-sm text-gray-500">Company announcements and news</p>
                        </div>
                        <Switch
                          id="announcements"
                          checked={notifications.announcements}
                          onCheckedChange={(checked) => handleToggleChange('announcements', checked)}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="task-assignments">Task Assignments</Label>
                          <p className="text-sm text-gray-500">When you're assigned new tasks</p>
                        </div>
                        <Switch
                          id="task-assignments"
                          checked={notifications.taskAssignments}
                          onCheckedChange={(checked) => handleToggleChange('taskAssignments', checked)}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <Button 
                    type="submit"
                    className="bg-primary hover:bg-primary-600"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? 'Saving...' : 'Save Preferences'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Admin System Settings */}
        {isAdmin && (
          <TabsContent value="system">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">System Settings</CardTitle>
                <CardDescription>Administrator-only system configuration</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium">General Configuration</h3>
                    <div className="mt-4 space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="maintenance-mode">Maintenance Mode</Label>
                          <p className="text-sm text-gray-500">Put the system in maintenance mode</p>
                        </div>
                        <Switch id="maintenance-mode" />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="new-registrations">Allow New Registrations</Label>
                          <p className="text-sm text-gray-500">Enable new user registrations</p>
                        </div>
                        <Switch id="new-registrations" defaultChecked />
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium">Data Management</h3>
                    <div className="mt-4 space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="auto-backup">Automatic Backups</Label>
                          <p className="text-sm text-gray-500">Schedule regular data backups</p>
                        </div>
                        <Switch id="auto-backup" defaultChecked />
                      </div>
                      
                      <div>
                        <Label htmlFor="retention-days">Data Retention (days)</Label>
                        <Input
                          id="retention-days"
                          type="number"
                          defaultValue={90}
                          className="w-full md:w-1/3 mt-1"
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium">Security Settings</h3>
                    <div className="mt-4 space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="2fa">Require Two-Factor Authentication</Label>
                          <p className="text-sm text-gray-500">For all admin users</p>
                        </div>
                        <Switch id="2fa" />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="session-timeout">Session Timeout</Label>
                          <p className="text-sm text-gray-500">Auto logout after inactivity</p>
                        </div>
                        <Input
                          id="session-timeout"
                          type="number"
                          defaultValue={30}
                          className="w-20"
                          min={5}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end mt-6">
                  <Button 
                    type="button" 
                    className="bg-primary hover:bg-primary-600"
                  >
                    Save System Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};

export default Settings;