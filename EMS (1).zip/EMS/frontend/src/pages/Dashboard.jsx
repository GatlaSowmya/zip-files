import { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '../components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '../components/ui/tabs';
import { useAuth } from '../contexts/AuthContext';
import { CheckCircle, XCircle } from 'lucide-react';

const Dashboard = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [anniversaries, setAnniversaries] = useState([]);

  // Check-In/Check-Out logic
  const [currentStatus, setCurrentStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString());
  const [selectedShift, setSelectedShift] = useState('');
  const [todayRecords, setTodayRecords] = useState([]);
  const [workUpdate, setWorkUpdate] = useState('');
  const [error, setError] = useState('');
  const [showWorkUpdateModal, setShowWorkUpdateModal] = useState(false);

  const shiftOptions = [
    { value: '6.00AM-2.00PM', label: '6:00 AM - 2:00 PM' },
    { value: '9.00AM-6.00PM', label: '9:00 AM - 6:00 PM' },
    { value: '2.00PM-10.00PM', label: '2:00 PM - 10:00 PM' },
  ];

  useEffect(() => {
    fetch(`${import.meta.env.VITE_API_BASE_URL}/api/anniversary-notifications`)
      .then((res) => res.json())
      .then((data) => setAnniversaries(data))
      .catch((err) =>
        console.error('Failed to fetch anniversary notifications:', err)
      );
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (user) fetchTodayStatus();
  }, [user]);

  const fetchTodayStatus = async () => {
    try {
      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/attendance/today/${user.id}`
      );
      const data = await res.json();
      setCurrentStatus(data?.status);
      setTodayRecords(data?.records || []);
    } catch (err) {
      console.error("Error fetching today's status:", err);
    }
  };

  const handleCheckIn = async () => {
    if (!user) return;
    if (todayRecords.some((r) => r.check_out_time)) {
      setError('You already checked out today.');
      return;
    }
    if (!selectedShift) {
      setError('Select a shift before check-in.');
      return;
    }
    setLoading(true);
    try {
      await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/attendance/checkin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          timestamp: new Date().toISOString(),
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
          shiftTimings: selectedShift,
        }),
      });
      await fetchTodayStatus();
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  const handleCheckOut = async () => {
    if (!workUpdate.trim()) {
      setShowWorkUpdateModal(true);
      return;
    }
    setLoading(true);
    try {
      await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/attendance/checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          workUpdate,
          timestamp: new Date().toISOString(),
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        }),
      });
      setWorkUpdate('');
      setShowWorkUpdateModal(false);
      await fetchTodayStatus();
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  const renderCheckButtons = () => {
    const hasCheckedOut = todayRecords.some((r) => r.check_out_time);
    if (currentStatus === 'checked-in') {
      return (
        <button
          onClick={handleCheckOut}
          disabled={loading}
          className="flex items-center px-3 py-1 text-red-600 border border-red-600 rounded hover:bg-red-50 disabled:opacity-50"
        >
          <XCircle size={16} className="mr-1" /> Out
        </button>
      );
    } else if (hasCheckedOut) {
      return (
        <button
          disabled
          className="px-3 py-1 border rounded text-gray-400 border-gray-300"
        >
          <CheckCircle size={16} className="mr-1" /> Done
        </button>
      );
    } else {
      return (
        <button
          onClick={handleCheckIn}
          disabled={loading}
          className="flex items-center px-3 py-1 text-green-600 border border-green-600 rounded hover:bg-green-50 disabled:opacity-50"
        >
          <CheckCircle size={16} className="mr-1" /> In
        </button>
      );
    }
  };

  if (!user) return <div>Loading...</div>;

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4  py-5  md:flex-row md:justify-between md:items-start">
        <div className="flex flex-col space-y-1 sm:space-y-2">
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
            Welcome back, {user.name}!
          </h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            Here's an overview of your employee management system
          </p>
        </div>

        {/* Check-in/out widget */}
        <div className="relative bg-white border rounded-xl shadow-md p-4 sm:p-5 w-full max-w-[90%] mx-auto sm:max-w-xs space-y-3 sm:space-y-4">
          {/* Widget Header */}
          <div className="flex justify-between items-center">
            <h3 className="text-base sm:text-lg font-semibold text-gray-800">
              Let’s get to work
            </h3>
            <span className="text-xs sm:text-sm text-gray-500">
              😊 Today’s Mood
            </span>
          </div>

          {/* Date & Time */}
          <div className="text-xs sm:text-sm text-gray-600">
            <p className="font-medium">
              {new Date().toLocaleDateString(undefined, {
                weekday: 'short',
                day: '2-digit',
                month: 'short',
                year: 'numeric',
              })}
            </p>
            <p className="text-blue-600 font-semibold text-lg sm:text-xl tracking-wide">
              {currentTime}
            </p>
          </div>

          {/* Shift Info */}
          <div className="text-xs sm:text-sm text-gray-500 flex items-center justify-between">
            <span className="font-medium">Shift</span>
            <span className="text-gray-700 font-semibold">
              {selectedShift || '--'}
            </span>
          </div>

          {/* Shift Dropdown */}
          {currentStatus !== 'checked-in' &&
            !todayRecords.some((r) => r.check_out_time) && (
              <div>
                <select
                  value={selectedShift}
                  onChange={(e) => setSelectedShift(e.target.value)}
                  className="w-full border border-gray-300 rounded-md px-2 py-1.5 sm:px-3 sm:py-2 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select your shift</option>
                  {shiftOptions.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
            )}

          {/* Clock In/Out Button */}
          <div className="pt-1 sm:pt-2">
            {currentStatus === 'checked-in' ? (
              <button
                onClick={handleCheckOut}
                disabled={loading}
                className="w-full bg-blue-600 text-white font-semibold py-1.5 sm:py-2 rounded-md hover:bg-blue-700 disabled:opacity-50 text-xs sm:text-sm"
              >
                Clock Out
              </button>
            ) : (
              <button
                onClick={handleCheckIn}
                disabled={loading || !selectedShift}
                className="w-full bg-green-600 text-white font-semibold py-1.5 sm:py-2 rounded-md hover:bg-green-700 disabled:opacity-50 text-xs sm:text-sm"
              >
                Clock In
              </button>
            )}
          </div>

          {/* Work Update Modal */}
          {showWorkUpdateModal && (
            <div className="fixed inset-0 bg-black/20 flex items-center justify-center z-10">
              <div className="bg-white shadow-lg rounded-xl p-3 sm:p-4 w-[90%] max-w-xs max-h-[80vh] overflow-auto relative z-20">
                <h4 className="text-xs sm:text-sm font-semibold text-gray-800 mb-2">
                  What did you work on today?
                </h4>
                <textarea
                  className="w-full border rounded-md px-2 py-1.5 sm:px-3 sm:py-2 text-xs sm:text-sm focus:ring-blue-500 focus:outline-none"
                  rows={3}
                  value={workUpdate}
                  onChange={(e) => setWorkUpdate(e.target.value)}
                  placeholder="E.g. Fixed bugs, attended meeting..."
                />
                <div className="flex justify-end gap-2 mt-2 sm:mt-3">
                  <button
                    onClick={() => setShowWorkUpdateModal(false)}
                    className="bg-white border border-gray-300 text-black px-2 sm:px-4 py-1 text-xs sm:text-sm rounded hover:bg-gray-100"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleCheckOut}
                    className="bg-blue-600 text-white px-2 sm:px-4 py-1 text-xs sm:text-sm rounded hover:bg-blue-700"
                  >
                    Submit
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Error */}
          {error && (
            <p className="text-xs sm:text-sm text-red-600 mt-1">{error}</p>
          )}
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="overview" className="space-y-3 sm:space-y-4">
        <TabsList className="overflow-x-auto flex-nowrap whitespace-nowrap">
          {/* <TabsTrigger
            value="overview"
            onClick={() => setActiveTab('overview')}
            className="px-2 sm:px-4 py-1 text-xs sm:text-sm"
          >
            Overview
          </TabsTrigger> */}
          {/* <TabsTrigger
            value="analytics"
            onClick={() => setActiveTab('analytics')}
            className="px-2 sm:px-4 py-1 text-xs sm:text-sm"
          >
            Analytics
          </TabsTrigger>
          <TabsTrigger
            value="reports"
            onClick={() => setActiveTab('reports')}
            className="px-2 sm:px-4 py-1 text-xs sm:text-sm"
          >
            Reports
          </TabsTrigger>
          <TabsTrigger
            value="notifications"
            onClick={() => setActiveTab('notifications')}
            className="px-2 sm:px-4 py-1 text-xs sm:text-sm"
          >
            Notifications
          </TabsTrigger> */}
        </TabsList>

        <TabsContent value="overview" className="space-y-3 sm:space-y-4">
          <div className="grid gap-3 sm:gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="pb-2 sm:pb-4">
                <CardTitle className="text-xs sm:text-sm">
                  Total Employees
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl sm:text-2xl font-bold">123</div>
                <p className="text-xs text-muted-foreground">
                  +4 since last month
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2 sm:pb-4">
                <CardTitle className="text-xs sm:text-sm">
                  Active Projects
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl sm:text-2xl font-bold">12</div>
                <p className="text-xs text-muted-foreground">
                  +2 since last month
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2 sm:pb-4">
                <CardTitle className="text-xs sm:text-sm">
                  Pending Approvals
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl sm:text-2xl font-bold">6</div>
                <p className="text-xs text-muted-foreground">
                  -2 since last week
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2 sm:pb-4">
                <CardTitle className="text-xs sm:text-sm">
                  Upcoming Events
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl sm:text-2xl font-bold">4</div>
                <p className="text-xs text-muted-foreground">
                  Next: Team Meeting (Tomorrow)
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-3 sm:gap-4 grid-cols-1 lg:grid-cols-7">
            <Card className="col-span-1 lg:col-span-4">
              <CardHeader>
                <CardTitle className="text-sm sm:text-base">
                  Recent Activity
                </CardTitle>
                <CardDescription className="text-xs sm:text-sm">
                  Overview of recent system activities
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 sm:space-y-4">
                  {[1, 2, 3, 4, 5].map((item) => (
                    <div key={item} className="flex items-center">
                      <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-primary/10 flex items-center justify-center mr-2 sm:mr-3">
                        <span className="text-xs sm:text-sm text-primary font-medium">
                          {String.fromCharCode(64 + item)}
                        </span>
                      </div>
                      <div>
                        <p className="text-xs sm:text-sm font-medium">
                          {[
                            'New employee account created',
                            'Leave request approved',
                            'Project deadline updated',
                            'Team meeting scheduled',
                            'Performance review completed',
                          ][item - 1]}
                        </p>
                        <p className="text-xs text-gray-500">
                          {item} hour{item === 1 ? '' : 's'} ago
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="col-span-1 lg:col-span-3">
              <CardHeader>
                <CardTitle className="text-sm sm:text-base">
                  Quick Access
                </CardTitle>
                <CardDescription className="text-xs sm:text-sm">
                  Frequently used features
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2 sm:gap-3">
                  {[
                    'View Employees',
                    'Leave Requests',
                    'Add User',
                    'View Projects',
                    'Reports',
                    'Settings',
                  ].map((action, i) => (
                    <div
                      key={action}
                      className="flex flex-col items-center justify-center p-3 sm:p-4 bg-muted/50 rounded-lg hover:bg-muted cursor-pointer"
                    >
                      <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-primary/10 flex items-center justify-center mb-1 sm:mb-2">
                        <span className="text-xs text-primary font-bold">
                          {i + 1}
                        </span>
                      </div>
                      <span className="text-xs sm:text-sm font-medium text-center">
                        {action}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-3 sm:gap-4 grid-cols-1 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm sm:text-base">
                  Announcements
                </CardTitle>
                <CardDescription className="text-xs sm:text-sm">
                  Latest company updates
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 sm:space-y-4">
                  {anniversaries.map((emp, idx) => (
                    <div
                      key={idx}
                      className="border-l-4 border-purple-500 pl-3 sm:pl-4 py-2"
                    >
                      <h4 className="text-xs sm:text-sm font-semibold">
                        🎉 Work Anniversary
                      </h4>
                      <p className="text-xs text-gray-500">
                        Today marks {emp.name}'s work anniversary! 🎉
                        Congratulate them on completing another year.
                      </p>
                    </div>
                  ))}
                  <div className="border-l-4 border-blue-500 pl-3 sm:pl-4 py-2">
                    <h4 className="text-xs sm:text-sm font-semibold">
                      Office Closure Notice
                    </h4>
                    <p className="text-xs text-gray-500">
                      The office will be closed on May 25th for maintenance.
                    </p>
                  </div>
                  <div className="border-l-4 border-green-500 pl-3 sm:pl-4 py-2">
                    <h4 className="text-xs sm:text-sm font-semibold">
                      New Policy Update
                    </h4>
                    <p className="text-xs text-gray-500">
                      Updated travel policy is now in effect. Please review.
                    </p>
                  </div>
                  <div className="border-l-4 border-amber-500 pl-3 sm:pl-4 py-2">
                    <h4 className="text-xs sm:text-sm font-semibold">
                      Upcoming Training
                    </h4>
                    <p className="text-xs text-gray-500">
                      Leadership training sessions scheduled for next week.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm sm:text-base">
                  Upcoming Deadlines
                </CardTitle>
                <CardDescription className="text-xs sm:text-sm">
                  Important dates to remember
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 sm:space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="text-xs sm:text-sm font-semibold">
                        Quarterly Reports
                      </h4>
                      <p className="text-xs text-gray-500">
                        Financial reports due
                      </p>
                    </div>
                    <div className="bg-red-100 text-red-800 text-xs font-semibold px-1.5 sm:px-2 py-1 rounded">
                      2 days left
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="text-xs sm:text-sm font-semibold">
                        Team Evaluations
                      </h4>
                      <p className="text-xs text-gray-500">
                        Complete performance reviews
                      </p>
                    </div>
                    <div className="bg-amber-100 text-amber-800 text-xs font-semibold px-1.5 sm:px-2 py-1 rounded">
                      1 week left
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="text-xs sm:text-sm font-semibold">
                        Project Milestone
                      </h4>
                      <p className="text-xs text-gray-500">
                        Phase 2 completion
                      </p>
                    </div>
                    <div className="bg-green-100 text-green-800 text-xs font-semibold px-1.5 sm:px-2 py-1 rounded">
                      2 weeks left
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-3 sm:space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm sm:text-base">
                Analytics Overview
              </CardTitle>
              <CardDescription className="text-xs sm:text-sm">
                Your company performance metrics
              </CardDescription>
            </CardHeader>
            <CardContent className="h-auto min-h-[200px] sm:h-[300px] flex items-center justify-center">
              <p className="text-xs sm:text-sm text-muted-foreground">
                Analytics data visualization will appear here
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-3 sm:space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm sm:text-base">
                Generated Reports
              </CardTitle>
              <CardDescription className="text-xs sm:text-sm">
                Your company reports
              </CardDescription>
            </CardHeader>
            <CardContent className="h-auto min-h-[200px] sm:h-[300px] flex items-center justify-center">
              <p className="text-xs sm:text-sm text-muted-foreground">
                Reports will appear here
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-3 sm:space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm sm:text-base">
                Your Notifications
              </CardTitle>
              <CardDescription className="text-xs sm:text-sm">
                Stay updated with recent events
              </CardDescription>
            </CardHeader>
            <CardContent className="h-auto min-h-[200px] sm:h-[300px] flex items-center justify-center">
              <p className="text-xs sm:text-sm text-muted-foreground">
                Notifications will appear here
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Dashboard;