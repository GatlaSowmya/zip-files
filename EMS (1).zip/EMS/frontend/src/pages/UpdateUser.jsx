// import { useState, useEffect } from 'react';
// import axios from 'axios';
// import { toast } from 'sonner';
// import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
// import { Input } from '@/components/ui/input';
// import { Label } from '@/components/ui/label';
// import { Button } from '@/components/ui/button';
// import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
// import { Loader2 } from 'lucide-react';

// const UpdateUser = () => {
//   const [userId, setUserId] = useState('');
//   const [formData, setFormData] = useState({
//     name: '', email: '', password: '', role: '', avatar: '',
//     fullName: '', dateOfBirth: '', gender: '', nationality: '', maritalStatus: '',
//     permanentAddress: '', currentAddress: '', phoneNumber: '', alternatePhoneNumber: '', personalEmail: '',
//     teamLead: '', manager: '', position: '', department: '',
//     aadhar: '', panCard: '', passport: '', drivingLicense: '',
//     bankName: '', bankBranch: '', accountNumber: '', ifscCode: ''
//   });
//   const [leadsAndManagers, setLeadsAndManagers] = useState([]);
//   const [isLoading, setIsLoading] = useState(false);
//   const [errors, setErrors] = useState({});

//   useEffect(() => {
//     axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/leads-managers`)
//       .then(res => setLeadsAndManagers(res.data))
//       .catch(() => toast.error('Failed to load Team Leads and Managers'));
//   }, []);

//   const validateForm = () => {
//     const newErrors = {};
//     if (!formData.name) newErrors.name = 'Name is required';
//     if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Valid email is required';
//     if (formData.password && formData.password.length < 6) newErrors.password = 'Password must be at least 6 characters';
//     setErrors(newErrors);
//     return Object.keys(newErrors).length === 0;
//   };

//   const handleFetch = async () => {
//     if (!userId) {
//       toast.warning('Please enter a user ID');
//       return;
//     }
//     setIsLoading(true);
//     try {
//       const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/user/${userId}`);
//       setFormData(res.data);
//       toast.success('User data loaded');
//     } catch (err) {
//       toast.error('User not found');
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   const handleUpdate = async () => {
//     if (!validateForm()) {
//       toast.error('Please fix the form errors');
//       return;
//     }
//     setIsLoading(true);
//     try {
//       await axios.put(`${import.meta.env.VITE_API_BASE_URL}/api/user/${userId}`, formData);
//       toast.success('User updated successfully');
//     } catch (err) {
//       toast.error('Failed to update user');
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     if (name === 'name' || name === 'fullName') {
//       // Allow only alphabetic characters and spaces, or empty string
//       if (value === '' || /^[A-Za-z\s]+$/.test(value)) {
//         setFormData(prev => ({ ...prev, [name]: value }));
//         setErrors(prev => ({ ...prev, [name]: '' }));
//       } else {
//         toast.error(`${name === 'name' ? 'Name' : 'Full Name'} can only contain letters and spaces`);
//       }
//     } else if (name === 'phoneNumber' || name === 'alternatePhoneNumber') {
//       // Allow only numbers, +, -, and spaces, or empty string
//       if (value === '' || /^[0-9+\-\s]+$/.test(value)) {
//         setFormData(prev => ({ ...prev, [name]: value }));
//         setErrors(prev => ({ ...prev, [name]: '' }));
//       } else {
//         toast.error(`${name === 'phoneNumber' ? 'Phone Number' : 'Alternate Phone Number'} can only contain numbers, +, -, and spaces`);
//       }
//     } else if (name === 'accountNumber') {
//       // Allow only numbers, or empty string
//       if (value === '' || /^[0-9]+$/.test(value)) {
//         setFormData(prev => ({ ...prev, [name]: value }));
//         setErrors(prev => ({ ...prev, [name]: '' }));
//       } else {
//         toast.error('Account Number can only contain numbers');
//       }
//     } else {
//       setFormData(prev => ({ ...prev, [name]: value }));
//       setErrors(prev => ({ ...prev, [name]: '' }));
//     }
//   };

//   const handleSelect = (name, value) => {
//     setFormData(prev => ({ ...prev, [name]: value }));
//     setErrors(prev => ({ ...prev, [name]: '' }));
//   };

//   const InputGroup = ({ label, name, type = 'text', placeholder }) => (
//     <div className="space-y-1">
//       <Label htmlFor={name} className="text-xs sm:text-sm font-medium text-gray-700">{label}</Label>
//       <Input
//         id={name}
//         name={name}
//         type={type}
//         value={formData[name] || ''}
//         onChange={handleChange}
//         placeholder={placeholder}
//         className={`border ${errors[name] ? 'border-red-500' : 'border-gray-300'} focus:ring-2 focus:ring-blue-500 transition-colors text-sm sm:text-base`}
//         pattern={
//           name === 'name' || name === 'fullName' ? '[A-Za-z\\s]+' :
//           name === 'phoneNumber' || name === 'alternatePhoneNumber' ? '[0-9+\\-\\s]+' :
//           name === 'accountNumber' ? '[0-9]+' : undefined
//         }
//         title={
//           name === 'name' || name === 'fullName' ? 'Can only contain letters and spaces' :
//           name === 'phoneNumber' || name === 'alternatePhoneNumber' ? 'Can only contain numbers, +, -, and spaces' :
//           name === 'accountNumber' ? 'Can only contain numbers' : undefined
//         }
//       />
//       {errors[name] && <p className="text-xs text-red-500">{errors[name]}</p>}
//     </div>
//   );

//   const SelectGroup = ({ label, name, options, placeholder }) => (
//     <div className="space-y-1">
//       <Label htmlFor={name} className="text-xs sm:text-sm font-medium text-gray-700">{label}</Label>
//       <Select value={formData[name] || ''} onValueChange={(val) => handleSelect(name, val)}>
//         <SelectTrigger id={name} className={`border ${errors[name] ? 'border-red-500' : 'border-gray-300'} focus:ring-2 focus:ring-blue-500 transition-colors text-sm sm:text-base`}>
//           <SelectValue placeholder={placeholder} />
//         </SelectTrigger>
//         <SelectContent className="bg-white text-black max-h-60 overflow-y-auto text-sm sm:text-base">
//           {options.map(opt => (
//             <SelectItem key={opt} value={opt}>{opt}</SelectItem>
//           ))}
//         </SelectContent>
//       </Select>
//       {errors[name] && <p className="text-xs text-red-500">{errors[name]}</p>}
//     </div>
//   );

//   const SectionTitle = ({ title }) => (
//     <h3 className="text-base sm:text-lg font-semibold text-gray-800 border-b pb-2 mb-4 col-span-full">{title}</h3>
//   );

//   return (
//     <div className="p-4 sm:p-6 lg:p-8">
//       <Card className="max-w-full sm:max-w-5xl mx-auto shadow-lg">
//         <CardTitle className="text-xl sm:text-2xl font-bold text-gray-800 mt-4 pl-4 sm:pl-5 lg:mt-6">
//           Update User Profile
//         </CardTitle>
//         <div className="border-b border-gray-300 mt-2 mb-4 mx-4 sm:mx-5"></div>
//         <CardHeader className="border-b">
//           <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
//             <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-4 w-full sm:w-auto">
//               <Input
//                 placeholder="Enter User ID"
//                 value={userId}
//                 onChange={(e) => setUserId(e.target.value)}
//                 className="w-full sm:w-48 border-gray-300 focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
//               />
//               <Button
//                 onClick={handleFetch}
//                 disabled={isLoading}
//                 className="bg-blue-600 hover:bg-blue-700 text-white transition-colors w-full sm:w-auto text-sm sm:text-base py-2 sm:py-2.5"
//               >
//                 {isLoading ? <Loader2 className="w-4 h-4 sm:w-5 sm:h-5 animate-spin" /> : 'Search'}
//               </Button>
//             </div>
//             {formData.avatar && (
//               <div className="mt-4 sm:mt-0 sm:ml-auto">
//                 <img
//                   src={formData.avatar || 'https://via.placeholder.com/96'}
//                   alt="User Avatar"
//                   className="w-20 h-20 sm:w-24 sm:h-24 object-cover border-2 border-gray-200 rounded-lg"
//                 />
//               </div>
//             )}
//           </div>
//         </CardHeader>
//         <CardContent className="p-4 sm:p-6">
//           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
//             <SectionTitle title="Basic Information" />
//             <InputGroup label="Name" name="name" placeholder="Enter name" />
//             <InputGroup label="Email" name="email" type="email" placeholder="Enter email" />
//             <InputGroup label="Password" name="password" type="password" placeholder="Enter password" />
//             <SelectGroup
//               label="Role"
//               name="role"
//               options={['Admin', 'HR', 'Director', 'Manager', 'Team Lead', 'Employee']}
//               placeholder="Select role"
//             />
//             <InputGroup label="Avatar URL" name="avatar" placeholder="Enter avatar URL" />
//             <div className="sm:col-span-2 lg:col-span-3"></div>
//             <SectionTitle title="Personal Information" />
//             <InputGroup label="Full Name" name="fullName" placeholder="Enter full name" />
//             <InputGroup label="Date of Joining" name="dateOfJoining" type="date" />
//             <InputGroup label="Date of Birth" name="dateOfBirth" type="date" />
//             <SelectGroup label="Gender" name="gender" options={['Male', 'Female', 'Other']} placeholder="Select gender" />
//             <InputGroup label="Nationality" name="nationality" placeholder="Enter nationality" />
//             <SelectGroup
//               label="Marital Status"
//               name="maritalStatus"
//               options={['Single', 'Married', 'Divorced', 'Widowed']}
//               placeholder="Select marital status"
//             />
//             <InputGroup label="Permanent Address" name="permanentAddress" placeholder="Enter permanent address" />
//             <InputGroup label="Current Address" name="currentAddress" placeholder="Enter current address" />
//             <InputGroup label="Phone Number" name="phoneNumber" placeholder="Enter phone number" />
//             <InputGroup label="Alternate Phone Number" name="alternatePhoneNumber" placeholder="Enter alternate phone" />
//             <InputGroup label="Personal Email" name="personalEmail" type="email" placeholder="Enter personal email" />
//             <SectionTitle title="Team & Role" />
//             <SelectGroup
//               label="Team Lead"
//               name="teamLead"
//               options={leadsAndManagers.filter(u => u.role === 'Team Lead').map(u => u.name)}
//               placeholder="Select team lead"
//             />
//             <SelectGroup
//               label="Manager"
//               name="manager"
//               options={leadsAndManagers.filter(u => u.role === 'Manager').map(u => u.name)}
//               placeholder="Select manager"
//             />
//             <InputGroup label="Position" name="position" placeholder="Enter position" />
//             <SelectGroup
//               label="Department"
//               name="department"
//               options={['Management', 'IT', 'Human Resources', 'Operations & Development', 'Finance']}
//               placeholder="Select department"
//             />
//             <SectionTitle title="Identity Details" />
//             <InputGroup label="Aadhar" name="aadhar" placeholder="Enter Aadhar number" />
//             <InputGroup label="PAN Card" name="panCard" placeholder="Enter PAN card number" />
//             <InputGroup label="Passport" name="passport" placeholder="Enter passport number" />
//             <InputGroup label="Driving License" name="drivingLicense" placeholder="Enter driving license number" />
//             <SectionTitle title="Bank Details" />
//             <InputGroup label="Bank Name" name="bankName" placeholder="Enter bank name" />
//             <InputGroup label="Bank Branch" name="bankBranch" placeholder="Enter bank branch" />
//             <InputGroup label="Account Number" name="accountNumber" placeholder="Enter account number" />
//             <InputGroup label="IFSC Code" name="ifscCode" placeholder="Enter IFSC code" />
//           </div>
//           <div className="flex justify-end mt-4 sm:mt-6">
//             <Button
//               onClick={handleUpdate}
//               disabled={isLoading}
//               className="bg-blue-600 hover:bg-blue-700 text-white px-4 sm:px-6 py-2 text-sm sm:text-base transition-colors"
//             >
//               {isLoading ? <Loader2 className="w-4 h-4 sm:w-5 sm:h-5 animate-spin mr-2" /> : null}
//               Update Profile
//             </Button>
//           </div>
//         </CardContent>
//       </Card>
//     </div>
//   );
// };

// export default UpdateUser;
import { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';

const InputGroup = ({ label, name, value, onChange, type = 'text', placeholder }) => (
  <div className="space-y-1">
    <Label htmlFor={name} className="text-xs sm:text-sm font-medium text-gray-700">{label}</Label>
    <Input
      id={name}
      name={name}
      type={type}
      value={value || ''}
      onChange={onChange}
      placeholder={placeholder}
      className="border border-gray-300 focus:ring-2 focus:ring-blue-500 transition-colors text-sm sm:text-base"
    />
  </div>
);

const SelectGroup = ({ label, name, value, onChange, options, placeholder }) => (
  <div className="space-y-1">
    <Label htmlFor={name} className="text-xs sm:text-sm font-medium text-gray-700">{label}</Label>
    <Select value={value || ''} onValueChange={(val) => onChange(name, val)}>
      <SelectTrigger id={name} className="border border-gray-300 focus:ring-2 focus:ring-blue-500 transition-colors text-sm sm:text-base">
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent className="bg-white text-black max-h-60 overflow-y-auto text-sm sm:text-base">
        {options.map(opt => (
          <SelectItem key={opt} value={opt}>{opt}</SelectItem>
        ))}
      </SelectContent>
    </Select>
  </div>
);

const SectionTitle = ({ title }) => (
  <h3 className="text-base sm:text-lg font-semibold text-gray-800 border-b pb-2 mb-4 col-span-full">{title}</h3>
);

const UpdateUser = () => {
  const [userId, setUserId] = useState('');
  const [formData, setFormData] = useState({
    name: '', email: '', password: '', role: '', avatar: '',
    fullName: '', dateOfBirth: '', gender: '', nationality: '', maritalStatus: '',
    permanentAddress: '', currentAddress: '', phoneNumber: '', alternatePhoneNumber: '', personalEmail: '',
    teamLead: '', manager: '', position: '', department: '',
    aadhar: '', panCard: '', passport: '', drivingLicense: '',
    bankName: '', bankBranch: '', accountNumber: '', ifscCode: ''
  });
  const [leadsAndManagers, setLeadsAndManagers] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/leads-managers`)
      .then(res => setLeadsAndManagers(res.data))
      .catch(() => toast.error('Failed to load Team Leads and Managers'));
  }, []);

  const handleFetch = async () => {
    if (!userId) {
      toast.warning('Please enter a user ID');
      return;
    }
    setIsLoading(true);
    try {
      const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/user/${userId}`);
      setFormData(res.data);
      toast.success('User data loaded');
    } catch (err) {
      toast.error('User not found');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdate = async () => {
    setIsLoading(true);
    try {
      await axios.put(`${import.meta.env.VITE_API_BASE_URL}/api/user/${userId}`, formData);
      toast.success('User updated successfully');
    } catch (err) {
      toast.error('Failed to update user');
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    if ((name === 'name' || name === 'fullName') && value && !/^[A-Za-z\s]*$/.test(value)) {
      toast.error(`${name === 'name' ? 'Name' : 'Full Name'} can only contain letters and spaces`);
      return;
    }

    if ((name === 'phoneNumber' || name === 'alternatePhoneNumber') && value && !/^[0-9+\-\s]*$/.test(value)) {
      toast.error(`${name === 'phoneNumber' ? 'Phone Number' : 'Alternate Phone Number'} can only contain numbers, +, -, and spaces`);
      return;
    }

    if (name === 'accountNumber' && value && !/^[0-9]*$/.test(value)) {
      toast.error('Account Number can only contain numbers');
      return;
    }

    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelect = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <Card className="max-w-full sm:max-w-5xl mx-auto shadow-lg">
        <CardTitle className="text-xl sm:text-2xl font-bold text-gray-800 mt-4 pl-4 sm:pl-5 lg:mt-6">
          Update User Profile
        </CardTitle>
        <div className="border-b border-gray-300 mt-2 mb-4 mx-4 sm:mx-5"></div>
        <CardHeader className="border-b">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-4 w-full sm:w-auto">
              <Input
                placeholder="Enter User ID"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                className="w-full sm:w-48 border-gray-300 focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
              />
              <Button
                onClick={handleFetch}
                disabled={isLoading}
                className="bg-blue-600 hover:bg-blue-700 text-white transition-colors w-full sm:w-auto text-sm sm:text-base py-2 sm:py-2.5"
              >
                {isLoading ? <Loader2 className="w-4 h-4 sm:w-5 sm:h-5 animate-spin" /> : 'Search'}
              </Button>
            </div>
            {formData.avatar && (
              <div className="mt-4 sm:mt-0 sm:ml-auto">
                <img
                  src={formData.avatar}
                  alt="User Avatar"
                  className="w-20 h-20 sm:w-24 sm:h-24 object-cover border-2 border-gray-200 rounded-lg"
                />
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-4 sm:p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            <SectionTitle title="Basic Information" />
            <InputGroup label="Name" name="name" value={formData.name} onChange={handleChange} placeholder="Enter name" />
            <InputGroup label="Email" name="email" type="email" value={formData.email} onChange={handleChange} placeholder="Enter email" />
            <InputGroup label="Password" name="password" type="password" value={formData.password} onChange={handleChange} placeholder="Enter password" />
            <SelectGroup label="Role" name="role" value={formData.role} onChange={handleSelect} options={['Admin', 'HR', 'Director', 'Manager', 'Team Lead', 'Employee']} placeholder="Select role" />
            <InputGroup label="Avatar URL" name="avatar" value={formData.avatar} onChange={handleChange} placeholder="Enter avatar URL" />
            <div className="sm:col-span-2 lg:col-span-3" />
            <SectionTitle title="Personal Information" />
            <InputGroup label="Full Name" name="fullName" value={formData.fullName} onChange={handleChange} placeholder="Enter full name" />
            <InputGroup label="Date of Joining" name="dateOfJoining" type="date" value={formData.dateOfJoining} onChange={handleChange} />
            <InputGroup label="Date of Birth" name="dateOfBirth" type="date" value={formData.dateOfBirth} onChange={handleChange} />
            <SelectGroup label="Gender" name="gender" value={formData.gender} onChange={handleSelect} options={['Male', 'Female', 'Other']} placeholder="Select gender" />
            <InputGroup label="Nationality" name="nationality" value={formData.nationality} onChange={handleChange} placeholder="Enter nationality" />
            <SelectGroup label="Marital Status" name="maritalStatus" value={formData.maritalStatus} onChange={handleSelect} options={['Single', 'Married', 'Divorced', 'Widowed']} placeholder="Select marital status" />
            <InputGroup label="Permanent Address" name="permanentAddress" value={formData.permanentAddress} onChange={handleChange} placeholder="Enter permanent address" />
            <InputGroup label="Current Address" name="currentAddress" value={formData.currentAddress} onChange={handleChange} placeholder="Enter current address" />
            <InputGroup label="Phone Number" name="phoneNumber" value={formData.phoneNumber} onChange={handleChange} placeholder="Enter phone number" />
            <InputGroup label="Alternate Phone Number" name="alternatePhoneNumber" value={formData.alternatePhoneNumber} onChange={handleChange} placeholder="Enter alternate phone" />
            <InputGroup label="Personal Email" name="personalEmail" type="email" value={formData.personalEmail} onChange={handleChange} placeholder="Enter personal email" />
            <SectionTitle title="Team & Role" />
            <SelectGroup label="Team Lead" name="teamLead" value={formData.teamLead} onChange={handleSelect} options={leadsAndManagers.filter(u => u.role === 'Team Lead').map(u => u.name)} placeholder="Select team lead" />
            <SelectGroup label="Manager" name="manager" value={formData.manager} onChange={handleSelect} options={leadsAndManagers.filter(u => u.role === 'Manager').map(u => u.name)} placeholder="Select manager" />
            <InputGroup label="Position" name="position" value={formData.position} onChange={handleChange} placeholder="Enter position" />
            <SelectGroup label="Department" name="department" value={formData.department} onChange={handleSelect} options={['Management', 'IT', 'Human Resources', 'Operations & Development', 'Finance']} placeholder="Select department" />
            <SectionTitle title="Identity Details" />
            <InputGroup label="Aadhar" name="aadhar" value={formData.aadhar} onChange={handleChange} placeholder="Enter Aadhar number" />
            <InputGroup label="PAN Card" name="panCard" value={formData.panCard} onChange={handleChange} placeholder="Enter PAN card number" />
            <InputGroup label="Passport" name="passport" value={formData.passport} onChange={handleChange} placeholder="Enter passport number" />
            <InputGroup label="Driving License" name="drivingLicense" value={formData.drivingLicense} onChange={handleChange} placeholder="Enter driving license number" />
            <SectionTitle title="Bank Details" />
            <InputGroup label="Bank Name" name="bankName" value={formData.bankName} onChange={handleChange} placeholder="Enter bank name" />
            <InputGroup label="Bank Branch" name="bankBranch" value={formData.bankBranch} onChange={handleChange} placeholder="Enter bank branch" />
            <InputGroup label="Account Number" name="accountNumber" value={formData.accountNumber} onChange={handleChange} placeholder="Enter account number" />
            <InputGroup label="IFSC Code" name="ifscCode" value={formData.ifscCode} onChange={handleChange} placeholder="Enter IFSC code" />
          </div>
          <div className="flex justify-end mt-4 sm:mt-6">
            <Button
              onClick={handleUpdate}
              disabled={isLoading}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 sm:px-6 py-2 text-sm sm:text-base transition-colors"
            >
              {isLoading ? <Loader2 className="w-4 h-4 sm:w-5 sm:h-5 animate-spin mr-2" /> : null}
              Update Profile
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UpdateUser;


