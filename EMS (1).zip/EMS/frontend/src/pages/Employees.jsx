import { useState, useEffect } from 'react';
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeftCircle, ArrowRightCircle } from 'lucide-react';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import axios from 'axios';

const Employees = () => {
  const { user } = useAuth();
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [editEmployee, setEditEmployee] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 10;

  const isAdmin = user?.role === 'Admin';
  const isHR = user?.role === 'HR';

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        setLoading(true);
        const response = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/employees`, {
          params: {
            role: user.role,
            name: user.name,
          },
        });
        setEmployees(response.data);
      } catch (error) {
        console.error('Error fetching employees:', error);
        toast.error('Failed to load employees');
      } finally {
        setLoading(false);
      }
    };

    if (user?.role) fetchEmployees();
  }, [user]);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, selectedDepartment, selectedStatus]);

  const filteredEmployees = employees.filter((employee) => {
    const matchesSearch = employee.name.toLowerCase().includes(searchTerm.toLowerCase())
      || employee.email.toLowerCase().includes(searchTerm.toLowerCase())
      || employee.position.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesDepartment = selectedDepartment === 'all' || employee.department === selectedDepartment;
    const matchesStatus = selectedStatus === 'all' || employee.status === selectedStatus;

    return matchesSearch && matchesDepartment && matchesStatus;
  });

  const totalPages = Math.ceil(filteredEmployees.length / rowsPerPage);
  const paginatedEmployees = filteredEmployees.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );

  const departments = [...new Set(employees.map(emp => emp.department))];

  const handleEditClick = (employee) => {
    setEditEmployee({ ...employee });
    setDialogOpen(true);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (editEmployee) {
      setEditEmployee({ ...editEmployee, [name]: value });
    }
  };

  const handleSelectChange = (name, value) => {
    if (editEmployee) {
      setEditEmployee({ ...editEmployee, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!editEmployee) return;

    try {
      const response = await axios.put(
        `${import.meta.env.VITE_API_BASE_URL}/api/employees/${editEmployee.id}`,
        editEmployee
      );
      setEmployees(employees.map(emp =>
        emp.id === editEmployee.id ? response.data : emp
      ));
      toast.success(`${editEmployee.name}'s information updated`);
      setDialogOpen(false);
      setEditEmployee(null);
    } catch (error) {
      console.error('Error updating employee:', error);
      toast.error('Failed to update employee');
    }
  };

  const handleStatusChange = async (employee) => {
    try {
      const newStatus = employee.status === 'Offline' ? 'Online' : 'Offline';
      const response = await axios.put(
        `${import.meta.env.VITE_API_BASE_URL}/api/employees/${employee.id}/status`,
        { status: newStatus }
      );
      setEmployees(employees.map(emp =>
        emp.id === employee.id ? response.data : emp
      ));
      toast.success(`${employee.name} status updated`);
    } catch (error) {
      console.error('Error updating status:', error);
      toast.error('Failed to update status');
    }
  };

  const handleDelete = async (employee) => {
    try {
      await axios.delete(`${import.meta.env.VITE_API_BASE_URL}/api/employees/${employee.id}`);
      setEmployees(employees.filter(emp => emp.id !== employee.id));
      toast.success(`${employee.name} removed`);
    } catch (error) {
      console.error('Error deleting employee:', error);
      toast.error('Failed to delete employee');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <p>Loading employees...</p>
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6 py-5">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg sm:text-xl">Employee Directory</CardTitle>
          <CardDescription className="text-xs sm:text-sm">View and manage all employees in the system</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-3 sm:gap-4 mb-4 sm:mb-6 md:flex-row">
            <Input
              placeholder="Search by name, email, or position..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-xs sm:text-sm md:flex-1"
            />
            <div className="flex flex-col gap-2 sm:flex-row">
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger className="w-full text-xs sm:text-sm sm:w-[140px]">
                  <SelectValue placeholder="All Departments" />
                </SelectTrigger>
                <SelectContent className="bg-white shadow-md rounded-md">
                  <SelectItem value="all" className="hover:bg-blue-100 cursor-pointer">All Departments</SelectItem>
                  {departments.map(dept => (
                    <SelectItem key={dept} value={dept} className="hover:bg-blue-100 cursor-pointer">{dept}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger className="w-full text-xs sm:text-sm sm:w-[120px]">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent className="bg-white shadow-md rounded-md">
                  <SelectItem value="all" className="hover:bg-blue-100 cursor-pointer">All Status</SelectItem>
                  <SelectItem value="Active" className="hover:bg-blue-100 cursor-pointer">Active</SelectItem>
                  <SelectItem value="On Leave" className="hover:bg-blue-100 cursor-pointer">On Leave</SelectItem>
                  <SelectItem value="Offline" className="hover:bg-blue-100 cursor-pointer">Offline</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Table for Desktop, Cards for Mobile */}
          <div className="rounded-md border">
            {paginatedEmployees.length > 0 ? (
              <>
                <div className="hidden sm:block overflow-x-auto">
                  <table className="w-full min-w-[600px] text-xs sm:text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="py-2 px-2 text-left sm:py-3 sm:px-4">Employee</th>
                        <th className="py-2 px-2 text-left sm:py-3 sm:px-4">Department</th>
                        <th className="py-2 px-2 text-left sm:py-3 sm:px-4">Position</th>
                        <th className="py-2 px-2 text-left sm:py-3 sm:px-4">Role</th>
                        <th className="py-2 px-2 text-left sm:py-3 sm:px-4">Status</th>
                        <th className="py-2 px-2 text-right sm:py-3 sm:px-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {paginatedEmployees.map(employee => (
                        <tr key={employee.id} className="hover:bg-gray-50">
                          <td className="py-2 px-2 sm:py-3 sm:px-4 flex items-center">
                            {employee.avatar ? (
                              <img src={employee.avatar} alt={employee.name} className="w-8 h-8 sm:w-10 sm:h-10 rounded-full mr-2 sm:mr-3" />
                            ) : (
                              <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-primary text-white flex items-center justify-center mr-2 sm:mr-3 text-xs sm:text-sm">
                                {employee.name[0]}
                              </div>
                            )}
                            <div>
                              <div className="font-medium">{employee.name}</div>
                              <div className="text-xs text-gray-500">{employee.email}</div>
                            </div>
                          </td>
                          <td className="py-2 px-2 sm:py-3 sm:px-4">{employee.department}</td>
                          <td className="py-2 px-2 sm:py-3 sm:px-4">{employee.position}</td>
                          <td className="py-2 px-2 sm:py-3 sm:px-4">{employee.role}</td>
                          <td className="py-2 px-2 sm:py-3 sm:px-4">
                            <span className={`text-xs px-1.5 py-0.5 sm:px-2 sm:py-1 rounded-full font-medium ${
                              employee.status === 'Online'
                                ? 'bg-green-100 text-green-700'
                                : employee.status === 'On Leave'
                                ? 'bg-yellow-100 text-yellow-700'
                                : 'bg-red-100 text-red-700'
                            }`}>
                              {employee.status}
                            </span>
                          </td>
                          <td className="py-2 px-2 sm:py-3 sm:px-4 text-right">
                            {(isAdmin || isHR) && (
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="xs sm:sm">•••</Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end" className="bg-white shadow-md rounded-md">
                                  <DropdownMenuItem onClick={() => handleEditClick(employee)} className="hover:bg-blue-100 cursor-pointer">Edit</DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleStatusChange(employee)} className="hover:bg-blue-100 cursor-pointer">
                                    {employee.status === 'Offline' ? 'Online' : 'Deactivate'}
                                  </DropdownMenuItem>
                                  {isAdmin && (
                                    <DropdownMenuItem onClick={() => handleDelete(employee)} className="text-red-600 hover:bg-red-50 cursor-pointer">
                                      Delete
                                    </DropdownMenuItem>
                                  )}
                                </DropdownMenuContent>
                              </DropdownMenu>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="sm:hidden space-y-3">
                  {paginatedEmployees.map(employee => (
                    <div key={employee.id} className="border rounded-md p-2 hover:bg-gray-50">
                      <div className="flex items-center gap-2">
                        {employee.avatar ? (
                          <img src={employee.avatar} alt={employee.name} className="w-8 h-8 rounded-full" />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-xs">
                            {employee.name[0]}
                          </div>
                        )}
                        <div>
                          <div className="font-medium">{employee.name}</div>
                          <div className="text-xs text-gray-500">{employee.email}</div>
                        </div>
                      </div>
                      <div className="mt-2 space-y-1 text-xs">
                        <div><span className="font-medium">Department:</span> {employee.department}</div>
                        <div><span className="font-medium">Position:</span> {employee.position}</div>
                        <div><span className="font-medium">Role:</span> {employee.role}</div>
                        <div>
                          <span className="font-medium">Status:</span>
                          <span className={`ml-1 px-1.5 py-0.5 rounded-full font-medium ${
                            employee.status === 'Online'
                              ? 'bg-green-100 text-green-700'
                              : employee.status === 'On Leave'
                              ? 'bg-yellow-100 text-yellow-700'
                              : 'bg-red-100 text-red-700'
                          }`}>
                            {employee.status}
                          </span>
                        </div>
                      </div>
                      {(isAdmin || isHR) && (
                        <div className="mt-2">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="xs">•••</Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="bg-white shadow-md rounded-md">
                              <DropdownMenuItem onClick={() => handleEditClick(employee)} className="hover:bg-blue-100 cursor-pointer">Edit</DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleStatusChange(employee)} className="hover:bg-blue-100 cursor-pointer">
                                {employee.status === 'Offline' ? 'Online' : 'Deactivate'}
                              </DropdownMenuItem>
                              {isAdmin && (
                                <DropdownMenuItem onClick={() => handleDelete(employee)} className="text-red-600 hover:bg-red-50 cursor-pointer">
                                  Delete
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="text-center text-gray-500 text-xs sm:text-sm py-4 sm:py-6">
                No employees found
              </div>
            )}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center items-center gap-2 sm:gap-4 mt-3 sm:mt-4">
              <Button
                type="button"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="p-0 disabled:opacity-50 sm:hover:scale-110"
              >
                <ArrowLeftCircle className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600" />
              </Button>
              <span className="text-xs sm:text-sm text-gray-700">
                Page {currentPage} of {totalPages}
              </span>
              <Button
                type="button"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="p-0 disabled:opacity-50 sm:hover:scale-110"
              >
                <ArrowRightCircle className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dialog (Edit) */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-white shadow-md rounded-md max-w-[90%] sm:max-w-md max-h-[80vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="text-base sm:text-lg">Edit Employee</DialogTitle>
            <DialogDescription className="text-xs sm:text-sm">Update the employee details.</DialogDescription>
          </DialogHeader>
          {editEmployee && (
            <form onSubmit={handleSubmit} className="space-y-3 sm:space-y-4">
              <Input name="name" value={editEmployee.name} onChange={handleInputChange} placeholder="Name" className="text-xs sm:text-sm" />
              <Input name="email" value={editEmployee.email} onChange={handleInputChange} placeholder="Email" className="text-xs sm:text-sm" />
              <Input name="department" value={editEmployee.department} onChange={handleInputChange} placeholder="Department" className="text-xs sm:text-sm" />
              <Input name="position" value={editEmployee.position} onChange={handleInputChange} placeholder="Position" className="text-xs sm:text-sm" />
              <DialogFooter>
                <Button variant="outline" onClick={() => setDialogOpen(false)} className="text-xs sm:text-sm">Cancel</Button>
                <Button type="submit" className="bg-green-600 text-white text-xs sm:text-sm">Save</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Employees;