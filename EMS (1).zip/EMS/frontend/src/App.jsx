import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import { AuthProvider } from "./contexts/AuthContext";
import Layout from "./components/Layout";
import ProtectedRoute from "./components/ProtectedRoute";
import { TaskProvider } from "./contexts/TaskContext"; 
import { UserProvider } from "./contexts/UserContext";

// Pages
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Employees from "./pages/Employees";
import AddUser from "./pages/AddUser";
import Leaves from "./pages/Leaves";
import Settings from "./pages/Settings";
import Unauthorized from "./pages/Unauthorized";
import NotFound from "./pages/NotFound";
import UpdateUser from "./pages/UpdateUser";
import Tasks from "./pages/tasks";
import TaskForm from "./components/tasks/TaskForm"; // Added import
import MattermostSender from "./components/MattermostSender";
import CheckInCheckOut from "./pages/CheckInCheckOut";
import UploadDocuments from "./pages/UploadDocuments";
import Reports from "./pages/reports";

const queryClient = new QueryClient();

/**
 * Main application component
 * @returns {JSX.Element}
 */
const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <UserProvider>
            <TaskProvider>
              <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/unauthorized" element={<Unauthorized />} />
                
                {/* Protected Routes with Layout */}
                <Route element={<Layout />}>
                  {/* Routes for all authenticated users */}
                  <Route element={<ProtectedRoute />}>
                    <Route path="/dashboard" element={<Dashboard />} />
                    <Route path="/leaves" element={<Leaves />} />
                    <Route path="/tasks" element={<Tasks />} />
                    <Route path="/checkin-checkout" element={<CheckInCheckOut />} /> 
                    <Route path="/mattermost" element={<MattermostSender />} />
                     <Route path="/Upload-documents" element={<UploadDocuments/>} />
                      <Route path="/reports" element={<Reports/>} />

                  </Route>
                  
                  {/* Admin/HR/Manager/Team Lead only routes for task creation */}
                  <Route element={<ProtectedRoute allowedRoles={["Admin", "HR", "Manager", "Team Lead"]} />}>
                    <Route path="/tasks/new" element={<TaskForm />} />
                  </Route>
                  
                  {/* Admin/HR/Manager only routes */}
                  <Route element={<ProtectedRoute allowedRoles={["Admin", "HR", "Manager", "Team Lead","Employee"]} />}>
                    <Route path="/employees" element={<Employees />} />
                  </Route>
                  
                  {/* Admin/HR only routes */}
                  <Route element={<ProtectedRoute allowedRoles={["Admin", "HR"]} />}>
                    <Route path="/add-user" element={<AddUser />} />
                    <Route path="/Update-User" element={<UpdateUser />} />
                  </Route>

                   {/* For Everyone routes */}
                  <Route element={<ProtectedRoute allowedRoles={["Admin", "HR", "Manager", "Team Lead","Employee"]} />}>
                   
         
                  </Route>
                  
                  {/* Admin only routes */}
                  <Route element={<ProtectedRoute allowedRoles={["Admin"]} />}>
                    <Route path="/settings" element={<Settings />} />
                  </Route>
                </Route>
                
                {/* Redirect / to /dashboard based on auth */}
                <Route path="/" element={<Navigate to="/dashboard" replace />} />
                
                {/* Catch-all route */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </TaskProvider>
          </UserProvider>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;