require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const { Pool } = require("pg");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();

// Configuration
const PORT = process.env.PORT || 5000;
const SECRET_KEY = process.env.SECRET_KEY || "visys";

// PostgreSQL connection pool
const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

pool
  .connect()
  .then(() => console.log("✅ Connected to PostgreSQL database"))
  .catch((err) => console.error("❌ Database connection error", err.stack));

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
// app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// // Ensure uploads folder exists
// const uploadDir = path.join(__dirname, "uploads");
// if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

// // Multer setup
// const storage = multer.diskStorage({
//   destination: (req, file, cb) => cb(null, "uploads/"),
//   filename: (req, file, cb) => {
//     const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
//     cb(null, uniqueSuffix + "-" + file.originalname);
//   }
// });
// const upload = multer({ storage });
// app.use("/uploads", express.static("uploads"));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
// Ensure uploads folder exists
const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // Save files in the 'uploads' folder
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Ensure unique filenames
  },
});

const upload = multer({ storage: storage });

// Health check
app.get("/", (req, res) => {
  res.status(200).json({
    status: "success",
    message: "Server is running",
    timestamp: new Date().toISOString(),
  });
});
// / ========================== Autentication Routes ==========================

// Create a POST endpoint for inserting a new record
app.post("/api/add-employee-admin", async (req, res) => {
  const {
    email,
    password,
    phone_number,
    user_role,
    active_flag,
    lock_flag,
    companyunqi_id,
  } = req.body;

  try {
    // Validate required fields
    if (!companyunqi_id) {
      return res.status(400).json({ error: "Company ID is required" });
    }

    // Create schema name from companyId
    const schemaName = `${companyunqi_id.toLowerCase()}`;
    const employeeTable = `${schemaName}.t_employee`;

    // Check if email already exists
    const existingUser = await pool.query(
      `SELECT email FROM ${employeeTable} WHERE email = $1`,
      [email]
    );

    if (existingUser.rows.length > 0) {
      return res.status(400).json({ error: "Email already exists" });
    }

    // Get the next user ID sequence
    const latestUser = await pool.query(
      `SELECT user_id FROM ${employeeTable} 
       WHERE user_id LIKE $1
       ORDER BY user_id DESC LIMIT 1`,
      [`${companyunqi_id}%`]
    );

    let nextUserId;
    if (latestUser.rows.length > 0) {
      // Extract the last number and increment
      const lastId = latestUser.rows[0].user_id;
      const lastNumber = parseInt(lastId.slice(companyunqi_id.length)) || 0;
      nextUserId = `${companyunqi_id}${String(lastNumber + 1).padStart(
        2,
        "0"
      )}`;
    } else {
      // First user for this company
      nextUserId = `${companyunqi_id}01`;
    }

    // Insert new employee
    const result = await pool.query(
      `INSERT INTO ${employeeTable} (
        user_id,
        companyunqi_id,
        email, 
        password, 
        phone_number,
        user_role, 
        active_flag, 
        lock_flag
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8
      ) RETURNING *`,
      [
        nextUserId,
        companyunqi_id,
        email,
        password, // Note: Should be hashed in production
        phone_number,
        user_role,
        active_flag,
        lock_flag,
      ]
    );

    res.status(201).json({
      message: "Employee added successfully",
      employee: result.rows[0],
    });
  } catch (err) {
    console.error("❌ Error adding employee:", err);

    // Handle case where schema doesn't exist
    if (
      err.message.includes("relation") &&
      err.message.includes("does not exist")
    ) {
      return res.status(404).json({ error: "Company schema not found" });
    }

    res.status(500).json({ error: "Failed to add employee" });
  }
});

// Update User
app.put("/api/update-user/:user_id", async (req, res) => {
  const { user_id } = req.params;
  const { companyId, ...userData } = req.body;

  try {
    if (!companyId) {
      return res.status(400).json({ message: "Company ID is required" });
    }

    const schemaName = companyId.toLowerCase();
    const query = `
      UPDATE ${schemaName}.t_employee 
      SET 
        email = $1,
        phone_number = $2,
        user_role = $3,
        active_flag = $4,
        lock_flag = $5
      WHERE user_id = $6
      RETURNING *
    `;

    const values = [
      userData.email,
      userData.phone_number,
      userData.user_role,
      userData.active_flag,
      userData.lock_flag,
      user_id,
    ];

    const result = await pool.query(query, values);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({ message: "User updated successfully", user: result.rows[0] });
  } catch (err) {
    console.error("Error updating user:", err);

    if (
      err.message.includes("relation") &&
      err.message.includes("does not exist")
    ) {
      return res.status(404).json({ message: "Company schema not found" });
    }

    res.status(500).json({ message: "Failed to update user" });
  }
});

// Delete User
app.delete("/api/delete-user/:user_id", async (req, res) => {
  const { user_id } = req.params;
  const { companyId } = req.query;

  try {
    if (!companyId) {
      return res.status(400).json({ message: "Company ID is required" });
    }

    const schemaName = companyId.toLowerCase();
    const query = `
      DELETE FROM ${schemaName}.t_employee 
      WHERE user_id = $1
      RETURNING *
    `;

    const result = await pool.query(query, [user_id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({ message: "User deleted successfully" });
  } catch (err) {
    console.error("Error deleting user:", err);

    if (
      err.message.includes("relation") &&
      err.message.includes("does not exist")
    ) {
      return res.status(404).json({ message: "Company schema not found" });
    }

    res.status(500).json({ message: "Failed to delete user" });
  }
});

app.get("/api/get-super-admins", async (req, res) => {
  try {
    // Get companyId from query parameters
    const { companyId } = req.query;

    if (!companyId) {
      return res.status(400).json({ message: "Company ID is required" });
    }

    // Convert to schema name (e.g., "C4BS1032" -> "c4bs1032")
    const schemaName = companyId.toLowerCase();
    const query = `SELECT * FROM ${schemaName}.t_employee ORDER BY user_id`;

    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    console.error(err);

    // Handle missing schema case
    if (
      err.message.includes("relation") &&
      err.message.includes("does not exist")
    ) {
      return res.status(404).json({ message: "Company schema not found" });
    }

    res
      .status(500)
      .json({ message: "Server error while fetching super admins" });
  }
});
// Add this endpoint to verify employees
app.get("/api/verify-employee/:userId", async (req, res) => {
  try {
    const { userId } = req.params;
    const { companyId } = req.query;

    if (!companyId) {
      return res
        .status(400)
        .json({ valid: false, error: "Company ID is required" });
    }

    const schemaName = companyId.toLowerCase();
    const result = await pool.query(
      `SELECT user_id FROM ${schemaName}.t_employee 
       WHERE user_id = $1 AND active_flag = 'Y'`,
      [userId]
    );

    res.json({ valid: result.rows.length > 0 });
  } catch (err) {
    console.error("Verification error:", err);
    res.status(500).json({ valid: false, error: "Verification failed" });
  }
});
app.post(
  "/api/consultants",
  upload.fields([
    { name: "visa_documents", maxCount: 1 },
    { name: "driving_license", maxCount: 1 },
    { name: "resume_path", maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      const {
        consultant_name,
        email_id,
        phone_no1,
        education_qualification,
        preferred_technology,
        year_of_experience,
        location,
        rate,
        recruiter_name,
        marketing_person,
        companyId,
        userId,
      } = req.body;

      // Validate required fields
      if (!companyId || !userId) {
        return res
          .status(400)
          .json({ error: "Company ID and User ID are required" });
      }

      const schemaName = companyId.toLowerCase();

      // Verify user exists in t_employee (corrected from t_user_registration)
      const userCheck = await pool.query(
        `SELECT user_id FROM ${schemaName}.t_employee 
         WHERE user_id = $1 AND active_flag = 'Y'`,
        [userId]
      );

      if (userCheck.rows.length === 0) {
        return res.status(404).json({
          error: `User ${userId} not found in employee table or not active`,
        });
      }
      const checkEmail = await pool.query(
        "SELECT * FROM vo_benchsales.t_consultants WHERE email_id = $1", [email_id]
      );
      if (checkEmail.rows.length > 0) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      // Check if the phone number already exists
      const checkPhone = await pool.query(
        "SELECT * FROM vo_benchsales.t_consultants WHERE phone_no1 = $1", [phone_no1]
      );
      if (checkPhone.rows.length > 0) {
        return res.status(400).json({ message: "Phone number already exists" });
      }

      // Get file paths
      const visa_documents = req.files.visa_documents?.[0]?.filename || null;
      const driving_license = req.files.driving_license?.[0]?.filename || null;
      const resume_path = req.files.resume_path?.[0]?.filename || null;
      

      // Insert into dynamic schema
      const result = await pool.query(
        `INSERT INTO ${schemaName}.t_consultants (
          user_id, consultant_name, email_id, phone_no1,
          education_qualification, preferred_technology,
          year_of_experience, resume_path, visa_documents,
          driving_license, location, rate, recruiter_name,
          marketing_person
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
        RETURNING *`,
        [
          userId, // This now correctly references t_employee
          consultant_name,
          email_id,
          phone_no1,
          education_qualification,
          preferred_technology,
          year_of_experience,
          resume_path,
          visa_documents,
          driving_license,
          location,
          rate,
          recruiter_name,
          marketing_person,
        ]
      );

      res.status(201).json({
        message: "Consultant created successfully",
        consultant: result.rows[0],
      });
    } catch (err) {
      console.error("Database error:", err);

      if (err.code === "23503") {
        // Foreign key violation
        return res.status(400).json({
          error: "Invalid employee reference",
          details: `User ${req.body.userId} not found in employee table`,
        });
      }

      res.status(500).json({
        error: "Database operation failed",
        details: err.message,
      });
    }
  }
);

app.get("/api/consultants", async (req, res) => {
  const { companyId } = req.query;

  if (!companyId) {
    return res.status(400).json({ error: "companyId is required" });
  }

  const schemaName = companyId.toLowerCase();

  try {
    const result = await pool.query(
      `SELECT * FROM ${schemaName}.t_consultants ORDER BY id DESC`
    );

    // Format file paths
    const consultants = result.rows.map((consultant) => ({
      ...consultant,
      resume_path: consultant.resume_path
        ? `/uploads/${consultant.resume_path}`
        : null,
      visa_documents: consultant.visa_documents
        ? `/uploads/${consultant.visa_documents}`
        : null,
      driving_license: consultant.driving_license
        ? `/uploads/${consultant.driving_license}`
        : null,
    }));

    res.status(200).json(consultants);
  } catch (err) {
    console.error("❌ Error fetching consultants:", err);
    res.status(500).json({ error: "Failed to fetch consultants" });
  }
});

// Update Consultant
app.put(
  "/api/consultants/:id",
  upload.fields([
    { name: "resume", maxCount: 1 },
    { name: "visa_documents", maxCount: 1 },
    { name: "driving_license", maxCount: 1 },
  ]),
  async (req, res) => {
    const { id } = req.params;
    const { companyId, userId } = req.query;

    // Validate required parameters
    if (!companyId || !userId) {
      return res.status(400).json({
        error: "Company ID and User ID are required",
      });
    }

    const schemaName = companyId.toLowerCase();

    try {
      // Verify user exists in t_employee
      const userCheck = await pool.query(
        `SELECT user_id FROM ${schemaName}.t_employee WHERE user_id = $1`,
        [userId]
      );

      if (userCheck.rows.length === 0) {
        return res.status(404).json({ error: "User not found" });
      }

      // Get file paths
      const files = {
        resume_path: req.files.resume?.[0]?.filename || null,
        visa_documents: req.files.visa_documents?.[0]?.filename || null,
        driving_license: req.files.driving_license?.[0]?.filename || null,
      };

      const result = await pool.query(
        `UPDATE ${schemaName}.t_consultants SET
        consultant_name = $1, email_id = $2, phone_no1 = $3, 
        education_qualification = $4, preferred_technology = $5, 
        year_of_experience = $6, resume_path = COALESCE($7, resume_path),
        visa_documents = COALESCE($8, visa_documents),
        driving_license = COALESCE($9, driving_license),
        location = $10, rate = $11, recruiter_name = $12, 
        marketing_person = $13, updated_at = CURRENT_TIMESTAMP
      WHERE id = $14 RETURNING *`,
        [
          req.body.consultant_name,
          req.body.email_id,
          req.body.phone_no1,
          req.body.education_qualification,
          req.body.preferred_technology,
          req.body.year_of_experience,
          files.resume_path,
          files.visa_documents,
          files.driving_license,
          req.body.location,
          req.body.rate,
          req.body.recruiter_name,
          req.body.marketing_person,
          id,
        ]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Consultant not found" });
      }

      res.status(200).json(result.rows[0]);
    } catch (err) {
      console.error("Error updating consultant:", err);
      res.status(500).json({
        error: "Failed to update consultant",
        details: err.message,
      });
    }
  }
);

// Delete Consultant
app.delete("/api/consultants/:id", async (req, res) => {
  const { id } = req.params;
  const { companyId, userId } = req.query;

  // Validate required parameters
  if (!companyId || !userId) {
    return res.status(400).json({
      error: "Company ID and User ID are required",
    });
  }

  const schemaName = companyId.toLowerCase();

  try {
    // Verify user exists in t_employee
    const userCheck = await pool.query(
      `SELECT user_id FROM ${schemaName}.t_employee WHERE user_id = $1`,
      [userId]
    );

    if (userCheck.rows.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    const result = await pool.query(
      `DELETE FROM ${schemaName}.t_consultants WHERE id = $1 RETURNING *`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Consultant not found" });
    }

    res.status(200).json({
      message: "Consultant deleted successfully",
      deleted: result.rows[0],
    });
  } catch (err) {
    console.error("Error deleting consultant:", err);
    res.status(500).json({
      error: "Failed to delete consultant",
      details: err.message,
    });
  }
});
// ========================== Sales Routes ==========================
app.get("/api/sales", async (req, res) => {
  try {
    const { companyId, userId } = req.query;

    if (!companyId || !userId) {
      return res
        .status(400)
        .json({ error: "Company ID and User ID are required" });
    }

    const schemaName = companyId.toLowerCase();
    const result = await pool.query(
      `SELECT * FROM ${schemaName}.t_bench_sales_tracker 
       WHERE user_id = $1
       ORDER BY created_at DESC`,
      [userId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching sales:", err);
    res.status(500).json({ error: "Failed to fetch sales records" });
  }
});
// Add sales record
app.post("/api/sales", async (req, res) => {
  try {
    const {
      assigned_consultant,
      technology,
      rate_on_c2c,
      vendor_company,
      vendor_mail,
      vendor_phone_number,
      end_client_details,
      status,
      companyId,
      userId,
    } = req.body;

    // Validate required fields
    if (!companyId || !userId) {
      return res.status(400).json({
        error: "Company ID and User ID are required",
      });
    }

    if (!technology) {
      return res.status(400).json({
        error: "Technology is required",
      });
    }

    const schemaName = companyId.toLowerCase();

    // Verify user exists in t_employee
    const userCheck = await pool.query(
      `SELECT user_id FROM ${schemaName}.t_employee WHERE user_id = $1`,
      [userId]
    );

    if (userCheck.rows.length === 0) {
      return res.status(404).json({
        error: "User not found in employee table",
      });
    }

    // Insert into dynamic schema
    const result = await pool.query(
      `INSERT INTO ${schemaName}.t_bench_sales_tracker (
        user_id, assigned_consultant, technology, rate_on_c2c,
        vendor_company, vendor_mail, vendor_phone_number,
        end_client_details, status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *`,
      [
        userId,
        assigned_consultant,
        technology,
        rate_on_c2c,
        vendor_company,
        vendor_mail,
        vendor_phone_number,
        end_client_details,
        status,
      ]
    );

    res.status(201).json({
      message: "Sales record created successfully",
      sale: result.rows[0],
    });
  } catch (err) {
    console.error("Error creating sales record:", err);

    if (err.code === "23503") {
      // Foreign key violation
      return res.status(400).json({
        error: "Invalid user reference",
        details: `User ${req.body.userId} not found in employee table`,
      });
    }

    res.status(500).json({
      error: "Failed to create sales record",
      details: err.message,
    });
  }
});

// Get sales records
app.get("/api/sales", async (req, res) => {
  try {
    const { companyId, userId } = req.query;

    if (!companyId) {
      return res.status(400).json({ error: "Company ID is required" });
    }

    const schemaName = companyId.toLowerCase();

    let query = `SELECT * FROM ${schemaName}.t_bench_sales_tracker`;
    const values = [];

    if (userId) {
      query += ` WHERE user_id = $1 ORDER BY created_at DESC`;
      values.push(userId);
    } else {
      query += ` ORDER BY created_at DESC`;
    }

    const result = await pool.query(query, values);
    res.status(200).json(result.rows);
  } catch (err) {
    console.error("❌ Error fetching dynamic sales records:", err);
    res.status(500).json({ error: "Failed to fetch sales data" });
  }
});

// Update sales record
app.put("/api/sales/:id", async (req, res) => {
  const { id } = req.params;
  const {
    companyId,
    assigned_consultant,
    technology,
    rate_on_c2c,
    vendor_company,
    vendor_mail,
    vendor_phone_number,
    end_client_details,
    status,
  } = req.body;

  try {
    // Validate that companyId exists
    if (!companyId) {
      return res.status(400).json({ error: "Company ID is required" });
    }

    const schemaName = companyId.toLowerCase();

    const result = await pool.query(
      `UPDATE ${schemaName}.t_bench_sales_tracker SET
        assigned_consultant = $1, technology = $2, rate_on_c2c = $3, 
        vendor_company = $4, vendor_mail = $5, vendor_phone_number = $6,
        end_client_details = $7, status = $8
      WHERE id = $9 RETURNING *`,
      [
        assigned_consultant,
        technology,
        rate_on_c2c,
        vendor_company,
        vendor_mail,
        vendor_phone_number,
        end_client_details,
        status,
        id,
      ]
    );

    if (result.rows.length === 0)
      return res.status(404).json({ error: "Sales record not found" });

    res.status(200).json(result.rows[0]);
  } catch (err) {
    console.error("❌ Error updating sales record:", err);
    res.status(500).json({ error: "Failed to update sales record" });
  }
});
app.delete("/api/sales/:id", async (req, res) => {
  const { id } = req.params;
  const { companyId } = req.query; // companyId sent as a query parameter

  try {
    // Validate that companyId exists
    if (!companyId) {
      return res.status(400).json({ error: "Company ID is required" });
    }

    const schemaName = companyId.toLowerCase();

    const result = await pool.query(
      `DELETE FROM ${schemaName}.t_bench_sales_tracker WHERE id = $1 RETURNING *`,
      [id]
    );

    if (result.rows.length === 0)
      return res.status(404).json({ error: "Sales record not found" });

    res.status(200).json({ message: "Sales record deleted successfully" });
  } catch (err) {
    console.error("❌ Error deleting sales record:", err);
    res.status(500).json({ error: "Failed to delete sales record" });
  }
});

app.post("/api/employer/login", async (req, res) => {
  const { userId, email, password } = req.body;

  try {
    // Basic validation
    if (!userId || !email || !password) {
      return res.status(400).json({
        success: false,
        message: "User ID, email, and password are required",
      });
    }

    // Extract company schema from first 8 characters of userId
    const companySchema = userId.substring(0, 8).toLowerCase();
    const employeeTable = `${companySchema}.t_employee`;

    // Query the database with dynamic schema
    const query = `
      SELECT * FROM ${employeeTable} 
      WHERE user_id = $1 
      AND email = $2 
      AND password = $3
      AND active_flag = 'Y'
    `;

    const { rows } = await pool.query(query, [userId, email, password]);

    if (rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: "Invalid credentials or account not active",
      });
    }

    const user = rows[0];

    // Return user data with companySchema
    const userData = {
      userId: user.user_id,
      companyId: user.companyunqi_id,
      companySchema: companySchema, // Added this line
      email: user.email,
      phoneNumber: user.phone_number,
      userRole: user.user_role,
    };

    res.json({
      success: true,
      message: "Login successful",
      user: userData,
    });
  } catch (err) {
    console.error("Login error:", err);

    // Handle schema doesn't exist error
    if (
      err.message.includes("relation") &&
      err.message.includes("does not exist")
    ) {
      return res.status(404).json({
        success: false,
        message: "Company schema not found",
      });
    }

    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
});

// ========================== Job Posting Routes ==========================

// Post job
app.post("/api/job-postings", async (req, res) => {
  const {
    title,
    description,
    location,
    salary_range,
    job_type,
    talent_acquisition_contact,
    talent_acquisition_email,
    companyId,
  } = req.body;

  // Validate companyId exists
  if (!companyId) {
    return res.status(400).json({ error: "Company ID is required" });
  }

  try {
    // Create schema name from companyId (assuming format like "C4BS1032")
    const schemaName = `${companyId.toLowerCase()}`; // Creates "vo_c4bs1032"

    const result = await pool.query(
      `INSERT INTO ${schemaName}.t_job_postings (
        title, description, location, salary_range,
        job_type, talent_acquisition_contact, talent_acquisition_email
      ) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [
        title,
        description,
        location,
        salary_range,
        job_type,
        talent_acquisition_contact,
        talent_acquisition_email,
      ]
    );

    res.status(201).json({ message: "Job posted", job: result.rows[0] });
  } catch (err) {
    console.error("❌ Error posting job:", err);

    // Handle case where schema doesn't exist
    if (
      err.message.includes("relation") &&
      err.message.includes("does not exist")
    ) {
      return res.status(404).json({ error: "Company schema not found" });
    }

    res.status(500).json({ error: "Failed to post job" });
  }
});

// Get all jobs
app.get("/api/jobs", async (req, res) => {
  try {
    const { companyId } = req.query;

    if (!companyId) {
      return res.status(400).json({ error: "Company ID is required" });
    }

    // Create schema name from companyId (assuming format like "C4BS1032")
    const schemaName = `${companyId.toLowerCase()}`;

    const result = await pool.query(
      `SELECT id, title, location, salary_range, job_type, description 
       FROM ${schemaName}.t_job_postings 
       ORDER BY created_date DESC`
    );

    res.status(200).json(result.rows);
  } catch (err) {
    console.error("❌ Error fetching jobs:", err);

    // Handle case where schema doesn't exist
    if (
      err.message.includes("relation") &&
      err.message.includes("does not exist")
    ) {
      return res.status(404).json({ error: "Company jobs not found" });
    }

    res.status(500).json({ error: "Failed to fetch jobs" });
  }
});

// Delete job
app.delete("/api/jobs/:id", async (req, res) => {
  const { id } = req.params;
  const { companyId } = req.query;

  try {
    // Validate companyId exists
    if (!companyId) {
      return res.status(400).json({ error: "Company ID is required" });
    }

    // Create schema name from companyId
    const schemaName = `${companyId.toLowerCase()}`;

    // First check if job exists
    const checkResult = await pool.query(
      `SELECT id FROM ${schemaName}.t_job_postings WHERE id = $1`,
      [id]
    );

    if (checkResult.rows.length === 0) {
      return res.status(404).json({ error: "Job not found" });
    }

    // Delete the job
    await pool.query(`DELETE FROM ${schemaName}.t_job_postings WHERE id = $1`, [
      id,
    ]);

    res.json({ message: "Job deleted successfully" });
  } catch (err) {
    console.error("❌ Error deleting job:", err);

    // Handle case where schema doesn't exist
    if (
      err.message.includes("relation") &&
      err.message.includes("does not exist")
    ) {
      return res.status(404).json({ error: "Company schema not found" });
    }

    res.status(500).json({ error: "Failed to delete job" });
  }
});

app.put("/api/jobs/:id", async (req, res) => {
  const { id } = req.params;
  const {
    title,
    description,
    location,
    salary_range,
    job_type,
    talent_acquisition_contact,
    talent_acquisition_email,
    companyId,
  } = req.body;

  try {
    // Validate required fields
    if (!companyId) {
      return res.status(400).json({ error: "Company ID is required" });
    }

    // Create schema name from companyId
    const schemaName = `${companyId.toLowerCase()}`;

    // First check if job exists
    const checkResult = await pool.query(
      `SELECT id FROM ${schemaName}.t_job_postings WHERE id = $1`,
      [id]
    );

    if (checkResult.rows.length === 0) {
      return res.status(404).json({ error: "Job not found" });
    }

    // Update the job
    const updateResult = await pool.query(
      `UPDATE ${schemaName}.t_job_postings 
       SET 
         title = $1,
         description = $2,
         location = $3,
         salary_range = $4,
         job_type = $5,
         talent_acquisition_contact = $6,
         talent_acquisition_email = $7 
       WHERE id = $8
       RETURNING *`,
      [
        title,
        description,
        location,
        salary_range,
        job_type,
        talent_acquisition_contact,
        talent_acquisition_email,
        id,
      ]
    );

    res.json({
      message: "Job updated successfully",
      job: updateResult.rows[0],
    });
  } catch (err) {
    console.error("❌ Error updating job:", err);

    // Handle case where schema doesn't exist
    if (
      err.message.includes("relation") &&
      err.message.includes("does not exist")
    ) {
      return res.status(404).json({ error: "Company schema not found" });
    }

    res.status(500).json({ error: "Failed to update job" });
  }
});
// ========================== Candidate Application Routes ==========================

// Apply to job
app.post("/api/applications", async (req, res) => {
  const {
    job_posting_id,
    first_name,
    last_name,
    email,
    phone_no,
    visa_status,
    resume,
    companyId,
  } = req.body;

  try {
    // Validate companyId exists
    if (!companyId) {
      return res.status(400).json({ error: "Company ID is required" });
    }

    // Create schema names from companyId
    const schemaName = `${companyId.toLowerCase()}`;
    const jobTable = `${schemaName}.t_job_postings`;
    const applicationsTable = `${schemaName}.t_candidate_applications`;

    // Check if job exists
    const job = await pool.query(
      `SELECT title FROM ${jobTable} WHERE id = $1`,
      [job_posting_id]
    );

    if (job.rows.length === 0) {
      return res.status(404).json({ error: "Job not found" });
    }

    // Submit application
    await pool.query(
      `INSERT INTO ${applicationsTable} (
        job_posting_id, title, first_name, last_name, 
        email, phone_no, visa_status, resume
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [
        job_posting_id,
        job.rows[0].title,
        first_name,
        last_name,
        email,
        phone_no,
        visa_status,
        resume,
      ]
    );

    res.json({ message: "Application submitted successfully" });
  } catch (err) {
    console.error("❌ Error applying to job:", err);

    // Handle case where schema doesn't exist
    if (
      err.message.includes("relation") &&
      err.message.includes("does not exist")
    ) {
      return res.status(404).json({ error: "Company schema not found" });
    }

    res.status(500).json({ error: "Failed to submit application" });
  }
});

// Get all applications
app.get("/api/applications", async (req, res) => {
  try {
    const { companyId } = req.query;

    if (!companyId) {
      return res.status(400).json({ error: "Company ID is required" });
    }

    // Create schema name from companyId
    const schemaName = `${companyId.toLowerCase()}`;
    const applicationsTable = `${schemaName}.t_candidate_applications`;

    const result = await pool.query(
      `SELECT * FROM ${applicationsTable} ORDER BY applied_date DESC`
    );

    res.status(200).json(result.rows);
  } catch (err) {
    console.error("❌ Error fetching applications:", err);

    // Handle case where schema doesn't exist
    if (
      err.message.includes("relation") &&
      err.message.includes("does not exist")
    ) {
      return res.status(404).json({ error: "Company applications not found" });
    }

    res.status(500).json({ error: "Failed to fetch applications" });
  }
});

// New Code
app.post("/api/admin/login", async (req, res) => {
  const { companyunqi_id, email_id, password } = req.body;

  try {
    // Basic validation
    if (!companyunqi_id || !email_id || !password) {
      return res
        .status(400)
        .json({ success: false, message: "All fields are required" });
    }

    // Extract schema prefix from companyunqi_id (assuming format like "C4BS0001")
    const schemaName = `${companyunqi_id.toLowerCase()}`; // Creates "vo_c4bs"

    // Query database with dynamic schema
    const query = `
      SELECT * FROM ${schemaName}.t_company_registration 
      WHERE companyunqi_id = $1 
      AND email_id = $2 
      AND password = $3
      AND is_active = true
    `;

    const { rows } = await pool.query(query, [
      companyunqi_id,
      email_id,
      password,
    ]);

    if (rows.length === 0) {
      return res
        .status(401)
        .json({ success: false, message: "Invalid credentials" });
    }

    const user = rows[0];

    // Return user data (without password)
    const userData = {
      companyunqi_id: user.companyunqi_id,
      company_name: user.company_name,
      email_id: user.email_id,
      firstname: user.firstname,
      lastname: user.lastname,
    };

    res.json({
      success: true,
      message: "Login successful",
      user: userData,
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message, // Send error details for debugging
    });
  }
});

// ========================== Start Server ==========================

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
