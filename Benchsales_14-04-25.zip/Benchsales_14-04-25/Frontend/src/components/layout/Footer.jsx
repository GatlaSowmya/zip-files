import React from "react";

import { FiBriefcase } from "react-icons/fi";
import { FaLinkedin, FaTwitter, FaFacebook } from "react-icons/fa";
function Footer() {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center mb-5">
              <div className="bg-blue-600 p-2 rounded-lg">
                <FiBriefcase className="h-5 w-5 text-white" />
              </div>
              <span className="ml-3 text-xl font-bold">Cloud4BenchSales</span>
            </div>
            <p className="text-gray-400 mb-5 text-sm">
              The most advanced job matching platform connecting top talent with
              innovative companies worldwide.
            </p>
            <div className="flex space-x-4">
              {[
                {
                  icon: <FaLinkedin className="h-5 w-5" />,
                  label: "LinkedIn",
                },
                { icon: <FaTwitter className="h-5 w-5" />, label: "Twitter" },
                {
                  icon: <FaFacebook className="h-5 w-5" />,
                  label: "Facebook",
                },
              ].map((social) => (
                <a
                  key={social.label}
                  href="#"
                  className="text-gray-400 hover:text-white transition-colors"
                  aria-label={social.label}
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>

          {[
            {
              title: "For Candidates",
              links: [
                "Browse Jobs",
                "Candidate Profile",
                "Job Alerts",
                "Career Resources",
              ],
            },
            {
              title: "For Employers",
              links: [
                "Post a Job",
                "Browse Candidates",
                "Recruitment Solutions",
                "Pricing",
              ],
            },
            {
              title: "Company",
              links: ["About Us", "Contact", "Careers", "Blog"],
            },
          ].map((section, index) => (
            <div key={index}>
              <h3 className="text-lg font-semibold mb-4">{section.title}</h3>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-gray-400 hover:text-white transition-colors text-sm"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            © {new Date().getFullYear()} Cloud4BenchSales. All rights reserved.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            {["Privacy Policy", "Terms of Service", "Cookies"].map((item) => (
              <a
                key={item}
                href="#"
                className="text-gray-400 hover:text-white transition-colors text-sm"
              >
                {item}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
