import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  FiBriefcase,
  FiMenu,
  FiX,
  FiHome,
  FiUsers,
  FiSettings,
  FiUserPlus,
} from "react-icons/fi";

const navItems = [
  { label: "Home", path: "/", icon: <FiHome /> },
  { label: "Browse Jobs", path: "/browsejobs-page", icon: <FiBriefcase /> },
  { label: "About Us", path: "/aboutus-page", icon: <FiUsers /> },
];

function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Lock scrolling on body when the menu is open
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }

    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [isMenuOpen]);

  return (
    <nav
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-white shadow-md py-2"
          : "bg-white/90 backdrop-blur-sm py-4"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="flex items-center"
          >
            <div className="bg-blue-600 p-2 rounded-lg">
              <FiBriefcase className="h-5 w-5 text-white" />
            </div>
            <span className="ml-3 text-lg md:text-xl font-bold text-gray-900 truncate max-w-[150px] sm:max-w-none">
              Cloud4BenchSales
            </span>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-6">
            {navItems.map((item) => (
              <motion.div
                key={item.path}
                whileHover={{
                  y: -2,
                  transition: { duration: 0.2 },
                }}
                whileTap={{ scale: 0.98 }}
              >
                <Link
                  to={item.path}
                  className={`relative
        text-gray-700 
        font-medium 
        hover:text-blue-600 
        transition-colors 
        px-3 py-2 
        flex items-center
        group
      `}
                >
                  <span className="mr-2 text-blue-500 group-hover:text-blue-600 transition-colors">
                    {item.icon}
                  </span>
                  <span className="relative">
                    {item.label}
                    <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-blue-600 group-hover:w-full transition-all duration-300"></span>
                  </span>
                </Link>
              </motion.div>
            ))}

            <div className="flex space-x-3 ml-4">
              {/* Admin Register - Purple */}
              <motion.div
                whileHover={{
                  scale: 1.03,
                  boxShadow: "0 4px 20px rgba(124, 58, 237, 0.3)",
                }}
                whileTap={{ scale: 0.98 }}
              >
                <Link
                  to="/admin-register"
                  className="px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors flex items-center"
                >
                  <FiUserPlus className="mr-2" />
                  Admin Register
                </Link>
              </motion.div>

              {/* Employer Login - Blue */}
              <motion.div
                whileHover={{
                  scale: 1.03,
                  boxShadow: "0 4px 20px rgba(59, 130, 246, 0.3)",
                }}
                whileTap={{ scale: 0.98 }}
              >
                <Link
                  to="/employer-login"
                  className="px-4 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors flex items-center"
                >
                  <FiBriefcase className="mr-2" />
                  Employer Login
                </Link>
              </motion.div>

              {/* Admin Login - Indigo */}
              <motion.div
                whileHover={{
                  scale: 1.03,
                  boxShadow: "0 4px 20px rgba(99, 102, 241, 0.3)",
                }}
                whileTap={{ scale: 0.98 }}
              >
                <Link
                  to="/admin-login"
                  className="px-4 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition-colors flex items-center"
                >
                  <FiSettings className="mr-2" />
                  Admin Login
                </Link>
              </motion.div>
            </div>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden text-gray-700 p-2"
            aria-label="Toggle navigation"
            aria-expanded={isMenuOpen}
            aria-controls="mobile-menu"
          >
            {isMenuOpen ? (
              <FiX className="h-6 w-6" />
            ) : (
              <FiMenu className="h-6 w-6" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              className="fixed inset-0 bg-black bg-opacity-30 z-40"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="lg:hidden bg-white shadow-lg overflow-hidden z-50"
            >
              <div className="px-4 py-3 space-y-3">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className="flex items-center px-3 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 rounded-lg font-medium transition-colors"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <span className="mr-2">{item.icon}</span>
                    {item.label}
                  </Link>
                ))}
                <div className="pt-2 space-y-3">
                  {/* Employer Login - Blue */}
                  <motion.div
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Link
                      to="/employer-login"
                      className="flex items-center justify-center w-full px-4 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      <FiBriefcase className="mr-2" />
                      Employer Login
                    </Link>
                  </motion.div>

                  {/* Admin Register - Purple */}
                  <motion.div
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Link
                      to="/admin-register"
                      className="flex items-center justify-center w-full px-4 py-3 bg-purple-600 text-white font-medium rounded-lg hover:bg-purple-700 transition-colors"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      <FiUserPlus className="mr-2" />
                      Admin Register
                    </Link>
                  </motion.div>

                  {/* Admin Login - Indigo */}
                  <motion.div
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Link
                      to="/admin-login"
                      className="flex items-center justify-center w-full px-4 py-3 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition-colors"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      <FiSettings className="mr-2" />
                      Admin Login
                    </Link>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </nav>
  );
}

export default Header;
