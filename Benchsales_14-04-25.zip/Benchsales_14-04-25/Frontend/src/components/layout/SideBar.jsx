import { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  Briefcase,
  User,
  FileText,
  Clipboard,
  Users,
  LogOut,
  Home,
  ChevronDown,
  ChevronUp,
  X,
  Menu,
  Settings,
  User as UserIcon,
  MessageSquare,
  Bell,
  Search,
  HelpCircle,
} from "lucide-react";

const SideBar = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const location = useLocation();
  const sidebarRef = useRef(null);
  const userDropdownRef = useRef(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (sidebarOpen && !sidebarRef.current?.contains(event.target)) {
        setSidebarOpen(false);
      }
      if (
        userDropdownOpen &&
        !userDropdownRef.current?.contains(event.target)
      ) {
        setUserDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [sidebarOpen, userDropdownOpen]);

  // Close sidebar on route change (mobile)
  useEffect(() => {
    setSidebarOpen(false);
  }, [location]);

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden transition-opacity duration-300" />
      )}

      {/* Sidebar */}
      <aside
        ref={sidebarRef}
        className={`fixed lg:relative w-72 bg-white text-gray-800 h-full flex flex-col z-50 transform ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0 transition-transform duration-300 ease-in-out shadow-xl border-r border-gray-200`}
      >
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <Link to="/" className="flex items-center">
            <div className="w-8 h-8 rounded-md bg-blue-600 flex items-center justify-center mr-3">
              <Briefcase className="text-white w-4 h-4" />
            </div>
            <span className="text-xl font-bold text-gray-800">
              Cloud4BenchSales
            </span>
          </Link>
          <button
            className="lg:hidden text-gray-500 hover:text-gray-700"
            onClick={() => setSidebarOpen(false)}
          >
            <X size={20} />
          </button>
        </div>

        {/* Sidebar Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Search (hidden on mobile) */}
          <div className="px-4 pt-4 hidden lg:block">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search..."
                className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-sm transition-all duration-200"
              />
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto p-4 space-y-1">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 mb-2">
              Main
            </p>
            <Link
              to="/admin/dashboard"
              className={`flex items-center py-2.5 px-4 rounded transition duration-200 ${
                location.pathname === "/admin/dashboard"
                  ? "bg-indigo-700 text-white"
                  : "hover:bg-indigo-700 hover:text-white"
              }`}
            >
              <Home className="text-indigo-500 w-5 h-5 mr-2" />
              <span>Dashboard</span>
            </Link>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 mb-2">
              User Management
            </p>
            <Link
              to="/add-user"
              className={`flex items-center py-2.5 px-4 rounded transition duration-200 ${
                location.pathname === "/add-user"
                  ? "bg-indigo-700 text-white"
                  : "hover:bg-indigo-700 hover:text-white"
              }`}
            >
              <User className="text-indigo-500 w-5 h-5 mr-2" />
              <span>User Management</span>
            </Link>
            <Link
              to="/user_listing"
              className={`flex items-center py-2.5 px-4 rounded transition duration-200 ${
                location.pathname === "/user_listing"
                  ? "bg-indigo-700 text-white"
                  : "hover:bg-indigo-700 hover:text-white"
              }`}
            >
              <User className="text-indigo-500 w-5 h-5 mr-2" />
              <span>User Listing</span>
            </Link>

            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 mb-2 mt-6">
              Recruitment
            </p>
            <Link
              to="/job_posting"
              className={`flex items-center py-2.5 px-4 rounded transition duration-200 ${
                location.pathname === "/jobposting"
                  ? "bg-indigo-700 text-white"
                  : "hover:bg-indigo-700 hover:text-white"
              }`}
            >
              <FileText className="text-indigo-500 w-5 h-5 mr-2" />
              <span>Job Posting</span>
            </Link>

            <Link
              to="/job-table"
              className={`flex items-center py-2.5 px-4 rounded transition duration-200 ${
                location.pathname === "/job-table"
                  ? "bg-indigo-700 text-white"
                  : "hover:bg-indigo-700 hover:text-white"
              }`}
            >
              <Clipboard className="text-indigo-500 w-5 h-5 mr-2" />
              <span>Job Listings</span>
            </Link>
            <Link
              to="/job_listings"
              className={`flex items-center py-2.5 px-4 rounded transition duration-200 ${
                location.pathname === "/job_listings"
                  ? "bg-indigo-700 text-white"
                  : "hover:bg-indigo-700 hover:text-white"
              }`}
            >
              <Briefcase className="text-indigo-500 w-5 h-5 mr-2" />
              <span> Job Applications </span>
            </Link>
            <Link
              to="/application"
              className={`flex items-center py-2.5 px-4 rounded transition duration-200 ${
                location.pathname === "/application"
                  ? "bg-indigo-700 text-white"
                  : "hover:bg-indigo-700 hover:text-white"
              }`}
            >
              <Clipboard className="text-indigo-500 w-5 h-5 mr-2" />
              <span> Applications Table</span>
            </Link>

            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 mb-2 mt-6">
              Consultants
            </p>
            <Link
              to="/consultant-form"
              className={`flex items-center py-2.5 px-4 rounded transition duration-200 ${
                location.pathname === "/consultant-form"
                  ? "bg-indigo-700 text-white"
                  : "hover:bg-indigo-700 hover:text-white"
              }`}
            >
              <Users className="text-indigo-500 w-5 h-5 mr-2" />
              <span>Consultant Form</span>
            </Link>

            <Link
              to="/consultant-list"
              className={`flex items-center py-2.5 px-4 rounded transition duration-200 ${
                location.pathname === "/consultant-list"
                  ? "bg-indigo-700 text-white"
                  : "hover:bg-indigo-700 hover:text-white"
              }`}
            >
              <Users className="text-indigo-500 w-5 h-5 mr-2" />
              <span>Consultant Reports</span>
            </Link>

            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 mb-2 mt-6">
              Sales
            </p>
            <Link
              to="/sales-form"
              className={`flex items-center py-2.5 px-4 rounded transition duration-200 ${
                location.pathname === "/sales-form"
                  ? "bg-indigo-700 text-white"
                  : "hover:bg-indigo-700 hover:text-white"
              }`}
            >
              <Briefcase className="text-indigo-500 w-5 h-5 mr-2" />
              <span>Bench Sales Form</span>
            </Link>

            <Link
              to="/sales-list"
              className={`flex items-center py-2.5 px-4 rounded transition duration-200 ${
                location.pathname === "/sales-list"
                  ? "bg-indigo-700 text-white"
                  : "hover:bg-indigo-700 hover:text-white"
              }`}
            >
              <Briefcase className="text-indigo-500 w-5 h-5 mr-2" />
              <span>Bench Sales Reports</span>
            </Link>
          </nav>

          {/* Sidebar Footer */}
          <div className="p-4 border-t border-gray-200">
            <Link
              to="/"
              className="flex items-center py-2.5 px-4 rounded transition duration-200 hover:bg-indigo-700 hover:text-white"
            >
              <LogOut className="text-indigo-500 w-5 h-5 mr-2" />
              <span>Logout</span>
            </Link>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Navigation */}
        <header className="bg-white shadow-sm z-30">
          <div className="flex items-center justify-between py-3 px-6">
            <div className="flex items-center">
              <button
                className="text-gray-600 hover:text-gray-900 lg:hidden mr-4"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                <Menu size={24} />
              </button>

              {/* Mobile Search */}
              {searchOpen ? (
                <div className="relative lg:hidden w-full max-w-xs mr-4">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="text"
                    placeholder="Search..."
                    className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-sm transition-all duration-200"
                    autoFocus
                    onBlur={() => setSearchOpen(false)}
                  />
                </div>
              ) : (
                <button
                  className="lg:hidden text-gray-500 hover:text-gray-700 mr-4"
                  onClick={() => setSearchOpen(true)}
                >
                  <Search size={20} />
                </button>
              )}
            </div>

            <div className="flex items-center space-x-4">
              <button className="p-1 text-gray-500 hover:text-gray-700 relative">
                <Bell size={20} />
                <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
              <button className="p-1 text-gray-500 hover:text-gray-700 relative">
                <MessageSquare size={20} />
                <span className="absolute top-0 right-0 w-2 h-2 bg-blue-500 rounded-full"></span>
              </button>
              <button className="p-1 text-gray-500 hover:text-gray-700">
                <HelpCircle size={20} />
              </button>

              {/* User Dropdown */}
              <div className="relative" ref={userDropdownRef}>
                <button
                  className="flex items-center focus:outline-none"
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-600 to-blue-400 flex items-center justify-center text-white font-medium text-sm">
                    AD
                  </div>
                  <div className="ml-2 text-left hidden md:block">
                    <p className="text-sm font-medium text-gray-800">
                      Admin User
                    </p>
                    <p className="text-xs text-gray-500">Administrator</p>
                  </div>
                  {userDropdownOpen ? (
                    <ChevronUp
                      className="ml-1 text-gray-500 hidden md:block"
                      size={16}
                    />
                  ) : (
                    <ChevronDown
                      className="ml-1 text-gray-500 hidden md:block"
                      size={16}
                    />
                  )}
                </button>

                <div
                  className={`absolute right-0 mt-2 w-56 bg-white rounded-md shadow-lg py-1 z-20 border border-gray-200 ${
                    userDropdownOpen ? "block" : "hidden"
                  }`}
                >
                  <div className="px-4 py-2 border-b border-gray-200">
                    <p className="text-sm font-medium text-gray-800">
                      Admin User
                    </p>
                    <p className="text-xs text-gray-500">admin@example.com</p>
                  </div>
                  <Link
                    to="#"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                  >
                    <UserIcon className="mr-2" size={14} />
                    Profile
                  </Link>
                  <Link
                    to="#"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                  >
                    <Settings className="mr-2" size={14} />
                    Settings
                  </Link>
                  <div className="border-t border-gray-200 my-1"></div>
                  <Link
                    to="/"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                  >
                    <LogOut className="mr-2" size={14} />
                    Logout
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50">
          <div className="container mx-auto">{children}</div>
        </main>
      </div>
    </div>
  );
};

export default SideBar;
