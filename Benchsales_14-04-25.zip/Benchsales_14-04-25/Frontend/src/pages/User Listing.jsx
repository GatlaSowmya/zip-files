import React, { useEffect, useState } from "react";
import axios from "axios";

const UserListing = () => {
  const [users, setUsers] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortKey, setSortKey] = useState("user_id");
  const [sortOrder, setSortOrder] = useState("asc");
  const [loading, setLoading] = useState(true);
  const [editIndex, setEditIndex] = useState(null);
  const [editUser, setEditUser] = useState({});

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      setLoading(true);

      // Get companyId from localStorage
      const companyId = localStorage.getItem("companyId");
      if (!companyId) {
        throw new Error("Company ID not found in localStorage");
      }

      const res = await axios.get(
        "http://localhost:5000/api/get-super-admins",
        {
          params: { companyId }, // Pass companyId as query parameter
        }
      );

      setUsers(res.data);
    } catch (error) {
      console.error("Failed to fetch users:", error);
      // Handle error (show toast/notification)
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleSort = (key) => {
    if (key === sortKey) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      setSortOrder("asc");
    }
  };

  const handleEdit = (index) => {
    setEditIndex(index);
    setEditUser({ ...users[index] });
  };

  const handleCancel = () => {
    setEditIndex(null);
    setEditUser({});
  };

  const handleSave = async () => {
    try {
      // Get companyId from localStorage
      const companyId = localStorage.getItem("companyId");
      if (!companyId) {
        alert("Company ID not found. Please login again.");
        return;
      }

      await axios.put(
        `http://localhost:5000/api/update-user/${editUser.user_id}`,
        { ...editUser, companyId } // Include companyId in the request body
      );

      const updatedUsers = [...users];
      updatedUsers[editIndex] = editUser;
      setUsers(updatedUsers);
      setEditIndex(null);
      setEditUser({});
      alert("User updated successfully");
    } catch (error) {
      console.error("Failed to update user:", error);
      alert(error.response?.data?.message || "Failed to update user");
    }
  };

  const handleDelete = async (user_id) => {
    if (window.confirm("Are you sure you want to delete this user?")) {
      try {
        // Get companyId from localStorage
        const companyId = localStorage.getItem("companyId");
        if (!companyId) {
          alert("Company ID not found. Please login again.");
          return;
        }

        await axios.delete(`http://localhost:5000/api/delete-user/${user_id}`, {
          params: { companyId }, // Pass companyId as query parameter
        });

        const updatedUsers = users.filter((u) => u.user_id !== user_id);
        setUsers(updatedUsers);
        alert("User deleted successfully");
      } catch (error) {
        console.error("Failed to delete user:", error);
        alert(error.response?.data?.message || "Failed to delete user");
      }
    }
  };

  const sortedUsers = [...users]
    .filter((user) =>
      Object.values(user).some((value) =>
        value?.toString().toLowerCase().includes(searchQuery.toLowerCase())
      )
    )
    .sort((a, b) => {
      const valA = a[sortKey];
      const valB = b[sortKey];
      if (valA === null || valA === undefined) return 1;
      if (valB === null || valB === undefined) return -1;
      return sortOrder === "asc"
        ? valA.toString().localeCompare(valB.toString())
        : valB.toString().localeCompare(valA.toString());
    });

  return (
    <div className="p-4 bg-gray-100 min-h-screen">
      <div className="max-w-7xl mx-auto bg-white p-6 rounded shadow">
        <h2 className="text-2xl font-semibold mb-4 text-center">User List</h2>
        <input
          type="text"
          placeholder="Search users..."
          className="mb-4 w-full px-4 py-2 border rounded shadow-sm"
          value={searchQuery}
          onChange={handleSearch}
        />
        {loading ? (
          <p className="text-center text-gray-600">Loading...</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full table-auto text-sm">
              <thead>
                <tr className="bg-gray-200 text-gray-700">
                  <th
                    onClick={() => handleSort("user_id")}
                    className="cursor-pointer px-4 py-2 text-left"
                  >
                    User ID
                  </th>
                  <th
                    onClick={() => handleSort("user_role")}
                    className="cursor-pointer px-4 py-2 text-left"
                  >
                    Role
                  </th>
                  <th
                    onClick={() => handleSort("email")}
                    className="cursor-pointer px-4 py-2 text-left"
                  >
                    Email
                  </th>
                  <th
                    onClick={() => handleSort("phone_number")}
                    className="cursor-pointer px-4 py-2 text-left"
                  >
                    Phone
                  </th>
                  <th
                    onClick={() => handleSort("active_flag")}
                    className="cursor-pointer px-4 py-2 text-left"
                  >
                    Active
                  </th>
                  <th
                    onClick={() => handleSort("lock_flag")}
                    className="cursor-pointer px-4 py-2 text-left"
                  >
                    Locked
                  </th>
                  <th className="px-4 py-2 text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                {sortedUsers.map((user, index) => (
                  <tr key={user.user_id} className="hover:bg-gray-50 border-b">
                    {editIndex === index ? (
                      <>
                        <td className="px-4 py-2">{user.user_id}</td>
                        <td className="px-4 py-2">
                          <input
                            value={editUser.user_role}
                            onChange={(e) =>
                              setEditUser({
                                ...editUser,
                                user_role: e.target.value,
                              })
                            }
                            className="border px-2 py-1 rounded w-full"
                          />
                        </td>
                        <td className="px-4 py-2">
                          <input
                            value={editUser.email}
                            onChange={(e) =>
                              setEditUser({
                                ...editUser,
                                email: e.target.value,
                              })
                            }
                            className="border px-2 py-1 rounded w-full"
                          />
                        </td>
                        <td className="px-4 py-2">
                          <input
                            value={editUser.phone_number}
                            onChange={(e) =>
                              setEditUser({
                                ...editUser,
                                phone_number: e.target.value,
                              })
                            }
                            className="border px-2 py-1 rounded w-full"
                          />
                        </td>
                        <td className="px-4 py-2">
                          <input
                            value={editUser.active_flag}
                            onChange={(e) =>
                              setEditUser({
                                ...editUser,
                                active_flag: e.target.value,
                              })
                            }
                            className="border px-2 py-1 rounded w-full"
                          />
                        </td>
                        <td className="px-4 py-2">
                          <input
                            value={editUser.lock_flag}
                            onChange={(e) =>
                              setEditUser({
                                ...editUser,
                                lock_flag: e.target.value,
                              })
                            }
                            className="border px-2 py-1 rounded w-full"
                          />
                        </td>
                        <td className="px-4 py-2 flex gap-2">
                          <button
                            onClick={handleSave}
                            className="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600"
                          >
                            Save
                          </button>
                          <button
                            onClick={handleCancel}
                            className="bg-gray-400 text-white px-3 py-1 rounded hover:bg-gray-500"
                          >
                            Cancel
                          </button>
                        </td>
                      </>
                    ) : (
                      <>
                        <td className="px-4 py-2">{user.user_id}</td>
                        <td className="px-4 py-2">{user.user_role}</td>
                        <td className="px-4 py-2">{user.email}</td>
                        <td className="px-4 py-2">{user.phone_number}</td>
                        <td className="px-4 py-2">{user.active_flag}</td>
                        <td className="px-4 py-2">{user.lock_flag}</td>
                        <td className="px-4 py-2 flex gap-2">
                          <button
                            onClick={() => handleEdit(index)}
                            className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => handleDelete(user.user_id)}
                            className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
                          >
                            Delete
                          </button>
                        </td>
                      </>
                    )}
                  </tr>
                ))}
                {sortedUsers.length === 0 && (
                  <tr>
                    <td colSpan="7" className="text-center py-4 text-gray-500">
                      No users found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserListing;
