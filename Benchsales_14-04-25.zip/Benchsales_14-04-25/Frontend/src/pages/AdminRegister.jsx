import React, { useState } from "react";
import {
  FaUser,
  FaBuilding,
  FaIdCard,
  FaPhone,
  FaLock,
  FaEnvelope,
} from "react-icons/fa";
import { FiEye, FiEyeOff } from "react-icons/fi";
import { Check, X } from "lucide-react";
import Nav from "../components/layout/Header";
import { Link } from "react-router-dom";

const AdminRegister = () => {
  const [formData, setFormData] = useState({
    firstname: "",
    lastname: "",
    email_id: "",
    password: "",
    company_name: "",
    company_registerid: "",
    mobile_no: "",
  });

  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [registrationSuccess, setRegistrationSuccess] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    // Clear error when user types
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: null,
      });
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.firstname.trim())
      newErrors.firstname = "First name is required";
    if (!formData.lastname.trim()) newErrors.lastname = "Last name is required";
    if (!formData.email_id.trim()) {
      newErrors.email_id = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email_id)) {
      newErrors.email_id = "Please enter a valid email";
    }
    if (!formData.password) {
      newErrors.password = "Password is required";
    } else if (formData.password.length < 8) {
      newErrors.password = "Password must be at least 8 characters";
    }
    if (!formData.company_name.trim())
      newErrors.company_name = "Company name is required";
    if (!formData.company_registerid.trim())
      newErrors.company_registerid = "Company registration ID is required";
    if (!formData.mobile_no.trim()) {
      newErrors.mobile_no = "Mobile number is required";
    } else if (!/^[0-9]{10,15}$/.test(formData.mobile_no)) {
      newErrors.mobile_no = "Please enter a valid mobile number";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (validateForm()) {
      setIsSubmitting(true);
      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1500));
        console.log("Registration data:", formData);
        setRegistrationSuccess(true);
      } catch (error) {
        console.error("Registration error:", error);
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  if (registrationSuccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md w-full text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Check className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            Registration Successful!
          </h2>
          <p className="text-gray-600 mb-6">
            Your admin account has been created successfully. You can now log in
            to the job portal.
          </p>
          <button
            onClick={() => setRegistrationSuccess(false)}
            className="w-full bg-indigo-600 text-white py-3 rounded-lg font-medium hover:bg-indigo-700 transition duration-200"
          >
            Register Another Admin
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 font-sans antialiased">
      <Nav />
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex pt-16">
        {/* Fixed Left Side (Blue Background) */}
        <div className="hidden md:block md:w-1/2 bg-indigo-600 p-10 text-white fixed top-0 left-0 right-0 bottom-0 flex items-center justify-center">
          <div className="h-screen relative">
            <div className="max-w-xs mx-auto absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <h2 className="text-3xl font-bold mb-4">Job Portal Admin</h2>
              <p className="mb-6">
                Register as an administrator to manage job postings, applicants,
                and company profiles.
              </p>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="bg-indigo-500 rounded-full p-2 mr-3">
                    <Check className="w-4 h-4" />
                  </div>
                  <span>Manage job postings</span>
                </div>
                <div className="flex items-center">
                  <div className="bg-indigo-500 rounded-full p-2 mr-3">
                    <Check className="w-4 h-4" />
                  </div>
                  <span>Review applications</span>
                </div>
                <div className="flex items-center">
                  <div className="bg-indigo-500 rounded-full p-2 mr-3">
                    <Check className="w-4 h-4" />
                  </div>
                  <span>Analytics dashboard</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Scrollable Right Side (Registration Form) */}
        <div className="w-full md:w-1/2 p-8 md:p-10 ml-auto overflow-y-auto">
          <h1 className="text-2xl font-bold text-gray-800 mb-6">
            Admin Registration
          </h1>

          <form onSubmit={handleSubmit}>
            {/* First Name and Last Name */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-gray-700 text-sm font-bold mb-2">
                  First Name
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <FaUser className="text-gray-400" />
                  </div>
                  <input
                    type="text"
                    name="firstname"
                    value={formData.firstname}
                    onChange={handleChange}
                    className={`pl-10 shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 ${
                      errors.firstname ? "border-red-500" : "border-gray-300"
                    }`}
                    placeholder="John"
                  />
                </div>
                {errors.firstname && (
                  <p className="mt-1 text-sm text-red-600">
                    {errors.firstname}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-gray-700 text-sm font-bold mb-2">
                  Last Name
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <FaUser className="text-gray-400" />
                  </div>
                  <input
                    type="text"
                    name="lastname"
                    value={formData.lastname}
                    onChange={handleChange}
                    className={`pl-10 shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 ${
                      errors.lastname ? "border-red-500" : "border-gray-300"
                    }`}
                    placeholder="Doe"
                  />
                </div>
                {errors.lastname && (
                  <p className="mt-1 text-sm text-red-600">{errors.lastname}</p>
                )}
              </div>
            </div>

            {/* Email */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FaEnvelope className="text-gray-400" />
                </div>
                <input
                  type="email"
                  name="email_id"
                  value={formData.email_id}
                  onChange={handleChange}
                  className={`pl-10 shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 ${
                    errors.email_id ? "border-red-500" : "border-gray-300"
                  }`}
                  placeholder="john.doe@company.com"
                />
              </div>
              {errors.email_id && (
                <p className="mt-1 text-sm text-red-600">{errors.email_id}</p>
              )}
            </div>

            {/* Password */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FaLock className="text-gray-400" />
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  className={`pl-10 shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 ${
                    errors.password ? "border-red-500" : "border-gray-300"
                  }`}
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <FiEyeOff className="text-gray-400 hover:text-gray-600" />
                  ) : (
                    <FiEye className="text-gray-400 hover:text-gray-600" />
                  )}
                </button>
              </div>
              {errors.password && (
                <p className="mt-1 text-sm text-red-600">{errors.password}</p>
              )}
            </div>

            {/* Other Fields: Company Name, Company Registration ID, Mobile Number */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Company Name
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FaBuilding className="text-gray-400" />
                </div>
                <input
                  type="text"
                  name="company_name"
                  value={formData.company_name}
                  onChange={handleChange}
                  className={`pl-10 shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 ${
                    errors.company_name ? "border-red-500" : "border-gray-300"
                  }`}
                  placeholder="Acme Inc."
                />
              </div>
              {errors.company_name && (
                <p className="mt-1 text-sm text-red-600">
                  {errors.company_name}
                </p>
              )}
            </div>

            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Company Registration ID
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FaIdCard className="text-gray-400" />
                </div>
                <input
                  type="text"
                  name="company_registerid"
                  value={formData.company_registerid}
                  onChange={handleChange}
                  className={`pl-10 shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 ${
                    errors.company_registerid
                      ? "border-red-500"
                      : "border-gray-300"
                  }`}
                  placeholder="CMP12345678"
                />
              </div>
              {errors.company_registerid && (
                <p className="mt-1 text-sm text-red-600">
                  {errors.company_registerid}
                </p>
              )}
            </div>

            <div className="mb-6">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Mobile Number
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FaPhone className="text-gray-400" />
                </div>
                <input
                  type="tel"
                  name="mobile_no"
                  value={formData.mobile_no}
                  onChange={handleChange}
                  className={`pl-10 shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 ${
                    errors.mobile_no ? "border-red-500" : "border-gray-300"
                  }`}
                  placeholder="1234567890"
                />
              </div>
              {errors.mobile_no && (
                <p className="mt-1 text-sm text-red-600">{errors.mobile_no}</p>
              )}
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="bg-blue-500 w-full hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-sm"
            >
              {isSubmitting ? (
                <>
                  <svg
                    className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Processing...
                </>
              ) : (
                "Register Admin"
              )}
            </button>
          </form>

          {/* Login Link */}
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              Already have an account?{" "}
              <Link
                to="/admin-login"
                className="text-indigo-600 hover:text-indigo-800 font-medium"
              >
                Login here
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminRegister;
