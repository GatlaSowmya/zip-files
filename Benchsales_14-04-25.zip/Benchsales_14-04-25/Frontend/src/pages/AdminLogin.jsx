import React, { useState } from "react";
import Nav from "../components/layout/Header";
import { useNavigate } from "react-router-dom";

function AdminLogin() {
  const [formData, setFormData] = useState({
    companyunqi_id: "",
    email_id: "",
    password: "",
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loginError, setLoginError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    // Clear error when user types
    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.companyunqi_id.trim()) {
      newErrors.companyunqi_id = "Company ID is required";
    } else if (!/^C4BS\d{4}$/.test(formData.companyunqi_id)) {
      newErrors.companyunqi_id =
        "Invalid Company ID format (should be C4BS followed by 4 digits)";
    }

    if (!formData.email_id.trim()) {
      newErrors.email_id = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email_id)) {
      newErrors.email_id = "Please enter a valid email";
    }

    if (!formData.password) {
      newErrors.password = "Password is required";
    } else if (formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoginError("");

    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      const response = await fetch("http://localhost:5000/api/admin/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Login failed");
      }

      // Store authentication data in localStorage
      localStorage.setItem("adminToken", data.token);
      localStorage.setItem("companyId", formData.companyunqi_id);
      localStorage.setItem("adminEmail", formData.email_id);

      // If your response includes user data, you could also store that:
      if (data.user) {
        localStorage.setItem("userData", JSON.stringify(data.user));
      }

      // Redirect to dashboard
      navigate("/admin/dashboard");
    } catch (error) {
      setLoginError(error.message);
      // Clear storage on error (optional)
      localStorage.removeItem("adminToken");
      localStorage.removeItem("companyId");
      localStorage.removeItem("adminEmail");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans antialiased">
      <Nav />
      <div className="flex flex-col items-center justify-center px-6 py-8 mx-auto md:h-screen lg:py-0">
        <div className="w-full bg-white rounded-lg shadow md:mt-0 sm:max-w-md xl:p-0">
          <div className="p-6 space-y-4 md:space-y-6 sm:p-8">
            <h1 className="text-xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl">
              Admin Sign in
            </h1>
            {loginError && (
              <div className="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg">
                {loginError}
              </div>
            )}
            <form className="space-y-4 md:space-y-6" onSubmit={handleSubmit}>
              <div>
                <label
                  htmlFor="companyunqi_id"
                  className="block mb-2 text-sm font-medium text-gray-900"
                >
                  Company Unique ID
                </label>
                <input
                  type="text"
                  name="companyunqi_id"
                  id="companyunqi_id"
                  value={formData.companyunqi_id}
                  onChange={handleChange}
                  className={`bg-gray-50 border ${
                    errors.companyunqi_id ? "border-red-500" : "border-gray-300"
                  } text-gray-900 sm:text-sm rounded-lg focus:ring-blue-600 focus:border-blue-600 block w-full p-2.5`}
                  placeholder="C4BS****"
                />
                {errors.companyunqi_id && (
                  <p className="mt-1 text-sm text-red-600">
                    {errors.companyunqi_id}
                  </p>
                )}
              </div>
              <div>
                <label
                  htmlFor="email_id"
                  className="block mb-2 text-sm font-medium text-gray-900"
                >
                  Email
                </label>
                <input
                  type="email"
                  name="email_id"
                  id="email_id"
                  value={formData.email_id}
                  onChange={handleChange}
                  className={`bg-gray-50 border ${
                    errors.email_id ? "border-red-500" : "border-gray-300"
                  } text-gray-900 sm:text-sm rounded-lg focus:ring-blue-600 focus:border-blue-600 block w-full p-2.5`}
                  placeholder="name@company.com"
                />
                {errors.email_id && (
                  <p className="mt-1 text-sm text-red-600">{errors.email_id}</p>
                )}
              </div>
              <div>
                <label
                  htmlFor="password"
                  className="block mb-2 text-sm font-medium text-gray-900"
                >
                  Password
                </label>
                <input
                  type="password"
                  name="password"
                  id="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="••••••••"
                  className={`bg-gray-50 border ${
                    errors.password ? "border-red-500" : "border-gray-300"
                  } text-gray-900 sm:text-sm rounded-lg focus:ring-blue-600 focus:border-blue-600 block w-full p-2.5`}
                />
                {errors.password && (
                  <p className="mt-1 text-sm text-red-600">{errors.password}</p>
                )}
              </div>
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? "Signing in..." : "Sign in"}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminLogin;
