import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  FiSearch,
  FiBriefcase,
  FiDollarSign,
  FiMapPin,
  FiClock,
  FiUser,
  FiAward,
  FiStar,
  FiArrowRight,
  FiHome,
  FiUsers,
  FiCode,
  FiLayers,
  FiBarChart2,
  FiTrendingUp,
} from "react-icons/fi";
import {
  FaRegHeart,
  FaHeart,
  FaReact,
  FaFigma,
  FaPython,
  FaDigitalOcean,
} from "react-icons/fa";
import Header from "../components/layout/Header";
import Footer from "../components/layout/Footer";

const Home = () => {
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [savedJobs, setSavedJobs] = useState([]);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const jobCategories = [
    {
      id: "all",
      name: "All Jobs",
      count: 1243,
      icon: <FiBriefcase className="text-blue-500 text-xl" />,
    },
    {
      id: "tech",
      name: "Technology",
      count: 432,
      icon: <FiCode className="text-purple-500 text-xl" />,
    },
    {
      id: "finance",
      name: "Finance",
      count: 198,
      icon: <FiTrendingUp className="text-green-500 text-xl" />,
    },
    {
      id: "health",
      name: "Healthcare",
      count: 156,
      icon: <FiUser className="text-red-500 text-xl" />,
    },
    {
      id: "marketing",
      name: "Marketing",
      count: 287,
      icon: <FiBarChart2 className="text-yellow-500 text-xl" />,
    },
  ];

  const featuredJobs = [
    {
      id: 1,
      title: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      location: "San Francisco, CA",
      salary: "$120,000 - $150,000",
      type: "Full-time",
      posted: "2 days ago",
      logo: <FaReact className="text-blue-500 text-4xl" />,
      featured: true,
      skills: ["React", "TypeScript", "Redux"],
      description:
        "We're looking for an experienced frontend developer to join our team working on cutting-edge web applications.",
      requirements: [
        "5+ years React experience",
        "Strong TypeScript skills",
        "Experience with state management",
      ],
      benefits: [
        "Competitive salary",
        "Flexible hours",
        "Health insurance",
        "Remote options",
      ],
    },
    {
      id: 2,
      title: "UX Designer",
      company: "DesignHub",
      location: "Remote",
      salary: "$90,000 - $110,000",
      type: "Full-time",
      posted: "1 week ago",
      logo: <FaFigma className="text-purple-500 text-4xl" />,
      featured: true,
      skills: ["Figma", "User Research", "Prototyping"],
      description:
        "Join our design team to create beautiful, intuitive user experiences for our global client base.",
      requirements: [
        "3+ years UX design",
        "Portfolio required",
        "Figma expertise",
      ],
      benefits: [
        "Fully remote",
        "Annual bonus",
        "Professional development budget",
      ],
    },
    {
      id: 3,
      title: "Data Scientist",
      company: "AnalyticsPro",
      location: "New York, NY",
      salary: "$130,000 - $160,000",
      type: "Full-time",
      posted: "3 days ago",
      logo: <FaPython className="text-green-500 text-4xl" />,
      skills: ["Python", "Machine Learning", "SQL"],
      description:
        "Help us build predictive models and extract insights from large datasets to drive business decisions.",
      requirements: [
        "Advanced degree in CS or related",
        "ML experience",
        "Strong Python skills",
      ],
      benefits: ["Stock options", "Conference budget", "Onsite gym"],
    },
    {
      id: 4,
      title: "Marketing Manager",
      company: "BrandVision",
      location: "Chicago, IL",
      salary: "$85,000 - $100,000",
      type: "Full-time",
      posted: "5 days ago",
      logo: <FaDigitalOcean className="text-blue-400 text-4xl" />,
      skills: ["Digital Marketing", "SEO", "Content Strategy"],
      description:
        "Lead our marketing team to develop and execute campaigns that drive growth and engagement.",
      requirements: [
        "5+ years marketing experience",
        "Proven track record",
        "Team leadership",
      ],
      benefits: ["Performance bonuses", "Flexible PTO", "Company retreats"],
    },
  ];

  const testimonials = [
    {
      id: 1,
      name: "Sarah Johnson",
      role: "Product Designer at TechCorp",
      content:
        "Found my dream job within two weeks of using this platform. The matching algorithm is incredibly accurate!",
      avatar: "https://randomuser.me/api/portraits/women/44.jpg",
      rating: 5,
    },
    {
      id: 2,
      name: "Michael Chen",
      role: "Senior Developer at DataSystems",
      content:
        "The application process was seamless and I got responses much faster than other job sites.",
      avatar: "https://randomuser.me/api/portraits/men/32.jpg",
      rating: 4,
    },
    {
      id: 3,
      name: "Emily Rodriguez",
      role: "Marketing Director",
      content:
        "As a hiring manager, I've found exceptional talent through this platform. Highly recommend!",
      avatar: "https://randomuser.me/api/portraits/women/63.jpg",
      rating: 5,
    },
  ];

  const navItems = [
    { label: "Home", path: "/", icon: <FiHome /> },
    { label: "Browse Jobs", path: "/browsejobs-page", icon: <FiBriefcase /> },
    { label: "About Us", path: "/aboutus-page", icon: <FiUsers /> },
  ];

  const toggleSaveJob = (jobId) => {
    if (savedJobs.includes(jobId)) {
      setSavedJobs(savedJobs.filter((id) => id !== jobId));
    } else {
      setSavedJobs([...savedJobs, jobId]);
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 font-sans antialiased">
      {/* Navigation */}
      <Header />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-800 to-blue-600 text-white pt-24 pb-16 md:pt-32 md:pb-24 overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-block mb-6 px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full border border-white/30"
            >
              <p className="text-sm font-medium text-white/90">
                NEW: AI-Powered Job Matching
              </p>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight"
            >
              Find Your <span className="text-yellow-300">Perfect</span> Career
              Match
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg md:text-xl text-blue-100 mb-8 max-w-3xl mx-auto"
            >
              Connecting top talent with innovative companies through our
              intelligent matching platform
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-white rounded-xl shadow-2xl p-1.5 max-w-2xl mx-auto"
            >
              <div className="flex flex-col md:flex-row">
                <div className="relative flex-grow">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <FiSearch className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    className="block w-full pl-12 pr-4 py-3 md:py-4 border-0 rounded-lg leading-5 bg-gray-50 placeholder-gray-500 focus:ring-2 focus:ring-blue-500 text-gray-900"
                    placeholder="Job title, keywords, or company"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="mt-3 md:mt-0 md:ml-3 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 md:py-4 rounded-lg font-medium shadow-md transition-all"
                >
                  Search Jobs
                </motion.button>
              </div>
            </motion.div>

            <div className="mt-8 flex flex-wrap justify-center gap-3">
              {["Remote", "Full-time", "Developer", "Designer"].map((tag) => (
                <motion.span
                  key={tag}
                  whileHover={{ y: -2 }}
                  className="px-3 py-1 bg-white/10 backdrop-blur-sm rounded-full text-sm font-medium border border-white/20"
                >
                  {tag}
                </motion.span>
              ))}
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-gray-50 to-transparent"></div>
      </section>

      {/* Main Content */}
      <main className="relative z-10">
        {/* Job Categories */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true, margin: "-50px" }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
                Explore by Category
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Browse thousands of jobs in popular industries
              </p>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              {jobCategories.map((category) => (
                <motion.button
                  key={category.id}
                  whileHover={{
                    y: -5,
                    boxShadow: "0 10px 25px -5px rgba(0,0,0,0.1)",
                  }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setActiveTab(category.id)}
                  className={`p-5 rounded-xl transition-all ${
                    activeTab === category.id
                      ? "bg-blue-600 text-white shadow-lg"
                      : "bg-gray-50 hover:bg-gray-100 text-gray-800 border border-gray-200"
                  }`}
                >
                  <div className="flex flex-col items-center text-center">
                    <div className="mb-3">{category.icon}</div>
                    <h3 className="text-lg font-semibold mb-1">
                      {category.name}
                    </h3>
                    <p
                      className={`text-sm ${
                        activeTab === category.id
                          ? "text-blue-100"
                          : "text-gray-500"
                      }`}
                    >
                      {category.count} jobs
                    </p>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Jobs */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true, margin: "-50px" }}
              className="flex flex-col md:flex-row justify-between items-center mb-12"
            >
              <div className="mb-6 md:mb-0">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                  Featured Opportunities
                </h2>
                <p className="text-gray-600">
                  Curated selection of top jobs from leading companies
                </p>
              </div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center text-blue-600 font-medium group"
              >
                View all jobs
                <FiArrowRight className="ml-2 transition-transform group-hover:translate-x-1" />
              </motion.button>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {featuredJobs.map((job) => (
                <motion.div
                  key={job.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  viewport={{ once: true }}
                  whileHover={{ y: -5 }}
                  className={`bg-white rounded-2xl overflow-hidden shadow-md transition-all 
                  }`}
                >
                  <div className="p-6">
                    <div className="flex items-start">
                      <div className="flex items-center justify-center h-14 w-14 rounded-lg bg-gray-100 border border-gray-200">
                        {job.logo}
                      </div>
                      <div className="ml-5 flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="text-lg font-bold text-gray-900">
                              {job.title}
                            </h3>
                            <p className="text-gray-600">{job.company}</p>
                          </div>
                          <button
                            onClick={() => toggleSaveJob(job.id)}
                            className="text-gray-400 hover:text-red-500 transition-colors"
                            aria-label={
                              savedJobs.includes(job.id)
                                ? "Unsave job"
                                : "Save job"
                            }
                          >
                            {savedJobs.includes(job.id) ? (
                              <FaHeart className="h-5 w-5 text-red-500" />
                            ) : (
                              <FaRegHeart className="h-5 w-5" />
                            )}
                          </button>
                        </div>

                        {job.featured && (
                          <div className="inline-block mt-2 px-2.5 py-0.5 bg-yellow-50 text-yellow-800 text-xs font-medium rounded-full">
                            Featured
                          </div>
                        )}

                        <div className="mt-4 flex flex-wrap gap-2">
                          {job.skills?.map((skill) => (
                            <span
                              key={skill}
                              className="px-2 py-1 bg-blue-50 text-blue-600 text-xs rounded-full"
                            >
                              {skill}
                            </span>
                          ))}
                        </div>

                        <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="flex items-center text-gray-500">
                            <FiMapPin className="mr-2 text-gray-400" />
                            <span className="text-sm">{job.location}</span>
                          </div>
                          <div className="flex items-center text-gray-500">
                            <FiDollarSign className="mr-2 text-gray-400" />
                            <span className="text-sm">{job.salary}</span>
                          </div>
                          <div className="flex items-center text-gray-500">
                            <FiClock className="mr-2 text-gray-400" />
                            <span className="text-sm">{job.type}</span>
                          </div>
                          <div className="flex items-center text-gray-500">
                            <FiUser className="mr-2 text-gray-400" />
                            <span className="text-sm">{job.posted}</span>
                          </div>
                        </div>

                        <div className="mt-6 flex flex-col sm:flex-row justify-between items-center gap-3">
                          <Link
                            to={`/jobs/${job.id}`}
                            className="text-blue-600 font-medium hover:text-blue-800 transition-colors text-sm sm:text-base"
                          >
                            View Details
                          </Link>
                          <motion.button
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.98 }}
                            className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg font-medium shadow-sm transition-all text-sm sm:text-base"
                          >
                            Apply Now
                          </motion.button>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true, margin: "-50px" }}
              className="bg-gradient-to-r from-blue-700 to-blue-600 rounded-xl p-8 md:p-10 text-white"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  {
                    value: "10,000+",
                    label: "Active Jobs",
                    icon: <FiBriefcase className="h-6 w-6" />,
                  },
                  {
                    value: "5,000+",
                    label: "Successful Hires",
                    icon: <FiUser className="h-6 w-6" />,
                  },
                  {
                    value: "1,200+",
                    label: "Companies",
                    icon: <FiLayers className="h-6 w-6" />,
                  },
                  {
                    value: "95%",
                    label: "Satisfaction Rate",
                    icon: <FiAward className="h-6 w-6" />,
                  },
                ].map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1, duration: 0.5 }}
                    viewport={{ once: true }}
                    className="text-center"
                  >
                    <div className="inline-flex items-center justify-center w-14 h-14 bg-white/10 rounded-full mb-3">
                      {stat.icon}
                    </div>
                    <h3 className="text-2xl md:text-3xl font-bold mb-1">
                      {stat.value}
                    </h3>
                    <p className="text-blue-100">{stat.label}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true, margin: "-50px" }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
                Success Stories
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Hear from professionals who found their dream jobs through us
              </p>
            </motion.div>

            <div className="relative max-w-4xl mx-auto">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentTestimonial}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.5 }}
                  className="bg-white rounded-xl p-6 shadow-lg"
                >
                  <div className="flex flex-col md:flex-row items-center">
                    <img
                      className="h-16 w-16 rounded-full object-cover border-4 border-white shadow-md"
                      src={testimonials[currentTestimonial].avatar}
                      alt={testimonials[currentTestimonial].name}
                    />
                    <div className="mt-4 md:mt-0 md:ml-6 text-center md:text-left">
                      <h4 className="text-lg font-bold text-gray-900">
                        {testimonials[currentTestimonial].name}
                      </h4>
                      <p className="text-gray-600 mb-3">
                        {testimonials[currentTestimonial].role}
                      </p>
                      <div className="flex justify-center md:justify-start text-yellow-400 mb-3">
                        {[...Array(5)].map((_, i) => (
                          <FiStar
                            key={i}
                            className={`h-4 w-4 ${
                              i < testimonials[currentTestimonial].rating
                                ? "fill-current"
                                : ""
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-700 italic text-center md:text-left mt-5">
                    "{testimonials[currentTestimonial].content}"
                  </p>
                </motion.div>
              </AnimatePresence>

              <div className="flex justify-center mt-6 space-x-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentTestimonial(index)}
                    className={`h-2 w-6 rounded-full transition-all ${
                      currentTestimonial === index
                        ? "bg-blue-600"
                        : "bg-gray-300"
                    }`}
                    aria-label={`View testimonial ${index + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true, margin: "-50px" }}
              className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl p-8 md:p-10 text-center text-white"
            >
              <h2 className="text-2xl md:text-3xl font-bold mb-5">
                Ready for your next career move?
              </h2>
              <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
                Join thousands of professionals who accelerated their careers
                with our platform
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-3">
                <motion.button
                  whileHover={{
                    scale: 1.05,
                    boxShadow: "0 10px 25px rgba(255,255,255,0.3)",
                  }}
                  whileTap={{ scale: 0.98 }}
                  className="bg-white text-blue-600 px-6 py-3 rounded-lg font-bold shadow-lg transition-all"
                >
                  Create Free Account
                </motion.button>
                <motion.button
                  whileHover={{
                    scale: 1.05,
                    boxShadow: "0 10px 25px rgba(255,255,255,0.1)",
                  }}
                  whileTap={{ scale: 0.98 }}
                  className="bg-transparent border-2 border-white px-6 py-3 rounded-lg font-bold shadow-lg transition-all"
                >
                  Browse Jobs
                </motion.button>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default Home;
