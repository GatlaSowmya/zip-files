import React, { useState, useEffect } from "react";
import {
  FaBriefcase,
  FaMapMarkerAlt,
  FaDollarSign,
  FaPaperPlane,
} from "react-icons/fa";
import { Heart, Save, Share2, Trash2, Briefcase } from "lucide-react";
import axios from "axios";
import { motion } from "framer-motion";
import ReactModal from "react-modal";
import toast, { Toaster } from "react-hot-toast";
import { CheckCircle } from "lucide-react";

ReactModal.setAppElement("#root");

const JobApplyModal = ({ isOpen, onRequestClose, job, onSubmit, darkMode }) => {
  const [isOverlayVisible, setIsOverlayVisible] = useState(false); // Overlay visibility state

  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    email: "",
    phone_no: "",
    visa_status: "",
    resume: "",
  });
  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === "resume") {
      setFormData({ ...formData, resume: files[0] });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  // const handleChange = (e) => {
  //   setFormData({ ...formData, [e.target.name]: e.target.value });
  // };

  const handleSubmit = (e) => {
    e.preventDefault();

    const phoneRegex = /^\+?[0-9]{7,15}$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;

    if (!phoneRegex.test(formData.phone_no)) {
      toast.error("Invalid phone number format.");
      return;
    }

    if (!emailRegex.test(formData.email)) {
      toast.error("Invalid email format.");
      return;
    }

    onSubmit({ ...formData, job_posting_id: job.id, title: job.title });
    onRequestClose();
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full  z-[9999]"
      aria-labelledby="modal-title"
      role="dialog"
      aria-modal="true"
    >
      <div
        className={`relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-1/2 shadow-lg rounded-md ${
          darkMode ? "bg-gray-900 text-white" : "bg-white text-gray-900"
        }`}
      >
        <div className="flex justify-between items-center pb-3">
          <h3 id="modal-title" className="text-lg font-semibold">
            Apply for {job.title}
          </h3>
          <button
            onClick={onRequestClose}
            className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center"
          >
            <svg
              className="w-5 h-5"
              fill="currentColor"
              viewBox="0 0 20 20"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fillRule="evenodd"
                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                clipRule="evenodd"
              ></path>
            </svg>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div className="h-[50vh] overflow-y-scroll">
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                First Name
              </label>
              <input
                name="first_name"
                placeholder="First Name"
                required
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              />
            </div>

            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Last Name
              </label>
              <input
                name="last_name"
                placeholder="Last Name"
                required
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              />
            </div>

            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Email
              </label>
              <input
                name="email"
                type="email"
                placeholder="Email"
                required
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              />
            </div>

            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Phone Number
              </label>
              <input
                name="phone_no"
                placeholder="e.g. +1234567890"
                required
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              />
            </div>

            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Visa Status
              </label>
              <select
                name="visa_status"
                required
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              >
                <option value="">Select Visa Status</option>
                <option>H1B</option>
                <option>L2</option>
                <option>OPT</option>
                <option>CPT</option>
                <option>Green Card</option>
                <option>Citizen</option>
                <option>H4-EAD</option>
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Upload Resume
              </label>
              <input
                type="file"
                name="resume"
                accept=".pdf,.doc,.docx"
                required
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2 space-x-4">
            <button
              type="button"
              onClick={onRequestClose}
              className="bg-gray-300 text-gray-800 active:bg-gray-400 font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg font-medium shadow-sm transition-all text-sm sm:text-base"
            >
              Submit Application
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const JobPostingRetrieve = ({ darkMode }) => {
  const [jobs, setJobs] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [savedJobs, setSavedJobs] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [locationFilter, setLocationFilter] = useState("");
  const [selectedJob, setSelectedJob] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const isAdmin = true;
  const [isOverlayVisible, setIsOverlayVisible] = useState(false); // Overlay visibility state

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const companyId = localStorage.getItem("companyId");
        if (!companyId) {
          console.error("Company ID not found in localStorage");
          return;
        }

        const response = await axios.get("http://localhost:5000/api/jobs", {
          params: { companyId }, // Send companyId as query parameter
        });

        setJobs(response.data);
      } catch (error) {
        console.error("Error fetching jobs:", error);
        // Optional: Show error to user
        // toast.error("Failed to load jobs. Please try again.");
      }
    };

    fetchJobs();
  }, []); // Empty dependency array means this runs once on mount

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/jobs/${id}`);
      setJobs((prev) => prev.filter((job) => job.id !== id));
      toast.success("Job deleted successfully!");
    } catch (error) {
      console.error("Delete failed:", error);
      toast.error("Failed to delete job.");
    }
  };

  const openApplyModal = (job) => {
    setSelectedJob(job);
    setIsModalOpen(true);
  };

  const handleApplicationSubmit = async (applicationData) => {
    setIsOverlayVisible(true);

    try {
      const companyId = localStorage.getItem("companyId");
      if (!companyId) {
        toast.error("Company ID not found. Please login again.");
        return;
      }

      await axios.post(
        "http://localhost:5000/api/applications",
        { ...applicationData, companyId } // Include companyId in the request body
      );

      // toast.success("Application submitted successfully!");
    } catch (error) {
      console.error("Application submission failed:", error);
      toast.error(
        error.response?.data?.error || "Submission failed. Try again."
      );
    } finally {
      setIsOverlayVisible(true);
    }
  };

  const filteredJobs = jobs.filter(
    (job) =>
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) &&
      job.location.toLowerCase().includes(locationFilter.toLowerCase())
  );

  return (
    <div
      className={`min-h-screen py-12 px-4 md:px-12 ${
        darkMode ? "bg-gray-900 text-white" : "bg-gray-100 text-gray-900"
      }`}
    >
      <Toaster />
      <h1 className="text-3xl font-bold mb-6 text-center text-gray-800">
        Job Listings
      </h1>

      <div className="flex flex-col md:flex-row gap-4 mb-8 justify-between">
        <input
          type="text"
          placeholder="Search by job title..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full md:w-1/2 p-3 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <input
          type="text"
          placeholder="Filter by location..."
          value={locationFilter}
          onChange={(e) => setLocationFilter(e.target.value)}
          className="w-full md:w-1/2 p-3 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredJobs.map((job) => (
          <motion.div
            key={job.id}
            whileHover={{ scale: 1.02 }}
            className={`rounded-lg shadow-xl p-6 transition-all duration-300 h-full flex flex-col ${
              darkMode
                ? "bg-gray-800 border border-gray-700"
                : "bg-white border border-gray-200"
            }`}
          >
            <div className="mb-4">
              <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-3 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                {job.title}
              </h3>
              <div className="flex mt-1 items-center bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-full font-semibold">
                <FaBriefcase className="mr-2 text-blue-500" />
                {job.company || "Company"}
              </div>
              <div className="flex mt-1 items-center bg-gray-100 dark:bg-gray-700 px-3 py-1 font-semibold rounded-full">
                <FaMapMarkerAlt className="mr-2 text-red-500" />
                {job.location || "Remote"}
              </div>
              <div className="flex mt-1 items-center bg-blue-100 text-blue-800 text-sm font-semibold px-3 py-1 rounded-full dark:bg-blue-200 dark:text-blue-800">
                <FaDollarSign className="mr-2 text-yellow-500" />
                {job.salary_range || "Not specified"}
              </div>
              <div className="flex mt-1 items-center bg-green-100 text-green-800 font-semibold px-3 py-1 rounded-full dark:bg-green-200 dark:text-green-900">
                <Briefcase className="mr-2 text-blue-500 " size={18} />
                {job.job_type || "Not specified"}
              </div>
            </div>
            <div className="text-gray-600 dark:text-gray-300 mb-6 overflow-y-auto max-h-40">
              {job.description?.slice(0, 100)}...
            </div>

            {/* Content at the bottom (flex-grow pushes it down) */}
            <div className="flex flex-col justify-between mt-auto">
              {/* Icons section */}
              <div className="flex justify-evenly gap-2 mt-4 text-sm">
                <button
                  onClick={() =>
                    setFavorites((prev) =>
                      prev.includes(job.id)
                        ? prev.filter((id) => id !== job.id)
                        : [...prev, job.id]
                    )
                  }
                  title="Favorite"
                >
                  <Heart
                    className={`w-5 h-5 ${
                      favorites.includes(job.id)
                        ? "text-red-500"
                        : "text-gray-400"
                    }`}
                  />
                </button>
                <button
                  onClick={() =>
                    setSavedJobs((prev) =>
                      prev.includes(job.id)
                        ? prev.filter((id) => id !== job.id)
                        : [...prev, job.id]
                    )
                  }
                  title="Save for Later"
                >
                  <Save
                    className={`w-5 h-5 ${
                      savedJobs.includes(job.id)
                        ? "text-green-500"
                        : "text-gray-400"
                    }`}
                  />
                </button>
                <button
                  onClick={() =>
                    navigator.share?.({
                      title: job.title,
                      text: job.description,
                      url: window.location.href,
                    })
                  }
                  title="Share"
                >
                  <Share2 className="w-5 h-5 text-blue-400" />
                </button>
                {isAdmin && (
                  <button onClick={() => handleDelete(job.id)} title="Delete">
                    <Trash2 className="w-5 h-5 text-red-500" />
                  </button>
                )}
              </div>

              {/* Apply Now Button */}
              <button
                onClick={() => openApplyModal(job)}
                className={`flex justify-center items-center w-full mt-4 bg-blue-600 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition duration-300 ${
                  darkMode
                    ? "bg-blue-600 hover:bg-blue-500 text-white"
                    : "bg-blue-500 hover:bg-blue-600 text-white"
                }`}
              >
                <FaPaperPlane className="mr-2" /> <span>Apply Now</span>
              </button>
            </div>
          </motion.div>
        ))}
        
      </div>

     {isOverlayVisible && (
             <div className="absolute top-0 left-0 right-0 bottom-0 flex items-center justify-center bg-black bg-opacity-50">
               <div className="p-5 bg-white rounded-lg shadow-lg flex items-center flex-col">
                 <CheckCircle className="text-green-500 w-16 h-16" />
                 <h2 className="text-2xl font-bold mt-4 mb-2">Success!</h2>
                 <p>Job posted Successfully</p>
                 <button
                   onClick={() => setIsOverlayVisible(false)}
                   className="mt-4 px-5 py-2 border border-transparent text-base font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
                 >
                   Close
                 </button>
               </div>
             </div>
          
        
      )}
      {selectedJob && (
        <JobApplyModal
          isOpen={isModalOpen}
          onRequestClose={() => setIsModalOpen(false)}
          job={selectedJob}
          onSubmit={handleApplicationSubmit}
          darkMode={darkMode}
        />
      )}
    </div>
  );
};

export default JobPostingRetrieve;
