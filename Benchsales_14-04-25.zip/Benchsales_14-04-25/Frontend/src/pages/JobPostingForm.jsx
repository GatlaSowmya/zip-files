import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { CheckCircle } from "lucide-react";

function JobPostingForm() {
  const [isOverlayVisible, setIsOverlayVisible] = useState(false); // Overlay visibility state

  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    location: "",
    salary_range: "",
    job_type: "",
    talent_acquisition_contact: "",
    talent_acquisition_email: "",
  });

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  // Form validation function
  const validateForm = () => {
    const {
      title,
      description,
      location,
      salary_range,
      job_type,
      talent_acquisition_contact,
      talent_acquisition_email,
    } = formData;
    if (
      !title ||
      !description ||
      !location ||
      !salary_range ||
      !job_type ||
      !talent_acquisition_contact ||
      !talent_acquisition_email
    ) {
      return "Please fill in all required fields.";
    }

    // Email validation
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(talent_acquisition_email)) {
      return "Please enter a valid email address.";
    }

    // // Salary range validation: it should be a number
    // if (isNaN(salary_range) || salary_range <= 0) {
    //   return "Please enter a valid salary range.";
    // }

    return null; // No errors
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    // Form validation
    const validationMessage = validateForm();
    if (validationMessage) {
      toast.error(validationMessage);
      setLoading(false);
      return;
    }

    // Get companyId from localStorage
    const companyId = localStorage.getItem("companyId");
    if (!companyId) {
      toast.error("Company ID not found. Please login again.");
      setLoading(false);
      return;
    }

    const form = e.target;
    const formDataToSend = {
      title: formData.title,
      description: formData.description,
      location: formData.location,
      salary_range: formData.salary_range,
      job_type: formData.job_type,
      talent_acquisition_contact: formData.talent_acquisition_contact,
      talent_acquisition_email: formData.talent_acquisition_email,
      companyId: companyId, // Add companyId to the payload
    };

    try {
      const res = await fetch("http://localhost:5000/api/job-postings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formDataToSend),
      });

      const data = await res.json();

      if (res.ok) {
        setIsOverlayVisible(true);
        form.reset();
        setFormData({
          title: "",
          description: "",
          location: "",
          salary_range: "",
          job_type: "",
          talent_acquisition_contact: "",
          talent_acquisition_email: "",
        });
      } else {
        toast.error(data?.error || "Failed to post job.");
      }
    } catch (err) {
      toast.error("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gray-100 min-h-screen py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-6 text-center text-gray-800">
          Create Job Posting
        </h1>

        <form
          id="jobPostingForm"
          className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4"
          onSubmit={handleSubmit}
        >
          {/* Inputs */}
          {[
            "title",
            "description",
            "location",
            "salary_range",
            "job_type",
            "talent_acquisition_contact",
            "talent_acquisition_email",
          ].map((field) => (
            <div key={field} className="mb-4">
              <label
                htmlFor={field}
                className="block text-gray-700 text-sm font-bold mb-2"
              >
                {field
                  .replace(/_/g, " ")
                  .replace(/\b\w/g, (l) => l.toUpperCase())}
              </label>
              {field === "description" ? (
                <textarea
                  id={field}
                  name={field}
                  value={formData[field]}
                  onChange={handleInputChange}
                  rows="4"
                  placeholder="Enter job description"
                  required
                  className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
              ) : field === "job_type" ? (
                <select
                  id="job_type"
                  name="job_type"
                  value={formData[field]}
                  onChange={handleInputChange}
                  required
                  className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                >
                  <option value="">Select job type</option>
                  <option value="Full-Time">Full-Time</option>
                  <option value="Part-Time">Part-Time</option>
                  <option value="Contract">Contract</option>
                  <option value="Internship">Internship</option>
                  <option value="Freelance">Freelance</option>
                </select>
              ) : (
                <input
                  id={field}
                  name={field}
                  type={field.includes("email") ? "email" : "text"}
                  value={formData[field]}
                  onChange={handleInputChange}
                  placeholder={`Enter ${field.replace(/_/g, " ")}`}
                  required={field !== "salary_range"}
                  className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
              )}
            </div>
          ))}

          {/* Submit Button + Loading */}
          <div className="flex items-center justify-between">
            <button
              type="submit"
              disabled={loading}
              className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg font-medium shadow-sm transition-all text-sm sm:text-base"
            >
              {loading ? "Posting..." : "Post Job"}
            </button>
            {loading && (
              <div className="ml-4 animate-spin rounded-full h-6 w-6 border-b-2 border-green-600"></div>
            )}
          </div>
        </form>

        {/* Toast Notifications */}
        <ToastContainer
          position="top-right"
          autoClose={5000}
          hideProgressBar={false}
          newestOnTop={true}
          closeButton={true}
          pauseOnHover={true}
        />
      </div>
      {isOverlayVisible && (
        <div className="absolute top-0 left-0 right-0 bottom-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="p-5 bg-white rounded-lg shadow-lg flex items-center flex-col">
            <CheckCircle className="text-green-500 w-16 h-16" />
            <h2 className="text-2xl font-bold mt-4 mb-2">Success!</h2>
            <p>Job posted Successfully</p>
            <button
              onClick={() => setIsOverlayVisible(false)}
              className="mt-4 px-5 py-2 border border-transparent text-base font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default JobPostingForm;
