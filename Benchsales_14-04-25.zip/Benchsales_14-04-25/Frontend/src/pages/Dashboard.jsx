import React, { useState, useEffect } from "react";
import {
  FaSearch,
  FaBuilding,
  FaChevronDown,
  FaChartLine,
  FaUserTie,
  FaHandshake,
  FaClock,
} from "react-icons/fa";
import { motion } from "framer-motion";
import { FiAward, FiBriefcase, FiDollarSign, FiUsers } from "react-icons/fi";

const Dashboard = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [activeStat, setActiveStat] = useState(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  const handleExploreJobs = () => {
    const jobsSection = document.getElementById("jobs-section");
    if (jobsSection) {
      jobsSection.scrollIntoView({ behavior: "smooth" });
    }
  };

  const stats = [
    {
      value: "10K+",
      label: "Jobs Available",
      icon: <FiBriefcase className="text-2xl" />,
      description: "Curated opportunities across industries",
    },
    {
      value: "500+",
      label: "Companies",
      icon: <FiUsers className="text-2xl" />,
      description: "Trusted employers hiring now",
    },
    {
      value: "95%",
      label: "Success Rate",
      icon: <FiAward className="text-2xl" />,
      description: "Candidate placement success",
    },
    {
      value: "24h",
      label: "Response Time",
      icon: <FiDollarSign className="text-2xl" />,
      description: "Average employer response",
    },
  ];

  const features = [
    {
      icon: <FaUserTie className="text-3xl text-blue-500" />,
      title: "Personalized Matches",
      description: "AI-powered job recommendations tailored to your profile",
    },
    {
      icon: <FaChartLine className="text-3xl text-green-500" />,
      title: "Career Growth",
      description: "Opportunities with clear advancement paths",
    },
    {
      icon: <FaHandshake className="text-3xl text-purple-500" />,
      title: "Direct Connections",
      description: "Chat directly with hiring managers",
    },
    {
      icon: <FaClock className="text-3xl text-orange-500" />,
      title: "Quick Apply",
      description: "One-click applications for qualified candidates",
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto scroll-smooth">
      {isLoading ? (
        <div className="flex items-center justify-center h-full min-h-[80vh]">
          <div className="flex flex-col items-center">
            <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-blue-500 mb-4"></div>
            <p className="text-gray-600">
              Loading your career opportunities...
            </p>
          </div>
        </div>
      ) : (
        <>
          {/* Hero Section */}
          <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
            {/* Animated Gradient Background */}
            <div className="absolute inset-0 overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-900 via-gray-900 to-gray-800 opacity-95"></div>
              <div className="absolute inset-0 opacity-20">
                <div className="absolute inset-0 bg-[url('https://grainy-graphics.com/images/large.png')] bg-fixed opacity-30"></div>
              </div>
            </div>

            {/* Content */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="relative z-10 text-center px-6 py-12 sm:px-8 lg:px-12 w-full max-w-7xl mx-auto"
            >
              <motion.div
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, duration: 0.5 }}
                className="inline-block mb-6 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full border border-white/20"
              >
                <p className="text-sm font-medium text-blue-300">
                  NEW: Enhanced Matching Algorithm
                </p>
              </motion.div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-blue-200">
                Discover Your{" "}
                <span className="text-blue-400">Dream Career</span>
              </h1>

              <p className="text-lg sm:text-xl lg:text-2xl max-w-3xl mx-auto mb-10 text-gray-300">
                We connect top talent with innovative companies through our
                intelligent matching platform
              </p>

              <div className="flex flex-col sm:flex-row justify-center gap-4 mb-16">
                <motion.button
                  whileHover={{
                    y: -2,
                    boxShadow: "0 10px 25px -5px rgba(59, 130, 246, 0.4)",
                  }}
                  whileTap={{ scale: 0.98 }}
                  className="relative bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 px-8 rounded-xl shadow-lg transition-all duration-300 flex items-center justify-center gap-3 text-lg group overflow-hidden"
                  onClick={handleExploreJobs}
                >
                  <span className="relative z-10 flex items-center gap-2">
                    <FaSearch className="text-xl" />
                    Explore Jobs
                  </span>
                  <span className="absolute inset-0 bg-gradient-to-r from-blue-500 to-blue-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
                </motion.button>

                <motion.button
                  whileHover={{
                    y: -2,
                    boxShadow: "0 10px 25px -5px rgba(16, 185, 129, 0.4)",
                  }}
                  whileTap={{ scale: 0.98 }}
                  className="relative bg-gray-800 hover:bg-gray-700 text-white font-semibold py-4 px-8 rounded-xl shadow-lg transition-all duration-300 flex items-center justify-center gap-3 text-lg group overflow-hidden border border-gray-700"
                >
                  <span className="relative z-10 flex items-center gap-2">
                    <FaBuilding className="text-xl" />
                    Post a Job
                  </span>
                  <span className="absolute inset-0 bg-gradient-to-r from-gray-700 to-gray-800 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
                </motion.button>
              </div>

              {/* Stats Section */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-5xl mx-auto">
                {stats.map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 + index * 0.1, duration: 0.5 }}
                    className={`bg-white/5 backdrop-blur-md p-5 rounded-xl border border-white/10 hover:border-blue-400/30 transition-all duration-300 cursor-pointer ${
                      activeStat === index
                        ? "ring-2 ring-blue-400 scale-[1.02]"
                        : ""
                    }`}
                    onMouseEnter={() => setActiveStat(index)}
                    onMouseLeave={() => setActiveStat(null)}
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 bg-blue-500/10 rounded-lg text-blue-400">
                        {stat.icon}
                      </div>
                      <p className="text-2xl sm:text-3xl font-bold text-white">
                        {stat.value}
                      </p>
                    </div>
                    <p className="text-sm font-medium text-gray-300">
                      {stat.label}
                    </p>
                    {activeStat === index && (
                      <motion.p
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        className="text-xs text-gray-400 mt-2 overflow-hidden"
                      >
                        {stat.description}
                      </motion.p>
                    )}
                  </motion.div>
                ))}
              </div>

              {/* Scroll indicator */}
              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
                className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center"
              >
                <p className="text-sm text-gray-400 mb-1">
                  Explore opportunities
                </p>
                <div className="animate-bounce">
                  <FaChevronDown className="text-xl text-white" />
                </div>
              </motion.div>
            </motion.div>
          </section>

          {/* Features Section */}
          <section
            id="jobs-section"
            className="py-16 sm:py-20 lg:py-24 bg-white"
          >
            <div className="container mx-auto px-6 sm:px-8 lg:px-12 max-w-7xl">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true, margin: "-100px" }}
                className="text-center mb-16"
              >
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
                  Why <span className="text-blue-600">Choose Us</span>
                </h2>
                <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                  Our platform is designed to streamline your job search or
                  hiring process with cutting-edge features
                </p>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {features.map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1, duration: 0.5 }}
                    viewport={{ once: true, margin: "-50px" }}
                    className="bg-gray-50 rounded-2xl p-8 hover:shadow-lg transition-all duration-300 border border-gray-100 hover:border-blue-100"
                  >
                    <div className="w-14 h-14 rounded-xl bg-blue-50 flex items-center justify-center mb-6">
                      {feature.icon}
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-3">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600">{feature.description}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="py-10 sm:py-10 lg:py-10 bg-gradient-to-r from-blue-600 to-blue-800">
            <div className="container mx-auto px-6 sm:px-8 lg:px-12 max-w-6xl text-center">
              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="text-white"
              >
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
                  Ready to transform your career?
                </h2>
                <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8">
                  Join thousands of professionals who found their dream jobs
                  through our platform
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                  <motion.button
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.98 }}
                    className="bg-white text-blue-600 hover:bg-gray-100 font-semibold py-4 px-8 rounded-xl shadow-lg transition-all duration-300"
                  >
                    Create Free Account
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.98 }}
                    className="bg-transparent border-2 border-white text-white hover:bg-white/10 font-semibold py-4 px-8 rounded-xl transition-all duration-300"
                  >
                    Learn More
                  </motion.button>
                </div>
              </motion.div>
            </div>
          </section>
        </>
      )}
    </div>
  );
};

export default Dashboard;
