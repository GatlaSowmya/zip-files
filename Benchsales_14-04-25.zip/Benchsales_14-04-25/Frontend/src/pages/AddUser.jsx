import React, { useState } from "react";
import axios from "axios";
import { CheckCircle } from "lucide-react";

function AddUser() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    phone_number: "",
    user_role: "EMPLOYEE",
    active_flag: "Y",
    lock_flag: "N",
  });

  const [errors, setErrors] = useState({
    email: "",
    password: "",
    phone_number: "",
    user_role: "",
    active_flag: "",
    lock_flag: "",
  });
  const [isOverlayVisible, setIsOverlayVisible] = useState(false); // Overlay visibility state

  // Handle form field changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  // Validate form inputs
  const validateForm = () => {
    let isValid = true;
    let errors = {};

    if (!formData.password) {
      errors.password = "Password is required";
      isValid = false;
    }

    if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = "A valid email is required";
      isValid = false;
    }

    if (!formData.phone_number) {
      errors.phone_number = "Phone number is required";
      isValid = false;
    }

    setErrors(errors);
    return isValid;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      const companyId = localStorage.getItem("companyId");
      if (!companyId) {
        alert("Company ID not found. Please login again.");
        return;
      }

      // Include companyId in the form data
      const payload = {
        ...formData,
        companyunqi_id: companyId,
      };

      const response = await axios.post(
        "http://localhost:5000/api/add-employee-admin",
        payload,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response.status === 201) {
        setIsOverlayVisible(true);
        setFormData({
          email: "",
          password: "",
          phone_number: "",
          user_role: "",
          active_flag: "Y",
          lock_flag: "N",
        });
        // Optional: Refresh employee list
        // fetchEmployees();
      } else {
        alert(response.data.message);
      }
    } catch (err) {
      console.error("Error:", err);
      alert(
        err.response?.data?.error || "There was an error submitting the form"
      );
    }
  };

  return (
    <div className="bg-gray-100 min-h-screen py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-6 text-center text-gray-800">
          Add User
        </h1>

        <form
          onSubmit={handleSubmit}
          className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 "
        >
          {/* Email */}
          <div className="mb-4">
            <label
              htmlFor="email"
              className="block text-gray-700 text-sm font-bold mb-2"
            >
              Email:
            </label>
            <input
              placeholder="Enter Email Address"
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
              required
            />
            {errors.email && (
              <p className="text-red-500 text-xs italic">{errors.email}</p>
            )}
          </div>

          {/* Password */}
          <div className="mb-4">
            <label
              htmlFor="password"
              className="block text-gray-700 text-sm font-bold mb-2"
            >
              Password:
            </label>
            <input
              placeholder="Enter Password"
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
              required
            />
            {errors.password && (
              <p className="text-red-500 text-xs italic">{errors.password}</p>
            )}
          </div>

          {/* Phone Number */}
          <div className="mb-4">
            <label
              htmlFor="phone_number"
              className="block text-gray-700 text-sm font-bold mb-2"
            >
              Phone Number:
            </label>
            <input
              placeholder="Enter Phone Number "
              type="text"
              id="phone_number"
              name="phone_number"
              value={formData.phone_number}
              onChange={handleChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
              required
            />
            {errors.phone_number && (
              <p className="text-red-500 text-xs italic">
                {errors.phone_number}
              </p>
            )}
          </div>

          {/* Role */}
          <div className="mb-4">
            <label
              htmlFor="user_role"
              className="block text-gray-700 text-sm font-bold mb-2"
            >
              Role:
            </label>
            <select
              id="user_role"
              name="user_role"
              value={formData.user_role}
              onChange={handleChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
              required
            >
              <option value="EMPLOYEE" selected>
                Employee
              </option>
              <option value="SALES">Sales</option>
              <option value="TALENT_ACQUISITION">Talent Acquisition</option>
            </select>
            {errors.user_role && (
              <p className="text-red-500 text-xs italic">{errors.user_role}</p>
            )}
          </div>

          {/* Active Flag */}
          <div className="mb-4">
            <label
              htmlFor="active_flag"
              className="block text-gray-700 text-sm font-bold mb-2"
            >
              Active:
            </label>
            <select
              id="active_flag"
              name="active_flag"
              value={formData.active_flag}
              onChange={handleChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
              required
            >
              <option value="Y">Yes</option>
              <option value="N">No</option>
            </select>
            {errors.active_flag && (
              <p className="text-red-500 text-xs italic">
                {errors.active_flag}
              </p>
            )}
          </div>

          {/* Lock Flag */}
          <div className="mb-4">
            <label
              htmlFor="lock_flag"
              className="block text-gray-700 text-sm font-bold mb-2"
            >
              Lock:
            </label>
            <select
              id="lock_flag"
              name="lock_flag"
              value={formData.lock_flag}
              onChange={handleChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
              required
            >
              <option value="Y">Yes</option>
              <option value="N">No</option>
            </select>
            {errors.lock_flag && (
              <p className="text-red-500 text-xs italic">{errors.lock_flag}</p>
            )}
          </div>

          {/* Submit */}
          <div className="mt-4">
            <button
              type="submit"
              className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110"
            >
              Add User
            </button>
          </div>
        </form>
      </div>
      {isOverlayVisible && (
        <div className="absolute top-0 left-0 right-0 bottom-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="p-5 bg-white rounded-lg shadow-lg flex items-center flex-col">
            <CheckCircle className="text-green-500 w-16 h-16" />
            <h2 className="text-2xl font-bold mt-4 mb-2">Success!</h2>
            <p>User added Successfully</p>
            <button
              onClick={() => setIsOverlayVisible(false)}
              className="mt-4 px-5 py-2 border border-transparent text-base font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default AddUser;
