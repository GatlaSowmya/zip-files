import React, { useState, useEffect } from "react";
import axios from "axios";
import { Edit2, Trash2 } from "lucide-react";

const ConsultantList = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [data, setData] = useState([]);
  const [error, setError] = useState(null);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentConsultant, setCurrentConsultant] = useState(null);

  // Fetch data from API on component mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        const companyId = localStorage.getItem("companyId");

        const response = await axios.get(
          "http://localhost:5000/api/consultants",
          {
            params: { companyId },
          }
        );

        setData(response.data);
      } catch (err) {
        console.error("Error fetching consultants:", err);
        setError("Error fetching data");
      }
    };

    fetchData();
  }, []);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleSort = (key) => {
    let direction = "asc";
    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }
    setSortConfig({ key, direction });
  };

  const getSortedData = () => {
    let sortedData = [...data];
    if (sortConfig.key) {
      sortedData.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? 1 : -1;
        }
        return 0;
      });
    }
    return sortedData;
  };

  const filteredData = getSortedData().filter((item) => {
    return (
      item.user_id?.toString().includes(searchQuery) ||
      item.consultant_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.email_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.phone_no1.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.education_qualification
        .toLowerCase()
        .includes(searchQuery.toLowerCase()) ||
      item.preferred_technology
        .toLowerCase()
        .includes(searchQuery.toLowerCase()) ||
      item.year_of_experience.toString().includes(searchQuery) ||
      item.visa_documents.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.driving_license.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.rate.toString().includes(searchQuery) ||
      item.recruiter_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.marketing_person.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.resume_path.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  if (error) {
    return <div>{error}</div>;
  }

  const renderSortArrow = (key) => {
    if (sortConfig.key !== key) return null;
    return sortConfig.direction === "asc" ? (
      <span className="ml-2 text-xs">↑</span>
    ) : (
      <span className="ml-2 text-xs">↓</span>
    );
  };

  // Open the modal and populate it with consultant data
  const handleEditClick = (consultant) => {
    setCurrentConsultant(consultant);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setCurrentConsultant(null);
  };

  const handleSubmitEdit = async (event) => {
    event.preventDefault();

    try {
      const companyId = localStorage.getItem("companyId");
      const userId = localStorage.getItem("employerUserId");

      if (!companyId || !userId) {
        throw new Error("Missing authentication data. Please login again.");
      }

      const formData = new FormData();

      // Append all fields
      Object.entries(currentConsultant).forEach(([key, value]) => {
        if (value !== null && value !== undefined && key !== "id") {
          formData.append(key, value);
        }
      });

      // Append files if they exist
      if (currentConsultant.resume)
        formData.append("resume", currentConsultant.resume);
      if (currentConsultant.visa_documents)
        formData.append("visa_documents", currentConsultant.visa_documents);
      if (currentConsultant.driving_license)
        formData.append("driving_license", currentConsultant.driving_license);

      const response = await axios.put(
        `http://localhost:5000/api/consultants/${currentConsultant.id}`,
        formData,
        {
          params: { companyId, userId },
          headers: { "Content-Type": "multipart/form-data" },
        }
      );

      const updatedData = data.map((consultant) =>
        consultant.id === currentConsultant.id ? response.data : consultant
      );

      setData(updatedData);
      setCurrentConsultant(null);
    } catch (error) {
      console.error("Error updating consultant:", error);
      const errorMsg =
        error.response?.data?.error ||
        error.response?.data?.details ||
        error.message;
    } finally {
    }
  };

  const handleDeleteClick = async (id) => {
    if (!window.confirm("Are you sure you want to delete this consultant?"))
      return;

    try {
      const companyId = localStorage.getItem("companyId");
      const userId = localStorage.getItem("employerUserId");

      if (!companyId || !userId) {
        throw new Error("Missing authentication data. Please login again.");
      }

      await axios.delete(`http://localhost:5000/api/consultants/${id}`, {
        params: { companyId, userId },
      });

      setData(data.filter((consultant) => consultant.id !== id));
    } catch (error) {
      console.error("Error deleting consultant:", error);
      const errorMsg =
        error.response?.data?.error ||
        error.response?.data?.details ||
        error.message;
    } finally {
    }
  };

  return (
    <div className="max-w-5xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden p-4 sm:p-6">
      <h1 className="text-3xl font-bold mb-6 text-center text-gray-800">
        Consultant List
      </h1>

      <div className="p-4 border-b">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-4 gap-4 sm:gap-6">
          <div className="flex gap-4">
            <select
              className="border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label="Rows per page"
            >
              <option value="5">5 per page</option>
              <option value="10">10 per page</option>
              <option value="25">25 per page</option>
            </select>
            <div className="relative">
              <button
                className="border rounded-lg px-4 py-2 inline-flex items-center gap-2 hover:bg-gray-50"
                aria-expanded="false"
              >
                <i className="fas fa-filter"></i> Filter
              </button>
            </div>
          </div>

          {/* Search box */}
          <div className="relative w-full sm:w-auto">
            <input
              type="text"
              placeholder="Search..."
              className="pl-8 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-auto"
              id="searchInput"
              value={searchQuery}
              onChange={handleSearchChange}
            />
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table
          className="w-full table-auto"
          role="grid"
          aria-label="Data table"
        >
          <thead>
            <tr className="bg-gray-50 text-left">
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("id")}
              >
                User id
                {renderSortArrow("id")}
              </th>
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("consultant_name")}
              >
                Consultant Name
                {renderSortArrow("consultant_name")}
              </th>
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("email_id")}
              >
                Email
                {renderSortArrow("email_id")}
              </th>
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("phone_no1")}
              >
                Phone No
                {renderSortArrow("phone_no1")}
              </th>
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("education_qualification")}
              >
                Qualification
                {renderSortArrow("education_qualification")}
              </th>
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("preferred_technology")}
              >
                Technology
                {renderSortArrow("preferred_technology")}
              </th>
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("year_of_experience")}
              >
                Experience
                {renderSortArrow("year_of_experience")}
              </th>
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
              >
                Visa Docs
              </th>
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
              >
                Driving License
              </th>
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("location")}
              >
                Location
                {renderSortArrow("location")}
              </th>
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("rate")}
              >
                Rate
                {renderSortArrow("rate")}
              </th>
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("recruiter_name")}
              >
                Recruiter
                {renderSortArrow("recruiter_name")}
              </th>
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("marketing_person")}
              >
                Marketing Person
                {renderSortArrow("marketing_person")}
              </th>
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
              >
                Resume
              </th>
              <th
                className="px-6 py-4 text-sm font-medium text-gray-600"
                style={{ textWrap: "nowrap" }}
              >
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredData.map((item, index) => (
              <tr
                key={index}
                className="hover:bg-gray-50 transition-colors cursor-pointer"
              >
                <td
                  className="px-6 py-4 text-sm sm:text-base"
                  style={{ textWrap: "nowrap" }}
                >
                  {item.user_id}
                </td>
                <td
                  className="px-6 py-4 text-sm sm:text-base"
                  style={{ textWrap: "nowrap" }}
                >
                  {item.consultant_name}
                </td>
                <td
                  className="px-6 py-4 text-sm sm:text-base"
                  style={{ textWrap: "nowrap" }}
                >
                  {item.email_id}
                </td>
                <td
                  className="px-6 py-4 text-sm sm:text-base"
                  style={{ textWrap: "nowrap" }}
                >
                  {item.phone_no1}
                </td>
                <td
                  className="px-6 py-4 text-sm sm:text-base"
                  style={{ textWrap: "nowrap" }}
                >
                  {item.education_qualification}
                </td>
                <td
                  className="px-6 py-4 text-sm sm:text-base"
                  style={{ textWrap: "nowrap" }}
                >
                  {item.preferred_technology}
                </td>
                <td
                  className="px-6 py-4 text-sm sm:text-base"
                  style={{ textWrap: "nowrap" }}
                >
                  {item.year_of_experience}
                </td>
                <td>
                  <a
                    href={`http://localhost:5000/${item.visa_documents}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:text-blue-700"
                  >
                    View
                  </a>
                </td>
                <td
                  className="px-6 py-4 text-sm sm:text-base"
                  // style={{ textWrap: "nowrap" }}
                >
                  {/* {item.driving_license} */}
                  <a
                    href={`http://localhost:5000/${item.driving_license}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:text-blue-700"
                  >
                    View
                  </a>
                </td>
                <td
                  className="px-6 py-4 text-sm sm:text-base"
                  style={{ textWrap: "nowrap" }}
                >
                  {item.location}
                </td>
                <td
                  className="px-6 py-4 text-sm sm:text-base"
                  style={{ textWrap: "nowrap" }}
                >
                  {item.rate}
                </td>
                <td
                  className="px-6 py-4 text-sm sm:text-base"
                  style={{ textWrap: "nowrap" }}
                >
                  {item.recruiter_name}
                </td>
                <td
                  className="px-6 py-4 text-sm sm:text-base"
                  style={{ textWrap: "nowrap" }}
                >
                  {item.marketing_person}
                </td>
                {/* <td
                  className="px-6 py-4 text-sm sm:text-base"
                  style={{ whiteSpace: "nowrap" }}
                >
                  {console.log("item.resume:", item.resume_path)}
                  {item.resume_path ? (
                    <a
                      href={`http://localhost:5000/${item.resume_path}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-500 hover:text-blue-700"
                    >
                      Download Resume
                    </a>
                  ) : (
                    "No Resume"
                  )}
                </td> */}
                <td
                  className="px-6 py-4 text-sm sm:text-base"
                  style={{ whiteSpace: "nowrap" }}
                >
                  {console.log("item.resume:", item.resume_path)}
                  {item.resume_path ? (
                    <a
                      href={`http://localhost:5000${item.resume_path.replace(
                        /^\/uploads\//,
                        ""
                      )}`} // Remove any existing '/uploads/' prefix from the resume_path
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-500 hover:text-blue-700"
                    >
                      Download Resume
                    </a>
                  ) : (
                    "No Resume"
                  )}
                </td>
                <td
                  className="px-6 py-4 text-sm sm:text-base"
                  style={{ textWrap: "nowrap" }}
                >
                  <div className="flex gap-4">
                    <button
                      onClick={() => handleEditClick(item)}
                      className="flex justify-center items-center gap-1 bg-blue-600 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition duration-300"
                    >
                      <Edit2 className="h-4 w-4" />
                      <span>Edit</span>
                    </button>
                    <button
                      onClick={() => handleDeleteClick(item.id)}
                      className="flex justify-center items-center gap-1 bg-red-500 hover:text-red-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition duration-300"
                    >
                      <Trash2 className="h-4 w-4" />
                      <span>Delete</span>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && currentConsultant && (
        <div
          className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-[9999]"
          aria-labelledby="modal-title"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-1/2 shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center pb-3">
              <h3
                id="modal-title"
                className="text-lg font-semibold text-gray-900"
              >
                Edit Consultant
              </h3>
              <button
                onClick={handleCloseModal}
                className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center"
              >
                <svg
                  className="w-5 h-5"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fill-rule="evenodd"
                    d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                    clip-rule="evenodd"
                  ></path>
                </svg>
              </button>
            </div>

            <form onSubmit={handleSubmitEdit} className="mt-4">
              <div className="h-[50vh] overflow-y-scroll">
                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Consultant Name
                  </label>
                  <input
                    type="text"
                    value={currentConsultant.consultant_name}
                    onChange={(e) =>
                      setCurrentConsultant({
                        ...currentConsultant,
                        consultant_name: e.target.value,
                      })
                    }
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    value={currentConsultant.email_id}
                    onChange={(e) =>
                      setCurrentConsultant({
                        ...currentConsultant,
                        email_id: e.target.value,
                      })
                    }
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Phone No
                  </label>
                  <input
                    type="text"
                    value={currentConsultant.phone_no1}
                    onChange={(e) =>
                      setCurrentConsultant({
                        ...currentConsultant,
                        phone_no1: e.target.value,
                      })
                    }
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Qualification
                  </label>
                  <input
                    type="text"
                    value={currentConsultant.education_qualification}
                    onChange={(e) =>
                      setCurrentConsultant({
                        ...currentConsultant,
                        education_qualification: e.target.value,
                      })
                    }
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Preferred Technology
                  </label>
                  <input
                    type="text"
                    value={currentConsultant.preferred_technology}
                    onChange={(e) =>
                      setCurrentConsultant({
                        ...currentConsultant,
                        preferred_technology: e.target.value,
                      })
                    }
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Year of Experience
                  </label>
                  <input
                    type="text"
                    value={currentConsultant.year_of_experience}
                    onChange={(e) =>
                      setCurrentConsultant({
                        ...currentConsultant,
                        year_of_experience: e.target.value,
                      })
                    }
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Visa Documents
                  </label>
                  <input
                    type="text"
                    value={currentConsultant.visa_documents}
                    onChange={(e) =>
                      setCurrentConsultant({
                        ...currentConsultant,
                        visa_documents: e.target.value,
                      })
                    }
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Driving License
                  </label>
                  <input
                    type="text"
                    value={currentConsultant.driving_license}
                    onChange={(e) =>
                      setCurrentConsultant({
                        ...currentConsultant,
                        driving_license: e.target.value,
                      })
                    }
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Location
                  </label>
                  <input
                    type="text"
                    value={currentConsultant.location}
                    onChange={(e) =>
                      setCurrentConsultant({
                        ...currentConsultant,
                        location: e.target.value,
                      })
                    }
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Rate
                  </label>
                  <input
                    type="text"
                    value={currentConsultant.rate}
                    onChange={(e) =>
                      setCurrentConsultant({
                        ...currentConsultant,
                        rate: e.target.value,
                      })
                    }
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Recruiter Name
                  </label>
                  <input
                    type="text"
                    value={currentConsultant.recruiter_name}
                    onChange={(e) =>
                      setCurrentConsultant({
                        ...currentConsultant,
                        recruiter_name: e.target.value,
                      })
                    }
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Marketing Person
                  </label>
                  <input
                    type="text"
                    value={currentConsultant.marketing_person}
                    onChange={(e) =>
                      setCurrentConsultant({
                        ...currentConsultant,
                        marketing_person: e.target.value,
                      })
                    }
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-2 space-x-4">
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="bg-gray-300 text-gray-800 active:bg-gray-400 font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-blue-500 text-white active:bg-blue-600 font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConsultantList;
