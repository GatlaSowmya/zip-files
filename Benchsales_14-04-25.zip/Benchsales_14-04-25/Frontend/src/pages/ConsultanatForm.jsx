import React, { useState } from "react";
import axios from "axios";
import { CheckCircle } from "lucide-react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function ConsultantForm() {
  const [isOverlayVisible, setIsOverlayVisible] = useState(false); // Overlay visibility state

  const [formData, setFormData] = useState({
    consultant_name: "",
    email_id: "",
    phone_no1: "",
    education_qualification: "",
    preferred_technology: "",
    year_of_experience: "",
    visa_documents: null,
    driving_license: null,
    location: "",
    rate: "",
    recruiter_name: "",
    marketing_person: "",
    resume_path: null,
  });

  const [errors, setErrors] = useState({
    consultant_name: "",
    email_id: "",
    phone_no1: "",
    education_qualification: "",
    preferred_technology: "",
    year_of_experience: "",
    visa_documents: "",
    driving_license: "",
    location: "",
    rate: "",
    recruiter_name: "",
    marketing_person: "",
    resume_path: "",
  });

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;
    if (type === "file") {
      setFormData((prevData) => ({
        ...prevData,
        [name]: files[0],
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.consultant_name)
      newErrors.consultant_name = "Consultant Name is required.";
    if (!formData.email_id || !/\S+@\S+\.\S+/.test(formData.email_id))
      newErrors.email_id = "Valid Email ID is required.";
    if (!formData.phone_no1)
      newErrors.phone_no1 = "Valid Phone Number is required.";
    if (!formData.education_qualification)
      newErrors.education_qualification =
        "Education Qualification is required.";
    if (!formData.preferred_technology)
      newErrors.preferred_technology = "Preferred Technology is required.";
    if (!formData.year_of_experience || formData.year_of_experience <= 0)
      newErrors.year_of_experience = "Valid Years of Experience are required.";
    if (!formData.visa_documents)
      newErrors.visa_documents = "Visa Document is required.";
    if (!formData.driving_license)
      newErrors.driving_license = "Driving License is required.";
    if (!formData.location) newErrors.location = "Location is required.";
    if (!formData.rate || formData.rate <= 0)
      newErrors.rate = "Valid Rate (per hour) is required.";
    if (!formData.recruiter_name)
      newErrors.recruiter_name = "Recruiter Name is required.";
    if (!formData.marketing_person)
      newErrors.marketing_person = "Marketing Person is required.";
    if (!formData.resume_path) newErrors.resume_path = "Resume is required.";

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) {
      toast.error("Please enter valid details for all required fields.");
    }
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }

    const form = new FormData();
    for (const key in formData) {
      form.append(key, formData[key]);
    }

    try {
      // 1. Get required IDs
      const companyId = localStorage.getItem("companyId"); // "C4BS1032"
      const userId = localStorage.getItem("employerUserId"); // "C4BS103202"

      if (!companyId || !userId) {
        throw new Error("Missing authentication data. Please login again.");
      }

      // 2. Verify user exists before submission
      const verifyResponse = await axios.get(
        `http://localhost:5000/api/verify-employee/${userId}`,
        {
          params: { companyId },
        }
      );

      if (!verifyResponse.data.valid) {
        throw new Error("Your employee account is not valid or active");
      }

      // 3. Prepare form data
      const form = new FormData();

      // Append all form fields
      form.append("consultant_name", formData.consultant_name);
      form.append("email_id", formData.email_id);
      form.append("phone_no1", formData.phone_no1);
      form.append(
        "education_qualification",
        formData.education_qualification || ""
      );
      form.append("preferred_technology", formData.preferred_technology || "");
      form.append("year_of_experience", formData.year_of_experience || "");
      form.append("location", formData.location || "");
      form.append("rate", formData.rate || "");
      form.append("recruiter_name", formData.recruiter_name || "");
      form.append("marketing_person", formData.marketing_person || "");

      // Append files if they exist
      if (formData.visa_documents)
        form.append("visa_documents", formData.visa_documents);
      if (formData.driving_license)
        form.append("driving_license", formData.driving_license);
      if (formData.resume_path)
        form.append("resume_path", formData.resume_path);

      // Append IDs
      form.append("companyId", companyId);
      form.append("userId", userId);

      // 4. Submit data
      const response = await axios.post(
        "http://localhost:5000/api/consultants",
        form,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      // 5. Handle success
      setIsOverlayVisible(true);
      toast.success("Consultant created successfully!");

      // Reset form
      setFormData({
        consultant_name: "",
        email_id: "",
        phone_no1: "",
        education_qualification: "",
        preferred_technology: "",
        year_of_experience: "",
        visa_documents: null,
        driving_license: null,
        location: "",
        rate: "",
        recruiter_name: "",
        marketing_person: "",
        resume_path: null,
      });
    } catch (error) {
      console.error("Submission failed:", error);
      const errorMsg =
        error.response?.data?.error ||
        error.response?.data?.details ||
        error.message;
      toast.error(`Failed: ${errorMsg}`);
    } finally {
    }
  };

  return (
    <div>
      <body className="bg-gray-100">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-3xl font-bold mb-6 text-center text-gray-800">
            Consultant Details Form
          </h1>
          <form
            id="consultantForm"
            className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4"
            onSubmit={handleSubmit}
          >
            {/* Consultant Name */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Consultant Name
              </label>
              <input
                name="consultant_name"
                type="text"
                value={formData.consultant_name}
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
                required
              />
              {errors.consultant_name && (
                <p className="text-red-500 text-xs italic">
                  {errors.consultant_name}
                </p>
              )}
            </div>

            {/* Email ID */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Email ID
              </label>
              <input
                name="email_id"
                type="email"
                value={formData.email_id}
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
                required
              />
              {errors.email_id && (
                <p className="text-red-500 text-xs italic">{errors.email_id}</p>
              )}
            </div>

            {/* Phone Number */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Phone Number
              </label>
              <input
                name="phone_no1"
                type="tel"
                value={formData.phone_no1}
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
                required
              />
              {errors.phone_no1 && (
                <p className="text-red-500 text-xs italic">
                  {errors.phone_no1}
                </p>
              )}
            </div>

            {/* Education Qualification */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Education Qualification
              </label>
              <input
                name="education_qualification"
                type="text"
                value={formData.education_qualification}
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
                required
              />
              {errors.education_qualification && (
                <p className="text-red-500 text-xs italic">
                  {errors.education_qualification}
                </p>
              )}
            </div>

            {/* Preferred Technology */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Preferred Technology
              </label>
              <input
                name="preferred_technology"
                type="text"
                value={formData.preferred_technology}
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
                required
              />
              {errors.preferred_technology && (
                <p className="text-red-500 text-xs italic">
                  {errors.preferred_technology}
                </p>
              )}
            </div>

            {/* Years of Experience */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Years of Experience
              </label>
              <input
                name="year_of_experience"
                type="number"
                value={formData.year_of_experience}
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
                required
              />
              {errors.year_of_experience && (
                <p className="text-red-500 text-xs italic">
                  {errors.year_of_experience}
                </p>
              )}
            </div>

            {/* Visa Documents */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Upload Visa Document
              </label>
              <input
                name="visa_documents"
                type="file"
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
                accept=".pdf,.doc,.docx,.jpg,.png"
                required
              />

              {errors.visa_documents && (
                <p className="text-red-500 text-xs italic">
                  {errors.visa_documents}
                </p>
              )}
            </div>

            {/* Driving License */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Upload Driving License
              </label>
              <input
                name="driving_license"
                type="file"
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
                accept=".pdf,.jpg,.png"
                required
              />
              {errors.driving_license && (
                <p className="text-red-500 text-xs italic">
                  {errors.driving_license}
                </p>
              )}
            </div>

            {/* Location */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Location
              </label>
              <input
                name="location"
                type="text"
                value={formData.location}
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
                required
              />
              {errors.location && (
                <p className="text-red-500 text-xs italic">{errors.location}</p>
              )}
            </div>

            {/* Rate */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Rate (per hour)
              </label>
              <input
                name="rate"
                type="number"
                value={formData.rate}
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
                required
              />
              {errors.rate && (
                <p className="text-red-500 text-xs italic">{errors.rate}</p>
              )}
            </div>

            {/* Recruiter Name */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Recruiter Name
              </label>
              <input
                name="recruiter_name"
                type="text"
                value={formData.recruiter_name}
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
                required
              />
              {errors.recruiter_name && (
                <p className="text-red-500 text-xs italic">
                  {errors.recruiter_name}
                </p>
              )}
            </div>

            {/* Marketing Person */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Marketing Person
              </label>
              <input
                name="marketing_person"
                type="text"
                value={formData.marketing_person}
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
                required
              />
              {errors.marketing_person && (
                <p className="text-red-500 text-xs italic">
                  {errors.marketing_person}
                </p>
              )}
            </div>

            {/* Resume Upload */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Upload Resume
              </label>
              <input
                name="resume_path"
                type="file"
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
                accept=".pdf,.doc,.docx"
                required
              />
              {errors.resume_path && (
                <p className="text-red-500 text-xs italic">
                  {errors.resume_path}
                </p>
              )}
            </div>

            {/* Submit */}
            <div className="flex items-center justify-between">
              <button
                className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg font-medium shadow-sm transition-all text-sm sm:text-base"
                type="submit"
              >
                Submit
              </button>
            </div>
          </form>
          </div>
         {isOverlayVisible && (
                <div className="absolute top-0 left-0 right-0 bottom-0 flex items-center justify-center bg-black bg-opacity-50">
                  <div className="p-5 bg-white rounded-lg shadow-lg flex items-center flex-col">
                    <CheckCircle className="text-green-500 w-16 h-16" />
                    <h2 className="text-2xl font-bold mt-4 mb-2">Success!</h2>
                    <p>Details added Successfully</p>
                    <button
                      onClick={() => setIsOverlayVisible(false)}
                      className="mt-4 px-5 py-2 border border-transparent text-base font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
                    >
                      Close
                    </button>
                  </div>
                </div>
              )}
      </body>
    </div>
  );
}
export default ConsultantForm;
