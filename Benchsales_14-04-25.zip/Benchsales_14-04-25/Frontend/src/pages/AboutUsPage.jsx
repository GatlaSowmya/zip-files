import React from "react";
import {
  FiUsers,
  FiAward,
  FiGlobe,
  FiHeart,
  FiBriefcase,
} from "react-icons/fi";
import { motion } from "framer-motion";
import Header from "../components/layout/Header";
import Footer from "../components/layout/Footer";

const AboutUsPage = () => {
  const stats = [
    {
      value: "10,000+",
      label: "Jobs Posted",
      icon: <FiBriefcase className="text-3xl" />,
    },
    {
      value: "5,000+",
      label: "Successful Hires",
      icon: <FiUsers className="text-3xl" />,
    },
    {
      value: "1,200+",
      label: "Companies",
      icon: <FiAward className="text-3xl" />,
    },
    {
      value: "95%",
      label: "Satisfaction Rate",
      icon: <FiHeart className="text-3xl" />,
    },
  ];

  const team = [
    {
      name: "Sarah Johnson",
      role: "CEO & Founder",
      bio: "With over 15 years in HR tech, Sarah founded Cloud4BenchSales to revolutionize hiring.",
      img: "https://randomuser.me/api/portraits/women/44.jpg",
    },
    {
      name: "Michael Chen",
      role: "CTO",
      bio: "Michael leads our technical team with expertise in AI and matching algorithms.",
      img: "https://randomuser.me/api/portraits/men/32.jpg",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 font-sans antialiased">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-700 to-blue-600 text-white py-36">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            About Cloud4BenchSales
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Connecting talent with opportunity through innovative technology and
            human insight
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
              Our Story
            </h2>
            <div className="space-y-6 text-gray-700">
              <p>
                Founded in 2015, Cloud4BenchSales began as a small team
                passionate about making hiring easier for both candidates and
                employers. We noticed the inefficiencies in traditional job
                boards and set out to create a better solution.
              </p>
              <p>
                Today, we're proud to serve thousands of companies and
                candidates worldwide, with advanced matching algorithms that go
                beyond keywords to understand the nuances of skills, culture,
                and career aspirations.
              </p>
              <p>
                Our mission remains the same: to create meaningful connections
                that transform careers and businesses.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">
            By The Numbers
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                whileHover={{ y: -5 }}
                className="bg-white p-6 rounded-xl shadow-sm text-center"
              >
                <div className="text-blue-600 mb-4 flex justify-center">
                  {stat.icon}
                </div>
                <h3 className="text-3xl font-bold text-gray-900 mb-2">
                  {stat.value}
                </h3>
                <p className="text-gray-600">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">
            Our Team
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {team.map((member, index) => (
              <motion.div
                key={index}
                whileHover={{ y: -5 }}
                className="bg-gray-50 rounded-xl p-6 flex flex-col md:flex-row items-center"
              >
                <img
                  src={member.img}
                  alt={member.name}
                  className="h-24 w-24 rounded-full object-cover border-4 border-white shadow-md mb-4 md:mb-0 md:mr-6"
                />
                <div>
                  <h3 className="text-xl font-bold text-gray-900">
                    {member.name}
                  </h3>
                  <p className="text-blue-600 mb-2">{member.role}</p>
                  <p className="text-gray-600">{member.bio}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to get started?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of companies and candidates who found their perfect
            match
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button className="px-8 py-3 bg-white text-blue-600 rounded-lg font-bold hover:bg-gray-100 transition-colors">
              Post a Job
            </button>
            <button className="px-8 py-3 border-2 border-white text-white rounded-lg font-bold hover:bg-blue-700 transition-colors">
              Browse Jobs
            </button>
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default AboutUsPage;
