import React, { useState, useEffect } from "react";
import axios from "axios";

const ApplicationRetrieve = () => {
  const [applications, setApplications] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchApplications = async () => {
      try {
        const companyId = localStorage.getItem("companyId");
        if (!companyId) {
          setError("Company ID not found. Please login again.");
          return;
        }

        const response = await axios.get(
          "http://localhost:5000/api/applications",
          {
            params: { companyId }, // Send companyId as query parameter
          }
        );

        setApplications(response.data);
      } catch (error) {
        console.error("Error fetching applications:", error);
        setError(error.response?.data?.error || "Failed to load applications.");
      }
    };

    fetchApplications();
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 md:px-12">
      <h1 className="text-3xl font-bold mb-6 text-center text-gray-800">
        Job Applications
      </h1>

      {error ? (
        <p className="text-red-600 text-center font-semibold">{error}</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {applications.length > 0 ? (
            applications.map((app) => (
              <div
                key={app.id}
                className="bg-white border border-gray-200 shadow-md hover:shadow-xl transition-all duration-300 rounded-2xl p-6 flex flex-col justify-between"
              >
                <div className="mb-4">
                  <h3 className="text-xl font-bold text-blue-700">
                    {app.title || "Untitled Position"}
                  </h3>
                  <p className="text-sm text-gray-500">
                    Job ID: #{app.job_posting_id}
                  </p>
                </div>

                <div className="space-y-2 text-sm text-gray-700">
                  <p>
                    <span className="font-medium">Name:</span> {app.first_name}{" "}
                    {app.last_name}
                  </p>
                  <p>
                    <span className="font-medium text-xs">Email:</span>{" "}
                    <a
                      href={`mailto:${app.email}`}
                      className="text-blue-600 hover:underline"
                    >
                      <span className="inline-flex items-center  bg-green-100 text-red-800 text-xs font-semibold px-2 py-1 rounded-full">
                        {app.email}
                      </span>
                    </a>
                  </p>
                  <p>
                    <span className="font-medium">Phone:</span>{" "}
                    <a
                      href={`tel:${app.phone_no}`}
                      className="text-blue-600 hover:underline"
                    >
                      {app.phone_no}
                    </a>
                  </p>
                  <p>
                    <span className="font-medium">Visa Status:</span>{" "}
                    <span className="inline-flex items-center  bg-blue-100 text-red-800 text-md font-semibold px-2 py-1 rounded-full">
                      {app.visa_status}
                    </span>
                  </p>
                  <p>
                    <span className="font-medium">Application Status:</span>{" "}
                    <span
                      className={`inline-block px-2 py-1 rounded-full text-xs font-semibold ${
                        app.application_status === "Pending"
                          ? "bg-yellow-100 text-yellow-800"
                          : app.application_status === "Reviewed"
                          ? "bg-blue-100 text-blue-800"
                          : app.application_status === "Shortlisted"
                          ? "bg-green-100 text-green-800"
                          : app.application_status === "Rejected"
                          ? "bg-red-100 text-red-800"
                          : "bg-purple-100 text-purple-800"
                      }`}
                    >
                      {app.application_status}
                    </span>
                  </p>
                  <p>
                    <span className="font-medium">Applied On:</span>{" "}
                    <span className="inline-flex items-center mb-2 bg-red-100 text-red-800 text-xs font-semibold px-2 py-1 rounded-full">
                      {new Date(app.applied_date).toLocaleString()}
                    </span>
                  </p>
                </div>

                <div className="mt-6">
                  {app.resume ? (
                    <a
                      href={app.resume}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-blue-600 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition duration-300"
                    >
                      View Resume
                    </a>
                  ) : (
                    <p className="text-sm text-gray-400 italic">
                      No resume uploaded.
                    </p>
                  )}
                </div>
              </div>
            ))
          ) : (
            <p className="text-center text-gray-500 col-span-3">
              No applications found.
            </p>
          )}
        </div>
      )}
    </div>
  );
};

export default ApplicationRetrieve;
