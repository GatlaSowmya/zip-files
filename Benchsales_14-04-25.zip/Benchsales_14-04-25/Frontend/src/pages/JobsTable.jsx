import React, { useEffect, useState } from "react";
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";
import ReactModal from "react-modal";
import { Edit2, Trash2 } from "lucide-react";

ReactModal.setAppElement("#root");

const JobTable = ({ darkMode }) => {
  const [jobs, setJobs] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedJob, setSelectedJob] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    fetchJobs();
  }, []);

  const fetchJobs = async () => {
    try {
      const companyId = localStorage.getItem("companyId");
      if (!companyId) {
        toast.error("Company ID not found. Please login again.");
        return;
      }

      const response = await axios.get("http://localhost:5000/api/jobs", {
        params: { companyId }, // Send companyId as query parameter
      });

      setJobs(response.data);
    } catch (error) {
      toast.error("Failed to fetch jobs");
    }
  };

  const handleDelete = async (id) => {
    try {
      const companyId = localStorage.getItem("companyId");
      if (!companyId) {
        toast.error("Company ID not found. Please login again.");
        return;
      }

      await axios.delete(`http://localhost:5000/api/jobs/${id}`, {
        params: { companyId }, // Send companyId as query parameter
      });

      setJobs((prev) => prev.filter((job) => job.id !== id));
      toast.success("Job deleted successfully");
    } catch (error) {
      toast.error(error.response?.data?.error || "Failed to delete job");
    }
  };

  const handleEdit = (job) => {
    setSelectedJob(job);
    setIsModalOpen(true);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSelectedJob({ ...selectedJob, [name]: value });
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const companyId = localStorage.getItem("companyId");
      if (!companyId) {
        toast.error("Company ID not found. Please login again.");
        return;
      }

      await axios.put(
        `http://localhost:5000/api/jobs/${selectedJob.id}`,
        { ...selectedJob, companyId } // Include companyId in the request body
      );

      toast.success("Job updated successfully");
      setIsModalOpen(false);
      fetchJobs(); // Refresh the jobs list
    } catch (error) {
      toast.error(error.response?.data?.error || "Failed to update job");
    }
  };

  const filteredJobs = jobs.filter((job) =>
    job.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-5xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden p-4 sm:p-6">
      <h1 className="text-3xl font-bold mb-6 text-center text-gray-800">
        Manage Job Postings
      </h1>

      {/* Filters and Search */}
      <div className="p-4 border-b">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div className="flex gap-4">
            <select
              className="border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label="Rows per page"
            >
              <option value="5">5 per page</option>
              <option value="10">10 per page</option>
              <option value="25">25 per page</option>
            </select>
            <button className="border rounded-lg px-4 py-2 flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-gray-700">
              <i className="fas fa-filter"></i> Filter
            </button>
          </div>

          <div className="relative w-full sm:w-auto">
            <input
              type="text"
              placeholder="Search..."
              className="pl-8 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 w-full"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <i className="fas fa-search absolute left-3 top-3 text-gray-400"></i>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full table-auto">
          <thead>
            <tr className="bg-gray-50 text-left">
              <th className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm">
                Title
              </th>
              <th className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm">
                Location
              </th>
              <th className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm">
                Salary
              </th>
              <th className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm">
                Type
              </th>
              <th className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredJobs.length > 0 ? (
              filteredJobs.map((job) => (
                <tr
                  key={job.id}
                  className="hover:bg-gray-50 transition-colors cursor-pointer"
                >
                  <td
                    className="px-6 py-4 text-sm "
                    style={{ textWrap: "nowrap" }}
                  >
                    {job.title}
                  </td>
                  <td
                    className="px-6 py-4 text-sm "
                    style={{ textWrap: "nowrap" }}
                  >
                    {job.location}
                  </td>
                  <td
                    className="px-6 py-4 text-sm "
                    style={{ textWrap: "nowrap" }}
                  >
                    {job.salary_range}
                  </td>
                  <td
                    className="px-6 py-4 text-sm "
                    style={{ textWrap: "nowrap" }}
                  >
                    {job.job_type}
                  </td>
                  <td
                    className="px-6 py-4 text-sm "
                    style={{ textWrap: "nowrap" }}
                  >
                    <div className="flex gap-4">
                      <button
                        onClick={() => handleEdit(job)}
                        className="flex justify-center items-center gap-1 bg-blue-600 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition duration-300"
                      >
                        <Edit2 className="h-4 w-4" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => handleDelete(job.id)}
                        className="flex justify-center items-center gap-1 bg-red-500 hover:text-red-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition duration-300"
                      >
                        <Trash2 className="h-4 w-4" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="text-center py-6 text-gray-500">
                  No jobs found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      <ReactModal
        isOpen={isModalOpen}
        onRequestClose={() => setIsModalOpen(false)}
        className={`p-6 rounded-md max-w-xl mx-auto mt-20 shadow-xl ${
          darkMode ? "bg-gray-800 text-white" : "bg-white text-gray-900"
        }`}
        overlayClassName="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-start z-50"
      >
        <h3 className="text-xl font-semibold mb-4">Edit Job Posting</h3>
        <form onSubmit={handleUpdate} className="space-y-4">
          <input
            name="title"
            value={selectedJob?.title || ""}
            onChange={handleInputChange}
            placeholder="Job Title"
            required
            className="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <input
            name="location"
            value={selectedJob?.location || ""}
            onChange={handleInputChange}
            placeholder="Location"
            className="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <input
            name="salary_range"
            value={selectedJob?.salary_range || ""}
            onChange={handleInputChange}
            placeholder="Salary Range"
            className="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <input
            name="job_type"
            value={selectedJob?.job_type || ""}
            onChange={handleInputChange}
            placeholder="Job Type"
            className="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
            >
              Save
            </button>
          </div>
        </form>
      </ReactModal>
    </div>
  );
};

export default JobTable;
