import React, { useState } from "react";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify"; // Importing Toastify
import "react-toastify/dist/ReactToastify.css"; // Import the default toast styles
import { CheckCircle } from "lucide-react";

function SalesForm() {
  const [isOverlayVisible, setIsOverlayVisible] = useState(false); // Overlay visibility state
  const [formData, setFormData] = useState({
    assigned_consultant: "",
    technology: "",
    rate_on_c2c: "",
    vendor_company: "",
    vendor_mail: "",
    vendor_phone_number: "",
    end_client_details: "",
    status: "",
  });

  const [errors, setErrors] = useState({
    assigned_consultant: "",
    technology: "",
    rate_on_c2c: "",
    vendor_company: "",
    vendor_mail: "",
    vendor_phone_number: "",
    end_client_details: "",
    status: "",
  });

  // Handle input changes and update state
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  // Validation function
  const validateForm = () => {
    const newErrors = {};

    // Check if each field is filled
    if (!formData.assigned_consultant)
      newErrors.assigned_consultant = "Assigned Consultant is required.";
    if (!formData.technology) newErrors.technology = "Technology is required.";
    if (!formData.rate_on_c2c)
      newErrors.rate_on_c2c = "Rate on C2C is required.";
    if (!formData.vendor_company)
      newErrors.vendor_company = "Vendor Company is required.";
    if (!formData.vendor_mail)
      newErrors.vendor_mail = "Vendor Email is required.";
    if (!formData.vendor_phone_number)
      newErrors.vendor_phone_number = "Vendor Phone Number is required.";
    if (!formData.end_client_details)
      newErrors.end_client_details = "End Client Details are required.";
    if (!formData.status) newErrors.status = "Status is required.";

    // Validate email format
    if (formData.vendor_mail && !/\S+@\S+\.\S+/.test(formData.vendor_mail)) {
      newErrors.vendor_mail = "Invalid email address.";
    }

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) {
      toast.error("Please enter valid details for all required fields.");
    }

    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      // Get IDs from localStorage
      const companyId = localStorage.getItem("companyId");
      const userId = localStorage.getItem("employerUserId");

      if (!companyId || !userId) {
        throw new Error("Missing authentication data. Please login again.");
      }

      // Prepare data with companyId and userId
      const payload = {
        ...formData,
        companyId,
        userId,
      };

      const response = await axios.post(
        "http://localhost:5000/api/sales",
        payload,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response.status === 201) {
        setIsOverlayVisible(true);
        toast.success("Sales record created successfully!");

        // Reset the form
        setFormData({
          assigned_consultant: "",
          technology: "",
          rate_on_c2c: "",
          vendor_company: "",
          vendor_mail: "",
          vendor_phone_number: "",
          end_client_details: "",
          status: "",
        });
      }
    } catch (error) {
      console.error("Error submitting data:", error);
      const errorMsg =
        error.response?.data?.error ||
        error.response?.data?.details ||
        "There was an error submitting the form.";
      toast.error(errorMsg, { position: toast.POSITION.TOP_RIGHT });
    }
  };
  return (
    <div>
      <body className="bg-gray-100">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-3xl font-bold mb-6 text-center text-gray-800">
            Bench Sales Form
          </h1>
          <form
            id="bpoForm"
            className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4"
            onSubmit={handleSubmit}
          >
            {/* Assigned Consultant */}
            <div className="mb-4">
              <label
                className="block text-gray-700 text-sm font-bold mb-2"
                htmlFor="assignedConsultant"
              >
                Assigned Consultant
              </label>
              <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="assignedConsultant"
                name="assigned_consultant"
                type="text"
                placeholder="Enter assigned consultant's name"
                value={formData.assigned_consultant}
                onChange={handleInputChange}
                required
                aria-required="true"
              />
              {errors.assigned_consultant && (
                <p className="text-red-500 text-xs italic">
                  {errors.assigned_consultant}
                </p>
              )}
            </div>

            {/* Technology */}
            <div className="mb-4">
              <label
                className="block text-gray-700 text-sm font-bold mb-2"
                htmlFor="technology"
              >
                Technology
              </label>
              <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="technology"
                name="technology"
                type="text"
                placeholder="Enter technology used"
                value={formData.technology}
                onChange={handleInputChange}
                required
                aria-required="true"
              />
              {errors.technology && (
                <p className="text-red-500 text-xs italic">
                  {errors.technology}
                </p>
              )}
            </div>

            {/* Rate on C2C */}
            <div className="mb-4">
              <label
                className="block text-gray-700 text-sm font-bold mb-2"
                htmlFor="rateOnC2C"
              >
                Rate on C2C
              </label>
              <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="rateOnC2C"
                name="rate_on_c2c"
                type="text"
                placeholder="Enter rate on C2C"
                value={formData.rate_on_c2c}
                onChange={handleInputChange}
                required
                aria-required="true"
              />
              {errors.rate_on_c2c && (
                <p className="text-red-500 text-xs italic">
                  {errors.rate_on_c2c}
                </p>
              )}
            </div>

            {/* Vendor Company */}
            <div className="mb-4">
              <label
                className="block text-gray-700 text-sm font-bold mb-2"
                htmlFor="vendorCompany"
              >
                Vendor Company
              </label>
              <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="vendorCompany"
                name="vendor_company"
                type="text"
                placeholder="Enter vendor company name"
                value={formData.vendor_company}
                onChange={handleInputChange}
                required
                aria-required="true"
              />
              {errors.vendor_company && (
                <p className="text-red-500 text-xs italic">
                  {errors.vendor_company}
                </p>
              )}
            </div>

            {/* Vendor Email */}
            <div className="mb-4">
              <label
                className="block text-gray-700 text-sm font-bold mb-2"
                htmlFor="vendorMail"
              >
                Vendor Email
              </label>
              <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="vendorMail"
                name="vendor_mail"
                type="email"
                placeholder="Enter vendor email"
                value={formData.vendor_mail}
                onChange={handleInputChange}
                required
                aria-required="true"
              />
              {errors.vendor_mail && (
                <p className="text-red-500 text-xs italic">
                  {errors.vendor_mail}
                </p>
              )}
            </div>

            {/* Vendor Phone Number */}
            <div className="mb-4">
              <label
                className="block text-gray-700 text-sm font-bold mb-2"
                htmlFor="vendorPhoneNumber"
              >
                Vendor Phone Number
              </label>
              <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="vendorPhoneNumber"
                name="vendor_phone_number"
                type="text"
                placeholder="Enter vendor phone number"
                value={formData.vendor_phone_number}
                onChange={handleInputChange}
                required
                aria-required="true"
              />
              {errors.vendor_phone_number && (
                <p className="text-red-500 text-xs italic">
                  {errors.vendor_phone_number}
                </p>
              )}
            </div>

            {/* End Client Details */}
            <div className="mb-4">
              <label
                className="block text-gray-700 text-sm font-bold mb-2"
                htmlFor="endClientDetails"
              >
                End Client Details
              </label>
              <textarea
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="endClientDetails"
                name="end_client_details"
                rows="4"
                placeholder="Enter end client details"
                value={formData.end_client_details}
                onChange={handleInputChange}
                required
                aria-required="true"
              ></textarea>
              {errors.end_client_details && (
                <p className="text-red-500 text-xs italic">
                  {errors.end_client_details}
                </p>
              )}
            </div>

            {/* Status */}
            <div className="mb-4">
              <label
                className="block text-gray-700 text-sm font-bold mb-2"
                htmlFor="status"
              >
                Status
              </label>
              <select
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="status"
                name="status"
                value={formData.status}
                onChange={handleInputChange}
                required
                aria-required="true"
              >
                <option value="">Select status</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="pending">Pending</option>
              </select>
              {errors.status && (
                <p className="text-red-500 text-xs italic">{errors.status}</p>
              )}
            </div>

            {/* Submit Button */}
            <div className="flex items-center justify-between">
              <button
                className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg font-medium shadow-sm transition-all text-sm sm:text-base"
                type="submit"
              >
                Submit
              </button>
            </div>
          </form>

          {/* Toast container to display the notifications */}
          <ToastContainer />
        </div>
        {isOverlayVisible && (
          <div className="absolute top-0 left-0 right-0 bottom-0 flex items-center justify-center bg-black bg-opacity-50">
            <div className="p-5 bg-white rounded-lg shadow-lg flex items-center flex-col">
              <CheckCircle className="text-green-500 w-16 h-16" />
              <h2 className="text-2xl font-bold mt-4 mb-2">Success!</h2>
              <p>Sales added Successfully</p>
              <button
                onClick={() => setIsOverlayVisible(false)}
                className="mt-4 px-5 py-2 border border-transparent text-base font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </body>
    </div>
  );
}

export default SalesForm;
