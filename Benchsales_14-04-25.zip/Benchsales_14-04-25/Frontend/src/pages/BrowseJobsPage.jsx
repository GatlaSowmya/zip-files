import React, { useState } from "react";
import {
  FiSearch,
  FiFilter,
  FiMapPin,
  FiDollarSign,
  FiClock,
  FiChevronDown,
  FiBriefcase,
  FiShield,
  FiSmartphone,
  FiCloud,
  FiFileText,
  FiCpu,
  FiDatabase,
  FiCheckCircle,
  FiLink,
  FiUsers,
  FiPlay,
  FiBarChart2,
  FiHeadphones,
  FiCode,
  FiTrendingUp,
  FiSettings,
  FiLayout,
  FiUserPlus,
  FiEdit,
  FiServer,
  FiGlasses,
} from "react-icons/fi";

import {
  FaReact,
  FaFigma,
  FaPython,
  FaNodeJs,
  FaAws,
  FaJava,
  FaRegHeart,
  FaHeart,
  FaGlasses,
} from "react-icons/fa";
import { motion, AnimatePresence } from "framer-motion";
import Header from "../components/layout/Header";
import Footer from "../components/layout/Footer";

const BrowseJobsPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [savedJobs, setSavedJobs] = useState([]);
  const [filters, setFilters] = useState({
    location: "",
    salaryRange: "",
    jobType: "",
    experienceLevel: "",
  });

  const jobs = [
    {
      id: 1,
      title: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      location: "San Francisco, CA (Remote)",
      salary: "$120,000 - $150,000",
      type: "Full-time",
      experience: "5+ years",
      logo: <FaReact className="text-blue-500 text-4xl" />,
      skills: ["React", "TypeScript", "Redux", "GraphQL"],
      posted: "2 days ago",
      featured: true,
    },
    {
      id: 2,
      title: "UX/UI Designer",
      company: "DesignHub",
      location: "Remote (Global)",
      salary: "$90,000 - $110,000",
      type: "Full-time",
      experience: "3+ years",
      logo: <FaFigma className="text-purple-500 text-4xl" />,
      skills: ["Figma", "User Research", "Prototyping"],
      posted: "1 week ago",
    },
    {
      id: 3,
      title: "Backend Engineer (Node.js)",
      company: "DataSystems",
      location: "New York, NY",
      salary: "$130,000 - $160,000",
      type: "Full-time",
      experience: "4+ years",
      logo: <FaNodeJs className="text-green-500 text-4xl" />,
      skills: ["Node.js", "Express", "MongoDB"],
      posted: "3 days ago",
      featured: true,
    },
    {
      id: 4,
      title: "Data Scientist",
      company: "AnalyticsPro",
      location: "Boston, MA (Hybrid)",
      salary: "$140,000 - $170,000",
      type: "Full-time",
      experience: "5+ years",
      logo: <FaPython className="text-yellow-500 text-4xl" />,
      skills: ["Python", "Machine Learning", "SQL"],
      posted: "5 days ago",
    },
    {
      id: 5,
      title: "DevOps Engineer",
      company: "CloudScale",
      location: "Austin, TX (Remote)",
      salary: "$135,000 - $165,000",
      type: "Full-time",
      experience: "4+ years",
      logo: <FaAws className="text-orange-500 text-4xl" />,
      skills: ["AWS", "Docker", "Kubernetes"],
      posted: "1 day ago",
    },
    {
      id: 6,
      title: "Java Developer",
      company: "EnterpriseSoft",
      location: "Chicago, IL",
      salary: "$110,000 - $140,000",
      type: "Full-time",
      experience: "3+ years",
      logo: <FaJava className="text-red-500 text-4xl" />,
      skills: ["Java", "Spring Boot", "Microservices"],
      posted: "4 days ago",
      featured: true,
    },
    {
      id: 7,
      title: "Product Manager",
      company: "InnovateCo",
      location: "Seattle, WA (Hybrid)",
      salary: "$140,000 - $180,000",
      type: "Full-time",
      experience: "6+ years",
      logo: <FiBriefcase className="text-indigo-500 text-4xl" />,
      skills: ["Product Strategy", "Agile", "Market Research"],
      posted: "2 days ago",
    },
    {
      id: 8,
      title: "Cybersecurity Analyst",
      company: "SecureNet",
      location: "Remote",
      salary: "$115,000 - $145,000",
      type: "Full-time",
      experience: "4+ years",
      logo: <FiShield className="text-cyan-500 text-4xl" />,
      skills: ["SIEM", "Threat Analysis", "Compliance"],
      posted: "1 week ago",
      featured: true,
    },
    {
      id: 9,
      title: "Mobile Developer (Flutter)",
      company: "AppWorks",
      location: "Miami, FL",
      salary: "$105,000 - $135,000",
      type: "Full-time",
      experience: "3+ years",
      logo: <FiSmartphone className="text-blue-400 text-4xl" />,
      skills: ["Flutter", "Dart", "Firebase"],
      posted: "3 days ago",
    },
    {
      id: 10,
      title: "Cloud Architect",
      company: "SkyNet Solutions",
      location: "Remote (US)",
      salary: "$160,000 - $200,000",
      type: "Full-time",
      experience: "7+ years",
      logo: <FiCloud className="text-sky-500 text-4xl" />,
      skills: ["AWS", "Azure", "Terraform"],
      posted: "5 days ago",
      featured: true,
    },
    {
      id: 11,
      title: "Technical Writer",
      company: "DocuTech",
      location: "Portland, OR (Remote)",
      salary: "$85,000 - $110,000",
      type: "Full-time",
      experience: "3+ years",
      logo: <FiFileText className="text-gray-500 text-4xl" />,
      skills: ["Documentation", "Markdown", "API Guides"],
      posted: "2 days ago",
    },
    {
      id: 12,
      title: "AI Research Scientist",
      company: "DeepMind Analytics",
      location: "Cambridge, MA",
      salary: "$180,000 - $220,000",
      type: "Full-time",
      experience: "PhD + 3 years",
      logo: <FiCpu className="text-purple-600 text-4xl" />,
      skills: ["TensorFlow", "PyTorch", "NLP"],
      posted: "1 week ago",
      featured: true,
    },
    {
      id: 13,
      title: "Salesforce Developer",
      company: "CRM Experts",
      location: "Dallas, TX",
      salary: "$120,000 - $150,000",
      type: "Contract",
      experience: "4+ years",
      logo: <FiDatabase className="text-blue-300 text-4xl" />,
      skills: ["Apex", "Lightning", "Sales Cloud"],
      posted: "4 days ago",
    },
    {
      id: 14,
      title: "QA Automation Engineer",
      company: "QualityFirst",
      location: "Remote",
      salary: "$95,000 - $125,000",
      type: "Full-time",
      experience: "3+ years",
      logo: <FiCheckCircle className="text-green-400 text-4xl" />,
      skills: ["Selenium", "Cypress", "Jest"],
      posted: "1 day ago",
    },
    {
      id: 15,
      title: "Blockchain Developer",
      company: "ChainInnovate",
      location: "Remote (Global)",
      salary: "$150,000 - $190,000",
      type: "Full-time",
      experience: "4+ years",
      logo: <FiLink className="text-indigo-600 text-4xl" />,
      skills: ["Solidity", "Ethereum", "Smart Contracts"],
      posted: "3 days ago",
      featured: true,
    },
    {
      id: 16,
      title: "HR Technology Specialist",
      company: "PeopleFirst",
      location: "Chicago, IL (Hybrid)",
      salary: "$90,000 - $120,000",
      type: "Full-time",
      experience: "3+ years",
      logo: <FiUsers className="text-pink-500 text-4xl" />,
      skills: ["Workday", "HRIS", "People Analytics"],
      posted: "1 week ago",
    },
    {
      id: 17,
      title: "Game Developer (Unity)",
      company: "NextGen Games",
      location: "Los Angeles, CA",
      salary: "$110,000 - $140,000",
      type: "Full-time",
      experience: "4+ years",
      logo: <FiPlay className="text-red-400 text-4xl" />,
      skills: ["Unity", "C#", "3D Modeling"],
      posted: "5 days ago",
    },
    {
      id: 18,
      title: "Data Engineer",
      company: "BigData Solutions",
      location: "Remote (US)",
      salary: "$130,000 - $160,000",
      type: "Full-time",
      experience: "5+ years",
      logo: <FiBarChart2 className="text-teal-500 text-4xl" />,
      skills: ["Spark", "Hadoop", "Data Pipelines"],
      posted: "2 days ago",
      featured: true,
    },
    {
      id: 19,
      title: "Technical Support Engineer",
      company: "SupportHero",
      location: "Remote",
      salary: "$75,000 - $95,000",
      type: "Full-time",
      experience: "2+ years",
      logo: <FiHeadphones className="text-blue-200 text-4xl" />,
      skills: ["Troubleshooting", "SaaS", "Customer Service"],
      posted: "1 day ago",
    },
    {
      id: 20,
      title: "Full Stack Developer",
      company: "WebCrafters",
      location: "Denver, CO",
      salary: "$115,000 - $145,000",
      type: "Full-time",
      experience: "4+ years",
      logo: <FiCode className="text-gray-700 text-4xl" />,
      skills: ["JavaScript", "Node.js", "React", "PostgreSQL"],
      posted: "1 week ago",
    },
    {
      id: 21,
      title: "Digital Marketing Specialist",
      company: "GrowthHackers",
      location: "Remote",
      salary: "$80,000 - $110,000",
      type: "Full-time",
      experience: "3+ years",
      logo: <FiTrendingUp className="text-green-500 text-4xl" />,
      skills: ["SEO", "Google Ads", "Content Marketing"],
      posted: "3 days ago",
      featured: true,
    },
    {
      id: 22,
      title: "iOS Developer",
      company: "MobileMasters",
      location: "Remote (US)",
      salary: "$125,000 - $155,000",
      type: "Full-time",
      experience: "5+ years",
      logo: <FiSmartphone className="text-blue-500 text-4xl" />,
      skills: ["Swift", "UIKit", "Core Data"],
      posted: "5 days ago",
    },
    {
      id: 23,
      title: "ERP Consultant",
      company: "BusinessSolutions",
      location: "Atlanta, GA",
      salary: "$100,000 - $130,000",
      type: "Full-time",
      experience: "4+ years",
      logo: <FiSettings className="text-purple-400 text-4xl" />,
      skills: ["SAP", "Oracle", "Business Process"],
      posted: "2 days ago",
    },
    {
      id: 24,
      title: "UI Developer",
      company: "PixelPerfect",
      location: "Remote",
      salary: "$105,000 - $135,000",
      type: "Full-time",
      experience: "4+ years",
      logo: <FiLayout className="text-amber-500 text-4xl" />,
      skills: ["HTML/CSS", "JavaScript", "Accessibility"],
      posted: "1 week ago",
    },
    {
      id: 25,
      title: "Machine Learning Engineer",
      company: "AILabs",
      location: "San Francisco, CA",
      salary: "$150,000 - $190,000",
      type: "Full-time",
      experience: "5+ years",
      logo: <FiCpu className="text-indigo-500 text-4xl" />,
      skills: ["Python", "TensorFlow", "Computer Vision"],
      posted: "3 days ago",
      featured: true,
    },
    {
      id: 26,
      title: "Technical Recruiter",
      company: "TalentFinders",
      location: "Remote (US)",
      salary: "$85,000 - $115,000",
      type: "Full-time",
      experience: "3+ years",
      logo: <FiUserPlus className="text-pink-400 text-4xl" />,
      skills: ["Sourcing", "Interviewing", "ATS"],
      posted: "1 day ago",
    },
    {
      id: 27,
      title: "Cloud Security Engineer",
      company: "SecureCloud",
      location: "Remote",
      salary: "$140,000 - $175,000",
      type: "Full-time",
      experience: "5+ years",
      logo: <FiShield className="text-green-600 text-4xl" />,
      skills: ["AWS Security", "IAM", "Compliance"],
      posted: "5 days ago",
    },
    {
      id: 28,
      title: "Content Designer",
      company: "WordCraft",
      location: "Remote (Global)",
      salary: "$90,000 - $120,000",
      type: "Full-time",
      experience: "4+ years",
      logo: <FiEdit className="text-blue-300 text-4xl" />,
      skills: ["UX Writing", "Content Strategy", "Localization"],
      posted: "2 days ago",
      featured: true,
    },
    {
      id: 29,
      title: "Site Reliability Engineer",
      company: "AlwaysUp",
      location: "Remote (US)",
      salary: "$145,000 - $180,000",
      type: "Full-time",
      experience: "5+ years",
      logo: <FiServer className="text-orange-500 text-4xl" />,
      skills: ["Kubernetes", "Prometheus", "Incident Management"],
      posted: "1 week ago",
    },
    {
      id: 30,
      title: "AR/VR Developer",
      company: "FutureReality",
      location: "Seattle, WA",
      salary: "$130,000 - $160,000",
      type: "Full-time",
      experience: "4+ years",
      logo: <FaGlasses className="text-purple-500 text-4xl" />,
      skills: ["Unity", "ARKit", "3D Modeling"],
      posted: "3 days ago",
    },
  ];
  const toggleSaveJob = (jobId) => {
    if (savedJobs.includes(jobId)) {
      setSavedJobs(savedJobs.filter((id) => id !== jobId));
    } else {
      setSavedJobs([...savedJobs, jobId]);
    }
  };

  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };

  const clearFilters = () => {
    setFilters({
      location: "",
      salaryRange: "",
      jobType: "",
      experienceLevel: "",
    });
  };

  const filteredJobs = jobs.filter((job) => {
    const matchesSearch =
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.skills.some((skill) =>
        skill.toLowerCase().includes(searchQuery.toLowerCase())
      );

    const matchesLocation =
      !filters.location ||
      job.location.toLowerCase().includes(filters.location.toLowerCase());

    const matchesSalary =
      !filters.salaryRange ||
      (filters.salaryRange === "100k+" &&
        parseInt(job.salary.replace(/[^0-9]/g, "")) >= 100000);

    const matchesJobType =
      !filters.jobType ||
      job.type.toLowerCase() === filters.jobType.toLowerCase();

    const matchesExperience =
      !filters.experienceLevel ||
      job.experience
        .toLowerCase()
        .includes(filters.experienceLevel.toLowerCase());

    return (
      matchesSearch &&
      matchesLocation &&
      matchesSalary &&
      matchesJobType &&
      matchesExperience
    );
  });

  return (
    <div className="min-h-screen bg-gray-50 font-sans antialiased">
      <Header />
      {/* Search and Filters */}
      <section className="bg-white py-2 sticky top-0 z-10 shadow-sm pt-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Browse Job Opportunities
          </h1>

          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="relative flex-grow">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <FiSearch className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Job title, keywords, or company"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={toggleFilters}
              className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <FiFilter className="mr-2" />
              Filters
              <FiChevronDown
                className={`ml-2 transition-transform ${
                  showFilters ? "rotate-180" : ""
                }`}
              />
            </motion.button>
          </div>

          <AnimatePresence>
            {showFilters && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
                className="bg-white rounded-lg border border-gray-200 p-4 mb-4"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Location
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      placeholder="City, state, or remote"
                      value={filters.location}
                      onChange={(e) =>
                        setFilters({ ...filters, location: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Salary Range
                    </label>
                    <select
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      value={filters.salaryRange}
                      onChange={(e) =>
                        setFilters({ ...filters, salaryRange: e.target.value })
                      }
                    >
                      <option value="">Any</option>
                      <option value="100k+">$100,000+</option>
                      <option value="150k+">$150,000+</option>
                      <option value="200k+">$200,000+</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Job Type
                    </label>
                    <select
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      value={filters.jobType}
                      onChange={(e) =>
                        setFilters({ ...filters, jobType: e.target.value })
                      }
                    >
                      <option value="">Any</option>
                      <option value="Full-time">Full-time</option>
                      <option value="Part-time">Part-time</option>
                      <option value="Contract">Contract</option>
                      <option value="Internship">Internship</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Experience Level
                    </label>
                    <select
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      value={filters.experienceLevel}
                      onChange={(e) =>
                        setFilters({
                          ...filters,
                          experienceLevel: e.target.value,
                        })
                      }
                    >
                      <option value="">Any</option>
                      <option value="Entry">Entry Level</option>
                      <option value="Mid">Mid Level</option>
                      <option value="Senior">Senior</option>
                    </select>
                  </div>
                </div>
                <div className="flex justify-end mt-4">
                  <button
                    onClick={clearFilters}
                    className="text-sm text-blue-600 hover:text-blue-800 mr-4"
                  >
                    Clear All
                  </button>
                  <button
                    onClick={toggleFilters}
                    className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg font-medium shadow-sm transition-all text-sm sm:text-base"
                  >
                    Apply Filters
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      {/* Job Listings */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-3 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">
            {filteredJobs.length} {filteredJobs.length === 1 ? "Job" : "Jobs"}{" "}
            Available
          </h2>
          <div className="text-sm text-gray-500">
            Sorted by: <span className="font-medium">Most Recent</span>
          </div>
        </div>

        {filteredJobs.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredJobs.map((job) => (
              <motion.div
                key={job.id}
                whileHover={{ y: -5 }}
                className={`bg-white rounded-2xl p-4 shadow-md hover:shadow-lg transition-shadow 
                }`}
              >
                <div className="flex flex-col h-full ">
                  <div className="flex items-center mb-4">
                    <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-gray-100 border border-gray-200">
                      {job.logo}
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-bold text-gray-900">
                        {job.title}
                      </h3>
                      <p className="text-gray-600">{job.company}</p>
                    </div>
                  </div>

                  <div className="mt-2 flex flex-wrap gap-2 mb-4">
                    {job.skills.map((skill) => (
                      <span
                        key={skill}
                        className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded-full"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>

                  <div className="mt-auto space-y-3">
                    <div className="flex items-center text-gray-500 text-sm">
                      <FiMapPin className="mr-2 text-gray-400" />
                      <span>{job.location}</span>
                    </div>
                    <div className="flex items-center text-gray-500 text-sm">
                      <FiDollarSign className="mr-2 text-gray-400" />
                      <span>{job.salary}</span>
                    </div>
                    <div className="flex items-center text-gray-500 text-sm">
                      <FiClock className="mr-2 text-gray-400" />
                      <span>
                        {job.type} • {job.posted}
                      </span>
                    </div>
                  </div>

                  <div className="mt-6 flex justify-between items-center">
                    <button
                      onClick={() => toggleSaveJob(job.id)}
                      className="text-gray-400 hover:text-red-500 transition-colors"
                      aria-label={
                        savedJobs.includes(job.id) ? "Unsave job" : "Save job"
                      }
                    >
                      {savedJobs.includes(job.id) ? (
                        <FaHeart className="h-5 w-5 text-red-500" />
                      ) : (
                        <FaRegHeart className="h-5 w-5" />
                      )}
                    </button>
                    <button className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg font-medium shadow-sm transition-all text-sm sm:text-base">
                      {" "}
                      View Details
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-xl p-8 text-center">
            <h3 className="text-xl font-medium text-gray-700 mb-2">
              No jobs found
            </h3>
            <p className="text-gray-500">
              Try adjusting your search or filters
            </p>
            <button
              onClick={clearFilters}
              className="mt-4 px-4 py-2 text-blue-600 hover:text-blue-800"
            >
              Clear all filters
            </button>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
};

export default BrowseJobsPage;
