import React, { useState, useEffect } from "react";
import axios from "axios";
import { Edit2, Trash2 } from "lucide-react";

const SaleTable = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [data, setData] = useState([]);
  const [error, setError] = useState(null);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });
  const [selectedItem, setSelectedItem] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);

  // Fetch data from API on component mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        const companyId = localStorage.getItem("companyId");
        const userId = localStorage.getItem("employerUserId");

        if (!companyId) {
          throw new Error("Missing company ID.");
        }

        const response = await axios.get("http://localhost:5000/api/sales", {
          params: { companyId, userId }, // optional userId
        });

        console.log(response.data);
        setData(response.data);
      } catch (err) {
        console.error("Error fetching sales data:", err);
        setError("Error fetching data");
      }
    };

    fetchData();
  }, []);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleSort = (key) => {
    let direction = "asc";
    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }
    setSortConfig({ key, direction });
  };

  const getSortedData = () => {
    let sortedData = [...data];
    if (sortConfig.key) {
      sortedData.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? 1 : -1;
        }
        return 0;
      });
    }
    return sortedData;
  };

  const filteredData = getSortedData().filter((item) => {
    return (
      item.id?.toString().includes(searchQuery) ||
      item.assigned_consultant
        ?.toLowerCase()
        .includes(searchQuery.toLowerCase()) ||
      item.technology?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.rate_on_c2c?.toString().includes(searchQuery) ||
      item.vendor_company?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.vendor_mail?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.vendor_phone_number
        ?.toLowerCase()
        .includes(searchQuery.toLowerCase()) ||
      item.end_client_details
        ?.toLowerCase()
        .includes(searchQuery.toLowerCase()) ||
      item.status?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  // ✅ Save (Update) Sales Record
  const handleSave = async () => {
    try {
      const companyId = localStorage.getItem("companyId");
      const userId = localStorage.getItem("employerUserId");

      if (!companyId || !userId) {
        throw new Error("Missing authentication data. Please login again.");
      }

      const payload = {
        ...selectedItem,
        companyId, // Required by backend
      };

      const response = await axios.put(
        `http://localhost:5000/api/sales/${selectedItem.id}`,
        payload
      );

      // Update local state with updated record
      setData(
        data.map((item) => (item.id === selectedItem.id ? response.data : item))
      );

      setModalOpen(false);
    } catch (error) {
      console.error("Error saving item:", error);
      setError("Error saving item.");
    }
  };

  // ✅ Delete Sales Record
  const handleDelete = async (id) => {
    try {
      const companyId = localStorage.getItem("companyId");
      const userId = localStorage.getItem("employerUserId");

      if (!companyId || !userId) {
        throw new Error("Missing authentication data. Please login again.");
      }

      await axios.delete(`http://localhost:5000/api/sales/${id}`, {
        params: { companyId }, // companyId sent as query param
      });

      // Remove deleted record from state
      setData(data.filter((item) => item.id !== id));
    } catch (error) {
      console.error("Error deleting item:", error);
      setError("Error deleting item.");
    }
  };

  const handleEdit = (item) => {
    setSelectedItem(item); // Store the selected item to edit
    setModalOpen(true); // Open the modal
  };

  const handleModalClose = () => {
    setModalOpen(false);
    setSelectedItem(null); // Reset the selected item when the modal is closed
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSelectedItem((prev) => ({ ...prev, [name]: value }));
  };

  const renderSortArrow = (key) => {
    if (sortConfig.key !== key) return null;
    return sortConfig.direction === "asc" ? (
      <span className="ml-2 text-xs">↑</span>
    ) : (
      <span className="ml-2 text-xs">↓</span>
    );
  };

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="max-w-5xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden p-4 sm:p-6">
      <h1 className="text-3xl font-bold mb-6 text-center text-gray-800">
        Sales List
      </h1>

      <div className="p-4 border-b">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-4 gap-4 sm:gap-6">
          <div className="flex gap-4">
            <select
              className="border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label="Rows per page"
            >
              <option value="5">5 per page</option>
              <option value="10">10 per page</option>
              <option value="25">25 per page</option>
            </select>
            <div className="relative">
              <button
                className="border rounded-lg px-4 py-2 inline-flex items-center gap-2 hover:bg-gray-50"
                aria-expanded="false"
              >
                <i className="fas fa-filter"></i> Filter
              </button>
            </div>
          </div>

          {/* Search box */}
          <div className="relative w-full sm:w-auto">
            <input
              type="text"
              placeholder="Search..."
              className="pl-8 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-auto"
              id="searchInput"
              value={searchQuery}
              onChange={handleSearchChange}
            />
            <i className="fas fa-search absolute left-3 top-3 text-gray-400"></i>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table
          className="w-full table-auto"
          role="grid"
          aria-label="Data table"
        >
          <thead>
            <tr className="bg-gray-50 text-left">
              {/* Table Headers */}
              <th
                className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm "
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("id")}
              >
                ID
                {renderSortArrow("id")}
              </th>
              <th
                className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm "
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("assigned_consultant")}
              >
                Assigned Consultant
                {renderSortArrow("assigned_consultant")}
              </th>
              <th
                className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm "
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("technology")}
              >
                Technology
                {renderSortArrow("technology")}
              </th>
              <th
                className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm "
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("rate_on_c2c")}
              >
                Rate on C2C
                {renderSortArrow("rate_on_c2c")}
              </th>
              <th
                className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm "
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("vendor_company")}
              >
                Vendor Company
                {renderSortArrow("vendor_company")}
              </th>
              <th
                className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm "
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("vendor_mail")}
              >
                Vendor Mail
                {renderSortArrow("vendor_mail")}
              </th>
              <th
                className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm "
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("vendor_phone_number")}
              >
                Vendor Phone
                {renderSortArrow("vendor_phone_number")}
              </th>
              <th
                className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm "
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("end_client_details")}
              >
                End Client Details
                {renderSortArrow("end_client_details")}
              </th>
              <th
                className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm "
                style={{ textWrap: "nowrap" }}
                onClick={() => handleSort("status")}
              >
                Status
                {renderSortArrow("status")}
              </th>
              <th
                className="px-6 py-4  font-medium text-gray-600 tracking-wider cursor-pointer select-none text-sm "
                style={{ textWrap: "nowrap" }}
              >
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredData.map((item, index) => (
              <tr
                key={index}
                className="hover:bg-gray-50 transition-colors cursor-pointer"
              >
                <td
                  className="px-6 py-4 text-sm "
                  style={{ textWrap: "nowrap" }}
                >
                  {item.id}
                </td>
                <td
                  className="px-6 py-4 text-sm "
                  style={{ textWrap: "nowrap" }}
                >
                  {item.assigned_consultant}
                </td>
                <td
                  className="px-6 py-4 text-sm "
                  style={{ textWrap: "nowrap" }}
                >
                  {item.technology}
                </td>
                <td
                  className="px-6 py-4 text-sm "
                  style={{ textWrap: "nowrap" }}
                >
                  {item.rate_on_c2c}
                </td>
                <td
                  className="px-6 py-4 text-sm "
                  style={{ textWrap: "nowrap" }}
                >
                  {item.vendor_company}
                </td>
                <td
                  className="px-6 py-4 text-sm "
                  style={{ textWrap: "nowrap" }}
                >
                  {item.vendor_mail}
                </td>
                <td
                  className="px-6 py-4 text-sm "
                  style={{ textWrap: "nowrap" }}
                >
                  {item.vendor_phone_number}
                </td>
                <td
                  className="px-6 py-4 text-sm "
                  style={{ textWrap: "nowrap" }}
                >
                  {item.end_client_details}
                </td>
                <td
                  className="px-6 py-4 text-sm "
                  style={{ textWrap: "nowrap" }}
                >
                  {item.status}
                </td>
                <td
                  className="px-6 py-4 text-sm "
                  style={{ textWrap: "nowrap" }}
                >
                  <div className="flex gap-4">
                    <button
                      onClick={() => handleEdit(item)}
                      className="flex justify-center items-center gap-1 bg-blue-600 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition duration-300"
                    >
                      <Edit2 className="h-4 w-4" />
                      <span>Edit</span>
                    </button>
                    <button
                      onClick={() => handleDelete(item.id)}
                      className="flex justify-center items-center gap-1 bg-red-500 hover:text-red-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition duration-300"
                    >
                      <Trash2 className="h-4 w-4" />
                      <span>Delete</span>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {modalOpen && selectedItem && (
        <div
          className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-[9999]"
          aria-labelledby="modal-title"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-1/2 shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center pb-3">
              <h3
                id="modal-title"
                className="text-lg font-semibold text-gray-900"
              >
                Edit Sale Item
              </h3>
              <button
                onClick={handleModalClose}
                className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center"
              >
                <svg
                  className="w-5 h-5"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fill-rule="evenodd"
                    d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                    clip-rule="evenodd"
                  ></path>
                </svg>
              </button>
            </div>

            <form className="mt-4">
              <div className="h-[50vh] overflow-y-scroll">
                <div className="mb-4">
                  <label
                    for="assigned_consultant"
                    className="block text-gray-700 text-sm font-bold mb-2"
                  >
                    Assigned Consultant
                  </label>
                  <input
                    type="text"
                    id="assigned_consultant"
                    name="assigned_consultant"
                    value={selectedItem.assigned_consultant}
                    onChange={handleChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label
                    for="technology"
                    className="block text-gray-700 text-sm font-bold mb-2"
                  >
                    Technology
                  </label>
                  <input
                    type="text"
                    id="technology"
                    name="technology"
                    value={selectedItem.technology}
                    onChange={handleChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label
                    for="rate_on_c2c"
                    className="block text-gray-700 text-sm font-bold mb-2"
                  >
                    Rate on C2C
                  </label>
                  <input
                    type="text"
                    id="rate_on_c2c"
                    name="rate_on_c2c"
                    value={selectedItem.rate_on_c2c}
                    onChange={handleChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label
                    for="vendor_company"
                    className="block text-gray-700 text-sm font-bold mb-2"
                  >
                    Vendor Company
                  </label>
                  <input
                    type="text"
                    id="vendor_company"
                    name="vendor_company"
                    value={selectedItem.vendor_company}
                    onChange={handleChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label
                    for="vendor_mail"
                    className="block text-gray-700 text-sm font-bold mb-2"
                  >
                    Vendor Mail
                  </label>
                  <input
                    type="email"
                    id="vendor_mail"
                    name="vendor_mail"
                    value={selectedItem.vendor_mail}
                    onChange={handleChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label
                    for="vendor_phone_number"
                    className="block text-gray-700 text-sm font-bold mb-2"
                  >
                    Vendor Phone Number
                  </label>
                  <input
                    type="text"
                    id="vendor_phone_number"
                    name="vendor_phone_number"
                    value={selectedItem.vendor_phone_number}
                    onChange={handleChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label
                    for="end_client_details"
                    className="block text-gray-700 text-sm font-bold mb-2"
                  >
                    End Client Details
                  </label>
                  <input
                    type="text"
                    id="end_client_details"
                    name="end_client_details"
                    value={selectedItem.end_client_details}
                    onChange={handleChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>

                <div className="mb-4">
                  <label
                    for="status"
                    className="block text-gray-700 text-sm font-bold mb-2"
                  >
                    Status
                  </label>
                  <input
                    type="text"
                    id="status"
                    name="status"
                    value={selectedItem.status}
                    onChange={handleChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-2 space-x-4">
                <button
                  type="button"
                  onClick={handleModalClose}
                  className="bg-gray-300 text-gray-800 active:bg-gray-400 font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSave}
                  className="bg-blue-500 text-white active:bg-blue-600 font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default SaleTable;
