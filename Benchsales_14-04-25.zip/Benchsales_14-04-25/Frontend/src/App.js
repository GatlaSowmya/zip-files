import "./App.css";
import { Routes, Route } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// Layout Components
import SideBar from "./components/layout/SideBar";

// Pages
import Dashboard from "./pages/Dashboard";
import ConsultanatForm from "./pages/ConsultanatForm";
import ConsultantList from "./pages/ConsultantList";
import SalesForm from "./pages/SalesForm";
import SalesTable from "./pages/SalesTable";
import JobPostingRetrieve from "./pages/JobPostingRetrieve";
import JobPostingForm from "./pages/JobPostingForm";
import ApplicationRetrieve from "./pages/ApplicationRetrieve";
import AdminRegister from "./pages/AdminRegister";
import AddUser from "./pages/AddUser";
import EmployerLogin from "./pages/EmployerLogin";
import JobTable from "./pages/JobsTable";
import Home from "./pages/Home";
import UserListing from "./pages/User Listing";
import AboutUsPage from "./pages/AboutUsPage";
import BrowseJobsPage from "./pages/BrowseJobsPage";
import AdminLogin from "./pages/AdminLogin";

// Wrapper for routes that need SideBar
const SideBarLayout = ({ children }) => <SideBar>{children}</SideBar>;

function App() {
  return (
    <div className="app">
      <ToastContainer />

      <Routes>
        {/* Public Routes (without SideBar) */}

        <Route path="/aboutus-page" element={<AboutUsPage />} />
        <Route path="/browsejobs-page" element={<BrowseJobsPage />} />
        <Route path="/admin-register" element={<AdminRegister />} />
        <Route path="/employer-login" element={<EmployerLogin />} />
        <Route path="/admin-login" element={<AdminLogin />} />

        {/* Protected Routes (with SideBar) */}
        <Route path="/" element={<Home />} />
        <Route
          path="/admin/dashboard"
          element={
            <SideBarLayout>
              <Dashboard />
            </SideBarLayout>
          }
        />
        <Route
          path="/add-user"
          element={
            <SideBarLayout>
              <AddUser />
            </SideBarLayout>
          }
        />
        <Route
          path="/user_Listing"
          element={
            <SideBarLayout>
              <UserListing />
            </SideBarLayout>
          }
        />

        {/* Consultant Routes */}
        <Route
          path="/consultant-form"
          element={
            <SideBarLayout>
              <ConsultanatForm />
            </SideBarLayout>
          }
        />
        <Route
          path="/Consultant-list"
          element={
            <SideBarLayout>
              <ConsultantList />
            </SideBarLayout>
          }
        />

        {/* Sales Routes */}
        <Route
          path="/sales-form"
          element={
            <SideBarLayout>
              <SalesForm />
            </SideBarLayout>
          }
        />
        <Route
          path="/sales-list"
          element={
            <SideBarLayout>
              <SalesTable />
            </SideBarLayout>
          }
        />

        {/* Job Routes */}
        <Route
          path="/job_listings"
          element={
            <SideBarLayout>
              <JobPostingRetrieve />
            </SideBarLayout>
          }
        />
        <Route
          path="/job_posting"
          element={
            <SideBarLayout>
              <JobPostingForm />
            </SideBarLayout>
          }
        />
        <Route
          path="/job-table"
          element={
            <SideBarLayout>
              <JobTable />
            </SideBarLayout>
          }
        />

        {/* Application Routes */}
        <Route
          path="/application"
          element={
            <SideBarLayout>
              <ApplicationRetrieve />
            </SideBarLayout>
          }
        />
      </Routes>
    </div>
  );
}

export default App;
