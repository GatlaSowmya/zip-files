import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { LayoutDashboard, Users, Store, LogOut } from "lucide-react";

const SuperAdminLayout = ({ children }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeView, setActiveView] = useState("dashboard");
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    console.log("SuperAdminLayout rendered, pathname:", location.pathname);
    const path = location.pathname;
    if (path === "/superadmin/dashboard") {
      setActiveView("dashboard");
    } else if (path === "/categories" || path.startsWith("/subcategories") || path.match(/^\/shops\/[^/]+$/)) {
      setActiveView("categories");
    } else if (path === "/superadmin/create-vendor") {
      setActiveView("create-vendor");
    } else if (path === "/vendors") {
      setActiveView("vendors");
    } else if (path === "/vendor/dashboard") {
      setActiveView("vendor-dashboard");
    } else if (path === "/shops") {
      setActiveView("manage-shops");
    }else if (path === "/shop-services") {
      setActiveView("manageShopServices");
    }
  }, [location.pathname]);

  const handleLogout = () => {
    console.log("Logging out");
    localStorage.removeItem("token");
    navigate("/");
  };

  const handleNavigation = (view, path) => {
    console.log("Navigating to:", view, path);
    setActiveView(view);
    navigate(path);
    setIsMobileMenuOpen(false);
  };

  const NavButton = ({ onClick, active, children, className = "" }) => (
    <button
      onClick={onClick}
      className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${className} ${
        active ? "bg-blue-100 text-blue-700 font-medium" : "text-gray-600 hover:bg-gray-100"
      }`}
    >
      {children}
    </button>
  );

  return (
    <div className="flex min-h-screen bg-gray-50">
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 bg-white rounded-md shadow-md text-gray-600 hover:text-gray-900"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>
      {isMobileMenuOpen && (
        <div
          className="lg:hidden fixed inset-0 z-40 bg-black bg-opacity-50"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
      <aside className="hidden lg:flex w-64 bg-white shadow-lg flex-col h-screen sticky top-0">
        <div className="flex-1 overflow-y-auto">
          <div className="p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-6">Super Admin</h2>
            <nav className="space-y-2">
              <NavButton
                onClick={() => handleNavigation("dashboard", "/superadmin/dashboard")}
                active={activeView === "dashboard"}
              >
                <LayoutDashboard size={20} className="inline mr-2" />
                Dashboard
              </NavButton>
              <NavButton
                onClick={() => handleNavigation("categories", "/categories")}
                active={activeView === "categories"}
                className="text-sm"
              >
                <Store size={16} className="inline mr-2" />
                Manage Categories
              </NavButton>
              <NavButton
                onClick={() => handleNavigation("vendors", "/vendors")}
                active={activeView === "vendors"}
                className="text-sm"
              >
                <Users size={16} className="inline mr-2" />
                Vendors
              </NavButton>
              <NavButton
                onClick={() => handleNavigation("create-vendor", "/superadmin/create-vendor")}
                active={activeView === "create-vendor"}
                className="text-sm"
              >
                <Users size={16} className="inline mr-2" />
                Create Vendor
              </NavButton>
              <NavButton
                onClick={() => handleNavigation("manage-shops", "/shops")}
                active={activeView === "manage-shops"}
                className="text-sm"
              >
                <Store size={16} className="inline mr-2" />
                Manage Shops
              </NavButton>
              <NavButton
                onClick={() => handleNavigation("manageShopServices", "/shop-services")}
                active={activeView === "manageShopServices"}
                className="text-sm"
              >
                <Store size={16} className="inline mr-2" />
                Manage Shop Services
              </NavButton>
            </nav>
          </div>
        </div>
        <div className="p-6 pt-0">
          <button
            onClick={handleLogout}
            className="w-full px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors text-sm font-medium"
          >
            <LogOut size={16} className="inline mr-2" />
            Logout
          </button>
        </div>
      </aside>
      <aside
        className={`lg:hidden fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out ${
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        } flex flex-col h-full`}
      >
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-lg font-bold text-gray-800">Super Admin</h2>
          <button
            onClick={() => setIsMobileMenuOpen(false)}
            className="p-1 text-gray-600 hover:text-gray-900"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="flex-1 overflow-y-auto">
          <div className="p-6">
            <nav className="space-y-2">
              <NavButton
                onClick={() => handleNavigation("dashboard", "/superadmin/dashboard")}
                active={activeView === "dashboard"}
              >
                <LayoutDashboard size={20} className="inline mr-2" />
                Dashboard
              </NavButton>
              <NavButton
                onClick={() => handleNavigation("categories", "/categories")}
                active={activeView === "categories"}
                className="text-sm"
              >
                <Store size={16} className="inline mr-2" />
                Manage Categories
              </NavButton>
              <NavButton
                onClick={() => handleNavigation("vendors", "/vendors")}
                active={activeView === "vendors"}
                className="text-sm"
              >
                <Users size={16} className="inline mr-2" />
                Vendors
              </NavButton>
              <NavButton
                onClick={() => handleNavigation("create-vendor", "/superadmin/create-vendor")}
                active={activeView === "create-vendor"}
                className="text-sm"
              >
                <Users size={16} className="inline mr-2" />
                Create Vendor
              </NavButton>
              <NavButton
                onClick={() => handleNavigation("manage-shops", "/shops")}
                active={activeView === "manage-shops"}
                className="text-sm"
              >
                <Store size={16} className="inline mr-2" />
                Manage Shops
              </NavButton>
               <NavButton
                onClick={() => handleNavigation("manageShopServices", "/shop-services")}
                active={activeView === "manageShopServices"}
                className="text-sm"
              >
                <Store size={16} className="inline mr-2" />
                Manage Shop Services
              </NavButton>
            </nav>
          </div>
        </div>
        <div className="p-6 pt-0">
          <button
            onClick={handleLogout}
            className="w-full px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors text-sm font-medium"
          >
            <LogOut size={16} className="inline mr-2" />
            Logout
          </button>
        </div>
      </aside>
      <main className="flex-1 lg:ml-0 ml-0 min-h-screen">
        <div className="p-4 lg:p-8 pt-16 lg:pt-8 max-w-7xl mx-auto">{children}</div>
      </main>
    </div>
  );
};

export default SuperAdminLayout;