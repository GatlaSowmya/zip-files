import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { User, Mail, Lock, Building, Image, CheckCircle, XCircle } from "lucide-react";
import uploadToS3 from "../services/uploadToS3";
import { BASE_URL } from "../config";

export default function VendorSignupForm({ onSuccess }) {
  const [formData, setFormData] = useState({
    business_name: "",
    username: "",
    email: "",
    password: "",
    business_type: "",
    category_id: "",
    status: "Pending",
  });
  const [profileImage, setProfileImage] = useState(null);
  const [categories, setCategories] = useState([]);
  const [message, setMessage] = useState("");
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await fetch(`${BASE_URL}/api/superadmin/categories`, {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        if (!res.ok) throw new Error("Failed to fetch categories");
        const data = await res.json();
        setCategories(data.categories || []);
      } catch (err) {
        console.error("Error fetching categories:", err.message);
        setError("Failed to load categories");
      }
    };
    fetchCategories();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    setProfileImage(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage("");
    setError(null);

    try {
      if (!formData.business_name || !formData.username || !formData.email || !formData.password || !formData.business_type) {
        throw new Error("Business name, username, email, password, and business type are required");
      }

      let profileImageUrl = "";
      if (profileImage) {
        console.log("Uploading profile image:", profileImage.name);
        profileImageUrl = await uploadToS3(profileImage, "vendors");
        console.log("Profile image uploaded:", profileImageUrl);
        if (!profileImageUrl) {
          throw new Error("Failed to upload profile image to S3");
        }
      }

      const data = new FormData();
      data.append("business_name", formData.business_name);
      data.append("username", formData.username);
      data.append("email", formData.email);
      data.append("password", formData.password);
      data.append("business_type", formData.business_type);
      if (formData.category_id) data.append("category_id", formData.category_id);
      if (profileImageUrl) data.append("profile_image", profileImageUrl);
      data.append("status", formData.status);

      console.log("FormData to send:");
      for (let [key, value] of data.entries()) {
        console.log(`  ${key}: ${value}`);
      }

      const res = await fetch(`${BASE_URL}/api/vendor/vendors`, {
        method: "POST",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        body: data,
      });

      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "Failed to create vendor");

      setMessage(`✅ Vendor created: ${result.vendor.business_name}`);
      setFormData({
        business_name: "",
        username: "",
        email: "",
        password: "",
        business_type: "",
        category_id: "",
        status: "Pending",
      });
      setProfileImage(null);
      setError(null);
      if (onSuccess) onSuccess();
      navigate("/vendors"); // Navigate back to /vendors
    } catch (err) {
      console.error("Vendor creation error:", err.message);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="bg-white rounded-xl shadow-lg p-8 w-full max-w-3xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Vendor Signup</h1>
          <p className="text-gray-600 mt-2">Register your business to join our platform</p>
        </div>

        {error && (
          <div className="flex items-center space-x-2 p-4 rounded-lg border text-red-700 bg-red-50 border-red-200 mb-6">
            <XCircle className="w-5 h-5" />
            <span className="text-sm font-medium">{error}</span>
          </div>
        )}
        {message && (
          <div className="flex items-center space-x-2 p-4 rounded-lg border text-green-700 bg-green-50 border-green-200 mb-6">
            <CheckCircle className="w-5 h-5" />
            <span className="text-sm font-medium">{message}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Business Name</label>
            <div className="relative">
              <Building className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                name="business_name"
                value={formData.business_name}
                onChange={handleInputChange}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 hover:shadow-sm"
                placeholder="Enter your business name"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                name="username"
                value={formData.username}
                onChange={handleInputChange}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 hover:shadow-sm"
                placeholder="Choose a username"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 hover:shadow-sm"
                placeholder="Enter your email"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 hover:shadow-sm"
                placeholder="Set a secure password"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Business Type</label>
            <select
              name="business_type"
              value={formData.business_type}
              onChange={handleInputChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 hover:shadow-sm"
              required
            >
              <option value="">Select Business Type</option>
              <option value="Service">Service</option>
              <option value="Retailer">Retailer</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
            <select
              name="category_id"
              value={formData.category_id}
              onChange={handleInputChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 hover:shadow-sm"
            >
              <option value="">Select Category</option>
              {categories.map((cat) => (
                <option key={cat.category_id} value={cat.category_id}>
                  {cat.category_name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Profile Image</label>
            <div className="relative">
              <Image className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="file"
                name="profile_image"
                onChange={handleFileChange}
                accept="image/*"
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 hover:shadow-sm"
              />
            </div>
            {profileImage && <p className="text-sm text-gray-600 mt-2">Selected: {profileImage.name}</p>}
            {formData.profile_image && (
              <img
                src={formData.profile_image}
                alt="Profile Preview"
                className="h-16 w-16 object-cover rounded mt-2"
                onError={(e) => {
                  console.error("Failed to load profile image preview:", e.target.src);
                  e.target.src = "https://via.placeholder.com/64?text=No+Image";
                }}
                onLoad={() => console.log("Profile image preview loaded:", formData.profile_image)}
              />
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
            <select
              name="status"
              value={formData.status}
              onChange={handleInputChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 hover:shadow-sm"
            >
              <option value="Pending">Pending</option>
              <option value="Approved">Approved</option>
              <option value="Rejected">Rejected</option>
            </select>
          </div>

          <div className="md:col-span-2 flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => {
                setFormData({
                  business_name: "",
                  username: "",
                  email: "",
                  password: "",
                  business_type: "",
                  category_id: "",
                  status: "Pending",
                });
                setProfileImage(null);
                setError(null);
                setMessage("");
              }}
              className="px-6 py-3 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-all duration-300 disabled:opacity-50"
              disabled={isLoading}
            >
              Reset
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-all duration-300 disabled:opacity-50 shadow-sm"
            >
              {isLoading ? (
                <div className="flex items-center justify-center space-x-2">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Creating...</span>
                </div>
              ) : (
                "Create Vendor"
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}