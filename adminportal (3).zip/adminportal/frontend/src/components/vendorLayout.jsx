import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";

const VendorLayout = ({ children }) => {
  const [activeView, setActiveView] = useState("dashboard");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // Set activeView based on current route
    const path = location.pathname;
    if (path.includes("/vendor/dashboard")) {
      setActiveView("dashboard");
    } else if (path.includes("/vendor/shops")) {
      setActiveView("shops");
    } else if (path.includes("/vendor/shop-images")) {
      setActiveView("shop-images");
    } else if (path.includes("/vendor/services")) {
      setActiveView("services");
    } else if (path.includes("/vendor/ratings")) {
      setActiveView("ratings");
    } else if (path.includes("/vendor/profile")) {
      setActiveView("profile");
    }
  }, [location.pathname]);

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  const handleNavigation = (view, path) => {
    setActiveView(view);
    navigate(path);
    setIsMobileMenuOpen(false); // Close mobile menu after navigation
  };

  const NavButton = ({ onClick, active, children, className = "" }) => (
    <button
      onClick={onClick}
      className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${className} ${
        active
          ? "bg-green-100 text-green-700 font-medium"
          : "text-gray-600 hover:bg-gray-100"
      }`}
    >
      {children}
    </button>
  );

  const NavigationContent = () => (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto">
        <div className="p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-6">Vendor Portal</h2>
          <nav className="space-y-2">
            <NavButton
              onClick={() => handleNavigation("dashboard", "/vendor/dashboard")}
              active={activeView === "dashboard"}
            >
              Dashboard
            </NavButton>

            <div className="pt-4">
              <p className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">Management</p>
              <div className="space-y-1">
                <NavButton
                  onClick={() => handleNavigation("shops", "/vendor/shops")}
                  active={activeView === "shops"}
                  className="text-sm"
                >
                  Manage Shops
                </NavButton>
                <NavButton
                  onClick={() => handleNavigation("shop-images", "/vendor/shop-images")}
                  active={activeView === "shop-images"}
                  className="text-sm"
                >
                  Manage Shop Images
                </NavButton>
                <NavButton
                  onClick={() => handleNavigation("services", "/vendor/services")}
                  active={activeView === "services"}
                  className="text-sm"
                >
                  Manage Services
                </NavButton>
                <NavButton
                  onClick={() => handleNavigation("ratings", "/vendor/ratings")}
                  active={activeView === "ratings"}
                  className="text-sm"
                >
                  Manage Ratings
                </NavButton>
                <NavButton
                  onClick={() => handleNavigation("profile", "/vendor/profile")}
                  active={activeView === "profile"}
                  className="text-sm"
                >
                  Manage Profile
                </NavButton>
              </div>
            </div>
          </nav>
        </div>
      </div>

      {/* Logout Button */}
      <div className="p-6 pt-0">
        <button
          onClick={handleLogout}
          className="w-full px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors text-sm font-medium"
        >
          Logout
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Mobile Menu Button */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 bg-white rounded-md shadow-md text-gray-600 hover:text-gray-900"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div
          className="lg:hidden fixed inset-0 z-40 bg-black bg-opacity-50"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 bg-white shadow-lg flex-col h-screen sticky top-0">
        <NavigationContent />
      </aside>

      {/* Mobile Sidebar */}
      <aside
        className={`lg:hidden fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out ${
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        } flex flex-col h-full`}
      >
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-lg font-bold text-gray-800">Vendor Portal</h2>
          <button
            onClick={() => setIsMobileMenuOpen(false)}
            className="p-1 text-gray-600 hover:text-gray-900"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <NavigationContent />
      </aside>

      {/* Main Content */}
      <main className="flex-1 lg:ml-0 ml-0 min-h-screen">
        <div className="p-4 lg:p-8 pt-16 lg:pt-8 max-w-7xl mx-auto">{children}</div>
      </main>
    </div>
  );
};

export default VendorLayout;