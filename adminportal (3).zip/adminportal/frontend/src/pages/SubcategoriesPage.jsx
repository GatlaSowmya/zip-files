import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { BASE_URL } from "../config";
import uploadToS3 from "../services/uploadToS3";

class ErrorBoundary extends React.Component {
  state = { hasError: false, error: null };

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-6 text-red-600">
          <h2>Something went wrong</h2>
          <p>{this.state.error?.message || "An unexpected error occurred"}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 p-2 bg-blue-600 text-white rounded-lg"
          >
            Reload Page
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

const SubcategoriesPage = () => {
  const { category_id } = useParams();
  const [subcategories, setSubcategories] = useState([]);
  const [parentCategoryName, setParentCategoryName] = useState("");
  const [modalType, setModalType] = useState(null);
  const [formData, setFormData] = useState({ image_file: null, icon_file: null });
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isParentLoading, setIsParentLoading] = useState(true);
  const navigate = useNavigate();

  const fetchParentCategory = async () => {
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/categories/${category_id}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Failed to fetch parent category");
      }
      const data = await res.json();
      console.log("fetchParentCategory - Response:", data);
      setParentCategoryName(data.category?.category_name || "Unknown Category");
    } catch (error) {
      console.error("fetchParentCategory error:", error);
      setError(error.message);
    } finally {
      setIsParentLoading(false);
    }
  };

  const fetchSubcategories = async () => {
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/subcategories?category_id=${category_id}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Failed to fetch subcategories");
      }
      const data = await res.json();
      console.log("fetchSubcategories - Response:", data);
      setSubcategories(data.subcategories || []);
    } catch (error) {
      console.error("fetchSubcategories error:", error);
      setError(error.message);
    }
  };

  useEffect(() => {
    fetchParentCategory();
    fetchSubcategories();
  }, [category_id]);

  const handleInputChange = (e) => {
    const { name, value, files } = e.target;
    if (files) {
      if (files.length > 0) {
        const file = files[0];
        if (file.size > 5 * 1024 * 1024) {
          setError("File size exceeds 5MB limit");
          return;
        }
        if (!file.type.startsWith("image/")) {
          setError("Please select an image file");
          return;
        }
        console.log(`${name} selected:`, file.name, file.size, file.type);
        setFormData((prev) => ({
          ...prev,
          [name]: file,
        }));
      } else {
        setFormData((prev) => ({
          ...prev,
          [name]: null,
        }));
      }
    } else {
      setFormData((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  const openModal = (type, data = {}) => {
    setModalType(type);
    setFormData({
      ...data,
      image_file: null,
      icon_file: null,
      category_name: data.category_name || "",
      description: data.description || "",
      image_url: data.image_url || "",
      icon_url: data.icon_url || "",
      parent_category_id: category_id,
    });
    setError(null);
  };

  const closeModal = () => {
    setModalType(null);
    setFormData({ image_file: null, icon_file: null });
    setError(null);
  };

  const handleAddSubcategory = async () => {
    if (!formData.category_name || !formData.parent_category_id) {
      setError("Category name and parent category are required");
      return;
    }
    setIsLoading(true);
    try {
      let imageUrl = "";
      let iconUrl = "";
      if (formData.image_file) {
        console.log("Uploading image file:", formData.image_file.name);
        imageUrl = await uploadToS3(formData.image_file, "subcategories");
        if (!imageUrl || typeof imageUrl !== "string") {
          throw new Error("Failed to upload image file");
        }
        console.log("Image uploaded, URL:", imageUrl);
      }
      if (formData.icon_file) {
        console.log("Uploading icon file:", formData.icon_file.name);
        iconUrl = await uploadToS3(formData.icon_file, "subcategories/icons");
        if (!iconUrl || typeof iconUrl !== "string") {
          throw new Error("Failed to upload icon file");
        }
        console.log("Icon uploaded, URL:", iconUrl);
      }

      const formDataToSend = new FormData();
      formDataToSend.append("category_name", formData.category_name || "");
      formDataToSend.append("parent_category_id", formData.parent_category_id);
      formDataToSend.append("description", formData.description || "");
      if (imageUrl) {
        formDataToSend.append("image_url", imageUrl);
        console.log("Appending image_url:", imageUrl);
      }
      if (iconUrl) {
        formDataToSend.append("icon_url", iconUrl);
        console.log("Appending icon_url:", iconUrl);
      }

      console.log("FormData to send:");
      for (let [key, value] of formDataToSend.entries()) {
        console.log(`  ${key}: ${value}`);
      }

      let res = await fetch(`${BASE_URL}/api/superadmin/subcategories`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: formDataToSend,
        keepalive: true,
      });

      if (!res.ok) {
        const errorData = await res.json();
        console.error("FormData request failed:", errorData);
        const jsonPayload = {
          category_name: formData.category_name || "",
          parent_category_id: formData.parent_category_id,
          description: formData.description || "",
          image_url: imageUrl || "",
          icon_url: iconUrl || "",
        };
        console.log("JSON payload:", jsonPayload);
        res = await fetch(`${BASE_URL}/api/superadmin/subcategories`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(jsonPayload),
        });
        if (!res.ok) {
          const errorData = await res.json();
          throw new Error(errorData.error || `Failed to create subcategory: ${res.statusText}`);
        }
      }

      const responseData = await res.json();
      console.log("Subcategory created:", responseData);
      await fetchSubcategories();
      closeModal();
    } catch (error) {
      console.error("handleAddSubcategory error:", error);
      setError(error.message || "Failed to create subcategory");
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditSubcategory = async () => {
    if (!formData.category_name || !formData.parent_category_id) {
      setError("Category name and parent category are required");
      return;
    }
    setIsLoading(true);
    try {
      let imageUrl = formData.image_url || "";
      let iconUrl = formData.icon_url || "";
      if (formData.image_file) {
        console.log("Uploading image file:", formData.image_file.name);
        imageUrl = await uploadToS3(formData.image_file, "subcategories");
        if (!imageUrl || typeof imageUrl !== "string") {
          throw new Error("Failed to upload image file");
        }
        console.log("Image uploaded, URL:", imageUrl);
      }
      if (formData.icon_file) {
        console.log("Uploading icon file:", formData.icon_file.name);
        iconUrl = await uploadToS3(formData.icon_file, "subcategories/icons");
        if (!iconUrl || typeof iconUrl !== "string") {
          throw new Error("Failed to upload icon file");
        }
        console.log("Icon uploaded, URL:", iconUrl);
      }

      const formDataToSend = new FormData();
      formDataToSend.append("category_name", formData.category_name || "");
      formDataToSend.append("parent_category_id", formData.parent_category_id);
      formDataToSend.append("description", formData.description || "");
      if (imageUrl) {
        formDataToSend.append("image_url", imageUrl);
        console.log("Appending image_url:", imageUrl);
      }
      if (iconUrl) {
        formDataToSend.append("icon_url", iconUrl);
        console.log("Appending icon_url:", iconUrl);
      }

      console.log("FormData to send:");
      for (let [key, value] of formDataToSend.entries()) {
        console.log(`  ${key}: ${value}`);
      }

      let res = await fetch(`${BASE_URL}/api/superadmin/categories/${formData.category_id}`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: formDataToSend,
        keepalive: true,
      });

      if (!res.ok) {
        const errorData = await res.json();
        console.error("FormData request failed:", errorData);
        console.log("Attempting JSON fallback...");
        const jsonPayload = {
          category_name: formData.category_name || "",
          parent_category_id: formData.parent_category_id,
          description: formData.description || "",
          image_url: imageUrl || "",
          icon_url: iconUrl || "",
        };
        console.log("JSON payload:", jsonPayload);
        res = await fetch(`${BASE_URL}/api/superadmin/categories/${formData.category_id}`, {
          method: "PUT",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(jsonPayload),
        });
        if (!res.ok) {
          const errorData = await res.json();
          throw new Error(errorData.error || `Failed to update subcategory: ${res.statusText}`);
        }
      }

      const responseData = await res.json();
      console.log("Subcategory updated:", responseData);
      await fetchSubcategories();
      closeModal();
    } catch (error) {
      console.error("handleEditSubcategory error:", error);
      setError(error.message || "Failed to update subcategory");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteSubcategory = async (id) => {
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/categories/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Failed to delete subcategory");
      }
      await fetchSubcategories();
    } catch (error) {
      console.error("handleDeleteSubcategory error:", error);
      setError(error.message);
    }
  };

  return (
    <ErrorBoundary>
      <div className="space-y-6 p-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-900">
            {isParentLoading ? "Loading..." : `Subcategories of ${parentCategoryName}`}
          </h1>
          <button
            onClick={() => navigate("/categories")}
            className="p-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
          >
            Back to Categories
          </button>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-800">Subcategories</h2>
            <button
              onClick={() => openModal("addSubcategory")}
              className="p-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200"
            >
              Add Subcategory
            </button>
          </div>
          {error && <p className="text-red-600 text-sm mb-4">{error}</p>}
          {subcategories.length === 0 ? (
            <p className="text-gray-600">No subcategories available</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {subcategories.map((subcategory) => (
                <div key={subcategory.category_id} className="p-4 border border-gray-200 rounded-lg">
                  <h3 className="text-lg font-medium text-gray-900">{subcategory.category_name}</h3>
                  <p className="text-sm text-gray-600">{subcategory.description}</p>
                  {subcategory.image_url ? (
                    <img
                      src={subcategory.image_url}
                      alt={subcategory.category_name}
                      className="h-16 w-16 object-cover rounded mt-2"
                      onError={(e) => console.error("Image load error:", subcategory.image_url, e)}
                    />
                  ) : (
                    <p className="text-sm text-gray-600 mt-2">No image available</p>
                  )}
                  {subcategory.icon_url ? (
                    <img
                      src={subcategory.icon_url}
                      alt={`${subcategory.category_name} icon`}
                      className="h-8 w-8 object-cover rounded mt-2"
                      onError={(e) => console.error("Icon load error:", subcategory.icon_url, e)}
                    />
                  ) : (
                    <p className="text-sm text-gray-600 mt-2">No icon available</p>
                  )}
                  <div className="mt-4 flex space-x-2">
                    <button
                      onClick={() => openModal("editSubcategory", subcategory)}
                      className="p-2 bg-yellow-100 text-yellow-700 rounded-lg hover:bg-yellow-200"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDeleteSubcategory(subcategory.category_id)}
                      className="p-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200"
                    >
                      Delete
                    </button>
                    <button
                      onClick={() => navigate(`/shops/${subcategory.category_id}`)}
                      className="p-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200"
                    >
                      View Shops
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        {modalType && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                {modalType === "addSubcategory" ? "Add Subcategory" : "Edit Subcategory"}
              </h2>
              {isLoading && (
                <div className="flex justify-center mb-4">
                  <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Subcategory Name</label>
                  <input
                    type="text"
                    name="category_name"
                    value={formData.category_name || ""}
                    onChange={handleInputChange}
                    className="mt-1 p-2 w-full border rounded-lg"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Description</label>
                  <textarea
                    name="description"
                    value={formData.description || ""}
                    onChange={handleInputChange}
                    className="mt-1 p-2 w-full border rounded-lg"
                    rows="4"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Image File</label>
                  <input
                    type="file"
                    name="image_file"
                    accept="image/*"
                    onChange={(e) => {
                      console.log("Image file selected:", e.target.files);
                      handleInputChange(e);
                    }}
                    className="mt-1 p-2 w-full border rounded-lg"
                  />
                  {formData.image_file && (
                    <p className="text-sm text-gray-600 mt-2">Selected: {formData.image_file.name}</p>
                  )}
                  {formData.image_url && !formData.image_file && (
                    <p className="text-sm text-gray-600 mt-2">Current: {formData.image_url}</p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Icon File</label>
                  <input
                    type="file"
                    name="icon_file"
                    accept="image/*"
                    onChange={(e) => {
                      console.log("Icon file selected:", e.target.files);
                      handleInputChange(e);
                    }}
                    className="mt-1 p-2 w-full border rounded-lg"
                  />
                  {formData.icon_file && (
                    <p className="text-sm text-gray-600 mt-2">Selected: {formData.icon_file.name}</p>
                  )}
                  {formData.icon_url && !formData.icon_file && (
                    <p className="text-sm text-gray-600 mt-2">Current: {formData.icon_url}</p>
                  )}
                </div>
                {error && <p className="text-red-600 text-sm">{error}</p>}
                <div className="flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={closeModal}
                    disabled={isLoading}
                    className="p-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={modalType === "addSubcategory" ? handleAddSubcategory : handleEditSubcategory}
                    disabled={isLoading}
                    className="p-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 disabled:opacity-50"
                  >
                    {isLoading ? "Saving..." : "Save"}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
};

export default SubcategoriesPage;