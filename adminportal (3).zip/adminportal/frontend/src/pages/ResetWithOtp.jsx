import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { BASE_URL } from "../config";

export default function ResetWithOtp() {
  const [email, setEmail] = useState(localStorage.getItem("resetEmail") || "");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleReset = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage("");

    try {
      // 1. Verify OTP and reset password
      const resetRes = await fetch(`${BASE_URL}/api/auth/verify-reset-otp`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, otp, newPassword }),
      });

      const resetData = await resetRes.json();

      if (!resetRes.ok) {
        setMessage(resetData.error || "Reset failed.");
        setIsLoading(false);
        return;
      }

      // 2. Automatically login the user
      const loginRes = await fetch(`${BASE_URL}/api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ loginId: email, password: newPassword }),
      });

      const loginData = await loginRes.json();

      if (!loginRes.ok) {
        setMessage("Password reset succeeded, but login failed.");
        setIsLoading(false);
        return;
      }

      // 3. Store token and redirect based on role
      localStorage.setItem("token", loginData.token);
      localStorage.removeItem("resetEmail");

      if (loginData.role === "vendor") {
        navigate("/vendor/dashboard");
      } else if (loginData.role === "superadmin") {
        navigate("/superadmin/dashboard");
      } else {
        setMessage("Unknown user role.");
      }
    // eslint-disable-next-line no-unused-vars
    } catch (err) {
      setMessage("Something went wrong. Try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-purple-50">
      <form onSubmit={handleReset} className="bg-white p-6 rounded-xl shadow-md w-full max-w-md">
        <h2 className="text-xl font-bold text-center mb-4 text-gray-800">Reset Password</h2>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Your Email"
          required
          className="w-full px-4 py-2 border border-gray-300 rounded-md mb-4"
        />
        <input
          type="text"
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
          placeholder="Enter OTP"
          required
          className="w-full px-4 py-2 border border-gray-300 rounded-md mb-4"
        />
        <input
          type="password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          placeholder="New Password"
          required
          className="w-full px-4 py-2 border border-gray-300 rounded-md mb-4"
        />
        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-purple-600 text-white py-2 rounded-md hover:bg-purple-700"
        >
          {isLoading ? "Resetting..." : "Reset Password"}
        </button>
        {message && <p className="mt-4 text-center text-sm text-gray-700">{message}</p>}
      </form>
    </div>
  );
}
