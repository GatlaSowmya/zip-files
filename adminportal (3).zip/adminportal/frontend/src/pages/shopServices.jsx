import React, { useState, useEffect } from "react";
import { XCircle, CheckCircle, Search } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { BASE_URL } from "../config";

const ManageShopServices = () => {
  const [shops, setShops] = useState([]);
  const [filteredShops, setFilteredShops] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [error, setError] = useState(null);
  const [message, setMessage] = useState("");
  const [isLoadingShops, setIsLoadingShops] = useState(false);
  const [pagination, setPagination] = useState({ page: 1, limit: 10, total: 0, totalPages: 1 });
  const navigate = useNavigate();

  // Fetch paginated shops
  const fetchShops = async (page = 1, limit = 10) => {
    setIsLoadingShops(true);
    setError(null);
    setMessage("");
    try {
      const url = `${BASE_URL}/api/superadmin/shops?page=${page}&limit=${limit}`;
      console.log(`Fetching shops from: ${url}`);
      const token = localStorage.getItem("token");
      if (!token) {
        throw new Error("No authentication token found");
      }
      const res = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        console.error("Shops fetch error response:", errorData);
        throw new Error(errorData.error || `Failed to fetch shops (Status: ${res.status})`);
      }
      const data = await res.json();
      console.log(`Shops fetch response (page ${page}):`, JSON.stringify(data, null, 2));

      if (!data.shops || !Array.isArray(data.shops)) {
        console.warn(`Invalid shops array in response for page ${page}:`, data);
        setMessage("No approved shops found for this page.");
        setShops([]);
        setFilteredShops([]);
        setPagination((prev) => ({
          ...prev,
          page,
          limit,
          total: data.pagination?.total || 0,
          totalPages: data.pagination?.totalPages || 1,
        }));
        return;
      }

      setShops(data.shops);
      setFilteredShops(data.shops);
      const paginationData = data.pagination || {
        page,
        limit,
        total: data.shops.length,
        totalPages: Math.ceil(data.shops.length / limit),
      };
      setPagination({
        page: paginationData.page || page,
        limit: paginationData.limit || limit,
        total: paginationData.total || data.shops.length,
        totalPages: paginationData.totalPages || Math.ceil((paginationData.total || data.shops.length) / limit),
      });

      if (data.shops.length === 0 && paginationData.total > 0) {
        setMessage(`No approved shops found for page ${page}.`);
      }
    } catch (error) {
      console.error("Fetch shops error:", error.message);
      setError(`Failed to fetch shops: ${error.message}`);
      setShops([]);
      setFilteredShops([]);
      setPagination((prev) => ({ ...prev, page: 1, limit, total: 0, totalPages: 1 }));
      setMessage("No shops available. Please check the server or add shops.");
    } finally {
      setIsLoadingShops(false);
    }
  };

  // Fetch shops for search
  const fetchAllShopsForSearch = async (query) => {
    setIsLoadingShops(true);
    setError(null);
    setMessage("");
    try {
      const url = `${BASE_URL}/api/superadmin/shops?search=${encodeURIComponent(query)}`;
      console.log(`Fetching shops for search from: ${url}`);
      const token = localStorage.getItem("token");
      if (!token) {
        throw new Error("No authentication token found");
      }
      let res = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) {
        console.warn(`Server-side search failed (Status: ${res.status}), falling back to fetching all shops`);
        const fallbackUrl = `${BASE_URL}/api/superadmin/shops?page=1&limit=1000`;
        console.log(`Fetching all shops from: ${fallbackUrl}`);
        res = await fetch(fallbackUrl, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) {
          const errorData = await res.json().catch(() => ({}));
          console.error("Fallback fetch error response:", errorData);
          throw new Error(errorData.error || `Failed to fetch shops for search (Status: ${res.status})`);
        }
      }

      const data = await res.json();
      console.log("Search shops response:", JSON.stringify(data, null, 2));

      if (!data.shops || !Array.isArray(data.shops)) {
        console.warn("Invalid shops array in search response:", data);
        setMessage("No shops found for the search query.");
        setFilteredShops([]);
        setPagination((prev) => ({ ...prev, page: 1, total: 0, totalPages: 1 }));
        return;
      }

      const filtered = res.url.includes("search=")
        ? data.shops
        : data.shops.filter((shop) => shop.shop_name.toLowerCase().includes(query.toLowerCase()));
      setFilteredShops(filtered);
      setPagination((prev) => ({
        ...prev,
        page: 1,
        total: filtered.length,
        totalPages: Math.ceil(filtered.length / prev.limit),
      }));

      if (filtered.length === 0) {
        setMessage("No shops found for the search query.");
      }
    } catch (error) {
      console.error("Search shops error:", error.message);
      setError(`Failed to fetch shops for search: ${error.message}`);
      setFilteredShops([]);
      setPagination((prev) => ({ ...prev, page: 1, total: 0, totalPages: 1 }));
      setMessage("No shops available for the search query.");
    } finally {
      setIsLoadingShops(false);
    }
  };

  // Handle search
  const handleSearch = (e) => {
    const query = e.target.value;
    setSearchQuery(query);
    setPagination((prev) => ({ ...prev, page: 1 }));
    if (query === "") {
      console.log("Search cleared, reverting to paginated fetch");
      fetchShops(1, pagination.limit);
    } else {
      fetchAllShopsForSearch(query);
    }
  };

  // Handle navigation to services page
  const handleViewServices = (shopId) => {
    console.log("Navigating to services with shop_id:", shopId);
    navigate(`/services?shop_id=${shopId}`);
  };

  // Handle page change
  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      console.log("Changing page to:", newPage);
      setPagination((prev) => ({ ...prev, page: newPage }));
    if (!searchQuery) {
  fetchShops(newPage, pagination.limit);
}

    } else {
      console.warn("Invalid page change attempted:", newPage);
    }
  };

  // Fetch shops on mount
 useEffect(() => {
  fetchShops(pagination.page, pagination.limit);
}, [pagination.page, pagination.limit]);


  // Slice shops for pagination
  const displayedShops = searchQuery ? filteredShops : shops;


  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">Manage Shop Services</h1>
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl border border-white/20 p-6">
          {/* Search Bar */}
          <div className="mb-4">
            <div className="relative max-w-md">
              <input
                type="text"
                value={searchQuery}
                onChange={handleSearch}
                placeholder="Search shops by name..."
                className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200"
              />
              <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
            </div>
          </div>

          {/* Error and Message Display */}
          {error && (
            <div className="flex items-center space-x-2 p-4 rounded-xl border text-red-700 bg-red-50 border-red-200 mb-4">
              <XCircle className="w-5 h-5" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}
          {message && !displayedShops.length && (
            <div className="flex items-center space-x-2 p-4 rounded-xl border text-green-700 bg-green-50 border-green-200 mb-4">
              <CheckCircle className="w-5 h-5" />
              <span className="text-sm font-medium">{message}</span>
            </div>
          )}

          {/* Shops Table */}
          {isLoadingShops ? (
            <div className="flex items-center justify-center space-x-2 py-6">
              <div className="w-5 h-5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
              <span className="text-gray-600">Loading shops...</span>
            </div>
          ) : displayedShops.length === 0 ? (
            <p className="text-gray-600 text-center py-4">{message || "No shops available."}</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="p-3 text-sm font-semibold text-gray-700">Shop Name</th>
                    <th className="p-3 text-sm font-semibold text-gray-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {displayedShops.map((shop) => (
                    <tr key={shop.shop_id} className="border-b border-gray-200 hover:bg-gray-50">
                      <td className="p-3">{shop.shop_name}</td>
                      <td className="p-3">
                        <button
                          onClick={() => handleViewServices(shop.shop_id)}
                          className="px-2 py-1 text-sm bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors duration-200"
                        >
                          View Services
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination Controls */}
          {pagination.total > 0 && (
            <div className="flex justify-between items-center mt-4">
              <button
                onClick={() => handlePageChange(pagination.page - 1)}
                disabled={pagination.page === 1}
                className="px-2 py-1 text-sm bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 disabled:opacity-50 transition-colors duration-200"
              >
                Previous
              </button>
              <span className="text-gray-700 text-sm">
                Page {pagination.page} of {pagination.totalPages} (Total: {pagination.total} shops)
              </span>
              <button
                onClick={() => handlePageChange(pagination.page + 1)}
                disabled={pagination.page === pagination.totalPages}
                className="px-2 py-1 text-sm bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 disabled:opacity-50 transition-colors duration-200"
              >
                Next
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ManageShopServices;