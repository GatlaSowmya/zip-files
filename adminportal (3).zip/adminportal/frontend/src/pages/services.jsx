
import React, { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { XCircle, CheckCircle, Plus, Edit, Trash, ArrowLeft } from "lucide-react";
import { BASE_URL } from "../config";
import uploadToS3 from "../services/uploadToS3";

const Services = () => {
  const [services, setServices] = useState([]);
  const [shopName, setShopName] = useState("");
  const [isLoadingShopName, setIsLoadingShopName] = useState(false);
  const [isLoadingServices, setIsLoadingServices] = useState(false);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState("");
  const [pagination, setPagination] = useState({ page: 1, limit: 10, total: 0, totalPages: 1 });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState("add");
  const [newService, setNewService] = useState({
    title: "",
    description: "",
    original_price: "",
    discount_price: "",
    image_file: null,
    service_id: null,
    nearby_landmarks: {},
    professional_achievements: {},
    facilities_features: {},
    quick_info: {},
  });
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const shopId = searchParams.get("shop_id");

  // Helper function for API requests
  const fetchData = async (url, options = {}) => {
    const token = localStorage.getItem("token");
    if (!token) {
      console.log("fetchData: No authentication token found");
      navigate("/login");
      throw new Error("No authentication token found");
    }

    console.log(`fetchData: Sending request to: ${url}`);
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
        ...options.headers,
      },
      ...options,
    });

    console.log(`fetchData: Response status: ${res.status}, Status Text: ${res.statusText}`);
    const responseData = await res.json();
    console.log(`fetchData: Full response data: ${JSON.stringify(responseData, null, 2)}`);

    if (!res.ok) {
      console.error(`fetchData: API error - Status: ${res.status}, Response: ${JSON.stringify(responseData)}`);
      throw new Error(responseData.error || `Failed to fetch data (Status: ${res.status})`);
    }

    return responseData;
  };

  // Validate UUID
  const isValidUUID = (str) => {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    return uuidRegex.test(str);
  };

  // Fetch shop name
  const fetchShopName = async (shopId) => {
    setIsLoadingShopName(true);
    try {
      const url = `${BASE_URL}/api/superadmin/shops?shop_id=${shopId}`;
      const responseData = await fetchData(url);

      const shopNameFromResponse = responseData.data?.shop_name || responseData.shop_name;
      if (!shopNameFromResponse || shopNameFromResponse.trim() === "") {
        console.log(`fetchShopName: shop_name is missing, null, or empty for shop_id=${shopId}`);
        setShopName("Unnamed Shop");
        localStorage.setItem(`shopName_${shopId}`, "Unnamed Shop");
        setError(`No valid shop name returned for shop_id=${shopId}`);
        return false;
      }

      console.log(`fetchShopName: Successfully fetched shop name: ${shopNameFromResponse}`);
      setShopName(shopNameFromResponse);
      localStorage.setItem(`shopName_${shopId}`, shopNameFromResponse);
      console.log(`shopName set to: ${shopNameFromResponse}, stored in localStorage as shopName_${shopId}`);
      if (responseData.is_approved === false) {
        console.log(`fetchShopName: Shop ${shopNameFromResponse} is not approved`);
        setError(`Shop "${shopNameFromResponse}" is not approved. Some features may be restricted.`);
      }
      return true;
    } catch (error) {
      console.error(`fetchShopName: Error fetching shop name: ${error.message}`);
      setError(`Failed to fetch shop name: ${error.message}`);
      setShopName("Unknown Shop");
      localStorage.setItem(`shopName_${shopId}`, "Unknown Shop");
      return false;
    } finally {
      setIsLoadingShopName(false);
    }
  };

  // Fetch services
  const fetchServices = async (shopId, page = 1, limit = 10) => {
    setIsLoadingServices(true);
    setError(null);
    setMessage("");
    try {
      const url = `${BASE_URL}/api/superadmin/services?shop_id=${shopId}&page=${page}&limit=${limit}`;
      const data = await fetchData(url);

      if (!data.services || !Array.isArray(data.services)) {
        setServices([]);
        setPagination({ page: 1, limit: 10, total: 0, totalPages: 1 });
        setMessage("No services found for this shop.");
      } else {
        setServices(data.services);
        setPagination(data.pagination || { page: 1, limit: 10, total: data.services.length, totalPages: Math.ceil(data.services.length / limit) });
        if (data.services.length === 0) {
          setMessage("No services found.");
        }
      }
    } catch (error) {
      console.error("Fetch services error:", error.message);
      setError(error.error || `Failed to fetch services: ${error.message}`);
      setServices([]);
      setPagination({ page: 1, limit: 10, total: 0, totalPages: 1 });
    } finally {
      setIsLoadingServices(false);
    }
  };

  // Handle input changes in the modal
  const handleInputChange = (e) => {
    const { name, value, files } = e.target;
    if (["nearby_landmarks", "professional_achievements", "facilities_features", "quick_info"].includes(name)) {
      try {
        setNewService((prev) => ({
          ...prev,
          [name]: value ? JSON.parse(value) : {},
        }));
      } catch (error) {
        setError(`Invalid JSON for ${name}: ${error.message}`);
      }
    } else {
      setNewService((prev) => ({
        ...prev,
        [name]: files ? files[0] : value,
      }));
    }
  };

  // Create a new service
  const handleCreateService = async (e) => {
    e.preventDefault();
    try {
      if (!newService.title) {
        throw new Error("Title is required");
      }
      if (newService.title.length > 255) {
        throw new Error("Title must be 255 characters or fewer");
      }
      if (newService.description && newService.description.length > 1000) {
        throw new Error("Description must be 1000 characters or fewer");
      }
      if (newService.original_price && (isNaN(newService.original_price) || newService.original_price < 0)) {
        throw new Error("Invalid original price");
      }
      if (newService.discount_price && (isNaN(newService.discount_price) || newService.discount_price < 0)) {
        throw new Error("Invalid discount price");
      }
      if (!shopId) {
        throw new Error("No shop ID provided");
      }

      setIsLoadingServices(true);
      let image_url = null;
      if (newService.image_file) {
        image_url = await uploadToS3(newService.image_file, "services");
        console.log("Uploaded image URL:", image_url);
      }

      const url = `${BASE_URL}/api/superadmin/services`;
      const responseData = await fetchData(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          shop_id: shopId,
          title: newService.title,
          description: newService.description || null,
          original_price: parseFloat(newService.original_price) || null,
          discount_price: parseFloat(newService.discount_price) || null,
          image_url,
          nearby_landmarks: newService.nearby_landmarks || null,
          professional_achievements: newService.professional_achievements || null,
          facilities_features: newService.facilities_features || null,
          quick_info: newService.quick_info || null,
        }),
      });

      console.log("Create service response:", responseData);
      setMessage("Service created successfully!");
      setNewService({
        title: "",
        description: "",
        original_price: "",
        discount_price: "",
        image_file: null,
        service_id: null,
        nearby_landmarks: {},
        professional_achievements: {},
        facilities_features: {},
        quick_info: {},
      });
      setIsModalOpen(false);
      fetchServices(shopId, pagination.page);
    } catch (error) {
      console.error("Create service error:", error.message);
      setError(`Failed to create service: ${error.message}`);
    } finally {
      setIsLoadingServices(false);
    }
  };

  // Update service
  const handleUpdateService = async (e) => {
    e.preventDefault();
    try {
      if (!newService.title) {
        throw new Error("Title is required");
      }
      if (newService.title.length > 255) {
        throw new Error("Title must be 255 characters or fewer");
      }
      if (newService.description && newService.description.length > 1000) {
        throw new Error("Description must be 1000 characters or fewer");
      }
      if (newService.original_price && (isNaN(newService.original_price) || newService.original_price < 0)) {
        throw new Error("Invalid original price");
      }
      if (newService.discount_price && (isNaN(newService.discount_price) || newService.discount_price < 0)) {
        throw new Error("Invalid discount price");
      }
      if (!shopId) {
        throw new Error("No shop ID provided");
      }

      setIsLoadingServices(true);
      let image_url = newService.image_url || null;
      if (newService.image_file) {
        image_url = await uploadToS3(newService.image_file, "services");
        console.log("Uploaded image URL:", image_url);
      }

      const url = `${BASE_URL}/api/superadmin/services/${newService.service_id}`;
      const responseData = await fetchData(url, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: newService.title,
          description: newService.description || null,
          original_price: parseFloat(newService.original_price) || null,
          discount_price: parseFloat(newService.discount_price) || null,
          image_url,
          nearby_landmarks: newService.nearby_landmarks || null,
          professional_achievements: newService.professional_achievements || null,
          facilities_features: newService.facilities_features || null,
          quick_info: newService.quick_info || null,
        }),
      });

      console.log("Update service response:", responseData);
      setMessage("Service updated successfully!");
      setNewService({
        title: "",
        description: "",
        original_price: "",
        discount_price: "",
        image_file: null,
        service_id: null,
        nearby_landmarks: {},
        professional_achievements: {},
        facilities_features: {},
        quick_info: {},
      });
      setIsModalOpen(false);
      fetchServices(shopId, pagination.page);
    } catch (error) {
      console.error("Update service error:", error.message);
      setError(`Failed to update service: ${error.message}`);
    } finally {
      setIsLoadingServices(false);
    }
  };

  // Delete service
  const handleDeleteService = async (serviceId) => {
    if (!window.confirm("Are you sure you want to delete this service?")) return;
    setIsLoadingServices(true);
    try {
      if (!/^srv_\d+$/.test(serviceId)) {
        throw new Error("Invalid service ID format");
      }
      const url = `${BASE_URL}/api/superadmin/services/${serviceId}`;
      await fetchData(url, {
        method: "DELETE",
      });
      setMessage("Service deleted successfully!");
      let newPage = pagination.page;
      if (services.length === 1 && pagination.page > 1) {
        newPage = pagination.page - 1;
      }
      fetchServices(shopId, newPage);
    } catch (error) {
      console.error("Delete service error:", error.message);
      setError(`Failed to delete service: ${error.message}`);
    } finally {
      setIsLoadingServices(false);
    }
  };

  // Open modal
  const openModal = (type, service = {}) => {
    setModalType(type);
    setNewService({
      title: service.title || "",
      description: service.description || "",
      original_price: service.original_price || "",
      discount_price: service.discount_price || "",
      image_file: null,
      service_id: service.service_id || null,
      image_url: service.image_url || null,
      nearby_landmarks: service.nearby_landmarks || {},
      professional_achievements: service.professional_achievements || {},
      facilities_features: service.facilities_features || {},
      quick_info: service.quick_info || {},
    });
    setIsModalOpen(true);
    setError(null);
  };

useEffect(() => {
  const storedShopName = localStorage.getItem(`shopName_${shopId}`);
  console.log(`Checking localStorage for shopName_${shopId}: ${storedShopName}`);

  if (storedShopName && storedShopName !== "Unknown Shop" && storedShopName !== "Unnamed Shop") {
    // If shopName is found in localStorage, use it
    setShopName(storedShopName);
    fetchServices(shopId);  // Only fetch services if shop name is available
  } else if (shopId) {
    // If shopName is not in localStorage, fetch from backend
    const fetchDataSequentially = async () => {
      const shopNameSuccess = await fetchShopName(shopId);
      console.log(`After fetchShopName, shopName is: ${shopName}, success: ${shopNameSuccess}`);
      if (shopNameSuccess) {
        fetchServices(shopId);  // Fetch services only if shopName is successfully fetched
      } else {
        console.log("Skipping fetchServices due to fetchShopName failure");
      }
    };

    fetchDataSequentially();
  }
}, [shopId]);

  // Log shopName changes
useEffect(() => {
  console.log(`shopName state changed to: ${shopName}`);
}, [shopName]);


  // Log render for debugging
  console.log(`Rendering Services component with shopName: ${shopName}, isLoadingShopName: ${isLoadingShopName}`);

  // Handle pagination
  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      console.log("Changing page to:", newPage);
      fetchServices(shopId, newPage, pagination.limit);
    }
  };

  // Handle image loading errors
  const handleImageError = (e) => {
    console.error("Failed to load image:", e.target.src);
    e.target.src = "https://via.placeholder.com/48?text=No+Image";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate("/manage-shop-services")}
              className="flex items-center space-x-2 px-2 py-1 text-sm bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 transition-colors duration-200"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Shops</span>
            </button>
            {/* <h1 className="text-3xl font-bold text-gray-900">
              {isLoadingShopName ? "Loading Shop Name..." : shopName ? `Services for ${shopName}` : "Services"}
            </h1> */}
          </div>
          <button
            onClick={() => openModal("add")}
            className="flex items-center space-x-2 px-2 py-1 text-sm bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors duration-200"
            disabled={isLoadingServices || !shopId || !isValidUUID(shopId) || !shopName}
          >
            <Plus className="w-4 h-4" />
            <span>Add Service</span>
          </button>
        </div>
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl border border-white/20 p-6">
          {error && (
            <div className="flex items-center space-x-2 p-4 rounded-xl border text-red-700 bg-red-50 border-red-200 mb-4">
              <XCircle className="w-5 h-5" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}
          {message && services.length === 0 && (
            <div className="flex items-center space-x-2 p-4 rounded-xl border text-green-700 bg-green-50 border-green-200 mb-4">
              <CheckCircle className="w-5 h-5" />
              <span className="text-sm font-medium">{message}</span>
            </div>
          )}
          {isLoadingServices ? (
            <div className="flex items-center justify-center space-x-2 py-6">
              <div className="w-5 h-5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
              <span className="text-gray-600">Loading services...</span>
            </div>
          ) : services.length === 0 ? (
            <p className="text-gray-600 text-center py-4">{message || "No services available."}</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="p-3 text-sm font-semibold text-gray-700">Title</th>
                    <th className="p-3 text-sm font-semibold text-gray-700">Description</th>
                    <th className="p-3 text-sm font-semibold text-gray-700">Original Price</th>
                    <th className="p-3 text-sm font-semibold text-gray-700">Discount Price</th>
                    <th className="p-3 text-sm font-semibold text-gray-700">Image</th>
                    <th className="p-3 text-sm font-semibold text-gray-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {services.map((service) => (
                    <tr key={service.service_id} className="border-b border-gray-200 hover:bg-gray-50">
                      <td className="p-3">{service.title}</td>
                      <td className="p-3">{service.description || "N/A"}</td>
                      <td className="p-3">₹{service.original_price || "N/A"}</td>
                      <td className="p-3">{service.discount_price ? `₹${service.discount_price}` : "N/A"}</td>
                      <td className="p-3">
                        {service.image_url ? (
                          <img
                            src={service.image_url}
                            alt={service.title}
                            className="h-12 w-12 object-cover rounded border border-gray-200"
                            onError={handleImageError}
                          />
                        ) : (
                          "No Image"
                        )}
                      </td>
                      <td className="p-3 flex space-x-2">
                        <button
                          onClick={() => openModal("edit", service)}
                          className="px-2 py-1 text-sm text-blue-600 hover:bg-blue-100 rounded-md transition-colors duration-200"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteService(service.service_id)}
                          className="px-2 py-1 text-sm text-red-600 hover:bg-red-100 rounded-md transition-colors duration-200"
                        >
                          <Trash className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {services.length > 0 && (
            <div className="flex justify-between items-center mt-4">
              <button
                onClick={() => handlePageChange(pagination.page - 1)}
                disabled={pagination.page === 1}
                className="px-2 py-1 text-sm bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 disabled:opacity-50 transition-colors duration-200"
              >
                Previous
              </button>
              <span className="text-gray-700 text-sm">
                Page {pagination.page} of {pagination.totalPages}
              </span>
              <button
                onClick={() => handlePageChange(pagination.page + 1)}
                disabled={pagination.page === pagination.totalPages}
                className="px-2 py-1 text-sm bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 disabled:opacity-50 transition-colors duration-200"
              >
                Next
              </button>
            </div>
          )}
        </div>

        {isModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-6 w-full max-w-lg max-h-[80vh] overflow-y-auto shadow-2xl">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                {modalType === "add" ? "Add New Service" : "Edit Service"}
              </h2>
              <form onSubmit={modalType === "add" ? handleCreateService : handleUpdateService} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                  <input
                    type="text"
                    name="title"
                    value={newService.title}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea
                    name="description"
                    value={newService.description}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200"
                    rows="4"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Original Price</label>
                  <input
                    type="number"
                    name="original_price"
                    value={newService.original_price}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200"
                    step="0.01"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Discount Price</label>
                  <input
                    type="number"
                    name="discount_price"
                    value={newService.discount_price}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200"
                    step="0.01"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nearby Landmarks (JSON)</label>
                  <textarea
                    name="nearby_landmarks"
                    value={JSON.stringify(newService.nearby_landmarks, null, 2)}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg font-mono text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200"
                    rows="4"
                    placeholder='{"landmark1": "Near Central Park", "landmark2": "Opposite Mall"}'
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Professional Achievements (JSON)</label>
                  <textarea
                    name="professional_achievements"
                    value={JSON.stringify(newService.professional_achievements, null, 2)}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg font-mono text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200"
                    rows="4"
                    placeholder='{"award1": "Best Service 2023", "certification": "ISO 9001"}'
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Facilities/Features (JSON)</label>
                  <textarea
                    name="facilities_features"
                    value={JSON.stringify(newService.facilities_features, null, 2)}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg font-mono text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200"
                    rows="4"
                    placeholder='{"feature1": "Free Wi-Fi", "feature2": "Parking Available"}'
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Quick Info (JSON)</label>
                  <textarea
                    name="quick_info"
                    value={JSON.stringify(newService.quick_info, null, 2)}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg font-mono text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200"
                    rows="4"
                    placeholder='{"info1": "Open 24/7", "info2": "Cash Only"}'
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Image</label>
                  <input
                    type="file"
                    name="image_file"
                    onChange={handleInputChange}
                    accept="image/*"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200"
                  />
                  {newService.image_url && modalType === "edit" && (
                    <img
                      src={newService.image_url}
                      alt="Current service"
                      className="h-12 w-12 object-cover rounded mt-2 border border-gray-200"
                      onError={handleImageError}
                    />
                  )}
                </div>
                <div className="flex space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="flex-1 px-2 py-1 text-sm bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 transition-colors duration-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isLoadingServices}
                    className="flex-1 px-2 py-1 text-sm bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50 transition-colors duration-200"
                  >
                    {isLoadingServices ? (
                      <div className="flex items-center justify-center space-x-2">
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        <span>Processing...</span>
                      </div>
                    ) : modalType === "add" ? (
                      "Create"
                    ) : (
                      "Update"
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Services;
