import React, { useState, useEffect, useCallback } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { CheckCircle, XCircle, Image as ImageIcon, Trash2, Edit, Check } from "lucide-react";
import uploadToS3 from "../services/uploadToS3";
import { BASE_URL } from "../config";
import sanitizeHtml from "sanitize-html";

const AllShopsPage = () => {
  const [shops, setShops] = useState([]);
  const [categories, setCategories] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [modalType, setModalType] = useState(null);
  const [formData, setFormData] = useState({
    top_category_id: "",
    category_id: "",
    vendor_id: "",
    shop_name: "",
    description: "",
    address: "",
    location: "",
    phone: "",
    whatsapp_number: "",
    email: "",
    website: "",
    opening_time: "",
    closing_time: "",
    rating: 0,
    image_files: [],
    images: [],
    shop_id: null,
    image_file: null,
    image_id: null,
  });
  const [shopImages, setShopImages] = useState([]);
  const [currentShopId, setCurrentShopId] = useState(null);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isCategoriesLoading, setIsCategoriesLoading] = useState(false);
  const [searchParams] = useSearchParams();
  const vendorId = searchParams.get("vendor_id");
  const navigate = useNavigate();
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 1,
  });

  const fetchShops = useCallback(async (page = 1) => {
    setIsLoading(true);
    try {
      let url = `${BASE_URL}/api/superadmin/shops?page=${page}&limit=${pagination.limit}`;
      if (vendorId) url += `&vendor_id=${vendorId}`;
      const res = await fetch(url, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `Failed to fetch shops: ${res.statusText}`);
      }
      const data = await res.json();
      setShops(data.shops || []);
      setPagination({
        page: data.pagination?.page || 1,
        limit: data.pagination?.limit || 10,
        total: data.pagination?.total || 0,
        totalPages: data.pagination?.totalPages || 1,
      });
      setError(null);
    } catch (error) {
      console.error("Error fetching shops:", error);
      setError(error.message);
      setShops([]);
      setPagination((prev) => ({ ...prev, page: 1, total: 0, totalPages: 1 }));
    } finally {
      setIsLoading(false);
    }
  }, [vendorId, pagination.limit]);

  const fetchTopLevelCategories = useCallback(async () => {
    setIsCategoriesLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/categories?topLevel=true`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `Failed to fetch top-level categories: ${res.statusText}`);
      }
      const data = await res.json();
      setCategories(data.categories || []);
      setError(null);
    } catch (error) {
      console.error("Error fetching top-level categories:", error);
      setError(error.message);
      setCategories([]);
    } finally {
      setIsCategoriesLoading(false);
    }
  }, []);

  const fetchSubcategories = useCallback(async (topCategoryId) => {
    if (!topCategoryId) {
      setSubcategories([]);
      return;
    }
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/subcategories?category_id=${topCategoryId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `Failed to fetch subcategories: ${res.statusText}`);
      }
      const data = await res.json();
      console.log("Fetched subcategories:", data.subcategories);
      setSubcategories(data.subcategories || []);
      setError(null);
    } catch (error) {
      console.error("Error fetching subcategories:", error);
      setError(error.message);
      setSubcategories([]);
    }
  }, []);

  const fetchVendors = useCallback(async () => {
    try {
      const token = localStorage.getItem("token");
      console.log("Fetching vendors with token:", token ? "Token present" : "No token");
      const res = await fetch(`${BASE_URL}/api/vendor/vendors`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `Failed to fetch vendors: ${res.statusText}`);
      }
      const data = await res.json();
      console.log("Fetched vendors:", data.vendors);
      const normalizedVendors = data.vendors.map((vendor) => ({
        ...vendor,
        vendor_id: vendor.id || vendor.vendor_id,
      }));
      setVendors(normalizedVendors || []);
      setError(null);
    } catch (error) {
      console.error("Error fetching vendors:", error);
      setError("Failed to load vendors. Please ensure you are logged in as a superadmin.");
      setVendors([]);
    }
  }, []);

  const fetchShopImages = useCallback(async (shopId) => {
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/shop-images?shop_id=${shopId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `Failed to fetch shop images: ${res.statusText}`);
      }
      const data = await res.json();
      setShopImages(data.shop_images || []);
      setError(null);
    } catch (error) {
      console.error("Error fetching shop images:", error);
      setError(error.message);
    }
  }, []);

  useEffect(() => {
    fetchShops(pagination.page);
    fetchTopLevelCategories();
    fetchVendors();
    if (vendorId) {
      setFormData((prev) => ({ ...prev, vendor_id: vendorId }));
    }
  }, [fetchShops, fetchTopLevelCategories, fetchVendors, vendorId, pagination.page]);

  const handleInputChange = (e) => {
    const { name, value, type, files } = e.target;
    const sanitizedValue = type !== "file" ? sanitizeHtml(value, { allowedTags: [], allowedAttributes: {} }) : value;
    setFormData((prev) => {
      const newFormData = {
        ...prev,
        [name]: type === "file" ? (name === "image_file" ? files[0] : [...files]) : sanitizedValue,
      };
      if (name === "top_category_id") {
        newFormData.category_id = "";
        fetchSubcategories(sanitizedValue);
      }
      console.log("Updated formData:", newFormData);
      return newFormData;
    });
  };

  const openModal = (type, data = {}) => {
    setModalType(type);
    setFormData({
      top_category_id: data.parent_category_id || "",
      category_id: data.category_id || "",
      vendor_id: data.vendor_id || vendorId || "",
      shop_name: data.shop_name || "",
      description: data.description || "",
      address: data.address || "",
      location: data.location || "",
      phone: data.phone || "",
      whatsapp_number: data.whatsapp_number || "",
      email: data.email || "",
      website: data.website || "",
      opening_time: data.opening_time || "",
      closing_time: data.closing_time || "",
      rating: data.rating || 0,
      image_files: [],
      images: data.images || [],
      shop_id: data.shop_id || null,
      image_file: null,
      image_id: data.image_id || null,
    });
    if (type === "manageImages") {
      setCurrentShopId(data.shop_id);
      fetchShopImages(data.shop_id);
    } else if (type === "editShopImage") {
      setCurrentShopId(data.shop_id);
    } else if (type === "editShop" && data.category_id) {
      const subcategory = subcategories.find((cat) => cat.category_id === data.category_id);
      if (subcategory && subcategory.parent_category_id) {
        setFormData((prev) => ({ ...prev, top_category_id: subcategory.parent_category_id }));
        fetchSubcategories(subcategory.parent_category_id);
      }
    }
    setError(null);
  };

  const closeModal = () => {
    setModalType(null);
    setFormData({
      top_category_id: "",
      category_id: "",
      vendor_id: vendorId || "",
      shop_name: "",
      description: "",
      address: "",
      location: "",
      phone: "",
      whatsapp_number: "",
      email: "",
      website: "",
      opening_time: "",
      closing_time: "",
      rating: 0,
      image_files: [],
      images: [],
      shop_id: null,
      image_file: null,
      image_id: null,
    });
    setShopImages([]);
    setCurrentShopId(null);
    setSubcategories([]);
    setError(null);
  };

  const validateForm = () => {
    if (!formData.category_id) return "Subcategory is required";
    if (!formData.vendor_id) return "Vendor is required";
    if (!formData.shop_name) return "Shop name is required";
    if (!formData.phone) return "Phone number is required";
    if (!/^\d{10}$/.test(formData.phone)) return "Phone number must be 10 digits";
    if (formData.whatsapp_number && !/^\d{10}$/.test(formData.whatsapp_number)) return "WhatsApp number must be 10 digits";
    if (formData.rating < 0 || formData.rating > 5) return "Rating must be between 0 and 5";
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) return "Invalid email format";
    if (formData.website && !isValidUrl(formData.website)) return "Invalid website URL";
    if (!subcategories.find((cat) => cat.category_id === formData.category_id)) return "Selected subcategory is invalid";
    if (!vendors.find((vendor) => vendor.vendor_id === formData.vendor_id)) return "Selected vendor is invalid or does not exist";
    return null;
  };

  const isValidUrl = (url) => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  };

  const handleAddShop = async () => {
    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      return;
    }
    setIsLoading(true);
    try {
      console.log("Submitting shop with formData:", {
        category_id: formData.category_id,
        vendor_id: formData.vendor_id,
        shop_name: formData.shop_name,
        phone: formData.phone,
      });
      const formDataToSend = new FormData();
      formDataToSend.append("category_id", formData.category_id);
      formDataToSend.append("vendor_id", formData.vendor_id);
      formDataToSend.append("shop_name", formData.shop_name);
      formDataToSend.append("description", formData.description || "");
      formDataToSend.append("address", formData.address || "");
      formDataToSend.append("location", formData.location || "");
      formDataToSend.append("phone", formData.phone);
      formDataToSend.append("whatsapp_number", formData.whatsapp_number || "");
      formDataToSend.append("email", formData.email || "");
      formDataToSend.append("website", formData.website || "");
      formDataToSend.append("opening_time", formData.opening_time || "");
      formDataToSend.append("closing_time", formData.closing_time || "");

      for (let [key, value] of formDataToSend.entries()) {
        console.log(`FormData ${key}: ${value}`);
      }

      const res = await fetch(`${BASE_URL}/api/superadmin/shops`, {
        method: "POST",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        body: formDataToSend,
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || `Failed to create shop: ${res.statusText}`);
      }
      const shopId = data.shop.shop_id;

      if (formData.image_files && formData.image_files.length > 0) {
        const uploadResults = await Promise.allSettled(
          formData.image_files.map((file) => uploadToS3(file, "shops"))
        );
        const imageUrls = uploadResults
          .filter((result) => result.status === "fulfilled")
          .map((result) => result.value);
        const failedUploads = uploadResults.filter((result) => result.status === "rejected");
        if (failedUploads.length > 0) {
          throw new Error(`Failed to upload ${failedUploads.length} image(s)`);
        }

        console.log("Image URLs sent to /api/superadmin/shop-images:", imageUrls);

        for (const imageUrl of imageUrls) {
          const imageFormData = new FormData();
          imageFormData.append("shop_id", shopId);
          imageFormData.append("image_url", imageUrl);
          console.log("Sending imageFormData:", { shop_id: shopId, image_url: imageUrl });
          const imageRes = await fetch(`${BASE_URL}/api/superadmin/shop-images`, {
            method: "POST",
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
            body: imageFormData,
          });
          const imageData = await imageRes.json();
          console.log("Shop image response:", { status: imageRes.status, data: imageData });
          if (!imageRes.ok) {
            throw new Error(imageData.error || `Failed to add shop image: ${imageRes.statusText}`);
          }
        }
      }

      await fetchShops(pagination.page); // Stay on current page
      closeModal();
    } catch (error) {
      console.error("Error adding shop:", error, { formData });
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditShop = async () => {
    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      return;
    }
    setIsLoading(true);
    try {
      const formDataToSend = new FormData();
      formDataToSend.append("category_id", formData.category_id);
      formDataToSend.append("vendor_id", formData.vendor_id);
      formDataToSend.append("shop_name", formData.shop_name);
      formDataToSend.append("description", formData.description || "");
      formDataToSend.append("address", formData.address || "");
      formDataToSend.append("location", formData.location || "");
      formDataToSend.append("phone", formData.phone);
      formDataToSend.append("whatsapp_number", formData.whatsapp_number || "");
      formDataToSend.append("email", formData.email || "");
      formDataToSend.append("website", formData.website || "");
      formDataToSend.append("opening_time", formData.opening_time || "");
      formDataToSend.append("closing_time", formData.closing_time || "");

      for (let [key, value] of formDataToSend.entries()) {
        console.log(`FormData ${key}: ${value}`);
      }

      const res = await fetch(`${BASE_URL}/api/superadmin/shops/${formData.shop_id}`, {
        method: "PUT",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        body: formDataToSend,
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `Failed to update shop: ${res.statusText}`);
      }

      if (formData.image_files && formData.image_files.length > 0) {
        const uploadResults = await Promise.allSettled(
          formData.image_files.map((file) => uploadToS3(file, "shops"))
        );
        const imageUrls = uploadResults
          .filter((result) => result.status === "fulfilled")
          .map((result) => result.value);
        const failedUploads = uploadResults.filter((result) => result.status === "rejected");
        if (failedUploads.length > 0) {
          throw new Error(`Failed to upload ${failedUploads.length} image(s)`);
        }

        console.log("Image URLs sent to /api/superadmin/shop-images:", imageUrls);

        for (const imageUrl of imageUrls) {
          const imageFormData = new FormData();
          imageFormData.append("shop_id", formData.shop_id);
          imageFormData.append("image_url", imageUrl);
          console.log("Sending imageFormData:", { shop_id: formData.shop_id, image_url: imageUrl });
          const imageRes = await fetch(`${BASE_URL}/api/superadmin/shop-images`, {
            method: "POST",
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
            body: imageFormData,
          });
          const imageData = await imageRes.json();
          console.log("Shop image response:", { status: imageRes.status, data: imageData });
          if (!imageRes.ok) {
            throw new Error(imageData.error || `Failed to add shop image: ${imageRes.statusText}`);
          }
        }
      }

      await fetchShops(pagination.page); // Stay on current page
      closeModal();
    } catch (error) {
      console.error("Error editing shop:", error, { formData });
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditShopImage = async () => {
    if (!formData.image_file) {
      setError("Image file is required");
      return;
    }
    setIsLoading(true);
    try {
      const imageUrl = await uploadToS3(formData.image_file, "shops");

      const formDataToSend = new FormData();
      formDataToSend.append("image_url", imageUrl);
      console.log("Sending edit imageFormData:", { image_id: formData.image_id, image_url: imageUrl });

      const res = await fetch(`${BASE_URL}/api/superadmin/shop-images/${formData.image_id}`, {
        method: "PUT",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        body: formDataToSend,
      });
      const imageData = await res.json();
      console.log("Edit shop image response:", { status: res.status, data: imageData });
      if (!res.ok) {
        throw new Error(imageData.error || `Failed to update shop image: ${res.statusText}`);
      }
      await fetchShopImages(currentShopId);
      closeModal();
    } catch (error) {
      console.error("Error editing shop image:", error);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddShopImage = async () => {
    if (!formData.image_files || formData.image_files.length === 0) {
      setError("No images selected");
      return;
    }
    setIsLoading(true);
    try {
      const uploadResults = await Promise.allSettled(
        formData.image_files.map((file) => uploadToS3(file, "shops"))
      );
      const imageUrls = uploadResults
        .filter((result) => result.status === "fulfilled")
        .map((result) => result.value);
      const failedUploads = uploadResults.filter((result) => result.status === "rejected");
      if (failedUploads.length > 0) {
        throw new Error(`Failed to upload ${failedUploads.length} image(s)`);
      }

      console.log("Image URLs sent to /api/superadmin/shop-images:", imageUrls);

      for (const imageUrl of imageUrls) {
        const imageFormData = new FormData();
        imageFormData.append("shop_id", currentShopId);
        imageFormData.append("image_url", imageUrl);
        console.log("Sending imageFormData:", { shop_id: currentShopId, image_url: imageUrl });
        const imageRes = await fetch(`${BASE_URL}/api/superadmin/shop-images`, {
          method: "POST",
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
          body: imageFormData,
        });
        const imageData = await imageRes.json();
        console.log("Shop image response:", { status: imageRes.status, data: imageData });
        if (!imageRes.ok) {
          throw new Error(imageData.error || `Failed to add shop image: ${imageRes.statusText}`);
        }
      }

      await fetchShopImages(currentShopId);
      setFormData((prev) => ({ ...prev, image_files: [] }));
    } catch (error) {
      console.error("Error adding shop image:", error);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteShop = async (id) => {
    if (!window.confirm("Are you sure you want to delete this shop?")) return;
    setIsLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/shops/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `Failed to delete shop: ${res.statusText}`);
      }
      // Check if the current page will be empty after deletion
      const newTotal = pagination.total - 1;
      const newTotalPages = Math.ceil(newTotal / pagination.limit);
      let newPage = pagination.page;
      if (shops.length === 1 && pagination.page > 1) {
        newPage = pagination.page - 1; // Go to previous page if current page becomes empty
      }
      await fetchShops(newPage); // Fetch shops for the appropriate page
    } catch (error) {
      console.error("Error deleting shop:", error);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApproveShop = async (id) => {
    setIsLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/shops/${id}/approve`, {
        method: "PUT",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `Failed to approve shop: ${res.statusText}`);
      }
      await fetchShops(pagination.page); // Stay on current page
    } catch (error) {
      console.error("Error approving shop:", error);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteShopImage = async (id) => {
    setIsLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/shop-images/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `Failed to delete shop image: ${res.statusText}`);
      }
      await fetchShopImages(currentShopId);
    } catch (error) {
      console.error("Error deleting shop image:", error);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      setPagination((prev) => ({ ...prev, page: newPage }));
      fetchShops(newPage);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-900">
            {isCategoriesLoading ? "Loading..." : vendorId ? `Shops for Vendor ${vendors.find((v) => v.vendor_id === vendorId)?.business_name || "Unknown"}` : "Manage All Shops"}
          </h1>
          <button
            onClick={() => navigate("/vendors")}
            className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition duration-200"
          >
            Back to Vendors
          </button>
        </div>
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl border border-white/20 p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-700">Shops</h2>
            <button
              onClick={() => openModal("addShop")}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition duration-200"
            >
              Add Shop
            </button>
          </div>
          {error && (
            <div className="flex items-center space-x-2 p-4 rounded-xl border text-red-700 bg-red-50 border-red-200 mb-6">
              <XCircle className="w-5 h-5" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}
          {isLoading && (
            <div className="flex justify-center items-center">
              <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
          )}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-3 text-sm font-semibold text-gray-700">Shop Name</th>
                  <th className="p-3 text-sm font-semibold text-gray-700">Vendor</th>
                  <th className="p-3 text-sm font-semibold text-gray-700">Category</th>
                  <th className="p-3 text-sm font-semibold text-gray-700">Phone</th>
                  <th className="p-3 text-sm font-semibold text-gray-700">Status</th>
                  <th className="p-3 text-sm font-semibold text-gray-700">Actions</th>
                </tr>
              </thead>
              <tbody>
                {shops.map((shop) => (
                  <tr key={shop.shop_id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="p-3">{shop.shop_name}</td>
                    <td className="p-3">{vendors.find((v) => v.vendor_id === shop.vendor_id)?.business_name || "Unknown"}</td>
                    <td>{shop.category_name || "Unknown"}</td>
                    <td className="p-3">{shop.phone}</td>
                    <td className="p-3">
                      {shop.is_approved ? (
                        <span className="text-green-600">Approved</span>
                      ) : (
                        <span className="text-red-600">Pending</span>
                      )}
                    </td>
                    <td className="p-3 flex space-x-2">
                      <button
                        onClick={() => openModal("editShop", shop)}
                        className="p-2 text-blue-600 hover:bg-blue-100 rounded"
                      >
                        <Edit className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => handleDeleteShop(shop.shop_id)}
                        className="p-2 text-red-600 hover:bg-red-100 rounded"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => openModal("manageImages", shop)}
                        className="p-2 text-purple-600 hover:bg-purple-100 rounded"
                      >
                        <ImageIcon className="w-5 h-5" />
                      </button>
                      {!shop.is_approved && (
                        <button
                          onClick={() => handleApproveShop(shop.shop_id)}
                          className="p-2 text-green-600 hover:bg-green-100 rounded"
                        >
                          <Check className="w-5 h-5" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex justify-between items-center mt-4">
            <button
              onClick={() => handlePageChange(pagination.page - 1)}
              disabled={pagination.page === 1}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg disabled:opacity-50"
            >
              Previous
            </button>
            <span>
              Page {pagination.page} of {pagination.totalPages}
            </span>
            <button
              onClick={() => handlePageChange(pagination.page + 1)}
              disabled={pagination.page === pagination.totalPages}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg disabled:opacity-50"
            >
              Next
            </button>
          </div>
        </div>

        {modalType && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg max-w-lg w-full max-h-[80vh] overflow-y-auto">
              <div className="p-6">
                <h2 className="text-xl font-semibold mb-4">
                  {modalType === "addShop" ? "Add Shop" : modalType === "editShop" ? "Edit Shop" : modalType === "manageImages" ? "Manage Images" : "Edit Image"}
                </h2>
                {error && (
                  <div className="flex items-center space-x-2 p-4 rounded-lg border text-red-700 bg-red-50 border-red-200 mb-4">
                    <XCircle className="w-5 h-5" />
                    <span className="text-sm font-medium">{error}</span>
                  </div>
                )}
                {modalType === "addShop" || modalType === "editShop" ? (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      modalType === "addShop" ? handleAddShop() : handleEditShop();
                    }}
                    className="space-y-4"
                  >
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Category</label>
                      <select
                        name="top_category_id"
                        value={formData.top_category_id}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                        required
                      >
                        <option value="">Select Top-Level Category</option>
                        {categories.map((cat) => (
                          <option key={cat.category_id} value={cat.category_id}>
                            {cat.category_name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Subcategory</label>
                      <select
                        name="category_id"
                        value={formData.category_id}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                        required
                        disabled={!formData.top_category_id}
                      >
                        <option value="">Select Subcategory</option>
                        {subcategories.map((subcat) => (
                          <option key={subcat.category_id} value={subcat.category_id}>
                            {subcat.category_name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Vendor</label>
                      <select
                        name="vendor_id"
                        value={formData.vendor_id}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                        required
                        disabled={vendors.length === 0}
                      >
                        <option value="">Select Vendor</option>
                        {vendors.map((vendor) => (
                          <option key={vendor.vendor_id} value={vendor.vendor_id}>
                            {vendor.business_name} (ID: {vendor.vendor_id})
                          </option>
                        ))}
                      </select>
                      {vendors.length === 0 && (
                        <p className="text-sm text-red-600 mt-1">No vendors available. Please add a vendor first.</p>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Shop Name</label>
                      <input
                        type="text"
                        name="shop_name"
                        value={formData.shop_name}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Description</label>
                      <textarea
                        name="description"
                        value={formData.description}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                        rows="4"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Address</label>
                      <input
                        type="text"
                        name="address"
                        value={formData.address}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Location</label>
                      <input
                        type="text"
                        name="location"
                        value={formData.location}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Phone</label>
                      <input
                        type="text"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">WhatsApp Number</label>
                      <input
                        type="text"
                        name="whatsapp_number"
                        value={formData.whatsapp_number}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Email</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Website</label>
                      <input
                        type="text"
                        name="website"
                        value={formData.website}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Opening Time</label>
                      <input
                        type="time"
                        name="opening_time"
                        value={formData.opening_time}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Closing Time</label>
                      <input
                        type="time"
                        name="closing_time"
                        value={formData.closing_time}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Images</label>
                      <input
                        type="file"
                        name="image_files"
                        onChange={handleInputChange}
                        accept="image/*"
                        multiple
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                      {formData.image_files.length > 0 && (
                        <div className="mt-2">
                          {Array.from(formData.image_files).map((file, index) => (
                            <p key={index} className="text-sm text-gray-600">{file.name}</p>
                          ))}
                        </div>
                      )}
                      {formData.images.length > 0 && (
                        <div className="mt-2 flex flex-wrap gap-2">
                          {formData.images.map((image, index) => (
                            <img
                              key={index}
                              src={image.image_url}
                              alt={`Shop ${index}`}
                              className="h-16 w-16 object-cover rounded"
                            />
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="flex justify-end space-x-2">
                      <button
                        type="button"
                        onClick={closeModal}
                        className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition duration-200"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={isLoading}
                        className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition duration-200 disabled:opacity-50"
                      >
                        {isLoading ? (
                          <div className="flex items-center space-x-2">
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                            <span>{modalType === "addShop" ? "Adding..." : "Updating..."}</span>
                          </div>
                        ) : (
                          modalType === "addShop" ? "Add Shop" : "Update Shop"
                        )}
                      </button>
                    </div>
                  </form>
                ) : modalType === "manageImages" ? (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Add New Image</label>
                      <input
                        type="file"
                        name="image_files"
                        onChange={handleInputChange}
                        accept="image/*"
                        multiple
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                      {formData.image_files.length > 0 && (
                        <div className="mt-2">
                          {Array.from(formData.image_files).map((file, index) => (
                            <p key={index} className="text-sm text-gray-600">{file.name}</p>
                          ))}
                        </div>
                      )}
                      <button
                        onClick={handleAddShopImage}
                        disabled={isLoading}
                        className="mt-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition duration-200 disabled:opacity-50"
                      >
                        {isLoading ? (
                          <div className="flex items-center space-x-2">
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                            <span>Uploading...</span>
                          </div>
                        ) : (
                          "Upload Images"
                        )}
                      </button>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      {shopImages.map((image) => (
                        <div key={image.image_id} className="relative">
                          <img
                            src={image.image_url}
                            alt="Shop"
                            className="h-24 w-full object-cover rounded"
                          />
                          <div className="absolute top-0 right-0 flex space-x-1">
                            <button
                              onClick={() => openModal("editShopImage", { ...image, shop_id: currentShopId })}
                              className="p-1 bg-blue-600 text-white rounded"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteShopImage(image.image_id)}
                              className="p-1 bg-red-600 text-white rounded"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-end">
                      <button
                        onClick={closeModal}
                        className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition duration-200"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Update Image</label>
                      <input
                        type="file"
                        name="image_file"
                        onChange={handleInputChange}
                        accept="image/*"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                      {formData.image_file && (
                        <p className="text-sm text-gray-600 mt-2">{formData.image_file.name}</p>
                      )}
                    </div>
                    <div className="flex justify-end space-x-2">
                      <button
                        onClick={closeModal}
                        className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition duration-200"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleEditShopImage}
                        disabled={isLoading}
                        className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition duration-200 disabled:opacity-50"
                      >
                        {isLoading ? (
                          <div className="flex items-center space-x-2">
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                            <span>Updating...</span>
                          </div>
                        ) : (
                          "Update Image"
                        )}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AllShopsPage;