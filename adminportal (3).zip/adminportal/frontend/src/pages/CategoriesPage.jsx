import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { BASE_URL } from "../config";
import uploadToS3 from "../services/uploadToS3";

class ErrorBoundary extends React.Component {
  state = { hasError: false, error: null };

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-6 text-red-600">
          <h2>Something went wrong</h2>
          <p>{this.state.error?.message || "An unexpected error occurred"}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 p-2 bg-blue-600 text-white rounded-lg"
          >
            Reload Page
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

const CategoriesPage = () => {
  const [categories, setCategories] = useState([]);
  const [modalType, setModalType] = useState(null);
  const [formData, setFormData] = useState({ image_file: null, icon_file: null });
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const fetchCategories = async () => {
    setIsLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/categories?topLevel=true`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || `Failed to fetch top-level categories: ${res.statusText}`);
      }
      const data = await res.json();
      console.log("Fetched top-level categories:", data.categories);
      // Client-side filter as a safeguard to ensure only top-level categories
      const topLevelCategories = (data.categories || []).filter(
        (cat) => cat.parent_category_id === null
      );
      if (data.categories.length !== topLevelCategories.length) {
        console.warn(
          `Backend returned ${data.categories.length} categories, but only ${topLevelCategories.length} are top-level (parent_category_id IS NULL)`
        );
      }
      setCategories(topLevelCategories);
      setError(null);
    } catch (error) {
      console.error("Error fetching top-level categories:", error);
      setError(error.message);
      setCategories([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const handleInputChange = (e) => {
    const { name, value, files } = e.target;
    if (files) {
      if (files.length > 0) {
        const file = files[0];
        if (file.size > 5 * 1024 * 1024) {
          setError("File size exceeds 5MB limit");
          return;
        }
        if (!file.type.startsWith("image/")) {
          setError("Please select an image file");
          return;
        }
        console.log(`${name} selected:`, file.name, file.size, file.type);
        setFormData((prev) => ({
          ...prev,
          [name]: file,
        }));
      } else {
        setFormData((prev) => ({
          ...prev,
          [name]: null,
        }));
      }
    } else {
      setFormData((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  const openModal = (type, data = {}) => {
    setModalType(type);
    setFormData({
      ...data,
      image_file: null,
      icon_file: null,
      category_name: data.category_name || "",
      description: data.description || "",
      image_url: data.image_url || "",
      icon_url: data.icon_url || "",
      parent_category_id: null, // Ensure new categories are top-level
    });
    setError(null);
  };

  const closeModal = () => {
    setModalType(null);
    setFormData({ image_file: null, icon_file: null });
    setError(null);
  };

  const handleDeleteCategory = async (id) => {
    if (!window.confirm("Are you sure you want to delete this category?")) return;
    setIsLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/categories/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || `Failed to delete category: ${res.statusText}`);
      }
      await fetchCategories();
      setError(null);
    } catch (error) {
      console.error("Error deleting category:", error);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddCategory = async () => {
    if (!formData.category_name) {
      setError("Category name is required");
      return;
    }
    setIsLoading(true);
    try {
      let imageUrl = "";
      let iconUrl = "";
      if (formData.image_file) {
        console.log("Uploading image file:", formData.image_file.name);
        imageUrl = await uploadToS3(formData.image_file, "categories");
        if (!imageUrl || typeof imageUrl !== "string") {
          throw new Error("Failed to upload image file");
        }
        console.log("Image uploaded, URL:", imageUrl);
      }
      if (formData.icon_file) {
        console.log("Uploading icon file:", formData.icon_file.name);
        iconUrl = await uploadToS3(formData.icon_file, "categories/icons");
        if (!iconUrl || typeof iconUrl !== "string") {
          throw new Error("Failed to upload icon file");
        }
        console.log("Icon uploaded, URL:", iconUrl);
      }

      const formDataToSend = new FormData();
      formDataToSend.append("category_name", formData.category_name || "");
      formDataToSend.append("description", formData.description || "");
      formDataToSend.append("parent_category_id", ""); // Explicitly set to empty string for top-level
      if (imageUrl) {
        formDataToSend.append("image_url", imageUrl);
        console.log("Appending image_url:", imageUrl);
      }
      if (iconUrl) {
        formDataToSend.append("icon_url", iconUrl);
        console.log("Appending icon_url:", iconUrl);
      }

      console.log("FormData to send:");
      for (let [key, value] of formDataToSend.entries()) {
        console.log(`  ${key}: ${value}`);
      }

      let res = await fetch(`${BASE_URL}/api/superadmin/categories`, {
        method: "POST",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        body: formDataToSend,
        keepalive: true,
      });

      if (!res.ok) {
        const errorData = await res.json();
        console.error("FormData request failed:", errorData);
        const jsonPayload = {
          category_name: formData.category_name || "",
          description: formData.description || "",
          parent_category_id: null, // Ensure top-level
          image_url: imageUrl || "",
          icon_url: iconUrl || "",
        };
        console.log("JSON payload:", jsonPayload);
        res = await fetch(`${BASE_URL}/api/superadmin/categories`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(jsonPayload),
        });
        if (!res.ok) {
          const errorData = await res.json();
          throw new Error(errorData.error || `Failed to create category: ${res.statusText}`);
        }
      }

      const responseData = await res.json();
      console.log("Category created:", responseData);
      await fetchCategories();
      closeModal();
    } catch (error) {
      console.error("Error adding category:", error);
      setError(error.message || "Failed to create category");
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditCategory = async () => {
    if (!formData.category_name) {
      setError("Category name is required");
      return;
    }
    setIsLoading(true);
    try {
      let imageUrl = formData.image_url || "";
      let iconUrl = formData.icon_url || "";
      if (formData.image_file) {
        console.log("Uploading image file:", formData.image_file.name);
        imageUrl = await uploadToS3(formData.image_file, "categories");
        if (!imageUrl || typeof imageUrl !== "string") {
          throw new Error("Failed to upload image file");
        }
        console.log("Image uploaded, URL:", imageUrl);
      }
      if (formData.icon_file) {
        console.log("Uploading icon file:", formData.icon_file.name);
        iconUrl = await uploadToS3(formData.icon_file, "categories/icons");
        if (!iconUrl || typeof iconUrl !== "string") {
          throw new Error("Failed to upload icon file");
        }
        console.log("Icon uploaded, URL:", iconUrl);
      }

      const formDataToSend = new FormData();
      formDataToSend.append("category_name", formData.category_name || "");
      formDataToSend.append("description", formData.description || "");
      formDataToSend.append("parent_category_id", ""); // Ensure remains top-level
      if (imageUrl) {
        formDataToSend.append("image_url", imageUrl);
        console.log("Appending image_url:", imageUrl);
      }
      if (iconUrl) {
        formDataToSend.append("icon_url", iconUrl);
        console.log("Appending icon_url:", iconUrl);
      }

      console.log("FormData to send:");
      for (let [key, value] of formDataToSend.entries()) {
        console.log(`  ${key}: ${value}`);
      }

      let res = await fetch(`${BASE_URL}/api/superadmin/categories/${formData.category_id}`, {
        method: "PUT",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        body: formDataToSend,
        keepalive: true,
      });

      if (!res.ok) {
        const errorData = await res.json();
        console.error("FormData request failed:", errorData);
        console.log("Attempting JSON fallback...");
        const jsonPayload = {
          category_name: formData.category_name || "",
          description: formData.description || "",
          parent_category_id: null, // Ensure remains top-level
          image_url: imageUrl || "",
          icon_url: iconUrl || "",
        };
        console.log("JSON payload:", jsonPayload);
        res = await fetch(`${BASE_URL}/api/superadmin/categories/${formData.category_id}`, {
          method: "PUT",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(jsonPayload),
        });
        if (!res.ok) {
          const errorData = await res.json();
          throw new Error(errorData.error || `Failed to update category: ${res.statusText}`);
        }
      }

      const responseData = await res.json();
      console.log("Category updated:", responseData);
      await fetchCategories();
      closeModal();
    } catch (error) {
      console.error("Error editing category:", error);
      setError(error.message || "Failed to update category");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ErrorBoundary>
      <div className="space-y-6 p-6">
        <h1 className="text-3xl font-bold text-gray-900">Top-Level Categories</h1>
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-800">Categories</h2>
            <button
              onClick={() => openModal("addCategory")}
              className="p-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200"
            >
              Add Top-Level Category
            </button>
          </div>
          {error && <p className="text-red-600 text-sm mb-4">{error}</p>}
          {isLoading ? (
            <div className="flex justify-center">
              <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : categories.length === 0 ? (
            <p className="text-gray-600">No top-level categories available</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {categories.map((category) => (
                <div key={category.category_id} className="p-4 border border-gray-200 rounded-lg">
                  <h3 className="text-lg font-medium text-gray-900">{category.category_name}</h3>
                  <p className="text-sm text-gray-600">{category.description}</p>
                  {category.image_url ? (
                    <img
                      src={category.image_url}
                      alt={category.category_name}
                      className="h-16 w-16 object-cover rounded mt-2"
                      onError={(e) => console.error("Image load error:", category.image_url, e)}
                    />
                  ) : (
                    <p className="text-sm text-gray-600 mt-2">No image available</p>
                  )}
                  {category.icon_url ? (
                    <img
                      src={category.icon_url}
                      alt={`${category.category_name} icon`}
                      className="h-8 w-8 object-cover rounded mt-2"
                      onError={(e) => console.error("Icon load error:", category.icon_url, e)}
                    />
                  ) : (
                    <p className="text-sm text-gray-600 mt-2">No icon available</p>
                  )}
                  <div className="mt-4 flex space-x-2">
                    <button
                      onClick={() => navigate(`/subcategories/${category.category_id}`)}
                      className="p-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200"
                    >
                      View Subcategories
                    </button>
                    <button
                      onClick={() => openModal("editCategory", category)}
                      className="p-2 bg-yellow-100 text-yellow-700 rounded-lg hover:bg-yellow-200"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDeleteCategory(category.category_id)}
                      className="p-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        {modalType && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                {modalType === "addCategory" ? "Add Top-Level Category" : "Edit Top-Level Category"}
              </h2>
              {isLoading && (
                <div className="flex justify-center mb-4">
                  <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Category Name</label>
                  <input
                    type="text"
                    name="category_name"
                    value={formData.category_name || ""}
                    onChange={handleInputChange}
                    className="mt-1 p-2 w-full border rounded-lg"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Description</label>
                  <textarea
                    name="description"
                    value={formData.description || ""}
                    onChange={handleInputChange}
                    className="mt-1 p-2 w-full border rounded-lg"
                    rows="4"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Image File</label>
                  <input
                    type="file"
                    name="image_file"
                    accept="image/*"
                    onChange={(e) => {
                      console.log("Image file selected:", e.target.files);
                      handleInputChange(e);
                    }}
                    className="mt-1 p-2 w-full border rounded-lg"
                  />
                  {formData.image_file && (
                    <p className="text-sm text-gray-600 mt-2">Selected: {formData.image_file.name}</p>
                  )}
                  {formData.image_url && !formData.image_file && (
                    <p className="text-sm text-gray-600 mt-2">Current: {formData.image_url}</p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Icon File</label>
                  <input
                    type="file"
                    name="icon_file"
                    accept="image/*"
                    onChange={(e) => {
                      console.log("Icon file selected:", e.target.files);
                      handleInputChange(e);
                    }}
                    className="mt-1 p-2 w-full border rounded-lg"
                  />
                  {formData.icon_file && (
                    <p className="text-sm text-gray-600 mt-2">Selected: {formData.icon_file.name}</p>
                  )}
                  {formData.icon_url && !formData.icon_file && (
                    <p className="text-sm text-gray-600 mt-2">Current: {formData.icon_url}</p>
                  )}
                </div>
                {error && <p className="text-red-600 text-sm">{error}</p>}
                <div className="flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={closeModal}
                    disabled={isLoading}
                    className="p-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={modalType === "addCategory" ? handleAddCategory : handleEditCategory}
                    disabled={isLoading}
                    className="p-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 disabled:opacity-50"
                  >
                    {isLoading ? "Saving..." : "Save"}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
};

export default CategoriesPage;