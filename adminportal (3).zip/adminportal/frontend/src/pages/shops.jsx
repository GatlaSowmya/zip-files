import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { XCircle, CheckCircle, Edit, Trash, Plus, Image as ImageIcon } from "lucide-react";
import { BASE_URL } from "../config";
import uploadToS3 from "../services/uploadToS3";
import sanitizeHtml from "sanitize-html";

const Shops = () => {
  const [shops, setShops] = useState([]);
  const [categoryName, setCategoryName] = useState("");
  const [topCategories, setTopCategories] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isVendorsLoading, setIsVendorsLoading] = useState(false);
  const [pagination, setPagination] = useState({ page: 1, limit: 10, total: 0, totalPages: 1 });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState(null);
  const [currentShopId, setCurrentShopId] = useState(null);
  const [shopImages, setShopImages] = useState([]);
  const [formData, setFormData] = useState({
    top_category_id: "",
    category_id: "",
    vendor_id: "",
    shop_name: "",
    description: "",
    address: "",
    location: "",
    phone: "",
    whatsapp_number: "",
    email: "",
    website: "",
    opening_time: "",
    closing_time: "",
    image_files: [],
    images: [],
    shop_id: null,
    image_file: null,
    image_id: null,
  });
  const navigate = useNavigate();
  const { categoryId } = useParams();

  // Fetch top-level categories
  const fetchTopCategories = async () => {
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/categories?topLevel=true`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to fetch top-level categories");
      }
      const data = await res.json();
      setTopCategories(data.categories || []);
    } catch (error) {
      console.error("Fetch top categories error:", error.message);
      setError(error.message);
      setTopCategories([]);
    }
  };

  // Fetch subcategories
  const fetchSubcategories = async (topCategoryId) => {
    if (!topCategoryId) {
      setSubcategories([]);
      return;
    }
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/subcategories?category_id=${topCategoryId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to fetch subcategories");
      }
      const data = await res.json();
      setSubcategories(data.subcategories || []);
    } catch (error) {
      console.error("Fetch subcategories error:", error.message);
      setError(error.message);
      setSubcategories([]);
    }
  };

  // Fetch category name
  const fetchCategoryName = async (categoryId) => {
    if (!categoryId) {
      setCategoryName("");
      return;
    }
    try {
      const url = `${BASE_URL}/api/superadmin/categories/${categoryId}`;
      const token = localStorage.getItem("token");
      const res = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Failed to fetch category");
      }
      const data = await res.json();
      setCategoryName(data.category.category_name || "Unknown Category");
      if (data.category.parent_category_id) {
        setFormData((prev) => ({ ...prev, top_category_id: data.category.parent_category_id }));
        fetchSubcategories(data.category.parent_category_id);
      }
    } catch (error) {
      console.error("Fetch category name error:", error.message);
      setError(error.message);
      setCategoryName("Unknown Category");
    }
  };

  // Fetch vendors
  const fetchVendors = async () => {
  setIsVendorsLoading(true);
  try {
    const res = await fetch(`${BASE_URL}/api/vendor/vendors`, {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    });
    if (!res.ok) {
      const data = await res.json();
      throw new Error(data.error || "Failed to fetch vendors");
    }
    const data = await res.json();
    const vendors = data.vendors || [];
    console.log("Fetched vendors (raw):", vendors); // Log raw data
    // Normalize vendor_id (handle both `vendor_id` and `id`)
    const normalizedVendors = vendors.map((vendor) => ({
      ...vendor,
      vendor_id: vendor.vendor_id || vendor.id,
    }));
    // Validate vendor_id (ensure it’s a non-empty string)
    const validVendors = normalizedVendors.filter((vendor) => {
      if (!vendor.vendor_id || typeof vendor.vendor_id !== "string") {
        console.warn(`Invalid vendor_id format: ${vendor.vendor_id}`);
        return false;
      }
      return true;
    });
    if (validVendors.length === 0) {
      console.warn("No valid vendors found after filtering");
      setError("No valid vendors available. Please add a vendor first.");
    }
    setVendors(validVendors);
    if (validVendors.length > 0 && (!formData.vendor_id || !validVendors.find((v) => v.vendor_id === formData.vendor_id))) {
      setFormData((prev) => ({ ...prev, vendor_id: validVendors[0].vendor_id }));
    }
  } catch (error) {
    console.error("Fetch vendors error:", error.message);
    setError("Failed to load vendors. Please ensure you are logged in as a superadmin.");
    setVendors([]);
  } finally {
    setIsVendorsLoading(false);
  }
};
  // Fetch shops
  const fetchShops = async (categoryId, page = 1, limit = 10) => {
    setIsLoading(true);
    setError(null);
    setMessage("");
    try {
      let url = `${BASE_URL}/api/superadmin/shops?page=${page}&limit=${limit}`;
      if (categoryId) url += `&category_id=${categoryId}`;
      const token = localStorage.getItem("token");
      const res = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Failed to fetch shops");
      }
      const data = await res.json();
      setShops(data.shops || []);
      setPagination(data.pagination || { page: 1, limit: 10, total: 0, totalPages: 1 });
      if (data.shops.length === 0) {
        setMessage("No shops found for this category or subcategory.");
      }
    } catch (error) {
      console.error("Fetch shops error:", error.message);
      setError(error.message);
      setShops([]);
      setPagination({ page: 1, limit: 10, total: 0, totalPages: 1 });
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch shop images
  const fetchShopImages = async (shopId) => {
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/shop-images?shop_id=${shopId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to fetch shop images");
      }
      const data = await res.json();
      setShopImages(data.shop_images || []);
    } catch (error) {
      console.error("Fetch shop images error:", error.message);
      setError(error.message);
    }
  };

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value, type, files } = e.target;
    const sanitizedValue = type !== "file" && name !== "vendor_id" ? sanitizeHtml(value, { allowedTags: [], allowedAttributes: {} }) : value;
    console.log(`Input changed: ${name} = ${sanitizedValue}`);
    setFormData((prev) => {
      const newFormData = {
        ...prev,
        [name]: type === "file" ? (name === "image_file" ? files[0] : [...files]) : sanitizedValue,
      };
      if (name === "top_category_id") {
        newFormData.category_id = "";
        fetchSubcategories(sanitizedValue);
      }
      return newFormData;
    });
  };

  // Validate form
  const validateForm = () => {
  if (!formData.category_id) return "Subcategory is required";
  if (!formData.vendor_id) return "Vendor is required";
  if (!vendors.find((vendor) => vendor.vendor_id === formData.vendor_id)) return "Selected vendor is invalid or does not exist";
  if (!formData.shop_name) return "Shop name is required";
  if (!formData.phone) return "Phone number is required";
  if (!/^\d{10}$/.test(formData.phone)) return "Phone number must be 10 digits";
  if (formData.whatsapp_number && !/^\d{10}$/.test(formData.whatsapp_number)) return "WhatsApp number must be 10 digits";
  if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) return "Invalid email format";
  if (formData.website && !isValidUrl(formData.website)) return "Invalid website URL";
  if (!subcategories.find((cat) => cat.category_id === formData.category_id)) return "Selected subcategory is invalid";
  return null;
};

  const isValidUrl = (url) => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  };

  // Create shop
  const handleCreateShop = async (e) => {
    e.preventDefault();
    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      return;
    }
    setIsLoading(true);
    try {
      console.log("Creating shop with formData:", formData);
      const formDataToSend = new FormData();
      formDataToSend.append("category_id", formData.category_id);
      formDataToSend.append("vendor_id", formData.vendor_id);
      formDataToSend.append("shop_name", formData.shop_name);
      formDataToSend.append("description", formData.description || "");
      formDataToSend.append("address", formData.address || "");
      formDataToSend.append("location", formData.location || "");
      formDataToSend.append("phone", formData.phone);
      formDataToSend.append("whatsapp_number", formData.whatsapp_number || "");
      formDataToSend.append("email", formData.email || "");
      formDataToSend.append("website", formData.website || "");
      formDataToSend.append("opening_time", formData.opening_time || "");
      formDataToSend.append("closing_time", formData.closing_time || "");

      const res = await fetch(`${BASE_URL}/api/superadmin/shops`, {
        method: "POST",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        body: formDataToSend,
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || `Failed to create shop: ${res.statusText}`);
      }
      const shopId = data.shop.shop_id;

      if (formData.image_files && formData.image_files.length > 0) {
        const imageUrls = await Promise.all(
          formData.image_files.map((file) => uploadToS3(file, "shops"))
        );
        for (const imageUrl of imageUrls) {
          const imageFormData = new FormData();
          imageFormData.append("shop_id", shopId);
          imageFormData.append("image_url", imageUrl);
          const imageRes = await fetch(`${BASE_URL}/api/superadmin/shop-images`, {
            method: "POST",
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
            body: imageFormData,
          });
          if (!imageRes.ok) {
            const imageData = await imageRes.json();
            throw new Error(imageData.error || `Failed to add shop image: ${imageRes.statusText}`);
          }
        }
      }

      setMessage("Shop created successfully");
      setIsModalOpen(false);
      fetchShops(categoryId);
    } catch (error) {
      console.error("Create shop error:", error.message);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Update shop
  const handleUpdateShop = async (e) => {
    e.preventDefault();
    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      return;
    }
    setIsLoading(true);
    try {
      console.log("Updating shop with formData:", formData);
      const formDataToSend = new FormData();
      formDataToSend.append("category_id", formData.category_id);
      formDataToSend.append("vendor_id", formData.vendor_id);
      formDataToSend.append("shop_name", formData.shop_name);
      formDataToSend.append("description", formData.description || "");
      formDataToSend.append("address", formData.address || "");
      formDataToSend.append("location", formData.location || "");
      formDataToSend.append("phone", formData.phone);
      formDataToSend.append("whatsapp_number", formData.whatsapp_number || "");
      formDataToSend.append("email", formData.email || "");
      formDataToSend.append("website", formData.website || "");
      formDataToSend.append("opening_time", formData.opening_time || "");
      formDataToSend.append("closing_time", formData.closing_time || "");

      const res = await fetch(`${BASE_URL}/api/superadmin/shops/${formData.shop_id}`, {
        method: "PUT",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        body: formDataToSend,
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `Failed to update shop: ${res.statusText}`);
      }

      if (formData.image_files && formData.image_files.length > 0) {
        const imageUrls = await Promise.all(
          formData.image_files.map((file) => uploadToS3(file, "shops"))
        );
        for (const imageUrl of imageUrls) {
          const imageFormData = new FormData();
          imageFormData.append("shop_id", formData.shop_id);
          imageFormData.append("image_url", imageUrl);
          const imageRes = await fetch(`${BASE_URL}/api/superadmin/shop-images`, {
            method: "POST",
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
            body: imageFormData,
          });
          if (!imageRes.ok) {
            const imageData = await imageRes.json();
            throw new Error(imageData.error || `Failed to add shop image: ${imageRes.statusText}`);
          }
        }
      }

      setMessage("Shop updated successfully");
      setIsModalOpen(false);
      fetchShops(categoryId);
    } catch (error) {
      console.error("Update shop error:", error.message);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Delete shop
  const handleDeleteShop = async (shopId) => {
    if (!window.confirm("Are you sure you want to delete this shop?")) return;
    setIsLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/shops/${shopId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `Failed to delete shop: ${res.statusText}`);
      }
      setMessage("Shop deleted successfully");
      fetchShops(categoryId);
    } catch (error) {
      console.error("Delete shop error:", error.message);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Approve shop
  const handleApproveShop = async (shopId) => {
    setIsLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/shops/${shopId}/approve`, {
        method: "PUT",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `Failed to approve shop: ${res.statusText}`);
      }
      setMessage("Shop approved successfully");
      fetchShops(categoryId);
    } catch (error) {
      console.error("Approve shop error:", error.message);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Add shop image
  const handleAddShopImage = async () => {
    if (!formData.image_files || formData.image_files.length === 0) {
      setError("No images selected");
      return;
    }
    setIsLoading(true);
    try {
      const imageUrls = await Promise.all(
        formData.image_files.map((file) => uploadToS3(file, "shops"))
      );
      for (const imageUrl of imageUrls) {
        const imageFormData = new FormData();
        imageFormData.append("shop_id", currentShopId);
        imageFormData.append("image_url", imageUrl);
        const imageRes = await fetch(`${BASE_URL}/api/superadmin/shop-images`, {
          method: "POST",
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
          body: imageFormData,
        });
        if (!imageRes.ok) {
          const imageData = await imageRes.json();
          throw new Error(imageData.error || `Failed to add shop image: ${imageRes.statusText}`);
        }
      }
      await fetchShopImages(currentShopId);
      setFormData((prev) => ({ ...prev, image_files: [] }));
    } catch (error) {
      console.error("Add shop image error:", error.message);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Edit shop image
  const handleEditShopImage = async () => {
    if (!formData.image_file) {
      setError("Image file is required");
      return;
    }
    setIsLoading(true);
    try {
      const imageUrl = await uploadToS3(formData.image_file, "shops");
      const imageFormData = new FormData();
      imageFormData.append("image_url", imageUrl);
      const res = await fetch(`${BASE_URL}/api/superadmin/shop-images/${formData.image_id}`, {
        method: "PUT",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        body: imageFormData,
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `Failed to update shop image: ${res.statusText}`);
      }
      await fetchShopImages(currentShopId);
      setIsModalOpen(false);
    } catch (error) {
      console.error("Edit shop image error:", error.message);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Delete shop image
  const handleDeleteShopImage = async (imageId) => {
    setIsLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/shop-images/${imageId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `Failed to delete shop image: ${res.statusText}`);
      }
      await fetchShopImages(currentShopId);
    } catch (error) {
      console.error("Delete shop image error:", error.message);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Open modal
  const openModal = (type, shop = {}) => {
    console.log("Opening modal with shop:", shop);
    setModalType(type);
    setFormData({
      top_category_id: shop.parent_category_id || formData.top_category_id || "",
      category_id: shop.category_id || categoryId || "",
      vendor_id: shop.vendor_id || (vendors.length > 0 ? vendors[0].vendor_id : ""),
      shop_name: shop.shop_name || "",
      description: shop.description || "",
      address: shop.address || "",
      location: shop.location || "",
      phone: shop.phone || "",
      whatsapp_number: shop.whatsapp_number || "",
      email: shop.email || "",
      website: shop.website || "",
      opening_time: shop.opening_time || "",
      closing_time: shop.closing_time || "",
      image_files: [],
      images: shop.images || [],
      shop_id: shop.shop_id || null,
      image_file: null,
      image_id: shop.image_id || null,
    });
    if (type === "manageImages") {
      setCurrentShopId(shop.shop_id);
      fetchShopImages(shop.shop_id);
    } else if (type === "editShopImage") {
      setCurrentShopId(shop.shop_id);
    } else if (type === "editShop" && shop.category_id) {
      const subcategory = subcategories.find((cat) => cat.category_id === shop.category_id);
      if (subcategory && subcategory.parent_category_id) {
        setFormData((prev) => ({ ...prev, top_category_id: subcategory.parent_category_id }));
        fetchSubcategories(subcategory.parent_category_id);
      }
    }
    setIsModalOpen(true);
    setError(null);
  };

  // Close modal
  const closeModal = () => {
    setIsModalOpen(false);
    setModalType(null);
    setFormData({
      top_category_id: "",
      category_id: categoryId || "",
      vendor_id: vendors.length > 0 ? vendors[0].vendor_id : "",
      shop_name: "",
      description: "",
      address: "",
      location: "",
      phone: "",
      whatsapp_number: "",
      email: "",
      website: "",
      opening_time: "",
      closing_time: "",
      image_files: [],
      images: [],
      shop_id: null,
      image_file: null,
      image_id: null,
    });
    setShopImages([]);
    setCurrentShopId(null);
    setSubcategories([]);
  };

  // Fetch data on mount
  useEffect(() => {
    fetchTopCategories();
    fetchCategoryName(categoryId);
    fetchShops(categoryId);
    fetchVendors();
  }, [categoryId]);

  // Handle page change
  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      fetchShops(categoryId, newPage, pagination.limit);
    }
  };

  // Handle image error
  const handleImageError = (e) => {
    console.error("Failed to load image:", e.target.src);
    e.target.src = "https://via.placeholder.com/64?text=No+Image";
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">
          {categoryName ? `Shops in ${categoryName}` : "Manage Shops"}
        </h1>
        <button
          onClick={() => openModal("addShop")}
          className="p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center space-x-2"
          disabled={isLoading || isVendorsLoading || vendors.length === 0}
        >
          <Plus className="w-5 h-5" />
          <span>Add Shop</span>
        </button>
      </div>
      <div className="bg-white rounded-lg shadow-sm p-6">
        {error && (
          <div className="flex items-center space-x-2 p-4 rounded-xl border text-red-700 bg-red-50 border-red-200 mb-4">
            <XCircle className="w-5 h-5" />
            <span className="text-sm font-medium">{error}</span>
          </div>
        )}
        {message && (
          <div className="flex items-center space-x-2 p-4 rounded-xl border text-gray-700 bg-gray-50 border-gray-200 mb-4">
            <CheckCircle className="w-5 h-5" />
            <span className="text-sm font-medium">{message}</span>
          </div>
        )}
        {isLoading ? (
          <div className="flex items-center justify-center space-x-2">
            <div className="w-5 h-5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
            <span>Loading shops...</span>
          </div>
        ) : shops.length === 0 ? (
          <p className="text-gray-600">{message || "No shops available."}</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {shops.map((shop) => (
              <div key={shop.shop_id} className="p-4 border border-gray-200 rounded-lg">
                <h3 className="text-lg font-medium text-gray-900">{shop.shop_name}</h3>
                <p className="text-sm text-gray-600">Category: {shop.category_name || "None"}</p>
                <p className="text-sm text-gray-600">Vendor: {vendors.find((v) => v.vendor_id === shop.vendor_id)?.business_name || "Unknown"}</p>
                <p className="text-sm text-gray-600">Phone: {shop.phone}</p>
                <p className="text-sm text-gray-600">Status: {shop.is_approved ? "Approved" : "Pending"}</p>
                {shop.address && <p className="text-sm text-gray-600">Address: {shop.address}</p>}
                {shop.images && shop.images.length > 0 && shop.images[0].image_url && (
                  <img
                    src={shop.images[0].image_url}
                    alt={`${shop.shop_name} image`}
                    className="h-16 w-16 object-cover rounded mt-2"
                    onError={handleImageError}
                  />
                )}
                <div className="mt-4 flex space-x-2">
                  <button
                    onClick={() => navigate(`/services?shop_id=${shop.shop_id}`)}
                    className="p-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200"
                  >
                    View Services
                  </button>
                  <button
                    onClick={() => openModal("editShop", shop)}
                    className="p-2 bg-yellow-100 text-yellow-700 rounded-lg hover:bg-yellow-200"
                  >
                    <Edit className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleDeleteShop(shop.shop_id)}
                    className="p-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200"
                  >
                    <Trash className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => openModal("manageImages", shop)}
                    className="p-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200"
                  >
                    <ImageIcon className="w-5 h-5" />
                  </button>
                  {!shop.is_approved && (
                    <button
                      onClick={() => handleApproveShop(shop.shop_id)}
                      className="p-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200"
                    >
                      <CheckCircle className="w-5 h-5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
        {shops.length > 0 && (
          <div className="mt-6 flex justify-center space-x-2">
            <button
              onClick={() => handlePageChange(pagination.page - 1)}
              disabled={pagination.page === 1}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 disabled:opacity-50"
            >
              Previous
            </button>
            <span className="px-4 py-2 text-gray-800">
              Page {pagination.page} of {pagination.totalPages}
            </span>
            <button
              onClick={() => handlePageChange(pagination.page + 1)}
              disabled={pagination.page === pagination.totalPages}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 disabled:opacity-50"
            >
              Next
            </button>
          </div>
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[80vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">
              {modalType === "addShop" ? "Add New Shop" : modalType === "editShop" ? "Edit Shop" : "Manage Images"}
            </h2>
            {error && (
              <div className="flex items-center space-x-2 p-4 rounded-xl border text-red-700 bg-red-50 border-red-200 mb-4">
                <XCircle className="w-5 h-5" />
                <span className="text-sm font-medium">{error}</span>
              </div>
            )}
            {modalType === "addShop" || modalType === "editShop" ? (
              <form
                onSubmit={modalType === "addShop" ? handleCreateShop : handleUpdateShop}
                className="space-y-4"
              >
                <div>
                  <label className="block text-sm font-medium text-gray-700">Top-Level Category</label>
                  <select
                    name="top_category_id"
                    value={formData.top_category_id}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                    required
                  >
                    <option value="">Select Top-Level Category</option>
                    {topCategories.map((cat) => (
                      <option key={cat.category_id} value={cat.category_id}>
                        {cat.category_name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Subcategory</label>
                  <select
                    name="category_id"
                    value={formData.category_id}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                    required
                    disabled={!formData.top_category_id}
                  >
                    <option value="">Select Subcategory</option>
                    {subcategories.map((subcat) => (
                      <option key={subcat.category_id} value={subcat.category_id}>
                        {subcat.category_name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Vendor</label>
                  <select
                    name="vendor_id"
                    value={formData.vendor_id}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                    required
                    disabled={isVendorsLoading || vendors.length === 0}
                  >
                    <option value="">Select Vendor</option>
                    {vendors.map((vendor) => (
                      <option key={vendor.vendor_id} value={vendor.vendor_id}>
                        {vendor.business_name}
                      </option>
                    ))}
                  </select>
                  {isVendorsLoading && <p className="text-sm text-gray-600 mt-1">Loading vendors...</p>}
                  {vendors.length === 0 && !isVendorsLoading && (
                    <p className="text-sm text-red-600 mt-1">No vendors available. Please add a vendor first.</p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Shop Name</label>
                  <input
                    type="text"
                    name="shop_name"
                    value={formData.shop_name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Description</label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Address</label>
                  <input
                    type="text"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Location</label>
                  <input
                    type="text"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Phone</label>
                  <input
                    type="text"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">WhatsApp Number</label>
                  <input
                    type="text"
                    name="whatsapp_number"
                    value={formData.whatsapp_number}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Website</label>
                  <input
                    type="text"
                    name="website"
                    value={formData.website}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Opening Time</label>
                  <input
                    type="time"
                    name="opening_time"
                    value={formData.opening_time}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Closing Time</label>
                  <input
                    type="time"
                    name="closing_time"
                    value={formData.closing_time}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Images</label>
                  <input
                    type="file"
                    name="image_files"
                    onChange={handleInputChange}
                    accept="image/*"
                    multiple
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  />
                  {formData.image_files.length > 0 && (
                    <div className="mt-2">
                      {Array.from(formData.image_files).map((file, index) => (
                        <p key={index} className="text-sm text-gray-600">{file.name}</p>
                      ))}
                    </div>
                  )}
                  {formData.images.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {formData.images.map((image, index) => (
                        <img
                          key={index}
                          src={image.image_url}
                          alt={`Shop ${index}`}
                          className="h-16 w-16 object-cover rounded"
                        />
                      ))}
                    </div>
                  )}
                </div>
                <div className="flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={closeModal}
                    className="p-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isLoading || isVendorsLoading || !formData.vendor_id}
                    className="p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50"
                  >
                    {isLoading ? "Processing..." : modalType === "addShop" ? "Create Shop" : "Update Shop"}
                  </button>
                </div>
              </form>
            ) : (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Add New Image</label>
                  <input
                    type="file"
                    name="image_files"
                    onChange={handleInputChange}
                    accept="image/*"
                    multiple
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  />
                  {formData.image_files.length > 0 && (
                    <div className="mt-2">
                      {Array.from(formData.image_files).map((file, index) => (
                        <p key={index} className="text-sm text-gray-600">{file.name}</p>
                      ))}
                    </div>
                  )}
                  <button
                    onClick={handleAddShopImage}
                    disabled={isLoading}
                    className="mt-2 p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50"
                  >
                    {isLoading ? "Uploading..." : "Upload Images"}
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {shopImages.map((image) => (
                    <div key={image.image_id} className="relative">
                      <img
                        src={image.image_url}
                        alt="Shop"
                        className="h-24 w-full object-cover rounded"
                      />
                      <div className="absolute top-0 right-0 flex space-x-1">
                        <button
                          onClick={() => openModal("editShopImage", { ...image, shop_id: currentShopId })}
                          className="p-1 bg-blue-600 text-white rounded"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteShopImage(image.image_id)}
                          className="p-1 bg-red-600 text-white rounded"
                        >
                          <Trash className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex justify-end">
                  <button
                    onClick={closeModal}
                    className="p-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
                  >
                    Close
                  </button>
                </div>
              </div>
            )}
            {modalType === "editShopImage" && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Update Image</label>
                  <input
                    type="file"
                    name="image_file"
                    onChange={handleInputChange}
                    accept="image/*"
                    className="w-full px-4 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  />
                  {formData.image_file && (
                    <p className="text-sm text-gray-600 mt-2">{formData.image_file.name}</p>
                  )}
                </div>
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={closeModal}
                    className="p-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleEditShopImage}
                    disabled={isLoading}
                    className="p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50"
                  >
                    {isLoading ? "Updating..." : "Update Image"}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Shops;