import React, { useState, useEffect } from "react";
import { useNavigate, Link, useLocation } from "react-router-dom";
import { User, Mail, Lock, Building, Image, CheckCircle, XCircle } from "lucide-react";
import uploadToS3 from "../services/uploadToS3";
import { BASE_URL } from "../config";

const VendorsPage = () => {
  const [vendors, setVendors] = useState([]);
  const [categories, setCategories] = useState([]);
  const [modalType, setModalType] = useState(null);
  const [formData, setFormData] = useState({
    id: "",
    business_name: "",
    username: "",
    email: "",
    password: "",
    business_type: "",
    category_id: "",
    profile_image: "",
    status: "Pending",
  });
  const [profileImage, setProfileImage] = useState(null);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const fetchVendors = async () => {
    try {
      const res = await fetch(`${BASE_URL}/api/vendor/vendors`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Failed to fetch vendors");
      }
      const data = await res.json();
      console.log("Fetched vendors:", data.vendors);
      setVendors(data.vendors || []);
    } catch (error) {
      console.error("Fetch vendors error:", error.message);
      setError(error.message);
    }
  };

  const fetchCategories = async () => {
    try {
      const res = await fetch(`${BASE_URL}/api/superadmin/categories`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Failed to fetch categories");
      }
      const data = await res.json();
      console.log("Fetched categories:", data.categories);
      setCategories(data.categories || []);
    } catch (error) {
      console.error("Fetch categories error:", error.message);
      setError(error.message);
    }
  };

  useEffect(() => {
    fetchVendors();
    fetchCategories();
  }, [location.pathname]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    setProfileImage(e.target.files[0]);
  };

  const handleEditVendor = async (e) => {
    e.preventDefault();
    if (!formData.business_name || !formData.username || !formData.email || !formData.business_type) {
      setError("Business name, username, email, and business type are required");
      return;
    }
    setIsLoading(true);
    setMessage("");
    setError(null);

    try {
      let profileImageUrl = formData.profile_image || "";
      if (profileImage) {
        console.log("Uploading profile image:", profileImage.name);
        profileImageUrl = await uploadToS3(profileImage, "vendors");
        console.log("Profile image uploaded:", profileImageUrl);
      }

      const data = new FormData();
      data.append("business_name", formData.business_name);
      data.append("username", formData.username);
      data.append("email", formData.email);
      if (formData.category_id) data.append("category_id", formData.category_id);
      data.append("business_type", formData.business_type);
      if (profileImageUrl) data.append("profile_image", profileImageUrl);
      data.append("status", formData.status);

      console.log("FormData to send:");
      for (let [key, value] of data.entries()) {
        console.log(`  ${key}: ${value}`);
      }

      const res = await fetch(`${BASE_URL}/api/vendor/vendors/${formData.id}`, {
        method: "PUT",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        body: data,
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "Failed to update vendor");

      setMessage(`✅ Vendor updated: ${result.vendor.business_name}`);
      await fetchVendors();
      setModalType(null);
      setFormData({
        id: "",
        business_name: "",
        username: "",
        email: "",
        password: "",
        business_type: "",
        category_id: "",
        profile_image: "",
        status: "Pending",
      });
      setProfileImage(null);
    } catch (error) {
      console.error("Vendor update error:", error.message);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteVendor = async (id) => {
    if (window.confirm("Are you sure you want to delete this vendor?")) {
      try {
        const res = await fetch(`${BASE_URL}/api/vendor/vendors/${id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        if (!res.ok) {
          const errorData = await res.json();
          throw new Error(errorData.error || "Failed to delete vendor");
        }
        await fetchVendors();
        setMessage("✅ Vendor deleted successfully");
        setError(null);
      } catch (error) {
        console.error("Delete vendor error:", error.message);
        setError(error.message);
      }
    }
  };

  const openModal = (type, data = {}) => {
    setModalType(type);
    setFormData({
      id: data.id || "",
      business_name: data.business_name || "",
      username: data.username || "",
      email: data.email || "",
      password: "",
      business_type: data.business_type || "",
      category_id: data.category_id || "",
      profile_image: data.profile_image || "",
      status: data.status || "Pending",
    });
    setProfileImage(null);
    setError(null);
    setMessage("");
  };

  const closeModal = () => {
    setModalType(null);
    setFormData({
      id: "",
      business_name: "",
      username: "",
      email: "",
      password: "",
      business_type: "",
      category_id: "",
      profile_image: "",
      status: "Pending",
    });
    setProfileImage(null);
    setError(null);
    setMessage("");
  };

  const handleImageError = (e) => {
    console.error("Failed to load image:", e.target.src);
    e.target.src = "https://via.placeholder.com/64?text=No+Image";
  };

  return (
    <div className="space-y-6 p-6">
      <h1 className="text-3xl font-bold text-gray-900">Vendors</h1>
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold text-gray-800">Vendors</h2>
          <Link
            to="/superadmin/create-vendor"
            className="p-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200"
          >
            Add Vendor
          </Link>
        </div>
        {error && (
          <div className="flex items-center space-x-2 p-4 rounded-xl border text-red-700 bg-red-50 border-red-200 mb-4">
            <XCircle className="w-5 h-5" />
            <span className="text-sm font-medium">{error}</span>
          </div>
        )}
        {message && (
          <div className="flex items-center space-x-2 p-4 rounded-xl border text-green-700 bg-green-50 border-green-200 mb-4">
            <CheckCircle className="w-5 h-5" />
            <span className="text-sm font-medium">{message}</span>
          </div>
        )}
        {vendors.length === 0 ? (
          <p className="text-gray-600">No vendors available</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {vendors.map((vendor) => (
              <div key={vendor.id} className="p-4 border border-gray-200 rounded-lg">
                <h3 className="text-lg font-medium text-gray-900">{vendor.business_name}</h3>
                <p className="text-sm text-gray-600">Username: {vendor.username}</p>
                <p className="text-sm text-gray-600">Email: {vendor.email}</p>
                <p className="text-sm text-gray-600">Status: {vendor.status}</p>
                <p className="text-sm text-gray-600">
                  Category: {categories.find((cat) => cat.category_id === vendor.category_id)?.category_name || "None"}
                </p>
                {vendor.profile_image && (
                  <img
                    src={vendor.profile_image}
                    alt={`${vendor.business_name} profile`}
                    className="h-16 w-16 object-cover rounded mt-2"
                    onError={handleImageError}
                    onLoad={() => console.log("Image loaded successfully:", vendor.profile_image)}
                  />
                )}
                <div className="mt-4 flex space-x-2">
                  <button
                    onClick={() => navigate(`/shops?vendor_id=${vendor.id}`)}
                    className="p-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200"
                  >
                    View Shops
                  </button>
                  <button
                    onClick={() => openModal("editVendor", vendor)}
                    className="p-2 bg-yellow-100 text-yellow-700 rounded-lg hover:bg-yellow-200"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeleteVendor(vendor.id)}
                    className="p-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {modalType === "editVendor" && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[80vh] overflow-y-auto">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Edit Vendor</h2>
            {error && (
              <div className="flex items-center space-x-2 p-4 rounded-lg border text-red-700 bg-red-50 border-red-200 mb-4">
                <XCircle className="w-5 h-5" />
                <span className="text-sm font-medium">{error}</span>
              </div>
            )}
            {message && (
              <div className="flex items-center space-x-2 p-4 rounded-lg border text-green-700 bg-green-50 border-green-200 mb-4">
                <CheckCircle className="w-5 h-5" />
                <span className="text-sm font-medium">{message}</span>
              </div>
            )}
            <form onSubmit={handleEditVendor} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Business Name</label>
                <div className="relative">
                  <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    name="business_name"
                    value={formData.business_name}
                    onChange={handleInputChange}
                    className="mt-1 p-2 pl-10 w-full border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Username</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    name="username"
                    value={formData.username}
                    onChange={handleInputChange}
                    className="mt-1 p-2 pl-10 w-full border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="mt-1 p-2 pl-10 w-full border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Business Type</label>
                <select
                  name="business_type"
                  value={formData.business_type}
                  onChange={handleInputChange}
                  className="mt-1 p-2 w-full border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  required
                >
                  <option value="">Select Business Type</option>
                  <option value="Service">Service</option>
                  <option value="Retailer">Retailer</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Category</label>
                <select
                  name="category_id"
                  value={formData.category_id}
                  onChange={handleInputChange}
                  className="mt-1 p-2 w-full border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                >
                  <option value="">Select Category</option>
                  {categories.map((cat) => (
                    <option key={cat.category_id} value={cat.category_id}>
                      {cat.category_name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Profile Image</label>
                <div className="relative">
                  <Image className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="file"
                    name="profile_image"
                    onChange={handleFileChange}
                    accept="image/*"
                    className="mt-1 p-2 pl-10 w-full border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  />
                </div>
                {formData.profile_image && !profileImage && (
                  <img
                    src={formData.profile_image}
                    alt="Current Profile"
                    className="h-16 w-16 object-cover rounded mt-2"
                    onError={handleImageError}
                    onLoad={() => console.log("Edit modal image loaded:", formData.profile_image)}
                  />
                )}
                {profileImage && <p className="text-sm text-gray-600 mt-2">Selected: {profileImage.name}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Status</label>
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleInputChange}
                  className="mt-1 p-2 w-full border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                >
                  <option value="Pending">Pending</option>
                  <option value="Approved">Approved</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={closeModal}
                  className="p-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
                  disabled={isLoading}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50"
                >
                  {isLoading ? "Saving..." : "Update Vendor"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default VendorsPage;