import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./pages/login";
import SuperAdminDashboard from "./pages/superAdminDasboard";
import VendorDashboard from "./pages/vendorDashboard";
import VendorSignupForm from "./components/vendorSignupForm";
import SuperAdminLayout from "./components/SuperAdminLayout";
import VendorLayout from "./components/vendorLayout";
import CategoriesPage from "./pages/CategoriesPage";
import SubcategoriesPage from "./pages/SubcategoriesPage";
import Shops from "./pages/shops";
import AllShopsPage from "./pages/ShopPage";
import VendorsPage from "./pages/VendorsPage";
import ForgotPassword from "./pages/forgotPassword";
import ResetPassword from "./pages/resetPassword";
import ResetWithOtp from "./pages/ResetWithOtp";
import VendorProfile from "./pages/vendorProfile";
import ManageShopServices from "./pages/shopServices";
import Services from "./pages/services"; // Import the Services component
import VendorShops from "./pages/vendors/vendoshops";

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        {/* Login page without sidebar */}
        <Route path="/" element={<Login />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/resetwithotp" element={<ResetWithOtp />} />

        {/* Super Admin Pages with Super Admin Layout */}
        <Route
          path="/superadmin/dashboard"
          element={
            <SuperAdminLayout>
              <SuperAdminDashboard />
            </SuperAdminLayout>
          }
        />
        <Route
          path="/superadmin/create-vendor"
          element={
            <SuperAdminLayout>
              <VendorSignupForm />
            </SuperAdminLayout>
          }
        />
        <Route
          path="/categories"
          element={
            <SuperAdminLayout>
              <CategoriesPage />
            </SuperAdminLayout>
          }
        />
        <Route
          path="/subcategories/:category_id"
          element={
            <SuperAdminLayout>
              <SubcategoriesPage />
            </SuperAdminLayout>
          }
        />
        <Route
          path="/shops/:categoryId"
          element={
            <SuperAdminLayout>
              <Shops />
            </SuperAdminLayout>
          }
        />
        <Route
          path="/shops"
          element={
            <SuperAdminLayout>
              <AllShopsPage />
            </SuperAdminLayout>
          }
        />
        <Route
          path="/services"
          element={
            <SuperAdminLayout>
              <Services />
            </SuperAdminLayout>
          }
        />
        <Route
          path="/shop-services"
          element={
            <SuperAdminLayout>
              <ManageShopServices />
            </SuperAdminLayout>
          }
        />
        
        <Route
          path="/vendors"
          element={
            <SuperAdminLayout>
              <VendorsPage />
            </SuperAdminLayout>
          }
        />

        {/* Vendor Pages with Vendor Layout */}
        <Route
          path="/vendor/dashboard"
          element={
            <VendorLayout>
              <VendorDashboard />
            </VendorLayout>
          }
        />
        <Route
          path="/vendor/profile"
          element={
            <VendorLayout>
              <VendorProfile />
            </VendorLayout>
          }
        />
        <Route
          path="/vendor/services"
          element={
            <VendorLayout>
              <div className="p-6">
                <h2 className="text-2xl font-bold mb-4">My Services</h2>
                <p className="text-gray-600">Add and manage your service offerings.</p>
              </div>
            </VendorLayout>
          }
        />
        <Route
          path="/vendor/shops"
          element={
            <VendorLayout>
              <VendorShops/>
            </VendorLayout>
          }
        />
        <Route
          path="/vendor/reviews"
          element={
            <VendorLayout>
              <div className="p-6">
                <h2 className="text-2xl font-bold mb-4">Reviews</h2>
                <p className="text-gray-600">View customer reviews and ratings.</p>
              </div>
            </VendorLayout>
          }
        />
        <Route
          path="/vendor/earnings"
          element={
            <VendorLayout>
              <div className="p-6">
                <h2 className="text-2xl font-bold mb-4">Earnings</h2>
                <p className="text-gray-600">Track your earnings and financial reports.</p>
              </div>
            </VendorLayout>
          }
        />
        <Route
          path="/vendor/settings"
          element={
            <VendorLayout>
              <div className="p-6">
                <h2 className="text-2xl font-bold mb-4">Settings</h2>
                <p className="text-gray-600">Manage your account settings and preferences.</p>
              </div>
            </VendorLayout>
          }
        />
      </Routes>
    </BrowserRouter>
  );
};

export default App;