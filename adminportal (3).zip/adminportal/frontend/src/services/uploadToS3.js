import { BASE_URL } from "../config";

async function uploadToS3(file, folder) {
  try {
    if (!file) {
      throw new Error("No file provided");
    }
    if (!file.type.startsWith("image/")) {
      throw new Error("File must be an image");
    }
    if (file.size > 5 * 1024 * 1024) {
      throw new Error("File size exceeds 5MB limit");
    }

    // Sanitize filename to replace special characters
    const sanitizedFilename = file.name.replace(/[^a-zA-Z0-9.-]/g, "-");
    console.log("uploadToS3 - Original filename:", file.name, "Sanitized filename:", sanitizedFilename);

    console.log("uploadToS3 - Requesting presigned URL for:", {
      folder,
      filename: sanitizedFilename,
      content_type: file.type,
    });
    const res = await fetch(`${BASE_URL}/api/superadmin/generate-presigned-url`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}` },
      body: JSON.stringify({
        folder,
        filename: sanitizedFilename,
        content_type: file.type,
      }),
    });

    if (!res.ok) {
      const errorData = await res.json();
      console.error("uploadToS3 - Failed to get presigned URL:", errorData);
      throw new Error(errorData.error || `Failed to get pre-signed URL: ${res.statusText}`);
    }

    const { uploadUrl, fileUrl } = await res.json();
    console.log("uploadToS3 - Received presigned URL:", { uploadUrl, fileUrl });

    console.log("uploadToS3 - Uploading file to S3:", sanitizedFilename);
    const uploadResponse = await fetch(uploadUrl, {
      method: "PUT",
      body: file,
      headers: { "Content-Type": file.type },
    });

    if (!uploadResponse.ok) {
      console.error("uploadToS3 - Failed to upload file to S3:", uploadResponse.statusText);
      throw new Error(`Failed to upload file to S3: ${uploadResponse.statusText}`);
    }

    console.log("uploadToS3 - File uploaded successfully, URL:", fileUrl);
    return fileUrl;
  } catch (error) {
    console.error("uploadToS3 error:", error.message, error.stack);
    throw error;
  }
}

export default uploadToS3;