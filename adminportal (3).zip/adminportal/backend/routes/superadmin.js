const express = require("express");
const router = express.Router();
const {
  createVendor,
  listVendors,
  updateVendor,
  deleteVendor,
  createCategory,
  listCategories,
  getCategory,
  updateCategory,
  deleteCategory,
  createSubcategory,
  listSubcategories,
  updateSubcategory,
  deleteSubcategory,
  createShop,
  listShops,
  updateShop,
  deleteShop,
  approveShop,
  createShopImage,
  listShopImages,
  updateShopImage,
  deleteShopImage,
  generatePresignedUrl,
  getSuperadminDashboard,
  createService,
  listServices,
  updateService,
  deleteService,
  createReview,
  listReviews,
  deleteReview,
  debugCategories,
} = require("../controllers/superadminController");
const { protect, requireRole } = require("../middleware/authMiddleware");
const multer = require("multer");

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fieldSize: 1024 * 1024,
    fields: 10,
  },
});

console.log("superadmin.js loaded - Using multer for routes");
console.log("protect:", typeof protect);
console.log("requireRole:", typeof requireRole);
console.log("listVendors:", typeof listVendors);
console.log("getSuperadminDashboard:", typeof getSuperadminDashboard);
console.log("getCategory:", typeof getCategory);

router.post("/generate-presigned-url", protect, requireRole("superadmin"), generatePresignedUrl);
router.post("/categories", protect, requireRole("superadmin"), upload.none(), createCategory);
router.get("/categories", protect, requireRole("superadmin"), listCategories);
router.get("/categories/:id", protect, requireRole("superadmin"), getCategory);
router.put("/categories/:id", protect, requireRole("superadmin"), upload.none(), updateCategory);
router.delete("/categories/:id", protect, requireRole("superadmin"), deleteCategory);
router.get("/debug-categories", protect, requireRole("superadmin"), debugCategories);


router.post("/subcategories", protect, requireRole("superadmin"), upload.none(), createSubcategory);
router.get("/subcategories", protect, requireRole("superadmin"), listSubcategories);
router.put("/subcategories/:id", protect, requireRole("superadmin"), upload.none(), updateSubcategory);
router.delete("/subcategories/:id", protect, requireRole("superadmin"), deleteSubcategory);

router.post("/shops", protect, requireRole("superadmin"), createShop);
router.get("/shops", protect, requireRole("superadmin"), listShops);
router.put("/shops/:id", protect, requireRole("superadmin"), updateShop);
router.delete("/shops/:id", protect, requireRole("superadmin"), deleteShop);
router.put("/shops/:id/approve", protect, requireRole("superadmin"), approveShop);

router.post("/shop-images", protect, requireRole("superadmin"), createShopImage);
router.get("/shop-images", protect, requireRole("superadmin"), listShopImages);
router.put("/shop-images/:id", protect, requireRole("superadmin"), updateShopImage);
router.delete("/shop-images/:id", protect, requireRole("superadmin"), deleteShopImage);

router.post("/services", protect, requireRole("superadmin"), createService);
router.get("/services", protect, requireRole("superadmin"), listServices);
router.put("/services/:id", protect, requireRole("superadmin"), updateService);
router.delete("/services/:id", protect, requireRole("superadmin"), deleteService);

router.post("/reviews", protect, requireRole("superadmin"), createReview);
router.get("/reviews", protect, requireRole("superadmin"), listReviews);
router.delete("/reviews/:id", protect, requireRole("superadmin"), deleteReview);

router.get("/dashboard", protect, requireRole("superadmin"), getSuperadminDashboard);

module.exports = router;