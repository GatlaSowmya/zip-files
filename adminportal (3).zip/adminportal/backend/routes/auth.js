const express = require("express");
const router = express.Router();
const { login, forgotPassword, verifyOtpAndResetPassword, changePassword } = require("../controllers/authController");
const { protect } = require("../middleware/authMiddleware");

router.post("/login", login);
router.post("/forgot-password", forgotPassword);
router.post("/reset-password", verifyOtpAndResetPassword);
router.post("/change-password", protect, changePassword);

module.exports = router;