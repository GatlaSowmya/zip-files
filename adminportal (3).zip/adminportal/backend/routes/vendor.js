const express = require("express");
const router = express.Router();
const {
  getDashboard,
  getProfile,
  updateProfile,
  createVendor,
  getAllVendors,
  updateVendor,
  deleteVendor
} = require("../controllers/vendorController");
const { protect, requireRole } = require("../middleware/authMiddleware");

router.get("/dashboard", protect, requireRole("vendor"), getDashboard);
router.get("/profile", protect, requireRole("vendor"), getProfile);
router.put("/profile", protect, requireRole("vendor"), updateProfile);
router.post("/vendors", protect, requireRole("superadmin"), createVendor);
router.get("/vendors", protect, requireRole("superadmin"), getAllVendors);
router.put("/vendors/:id", protect, requireRole("superadmin"), updateVendor);
router.delete("/vendors/:id", protect, requireRole("superadmin"), deleteVendor);

module.exports = router;