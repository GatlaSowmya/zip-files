const express = require('express');
const cors = require('cors');
const multer = require('multer');
const pool = require('./db');
require('dotenv').config();

const app = express();
const authRoutes = require('./routes/auth');
const superadminRoutes = require('./routes/superadmin');
const vendorRoutes = require('./routes/vendor');

// Configure multer for FormData parsing
const upload = multer({ storage: multer.memoryStorage() });

// Verify database connection on startup
pool.query("SELECT NOW()", (err, res) => {
  if (err) {
    console.error("❌ Database connection error:", err.message);
  } else {
    console.log("✅ Database connected:", res.rows[0]);
  }
});

// Middleware for CORS and body parsing
app.use(
  cors({
    origin: process.env.FRONTEND_URL || "http://localhost:3009",
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ limit: "10mb", extended: true }));
app.use(upload.none()); // Parse FormData fields without files

// Log incoming requests for debugging
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url} - Body:`, req.body);
  next();
});

// Register routes
app.use("/api/auth", authRoutes);
app.use("/api/superadmin", superadminRoutes);
app.use("/api/vendor", vendorRoutes);

// Log all registered routes after startup
function logRoutes(router, prefix = "") {
  if (!router || !router.stack) return;
  router.stack.forEach((layer) => {
    if (layer.route && layer.route.path) {
      const methods = layer.route.stack.map((s) => s.method.toUpperCase()).join(",");
      console.log(`  ${methods} ${prefix}${layer.route.path}`);
    } else if (layer.handle && layer.handle.stack) {
      const subPrefix = layer.regexp
        ? `${prefix}${layer.regexp.toString().replace(/.*?(\/[^?]+).*/, "$1")}`
        : prefix;
      logRoutes(layer.handle, subPrefix);
    }
  });
}

app.listen(process.env.PORT || 5000, () => {
  console.log(`Server running on port ${process.env.PORT || 5000}`);
  console.log("Registered routes:");
  logRoutes(app._router || app);
});

// Handle unmatched routes
app.use((req, res) => {
  console.error(`Unmatched route: ${req.method} ${req.url}`);
  res.status(404).json({ error: "Route not found" });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error("❌ Server error:", err.message, err.stack);
  res.status(500).json({ error: "Server error", details: err.message });
});
