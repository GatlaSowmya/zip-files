// const bcrypt = require("bcrypt");
// const pool = require("./db");

// async function seedSuperadmin() {
//   const hashed = await bcrypt.hash("admin@321", 10);
//   await pool.query(
//     "INSERT INTO search_hyderabad.superadmin (username, password) VALUES ($1, $2, $3)",
//     ["admin123", hashed]
//   );
//   console.log("✅ Superadmin created with username 'admin123' and password 'admin@321'");
//   process.exit();
// }

// seedSuperadmin();

const bcrypt = require("bcrypt");


const password = "admin@123";
bcrypt.hash(password, 10, (err, hashedPassword) => {
  if (err) {
    console.log("Error hashing password:", err);
  } else {
    console.log("Hashed Password:", hashedPassword);
  }
});

