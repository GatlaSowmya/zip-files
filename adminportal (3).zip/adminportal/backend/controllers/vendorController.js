const pool = require("../db");
const bcrypt = require("bcrypt");
const sendEmail = require("../utils/sendEmail");

exports.getDashboard = async (req, res) => {
  const vendorId = req.user.id;
  try {
    const vendorResult = await pool.query(
      "SELECT vendor_id, business_name, username, email, business_type, status, profile_image FROM search_hyderabad.vendors WHERE vendor_id = $1",
      [vendorId]
    );
    if (vendorResult.rows.length === 0) {
      return res.status(404).json({ error: "Vendor not found" });
    }
    const shopsResult = await pool.query(
      `SELECT s.*, array_agg(json_build_object('image_id', si.image_id, 'image_url', si.image_url)) as images
       FROM search_hyderabad.shops s
       LEFT JOIN search_hyderabad.shop_images si ON s.shop_id = si.shop_id
       WHERE s.vendor_id = $1
       GROUP BY s.shop_id`,
      [vendorId]
    );
    res.json({ vendor: vendorResult.rows[0], shops: shopsResult.rows });
  } catch (err) {
    console.error("Error fetching vendor dashboard:", err.message, err.stack);
    res.status(500).json({ error: "Server error", details: err.message });
  }
};

exports.getProfile = async (req, res) => {
  const vendorId = req.user.id;
  try {
    const result = await pool.query(
      "SELECT vendor_id, business_name, username, email, business_type, status, profile_image FROM search_hyderabad.vendors WHERE vendor_id = $1",
      [vendorId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Vendor not found" });
    }
    res.json({ vendor: result.rows[0] });
  } catch (err) {
    console.error("Error fetching vendor profile:", err.message, err.stack);
    res.status(500).json({ error: "Server error", details: err.message });
  }
};

exports.updateProfile = async (req, res) => {
  const vendorId = req.user.id;
  const { business_name, username, email, business_type, profile_image } = req.body;
  try {
    if (!business_name || !username || !email) {
      return res.status(400).json({ error: "Business name, username, and email are required" });
    }
    const result = await pool.query(
      `UPDATE search_hyderabad.vendors 
       SET business_name = $1, username = $2, email = $3, business_type = $4, profile_image = $5
       WHERE vendor_id = $6
       RETURNING vendor_id, business_name, username, email, business_type, status, profile_image`,
      [business_name, username, email, business_type, profile_image || null, vendorId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Vendor not found" });
    }
    res.json({ vendor: result.rows[0], message: "Profile updated successfully" });
  } catch (err) {
    console.error("Error updating vendor profile:", err.message, err.stack);
    if (err.code === "23505") {
      if (err.constraint === "vendors_username_key") {
        return res.status(400).json({ error: "Username already exists" });
      } else if (err.constraint === "vendors_email_key") {
        return res.status(400).json({ error: "Email already exists" });
      }
    }
    res.status(500).json({ error: "Server error", details: err.message });
  }
};

exports.createVendor = async (req, res) => {
  console.log("createVendor - Raw request body:", req.body);
  const { business_name, username, email, password, business_type, profile_image, category_id, status } = req.body;
  try {
    console.log("createVendor - Parsed body:", { business_name, username, email, password, business_type, profile_image, category_id, status });
    if (!business_name || !username || !email || !password || !business_type) {
      return res.status(400).json({ error: "Business name, username, email, password, and business type are required" });
    }
    // Validate category_id if provided
    if (category_id) {
      const categoryCheck = await pool.query(
        "SELECT category_id FROM search_hyderabad.categories WHERE category_id = $1",
        [category_id]
      );
      if (categoryCheck.rows.length === 0) {
        return res.status(400).json({ error: "Invalid category_id" });
      }
    }
    // Validate status
    if (status && !["Pending", "Approved", "Rejected"].includes(status)) {
      return res.status(400).json({ error: "Invalid status. Must be Pending, Approved, or Rejected" });
    }
    // Check for existing username or email
    const existingVendor = await pool.query(
      "SELECT vendor_id, username, email FROM search_hyderabad.vendors WHERE username = $1 OR email = $2",
      [username, email]
    );
    if (existingVendor.rows.length > 0) {
      const conflict = existingVendor.rows[0];
      if (conflict.username === username && conflict.email === email) {
        return res.status(400).json({ error: "Both username and email already exist" });
      } else if (conflict.username === username) {
        return res.status(400).json({ error: "Username already exists" });
      } else {
        return res.status(400).json({ error: "Email already exists" });
      }
    }
    // Hash password
    console.log("createVendor - Hashing password for:", username);
    const hashedPassword = await bcrypt.hash(password, 10);
    console.log("createVendor - Password hashed successfully");
    // Insert new vendor
    console.log("createVendor - Inserting vendor into database");
    const result = await pool.query(
      `INSERT INTO search_hyderabad.vendors (business_name, username, email, password, business_type, profile_image, status, category_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING vendor_id, business_name, username, email, business_type, status, profile_image, category_id`,
      [business_name, username, email, hashedPassword, business_type, profile_image || null, status || "Pending", category_id || null]
    );
    console.log("createVendor - Vendor inserted:", result.rows[0]);
    
    const vendor = result.rows[0];
    await sendEmail({
      to: email,
      subject: "Vendor Account Created",
      text: `Hi ${business_name},\n\nYour vendor account has been created successfully.\n\nUsername: ${username}\nEmail: ${email}\nPassword: ${password}\nStatus: ${vendor.status}\n\nRegards,\nSearch Hyderabad`
    });

    res.status(201).json({ vendor: result.rows[0], message: "Vendor created successfully" });
  } catch (err) {
    console.error("Error creating vendor:", err.message, err.stack);
    if (err.code === "23505") {
      if (err.constraint === "vendors_username_key") {
        return res.status(400).json({ error: "Username already exists" });
      } else if (err.constraint === "vendors_email_key") {
        return res.status(400).json({ error: "Email already exists" });
      }
    }
    res.status(500).json({ error: "Server error", details: err.message });
  }
};

exports.getAllVendors = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT vendor_id, business_name, username, email, business_type, status, profile_image, category_id
       FROM search_hyderabad.vendors`
    );
    console.log("getAllVendors - Returning vendors:", result.rows);
    res.json({ vendors: result.rows });
  } catch (err) {
    console.error("Error fetching all vendors:", err.message, err.stack);
    res.status(500).json({ error: "Server error", details: err.message });
  }
};
exports.updateVendor = async (req, res) => {
  const { id } = req.params;
  const { business_name, username, email, business_type, profile_image, category_id, status } = req.body;
  try {
    console.log("updateVendor - Parsed body:", { business_name, username, email, business_type, profile_image, category_id, status });
    if (!business_name || !username || !email) {
      return res.status(400).json({ error: "Business name, username, and email are required" });
    }
    // Validate category_id if provided
    if (category_id) {
      const categoryCheck = await pool.query(
        "SELECT category_id FROM search_hyderabad.categories WHERE category_id = $1",
        [category_id]
      );
      if (categoryCheck.rows.length === 0) {
        return res.status(400).json({ error: "Invalid category_id" });
      }
    }
    // Validate status
    if (status && !["Pending", "Approved", "Rejected"].includes(status)) {
      return res.status(400).json({ error: "Invalid status. Must be Pending, Approved, or Rejected" });
    }
    // Check for existing username or email (excluding current vendor)
    const existingVendor = await pool.query(
      "SELECT vendor_id, username, email FROM search_hyderabad.vendors WHERE (username = $1 OR email = $2) AND vendor_id != $3",
      [username, email, id]
    );
    if (existingVendor.rows.length > 0) {
      const conflict = existingVendor.rows[0];
      if (conflict.username === username && conflict.email === email) {
        return res.status(400).json({ error: "Both username and email already exist" });
      } else if (conflict.username === username) {
        return res.status(400).json({ error: "Username already exists" });
      } else {
        return res.status(400).json({ error: "Email already exists" });
      }
    }
    const result = await pool.query(
      `UPDATE search_hyderabad.vendors 
       SET business_name = $1, username = $2, email = $3, business_type = $4, profile_image = $5, category_id = $6, status = $7
       WHERE vendor_id = $8
       RETURNING vendor_id AS id, business_name, username, email, business_type, status, profile_image, category_id`,
      [business_name, username, email, business_type, profile_image || null, category_id || null, status || "Pending", id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Vendor not found" });
    }
    res.json({ vendor: result.rows[0], message: "Vendor updated successfully" });
  } catch (err) {
    console.error("Error updating vendor:", err.message, err.stack);
    if (err.code === "23505") {
      if (err.constraint === "vendors_username_key") {
        return res.status(400).json({ error: "Username already exists" });
      } else if (err.constraint === "vendors_email_key") {
        return res.status(400).json({ error: "Email already exists" });
      }
    }
    res.status(500).json({ error: "Server error", details: err.message });
  }
};

exports.deleteVendor = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      "DELETE FROM search_hyderabad.vendors WHERE vendor_id = $1 RETURNING vendor_id",
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Vendor not found" });
    }
    res.json({ message: "Vendor deleted successfully" });
  } catch (err) {
    console.error("Error deleting vendor:", err.message, err.stack);
    res.status(500).json({ error: "Server error", details: err.message });
  }
};