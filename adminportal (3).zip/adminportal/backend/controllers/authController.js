const pool = require("../db");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const sendEmail = require("../utils/sendEmail");

exports.login = async (req, res) => {
  const { loginId, password } = req.body;
  console.log("Login request received:", { loginId });
  try {
    if (!loginId || !password) {
      return res.status(400).json({ error: "Login ID and password are required" });
    }
    console.log("Querying database for superadmin and vendor...");
    const [superadmin, vendor] = await Promise.all([
      pool.query("SELECT * FROM search_hyderabad.superadmin WHERE username = $1", [loginId]),
      pool.query("SELECT vendor_id, business_name, email, password, status FROM search_hyderabad.vendors WHERE email = $1", [loginId]),
    ]);

    console.log("Superadmin rows:", superadmin.rows.length, "Vendor rows:", vendor.rows.length);

    if (superadmin.rows.length > 0) {
      const match = await bcrypt.compare(password, superadmin.rows[0].password);
      if (!match) {
        console.log("Superadmin password mismatch");
        return res.status(401).json({ error: "Invalid credentials" });
      }
      const accessToken = jwt.sign(
        { id: superadmin.rows[0].id, role: "superadmin" },
        process.env.JWT_SECRET,
        { expiresIn: "1d" }
      );
      console.log("Superadmin login successful, access token generated:", {
        id: superadmin.rows[0].id,
        accessTokenSnippet: accessToken.slice(0, 20) + "...",
      });
      return res.json({ accessToken, role: "superadmin" });
    }

    if (vendor.rows.length > 0) {
      if (vendor.rows[0].status !== "Approved") {
        console.log("Vendor account not approved:", vendor.rows[0].status);
        return res.status(403).json({ error: "Account not approved" });
      }
      const match = await bcrypt.compare(password, vendor.rows[0].password);
      if (!match) {
        console.log("Vendor password mismatch");
        return res.status(401).json({ error: "Invalid credentials" });
      }
      const accessToken = jwt.sign(
        { id: vendor.rows[0].vendor_id, role: "vendor" },
        process.env.JWT_SECRET,
        { expiresIn: "1d" }
      );
      console.log("Vendor login successful, access token generated:", {
        id: vendor.rows[0].vendor_id,
        accessTokenSnippet: accessToken.slice(0, 20) + "...",
      });
      return res.json({ accessToken, role: "vendor", business_name: vendor.rows[0].business_name });
    }

    console.log("User not found for loginId:", loginId);
    return res.status(404).json({ error: "User not found" });
  } catch (err) {
    console.error("Login error:", err.message, err.stack);
    res.status(500).json({ error: "Server error", details: err.message });
  }
};

exports.forgotPassword = async (req, res) => {
  const { email } = req.body;
  console.log("Forgot password request received:", { email });
  try {
    if (!email) {
      return res.status(400).json({ error: "Email is required" });
    }
    const result = await pool.query(
      "SELECT id, role FROM search_hyderabad.superadmin WHERE email = $1 UNION SELECT vendor_id AS id, 'vendor' as role FROM search_hyderabad.vendors WHERE email = $1",
      [email]
    );
    if (result.rows.length === 0) {
      console.log("User not found for email:", email);
      return res.status(404).json({ error: "User not found" });
    }
    const user = result.rows[0];
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const otpExpires = new Date(Date.now() + 10 * 60 * 1000);
    await pool.query(
      "UPDATE search_hyderabad.superadmin SET reset_password_otp = $1, reset_password_expires = $2 WHERE email = $3 AND role = 'superadmin'",
      [otp, otpExpires, email]
    );
    await pool.query(
      "UPDATE search_hyderabad.vendors SET reset_password_otp = $1, reset_password_expires = $2 WHERE email = $3",
      [otp, otpExpires, email]
    );
    await sendEmail(email, "Password Reset OTP", `Your OTP is ${otp}. It expires in 10 minutes.`);
    console.log("OTP sent successfully to:", email);
    res.json({ message: "OTP sent to email" });
  } catch (err) {
    console.error("Forgot password error:", err.message, err.stack);
    res.status(500).json({ error: "Server error", details: err.message });
  }
};

exports.verifyOtpAndResetPassword = async (req, res) => {
  const { email, otp, newPassword } = req.body;
  console.log("Verify OTP and reset password request received:", { email, otp });
  try {
    if (!email || !otp || !newPassword) {
      return res.status(400).json({ error: "Email, OTP, and new password are required" });
    }
    const result = await pool.query(
      "SELECT id, role, reset_password_otp, reset_password_expires FROM search_hyderabad.superadmin WHERE email = $1 AND reset_password_otp = $2 AND reset_password_expires > NOW() " +
      "UNION SELECT vendor_id AS id, 'vendor' as role, reset_password_otp, reset_password_expires FROM search_hyderabad.vendors WHERE email = $1 AND reset_password_otp = $2 AND reset_password_expires > NOW()",
      [email, otp]
    );
    if (result.rows.length === 0) {
      console.log("Invalid or expired OTP for email:", email);
      return res.status(400).json({ error: "Invalid or expired OTP" });
    }
    const user = result.rows[0];
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    if (user.role === "superadmin") {
      await pool.query(
        "UPDATE search_hyderabad.superadmin SET password = $1, reset_password_otp = NULL, reset_password_expires = NULL WHERE email = $2",
        [hashedPassword, email]
      );
    } else {
      await pool.query(
        "UPDATE search_hyderabad.vendors SET password = $1, reset_password_otp = NULL, reset_password_expires = NULL WHERE email = $2",
        [hashedPassword, email]
      );
    }
    console.log("Password reset successfully for email:", email);
    res.json({ message: "Password reset successfully" });
  } catch (err) {
    console.error("Verify OTP and reset password error:", err.message, err.stack);
    res.status(500).json({ error: "Server error", details: err.message });
  }
};

exports.changePassword = async (req, res) => {
  const { oldPassword, newPassword } = req.body;
  const userId = req.user.id;
  const role = req.user.role;
  console.log("Change password request received:", { userId, role });
  try {
    if (!oldPassword || !newPassword) {
      return res.status(400).json({ error: "Old and new passwords are required" });
    }
    let user;
    if (role === "superadmin") {
      user = await pool.query("SELECT password FROM search_hyderabad.superadmin WHERE id = $1", [userId]);
    } else if (role === "vendor") {
      user = await pool.query("SELECT password FROM search_hyderabad.vendors WHERE vendor_id = $1", [userId]);
    }
    if (!user || user.rows.length === 0) {
      console.log("User not found for id:", userId);
      return res.status(404).json({ error: "User not found" });
    }
    const match = await bcrypt.compare(oldPassword, user.rows[0].password);
    if (!match) {
      console.log("Old password incorrect for userId:", userId);
      return res.status(401).json({ error: "Old password is incorrect" });
    }
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    if (role === "superadmin") {
      await pool.query("UPDATE search_hyderabad.superadmin SET password = $1 WHERE id = $2", [hashedPassword, userId]);
    } else {
      await pool.query("UPDATE search_hyderabad.vendors SET password = $1 WHERE vendor_id = $2", [hashedPassword, userId]);
    }
    console.log("Password changed successfully for userId:", userId);
    res.json({ message: "Password changed successfully" });
  } catch (err) {
    console.error("Change password error:", err.message, err.stack);
    res.status(500).json({ error: "Server error", details: err.message });
  }
};