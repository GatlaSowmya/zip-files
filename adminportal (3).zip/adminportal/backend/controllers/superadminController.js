const pool = require("../db");
const bcrypt = require("bcrypt");
const sendEmail = require("../utils/sendEmail");
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const { v4: uuidv4 } = require("uuid");

const s3Client = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

function isValidS3Url(url) {
  const bucket = process.env.BUCKET_NAME;
  const region = process.env.AWS_REGION;
  const regex = new RegExp(`^http://${bucket}\\.s3\\.${region}\\.amazonaws\\.com/.*$`);
  return regex.test(url);
}

exports.generatePresignedUrl = async (req, res) => {
  const { folder, filename, content_type } = req.body;
  try {
    if (!folder || !filename || !content_type) {
      return res.status(400).json({ error: "Folder, filename, and content_type are required", code: "INVALID_INPUT" });
    }
    const fileKey = `${folder}/${uuidv4()}-${filename}`;
    const command = new PutObjectCommand({
      Bucket: process.env.BUCKET_NAME,
      Key: fileKey,
      ContentType: content_type,
    });
    const uploadUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 });
    const fileUrl = `http://${process.env.BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${fileKey}`;
    console.log("generatePresignedUrl - Generated URLs:", {
      uploadUrl,
      fileUrl,
      bucket: process.env.BUCKET_NAME,
      region: process.env.AWS_REGION
    });
    res.json({
      uploadUrl,
      fileUrl,
    });
  } catch (err) {
    console.error("Error generating pre-signed URL:", err.message, err.stack);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.createCategory = async (req, res) => {
  const { category_name, parent_category_id, description, image_url, icon_url } = req.body;
  try {
    if (!category_name) {
      return res.status(400).json({ error: "Category name is required", code: "INVALID_INPUT" });
    }
    if (image_url && !isValidS3Url(image_url)) {
      return res.status(400).json({ error: "Invalid image URL", code: "INVALID_URL" });
    }
    if (icon_url && !isValidS3Url(icon_url)) {
      return res.status(400).json({ error: "Invalid icon URL", code: "INVALID_URL" });
    }
    const result = await pool.query(
      `INSERT INTO search_hyderabad.categories (category_id, category_name, parent_category_id, description, image_url, icon_url)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING category_id, category_name, parent_category_id, description, image_url, icon_url`,
      [uuidv4(), category_name, parent_category_id || null, description || null, image_url || null, icon_url || null]
    );
    res.status(201).json({ category: result.rows[0], message: "Category created successfully" });
  } catch (err) {
    console.error("Error creating category:", err.message, err.stack);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.createSubcategory = async (req, res) => {
  const { category_name, parent_category_id, description, image_url, icon_url } = req.body;
  try {
    if (!category_name || !parent_category_id) {
      return res.status(400).json({ error: "Name and parent_category_id are required", code: "INVALID_INPUT" });
    }
    const categoryCheck = await pool.query(
      "SELECT category_id FROM search_hyderabad.categories WHERE category_id = $1 AND parent_category_id IS NULL",
      [parent_category_id]
    );
    if (categoryCheck.rows.length === 0) {
      return res.status(400).json({ error: "Parent category must be a top-level category", code: "INVALID_CATEGORY" });
    }
    if (image_url && !isValidS3Url(image_url)) {
      return res.status(400).json({ error: "Invalid image URL", code: "INVALID_URL" });
    }
    if (icon_url && !isValidS3Url(icon_url)) {
      return res.status(400).json({ error: "Invalid icon URL", code: "INVALID_URL" });
    }
    const result = await pool.query(
      `INSERT INTO search_hyderabad.categories (category_id, category_name, parent_category_id, description, image_url, icon_url)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING category_id, category_name, parent_category_id, description, image_url, icon_url`,
      [uuidv4(), category_name, parent_category_id, description || null, image_url || null, icon_url || null]
    );
    res.status(201).json({ subcategory: result.rows[0], message: "Subcategory created successfully" });
  } catch (err) {
    console.error("Error creating subcategory:", err.message, err.stack);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.createVendor = async (req, res) => {
  const { business_name, username, email, password, business_type, profile_image, category_id, status } = req.body;
  try {
    if (!business_name || !username || !email || !password || !business_type) {
      return res.status(400).json({ error: "Business name, username, email, password, and business type are required", code: "INVALID_INPUT" });
    }
    if (category_id) {
      const categoryCheck = await pool.query(
        "SELECT category_id FROM search_hyderabad.categories WHERE category_id = $1",
        [category_id]
      );
      if (categoryCheck.rows.length === 0) {
        return res.status(400).json({ error: "Invalid category_id", code: "INVALID_CATEGORY" });
      }
    }
    if (profile_image && !isValidS3Url(profile_image)) {
      return res.status(400).json({ error: "Invalid profile image URL", code: "INVALID_URL" });
    }
    if (status && !["Pending", "Approved", "Rejected"].includes(status)) {
      return res.status(400).json({ error: "Invalid status. Must be Pending, Approved, or Rejected", code: "INVALID_INPUT" });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const result = await pool.query(
      `INSERT INTO search_hyderabad.vendors (business_name, username, email, password, business_type, profile_image, status, category_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING vendor_id, business_name, username, email, business_type, status, profile_image, category_id`,
      [business_name, username, email, hashedPassword, business_type, profile_image || null, status || "Pending", category_id || null]
    );
    const vendor = result.rows[0];
    await sendEmail({
      to: email,
      subject: "Vendor Account Created",
      text: `Hi ${business_name},\n\nYour vendor account has been created successfully.\n\nUsername: ${username}\nEmail: ${email}\nPassword: ${password}\n\nRegards,\nSearch Hyderabad`
    });
    res.status(201).json({ vendor, message: "Vendor created successfully" });
  } catch (err) {
    console.error("Error creating vendor:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.createShop = async (req, res) => {
  const {
    category_id, vendor_id, shop_name, description, address, location, phone,
    whatsapp_number, email, website, opening_time, closing_time
  } = req.body;
  try {
    if (!category_id || !vendor_id || !shop_name || !phone || !/^\d{10}$/.test(phone)) {
      return res.status(400).json({ error: "Invalid input: category_id, vendor_id, shop_name, and 10-digit phone are required", code: "INVALID_INPUT" });
    }
    const categoryCheck = await pool.query(
      "SELECT category_id FROM search_hyderabad.categories WHERE category_id = $1",
      [category_id]
    );
    if (categoryCheck.rows.length === 0) {
      return res.status(400).json({ error: "Invalid category_id", code: "INVALID_CATEGORY" });
    }
    const vendorCheck = await pool.query(
      "SELECT vendor_id FROM search_hyderabad.vendors WHERE vendor_id = $1",
      [vendor_id]
    );
    if (vendorCheck.rows.length === 0) {
      return res.status(400).json({ error: "Invalid vendor_id", code: "INVALID_VENDOR" });
    }
    if (whatsapp_number && !/^\d{10}$/.test(whatsapp_number)) {
      return res.status(400).json({ error: "WhatsApp number must be 10 digits", code: "INVALID_INPUT" });
    }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: "Invalid email format", code: "INVALID_INPUT" });
    }
    if (website && !isValidUrl(website)) {
      return res.status(400).json({ error: "Invalid website URL", code: "INVALID_URL" });
    }
    await pool.query("BEGIN");
    const shopResult = await pool.query(
      `INSERT INTO search_hyderabad.shops (
        vendor_id, category_id, shop_name, description, address, location, phone,
        whatsapp_number, email, website, opening_time, closing_time, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, CURRENT_TIMESTAMP)
      RETURNING *`,
      [
        vendor_id, category_id, shop_name, description || null, address || null,
        location || null, phone, whatsapp_number || null, email || null, website || null,
        opening_time || null, closing_time || null
      ]
    );
    const shop = shopResult.rows[0];
    await pool.query("COMMIT");
    const imagesResult = await pool.query(
      "SELECT image_id, image_url FROM search_hyderabad.shop_images WHERE shop_id = $1",
      [shop.shop_id]
    );
    res.status(201).json({ shop: { ...shop, images: imagesResult.rows }, message: "Shop created successfully" });
  } catch (err) {
    await pool.query("ROLLBACK");
    console.error("Error creating shop:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.createShopImage = async (req, res) => {
  const { shop_id, image_url } = req.body;
  try {
    if (!shop_id || !image_url) {
      return res.status(400).json({ error: "Shop ID and image URL are required", code: "INVALID_INPUT" });
    }
    if (!isValidS3Url(image_url)) {
      return res.status(400).json({ error: "Invalid image URL", code: "INVALID_URL" });
    }
    const shopCheck = await pool.query(
      "SELECT shop_id FROM search_hyderabad.shops WHERE shop_id = $1",
      [shop_id]
    );
    if (shopCheck.rows.length === 0) {
      return res.status(404).json({ error: "Shop not found", code: "NOT_FOUND" });
    }
    const result = await pool.query(
      `INSERT INTO search_hyderabad.shop_images (shop_id, image_url)
       VALUES ($1, $2)
       RETURNING image_id, shop_id, image_url, created_at`,
      [shop_id, image_url]
    );
    res.status(201).json({ shop_image: result.rows[0], message: "Shop image created successfully" });
  } catch (err) {
    console.error("Error creating shop image:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.updateVendor = async (req, res) => {
  const { id } = req.params;
  const { business_name, username, email, business_type, status, profile_image, category_id } = req.body;
  try {
    if (!business_name || !username || !email) {
      return res.status(400).json({ error: "Business name, username, and email are required", code: "INVALID_INPUT" });
    }
    if (category_id) {
      const categoryCheck = await pool.query(
        "SELECT category_id FROM search_hyderabad.categories WHERE category_id = $1",
        [category_id]
      );
      if (categoryCheck.rows.length === 0) {
        return res.status(400).json({ error: "Invalid category_id", code: "INVALID_CATEGORY" });
      }
    }
    if (profile_image && !isValidS3Url(profile_image)) {
      return res.status(400).json({ error: "Invalid profile image URL", code: "INVALID_URL" });
    }
    const result = await pool.query(
      `UPDATE search_hyderabad.vendors
       SET business_name = $1, username = $2, email = $3, business_type = $4, status = $5, profile_image = $6, category_id = $7
       WHERE vendor_id = $8
       RETURNING vendor_id, business_name, username, email, business_type, status, profile_image, category_id`,
      [business_name, username, email, business_type, status || "Pending", profile_image || null, category_id || null, id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Vendor not found", code: "NOT_FOUND" });
    }
    res.json({ vendor: result.rows[0], message: "Vendor updated successfully" });
  } catch (err) {
    console.error("Error updating vendor:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.deleteVendor = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      "DELETE FROM search_hyderabad.vendors WHERE vendor_id = $1 RETURNING vendor_id",
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Vendor not found", code: "NOT_FOUND" });
    }
    res.json({ message: "Vendor deleted successfully" });
  } catch (err) {
    console.error("Error deleting vendor:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.listVendors = async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT vendor_id, business_name, username, email, business_type, status, profile_image, category_id FROM search_hyderabad.vendors"
    );
    res.json({ vendors: result.rows });
  } catch (err) {
    console.error("Error listing vendors:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.updateCategory = async (req, res) => {
  const { id } = req.params;
  const { category_name, parent_category_id, description, image_url, icon_url } = req.body;
  try {
    if (!category_name) {
      return res.status(400).json({ error: "Category name is required", code: "INVALID_INPUT" });
    }
    if (image_url && !isValidS3Url(image_url)) {
      return res.status(400).json({ error: "Invalid image URL", code: "INVALID_URL" });
    }
    if (icon_url && !isValidS3Url(icon_url)) {
      return res.status(400).json({ error: "Invalid icon URL", code: "INVALID_URL" });
    }
    const result = await pool.query(
      `UPDATE search_hyderabad.categories
       SET category_name = $1, parent_category_id = $2, description = $3, image_url = $4, icon_url = $5
       WHERE category_id = $6
       RETURNING category_id, category_name, parent_category_id, description, image_url, icon_url`,
      [category_name, parent_category_id || null, description || null, image_url || null, icon_url || null, id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Category not found", code: "NOT_FOUND" });
    }
    res.json({ category: result.rows[0], message: "Category updated successfully" });
  } catch (err) {
    console.error("Error updating category:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.deleteCategory = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      "DELETE FROM search_hyderabad.categories WHERE category_id = $1 RETURNING category_id",
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Category not found", code: "NOT_FOUND" });
    }
    res.json({ message: "Category deleted successfully" });
  } catch (err) {
    console.error("Error deleting category:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.debugCategories = async (req, res) => {
  try {
    const allCategories = await pool.query("SELECT category_id, category_name, parent_category_id FROM search_hyderabad.categories");
    const topLevel = await pool.query("SELECT category_id, category_name, parent_category_id FROM search_hyderabad.categories WHERE parent_category_id IS NULL");
    res.json({ allCategories: allCategories.rows, topLevel: topLevel.rows });
  } catch (err) {
    console.error("Error debugging categories:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.listCategories = async (req, res) => {
  const { topLevel } = req.query;
  try {
    let query = `
      SELECT c1.category_id, c1.category_name, c1.parent_category_id, c1.description, c1.image_url, c1.icon_url,
             c2.category_name AS parent_category_name
      FROM search_hyderabad.categories c1
      LEFT JOIN search_hyderabad.categories c2 ON c1.parent_category_id = c2.category_id
    `;
    let params = [];
    
    if (topLevel === "true") {
      query += " WHERE c1.parent_category_id IS NULL";
    }
    
    query += " ORDER BY c2.category_name NULLS FIRST, c1.category_name";
    
    const result = await pool.query(query, params);
    res.json({ categories: result.rows });
  } catch (err) {
    console.error("Error listing categories:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.getCategory = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      `SELECT category_id, category_name, parent_category_id, description, image_url, icon_url
       FROM search_hyderabad.categories
       WHERE category_id = $1`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Category not found", code: "NOT_FOUND" });
    }
    res.json({ category: result.rows[0] });
  } catch (err) {
    console.error("Error fetching category:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.listSubcategories = async (req, res) => {
  const { category_id } = req.query;
  try {
    if (!category_id) {
      return res.status(400).json({ error: "Category ID is required", code: "INVALID_INPUT" });
    }
    const result = await pool.query(
      `SELECT category_id, category_name, parent_category_id, description, image_url, icon_url
       FROM search_hyderabad.categories
       WHERE parent_category_id = $1
       ORDER BY category_name`,
      [category_id]
    );
    res.json({ subcategories: result.rows });
  } catch (err) {
    console.error("Error listing subcategories:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.updateSubcategory = async (req, res) => {
  const { id } = req.params;
  const { category_name, parent_category_id, description, image_url, icon_url } = req.body;
  try {
    if (!category_name || !parent_category_id) {
      return res.status(400).json({ error: "Name and parent_category_id are required", code: "INVALID_INPUT" });
    }
    if (image_url && !isValidS3Url(image_url)) {
      return res.status(400).json({ error: "Invalid image URL", code: "INVALID_URL" });
    }
    if (icon_url && !isValidS3Url(icon_url)) {
      return res.status(400).json({ error: "Invalid icon URL", code: "INVALID_URL" });
    }
    const categoryCheck = await pool.query(
      "SELECT category_id FROM search_hyderabad.categories WHERE category_id = $1 AND parent_category_id IS NULL",
      [parent_category_id]
    );
    if (categoryCheck.rows.length === 0) {
      return res.status(400).json({ error: "Parent category must be a top-level category", code: "INVALID_CATEGORY" });
    }
    const result = await pool.query(
      `UPDATE search_hyderabad.categories
       SET category_name = $1, parent_category_id = $2, description = $3, image_url = $4, icon_url = $5
       WHERE category_id = $6
       RETURNING category_id, category_name, parent_category_id, description, image_url, icon_url`,
      [category_name, parent_category_id, description || null, image_url || null, icon_url || null, id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Subcategory not found", code: "NOT_FOUND" });
    }
    res.json({ subcategory: result.rows[0], message: "Subcategory updated successfully" });
  } catch (err) {
    console.error("Error updating subcategory:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.deleteSubcategory = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      "DELETE FROM search_hyderabad.categories WHERE category_id = $1 AND parent_category_id IS NOT NULL RETURNING category_id",
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Subcategory not found", code: "NOT_FOUND" });
    }
    res.json({ message: "Subcategory deleted successfully" });
  } catch (err) {
    console.error("Error deleting subcategory:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.listShops = async (req, res) => {
  const { category_id, vendor_id, page = 1, limit = 10, search } = req.query;
  try {
    if (vendor_id && vendor_id !== req.user?.vendor_id) {
      return res.status(403).json({ error: "Unauthorized access to vendor data", code: "FORBIDDEN" });
    }
    let query = `SELECT s.*, c.category_name AS category_name,
                 COALESCE(array_agg(json_build_object('image_id', si.image_id, 'image_url', si.image_url)) FILTER (WHERE si.image_id IS NOT NULL), '{}') as images
                 FROM search_hyderabad.shops s
                 LEFT JOIN search_hyderabad.categories c ON s.category_id = c.category_id
                 LEFT JOIN search_hyderabad.shop_images si ON s.shop_id = si.shop_id
                 WHERE s.is_approved = TRUE`;
    let params = [];
    let conditions = [];

    if (category_id) {
      conditions.push(`s.category_id = $${params.length + 1}`);
      params.push(category_id);
    }
    if (vendor_id) {
      conditions.push(`s.vendor_id = $${params.length + 1}`);
      params.push(vendor_id);
    }
    if (search) {
      conditions.push(`s.shop_name ILIKE $${params.length + 1}`);
      params.push(`%${search}%`);
    }

    if (conditions.length > 0) {
      query += ` AND ${conditions.join(" AND ")}`;
    }

    query += ` GROUP BY s.shop_id, s.category_id, c.category_name`;
    query += ` ORDER BY s.shop_name`;
    query += ` LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));

    let countQuery = `SELECT COUNT(DISTINCT s.shop_id) FROM search_hyderabad.shops s
                      LEFT JOIN search_hyderabad.categories c ON s.category_id = c.category_id
                      WHERE s.is_approved = TRUE`;
    let countParams = [];
    if (category_id) {
      countQuery += ` AND s.category_id = $${countParams.length + 1}`;
      countParams.push(category_id);
    }
    if (vendor_id) {
      countQuery += ` AND s.vendor_id = $${countParams.length + 1}`;
      countParams.push(vendor_id);
    }
    if (search) {
      countQuery += ` AND s.shop_name ILIKE $${countParams.length + 1}`;
      countParams.push(`%${search}%`);
    }

    console.log("listShops query:", query, params);
    console.log("listShops countQuery:", countQuery, countParams);

    const [result, countResult] = await Promise.all([
      pool.query(query, params),
      pool.query(countQuery, countParams),
    ]);

    console.log("listShops results:", { shopCount: result.rows.length, total: parseInt(countResult.rows[0].count) });

    const total = parseInt(countResult.rows[0].count);
    res.json({
      shops: result.rows,
      pagination: { page: parseInt(page), limit: parseInt(limit), total, totalPages: Math.ceil(total / limit) },
    });
  } catch (err) {
    console.error("Error listing shops:", err.message, err.stack);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.updateShop = async (req, res) => {
  const { id } = req.params;
  const {
    category_id, vendor_id, shop_name, description, address, location, phone,
    whatsapp_number, email, website, opening_time, closing_time
  } = req.body;
  try {
    if (!category_id || !vendor_id || !shop_name || !phone || !/^\d{10}$/.test(phone)) {
      return res.status(400).json({ error: "Invalid input: category_id, vendor_id, shop_name, and 10-digit phone are required", code: "INVALID_INPUT" });
    }
    const categoryCheck = await pool.query(
      "SELECT category_id FROM search_hyderabad.categories WHERE category_id = $1",
      [category_id]
    );
    if (categoryCheck.rows.length === 0) {
      return res.status(400).json({ error: "Invalid category_id", code: "INVALID_CATEGORY" });
    }
    const vendorCheck = await pool.query(
      "SELECT vendor_id FROM search_hyderabad.vendors WHERE vendor_id = $1",
      [vendor_id]
    );
    if (vendorCheck.rows.length === 0) {
      return res.status(400).json({ error: "Invalid vendor_id", code: "INVALID_VENDOR" });
    }
    if (whatsapp_number && !/^\d{10}$/.test(whatsapp_number)) {
      return res.status(400).json({ error: "WhatsApp number must be 10 digits", code: "INVALID_INPUT" });
    }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: "Invalid email format", code: "INVALID_INPUT" });
    }
    if (website && !isValidUrl(website)) {
      return res.status(400).json({ error: "Invalid website URL", code: "INVALID_URL" });
    }
    await pool.query("BEGIN");
    const shopResult = await pool.query(
      `UPDATE search_hyderabad.shops
       SET category_id = $1, vendor_id = $2, shop_name = $3, description = $4, address = $5,
           location = $6, phone = $7, whatsapp_number = $8, email = $9, website = $10,
           opening_time = $11, closing_time = $12
       WHERE shop_id = $13
       RETURNING *`,
      [
        category_id, vendor_id, shop_name, description || null, address || null,
        location || null, phone, whatsapp_number || null, email || null, website || null,
        opening_time || null, closing_time || null, id
      ]
    );
    if (shopResult.rows.length === 0) {
      await pool.query("ROLLBACK");
      return res.status(404).json({ error: "Shop not found", code: "NOT_FOUND" });
    }
    const shop = shopResult.rows[0];
    await pool.query("COMMIT");
    const imagesResult = await pool.query(
      "SELECT image_id, image_url FROM search_hyderabad.shop_images WHERE shop_id = $1",
      [id]
    );
    res.json({ shop: { ...shop, images: imagesResult.rows }, message: "Shop updated successfully" });
  } catch (err) {
    await pool.query("ROLLBACK");
    console.error("Error updating shop:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.deleteShop = async (req, res) => {
  const { id } = req.params;
  try {
    const shopResult = await pool.query(
      "SELECT shop_id FROM search_hyderabad.shops WHERE shop_id = $1",
      [id]
    );
    if (shopResult.rows.length === 0) {
      return res.status(404).json({ error: "Shop not found", code: "NOT_FOUND" });
    }
    await pool.query("BEGIN");
    await pool.query("DELETE FROM search_hyderabad.shops WHERE shop_id = $1", [id]);
    await pool.query("COMMIT");
    res.json({ message: "Shop deleted successfully" });
  } catch (err) {
    await pool.query("ROLLBACK");
    console.error("Error deleting shop:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.approveShop = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      `UPDATE search_hyderabad.shops SET is_approved = TRUE WHERE shop_id = $1 RETURNING *`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Shop not found", code: "NOT_FOUND" });
    }
    const imagesResult = await pool.query(
      "SELECT image_id, image_url FROM search_hyderabad.shop_images WHERE shop_id = $1",
      [id]
    );
    res.json({ shop: { ...result.rows[0], images: imagesResult.rows }, message: "Shop approved successfully" });
  } catch (err) {
    console.error("Error approving shop:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.updateShopImage = async (req, res) => {
  const { id } = req.params;
  const { image_url } = req.body;
  try {
    if (!image_url) {
      return res.status(400).json({ error: "Image URL is required", code: "INVALID_INPUT" });
    }
    if (!isValidS3Url(image_url)) {
      return res.status(400).json({ error: "Invalid image URL", code: "INVALID_URL" });
    }
    const result = await pool.query(
      `UPDATE search_hyderabad.shop_images
       SET image_url = $1
       WHERE image_id = $2
       RETURNING image_id, shop_id, image_url, created_at`,
      [image_url, parseInt(id)]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Shop image not found", code: "NOT_FOUND" });
    }
    res.json({ shop_image: result.rows[0], message: "Shop image updated successfully" });
  } catch (err) {
    console.error("Error updating shop image:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.listShopImages = async (req, res) => {
  const { shop_id } = req.query;
  try {
    if (!shop_id) {
      return res.status(400).json({ error: "Shop ID is required", code: "INVALID_INPUT" });
    }
    const result = await pool.query(
      "SELECT image_id, shop_id, image_url, created_at FROM search_hyderabad.shop_images WHERE shop_id = $1",
      [shop_id]
    );
    res.json({ shop_images: result.rows });
  } catch (err) {
    console.error("Error listing shop images:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.deleteShopImage = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      "DELETE FROM search_hyderabad.shop_images WHERE image_id = $1 RETURNING image_id",
      [parseInt(id)]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Shop image not found", code: "NOT_FOUND" });
    }
    res.json({ message: "Shop image deleted successfully" });
  } catch (err) {
    console.error("Error deleting shop image:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.getSuperadminDashboard = async (req, res) => {
  try {
    const vendorCount = await pool.query("SELECT COUNT(*) FROM search_hyderabad.vendors");
    const shopCount = await pool.query("SELECT COUNT(*) FROM search_hyderabad.shops");
    const categoryCount = await pool.query("SELECT COUNT(*) FROM search_hyderabad.categories WHERE parent_category_id IS NULL");
    const subcategoryCount = await pool.query("SELECT COUNT(*) FROM search_hyderabad.categories WHERE parent_category_id IS NOT NULL");

    res.json({
      vendorCount: parseInt(vendorCount.rows[0].count),
      shopCount: parseInt(shopCount.rows[0].count),
      categoryCount: parseInt(categoryCount.rows[0].count),
      subcategoryCount: parseInt(subcategoryCount.rows[0].count),
      message: "Superadmin dashboard data",
    });
  } catch (err) {
    console.error("Error fetching superadmin dashboard:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.listServices = async (req, res) => {
  try {
    const { page = 1, limit = 10, shop_id } = req.query;
    let query = `
      SELECT c.service_id, c.shop_id, c.title, c.description, c.original_price, c.discount_price, c.image_url, c.created_at,
             c.nearby_landmarks, c.professional_achievements, c.facilities_features, c.quick_info,
             s.shop_name
      FROM search_hyderabad.catalogue c
      LEFT JOIN search_hyderabad.shops s ON c.shop_id = s.shop_id
      WHERE s.is_approved = TRUE
    `;
    let params = [parseInt(limit), (parseInt(page) - 1) * parseInt(limit)];
    let countQuery = `
      SELECT COUNT(*) 
      FROM search_hyderabad.catalogue c
      LEFT JOIN search_hyderabad.shops s ON c.shop_id = s.shop_id
      WHERE s.is_approved = TRUE
    `;
    let countParams = [];

    if (shop_id) {
      query += " AND c.shop_id = $" + (params.length + 1);
      countQuery += " AND c.shop_id = $1";
      params.push(shop_id);
      countParams.push(shop_id);
    }

    query += " ORDER BY s.shop_name, c.title LIMIT $1 OFFSET $2";

    // Ensure the queries are executed together
    const [servicesResult, countResult] = await Promise.all([
      pool.query(query, params),
      pool.query(countQuery, countParams),
    ]);

    const total = parseInt(countResult.rows[0].count);
    res.json({
      services: servicesResult.rows,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (err) {
    console.error("Error listing services:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};


exports.createService = async (req, res) => {
  const { shop_id, title, description, original_price, discount_price, image_url, nearby_landmarks, professional_achievements, facilities_features, quick_info } = req.body;
  try {
    if (!shop_id || !title) {
      return res.status(400).json({ error: "Shop ID and title are required", code: "INVALID_INPUT" });
    }
    if (title.length > 255) {
      return res.status(400).json({ error: "Title must be 255 characters or less", code: "INVALID_INPUT" });
    }
    if (description && description.length > 1000) {
      return res.status(400).json({ error: "Description must be 1000 characters or less", code: "INVALID_INPUT" });
    }
    if (original_price && (isNaN(original_price) || original_price < 0)) {
      return res.status(400).json({ error: "Invalid original price", code: "INVALID_INPUT" });
    }
    if (discount_price && (isNaN(discount_price) || discount_price < 0)) {
      return res.status(400).json({ error: "Invalid discount price", code: "INVALID_INPUT" });
    }
    if (image_url && !isValidS3Url(image_url)) {
      return res.status(400).json({ error: "Invalid image URL", code: "INVALID_URL" });
    }
    // Validate JSONB fields
    if (nearby_landmarks && (typeof nearby_landmarks !== 'object' || Array.isArray(nearby_landmarks))) {
      return res.status(400).json({ error: "nearby_landmarks must be a valid JSON object", code: "INVALID_INPUT" });
    }
    if (professional_achievements && (typeof professional_achievements !== 'object' || Array.isArray(professional_achievements))) {
      return res.status(400).json({ error: "professional_achievements must be a valid JSON object", code: "INVALID_INPUT" });
    }
    if (facilities_features && (typeof facilities_features !== 'object' || Array.isArray(facilities_features))) {
      return res.status(400).json({ error: "facilities_features must be a valid JSON object", code: "INVALID_INPUT" });
    }
    if (quick_info && (typeof quick_info !== 'object' || Array.isArray(quick_info))) {
      return res.status(400).json({ error: "quick_info must be a valid JSON object", code: "INVALID_INPUT" });
    }
    const shopCheck = await pool.query(
      "SELECT shop_id FROM search_hyderabad.shops WHERE shop_id = $1 AND is_approved = TRUE",
      [shop_id]
    );
    if (shopCheck.rows.length === 0) {
      return res.status(404).json({ error: "Approved shop not found", code: "NOT_FOUND" });
    }
    const service_id = `srv_${(await pool.query("SELECT nextval('search_hyderabad.service_id_seq')")).rows[0].nextval}`;
    const result = await pool.query(
      `INSERT INTO search_hyderabad.catalogue (
        service_id, shop_id, title, description, original_price, discount_price, image_url,
        nearby_landmarks, professional_achievements, facilities_features, quick_info
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING service_id, shop_id, title, description, original_price, discount_price, image_url, created_at,
                nearby_landmarks, professional_achievements, facilities_features, quick_info`,
      [
        service_id, shop_id, title, description || null, parseFloat(original_price) || null, parseFloat(discount_price) || null, image_url || null,
        nearby_landmarks || null, professional_achievements || null, facilities_features || null, quick_info || null
      ]
    );
    res.status(201).json({ service: result.rows[0], message: "Service created successfully" });
  } catch (err) {
    console.error("Error creating service:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.updateService = async (req, res) => {
  const { service_id } = req.params;
  const { title, description, original_price, discount_price, image_url, nearby_landmarks, professional_achievements, facilities_features, quick_info } = req.body;
  try {
    if (!title) {
      return res.status(400).json({ error: "Title is required", code: "INVALID_INPUT" });
    }
    if (title.length > 255) {
      return res.status(400).json({ error: "Title must be 255 characters or less", code: "INVALID_INPUT" });
    }
    if (description && description.length > 1000) {
      return res.status(400).json({ error: "Description must be 1000 characters or less", code: "INVALID_INPUT" });
    }
    if (original_price && (isNaN(original_price) || original_price < 0)) {
      return res.status(400).json({ error: "Invalid original price", code: "INVALID_INPUT" });
    }
    if (discount_price && (isNaN(discount_price) || discount_price < 0)) {
      return res.status(400).json({ error: "Invalid discount price", code: "INVALID_INPUT" });
    }
    if (image_url && !isValidS3Url(image_url)) {
      return res.status(400).json({ error: "Invalid image URL", code: "INVALID_URL" });
    }
    // Validate JSONB fields
    if (nearby_landmarks && (typeof nearby_landmarks !== 'object' || Array.isArray(nearby_landmarks))) {
      return res.status(400).json({ error: "nearby_landmarks must be a valid JSON object", code: "INVALID_INPUT" });
    }
    if (professional_achievements && (typeof professional_achievements !== 'object' || Array.isArray(professional_achievements))) {
      return res.status(400).json({ error: "professional_achievements must be a valid JSON object", code: "INVALID_INPUT" });
    }
    if (facilities_features && (typeof facilities_features !== 'object' || Array.isArray(facilities_features))) {
      return res.status(400).json({ error: "facilities_features must be a valid JSON object", code: "INVALID_INPUT" });
    }
    if (quick_info && (typeof quick_info !== 'object' || Array.isArray(quick_info))) {
      return res.status(400).json({ error: "quick_info must be a valid JSON object", code: "INVALID_INPUT" });
    }
    const result = await pool.query(
      `UPDATE search_hyderabad.catalogue
       SET title = $1, description = $2, original_price = $3, discount_price = $4, image_url = $5,
           nearby_landmarks = $6, professional_achievements = $7, facilities_features = $8, quick_info = $9
       WHERE service_id = $10
       RETURNING service_id, shop_id, title, description, original_price, discount_price, image_url, created_at,
                 nearby_landmarks, professional_achievements, facilities_features, quick_info`,
      [
        title, description || null, parseFloat(original_price) || null, parseFloat(discount_price) || null, image_url || null,
        nearby_landmarks || null, professional_achievements || null, facilities_features || null, quick_info || null, service_id
      ]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Service not found", code: "NOT_FOUND" });
    }
    res.json({ service: result.rows[0], message: "Service updated successfully" });
  } catch (err) {
    console.error("Error updating service:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.deleteService = async (req, res) => {
  const { service_id } = req.params;
  try {
    const result = await pool.query(
      `DELETE FROM search_hyderabad.catalogue WHERE service_id = $1 RETURNING service_id`,
      [service_id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Service not found", code: "NOT_FOUND" });
    }
    res.json({ message: "Service deleted successfully" });
  } catch (err) {
    console.error("Error deleting service:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.createReview = async (req, res) => {
  const { shop_id, user_id, rating, comment } = req.body;
  try {
    if (!shop_id || !user_id || !rating || rating < 1 || rating > 5) {
      return res.status(400).json({ error: "Shop ID, user ID, and rating (1-5) are required", code: "INVALID_INPUT" });
    }
    const shopCheck = await pool.query(
      "SELECT shop_id FROM search_hyderabad.shops WHERE shop_id = $1",
      [shop_id]
    );
    if (shopCheck.rows.length === 0) {
      return res.status(404).json({ error: "Shop not found", code: "NOT_FOUND" });
    }
    const userCheck = await pool.query(
      "SELECT user_id FROM search_hyderabad.c_users WHERE user_id = $1",
      [user_id]
    );
    if (userCheck.rows.length === 0) {
      return res.status(404).json({ error: "User not found", code: "NOT_FOUND" });
    }
    await pool.query("BEGIN");
    const reviewResult = await pool.query(
      `INSERT INTO search_hyderabad.reviews (review_id, shop_id, user_id, rating, comment)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING review_id, shop_id, user_id, rating, comment, created_at`,
      [uuidv4(), shop_id, user_id, parseInt(rating), comment || null]
    );
    await pool.query(
      `UPDATE search_hyderabad.shops
       SET review_count = review_count + 1,
           rating = (SELECT AVG(rating) FROM search_hyderabad.reviews WHERE shop_id = $1)
       WHERE shop_id = $1`,
      [shop_id]
    );
    await pool.query("COMMIT");
    res.status(201).json({ review: reviewResult.rows[0], message: "Review created successfully" });
  } catch (err) {
    await pool.query("ROLLBACK");
    console.error("Error creating review:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.listReviews = async (req, res) => {
  const { shop_id } = req.query;
  try {
    if (!shop_id) {
      return res.status(400).json({ error: "Shop ID is required", code: "INVALID_INPUT" });
    }
    const result = await pool.query(
      "SELECT review_id, shop_id, user_id, rating, comment, created_at FROM search_hyderabad.reviews WHERE shop_id = $1",
      [shop_id]
    );
    res.json({ reviews: result.rows });
  } catch (err) {
    console.error("Error listing reviews:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.deleteReview = async (req, res) => {
  const { id } = req.params;
  try {
    const reviewResult = await pool.query(
      "SELECT shop_id FROM search_hyderabad.reviews WHERE review_id = $1",
      [id]
    );
    if (reviewResult.rows.length === 0) {
      return res.status(404).json({ error: "Review not found", code: "NOT_FOUND" });
    }
    const shop_id = reviewResult.rows[0].shop_id;
    await pool.query("BEGIN");
    await pool.query("DELETE FROM search_hyderabad.reviews WHERE review_id = $1", [id]);
    await pool.query(
      `UPDATE search_hyderabad.shops
       SET review_count = review_count - 1,
           rating = COALESCE((SELECT AVG(rating) FROM search_hyderabad.reviews WHERE shop_id = $1), 0)
       WHERE shop_id = $1`,
      [shop_id]
    );
    await pool.query("COMMIT");
    res.json({ message: "Review deleted successfully" });
  } catch (err) {
    await pool.query("ROLLBACK");
    console.error("Error deleting review:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

// Fetch a single shop by shop_id
exports.getShopById = async (req, res) => {
  const { shop_id } = req.query;

  try {
    if (!shop_id) {
      console.log("getShopById: No shop_id provided in query");
      return res.status(400).json({ error: "Shop ID is required", code: "INVALID_INPUT" });
    }

    console.log(`getShopById: Processing shop_id: ${shop_id}`);
    const result = await pool.query(
      `SELECT shop_id, shop_name, is_approved FROM search_hyderabad.shops WHERE shop_id::text = $1`,
      [shop_id]
    );

    console.log(`getShopById: Query result: ${JSON.stringify(result.rows)}`);
    if (result.rows.length === 0) {
      console.log(`getShopById: No shop found for shop_id: ${shop_id}`);
      return res.status(404).json({ error: "Shop not found", code: "NOT_FOUND" });
    }

    const shop = result.rows[0];
    console.log(`getShopById: Found shop: ${JSON.stringify(shop)}`);
    res.json({ shop_name: shop.shop_name, is_approved: shop.is_approved });
  } catch (err) {
    console.error(`getShopById: Error fetching shop for shop_id ${shop_id}:`, err.message, err.stack);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};


exports.createHomeAd = async (req, res) => {
  const { image_url } = req.body;
  try {
    if (!image_url || !isValidS3Url(image_url)) {
      return res.status(400).json({ error: "Valid S3 image URL is required", code: "INVALID_INPUT" });
    }
    const result = await pool.query(
      `INSERT INTO search_hyderabad.home_ads (image_url, uploaded_at)
       VALUES ($1, CURRENT_TIMESTAMP)
       RETURNING id, image_url, uploaded_at`,
      [image_url]
    );
    res.status(201).json({ ad: result.rows[0], message: "Home ad created successfully" });
  } catch (err) {
    console.error("Error creating home ad:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.updateHomeAd = async (req, res) => {
  const { id } = req.params;
  const { image_url } = req.body;
  try {
    if (!image_url || !isValidS3Url(image_url)) {
      return res.status(400).json({ error: "Valid S3 image URL is required", code: "INVALID_INPUT" });
    }
    const result = await pool.query(
      `UPDATE search_hyderabad.home_ads
       SET image_url = $1
       WHERE id = $2
       RETURNING id, image_url, uploaded_at`,
      [image_url, parseInt(id)]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Home ad not found", code: "NOT_FOUND" });
    }
    res.json({ ad: result.rows[0], message: "Home ad updated successfully" });
  } catch (err) {
    console.error("Error updating home ad:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.deleteHomeAd = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      `DELETE FROM search_hyderabad.home_ads WHERE id = $1 RETURNING id`,
      [parseInt(id)]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Home ad not found", code: "NOT_FOUND" });
    }
    res.json({ message: "Home ad deleted successfully" });
  } catch (err) {
    console.error("Error deleting home ad:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.listHomeAds = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, image_url, uploaded_at FROM search_hyderabad.home_ads ORDER BY uploaded_at DESC`
    );
    res.json({ ads: result.rows });
  } catch (err) {
    console.error("Error listing home ads:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.createPopupAd = async (req, res) => {
  const { image_url } = req.body;
  try {
    if (!image_url || !isValidS3Url(image_url)) {
      return res.status(400).json({ error: "Valid S3 image URL is required", code: "INVALID_INPUT" });
    }
    const result = await pool.query(
      `INSERT INTO search_hyderabad.popup_ads (image_url, uploaded_at)
       VALUES ($1, CURRENT_TIMESTAMP)
       RETURNING id, image_url, uploaded_at`,
      [image_url]
    );
    res.status(201).json({ ad: result.rows[0], message: "Popup ad created successfully" });
  } catch (err) {
    console.error("Error creating popup ad:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.updatePopupAd = async (req, res) => {
  const { id } = req.params;
  const { image_url } = req.body;
  try {
    if (!image_url || !isValidS3Url(image_url)) {
      return res.status(400).json({ error: "Valid S3 image URL is required", code: "INVALID_INPUT" });
    }
    const result = await pool.query(
      `UPDATE search_hyderabad.popup_ads
       SET image_url = $1
       WHERE id = $2
       RETURNING id, image_url, uploaded_at`,
      [image_url, parseInt(id)]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Popup ad not found", code: "NOT_FOUND" });
    }
    res.json({ ad: result.rows[0], message: "Popup ad updated successfully" });
  } catch (err) {
    console.error("Error updating popup ad:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.deletePopupAd = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      `DELETE FROM search_hyderabad.popup_ads WHERE id = $1 RETURNING id`,
      [parseInt(id)]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Popup ad not found", code: "NOT_FOUND" });
    }
    res.json({ message: "Popup ad deleted successfully" });
  } catch (err) {
    console.error("Error deleting popup ad:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

exports.listPopupAds = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, image_url, uploaded_at FROM search_hyderabad.popup_ads ORDER BY uploaded_at DESC`
    );
    res.json({ ads: result.rows });
  } catch (err) {
    console.error("Error listing popup ads:", err.message);
    res.status(500).json({ error: "Server error", code: "SERVER_ERROR" });
  }
};

// Utility function to validate URLs
function isValidUrl(url) {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
}