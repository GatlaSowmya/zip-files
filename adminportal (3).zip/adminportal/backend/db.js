const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

// Handle initial connection
pool.connect()
  .then(() => console.log("✅ Connected to PostgreSQL database"))
  .catch((err) => {
    console.error("❌ Database connection error:", err.message);
    process.exit(1);  // Exit the process if the DB connection fails
  });

// Reconnect on error
pool.on('error', (err, client) => {
  console.error('Unexpected error on idle client', err);
  process.exit(1);  // Exit the process if there's an unexpected DB error
});

module.exports = pool;
