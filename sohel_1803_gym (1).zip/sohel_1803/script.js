
// scroll down for the navbar
window.addEventListener("scroll", () => {
    const navbar = document.querySelector(".navbar");
    if (window.scrollY > 50) {  // Add color after scrolling 50px
        navbar.classList.add("scrolled");
    } else {
        navbar.classList.remove("scrolled");
    }
});

// Scroll Animation for about section 
    window.addEventListener('scroll', () => {
        const aboutSection = document.querySelector('.about');
        const sectionTop = aboutSection.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;

        if (sectionTop < windowHeight * 0.8) {
            aboutSection.classList.add('slide-in');
        }
    });

// Scroll down  Animation effect for the prices section 
    document.addEventListener("DOMContentLoaded", () => {
        const cards = document.querySelectorAll('.GYMNASTY-card');

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('reveal');
                }
            });
        }, {
            threshold: 0.2
        });

        cards.forEach(card => {
            observer.observe(card);
        });
    });

// Magnetic effect for gallery section 

document.addEventListener("DOMContentLoaded", () => {
    const images = document.querySelectorAll(".magnetic");

    images.forEach(img => {
        img.addEventListener("mousemove", (e) => {
            const { left, top, width, height } = img.getBoundingClientRect();
            const x = (e.clientX - left - width / 2) * 0.1;
            const y = (e.clientY - top - height / 2) * 0.1;
            img.style.transform = `translate(${x}px, ${y}px) scale(1.05)`;
        });

        img.addEventListener("mouseleave", () => {
            img.style.transform = "translate(0, 0) scale(1)";
        });
    });
});

// Scroll Animation for gallery  section 
window.addEventListener('scroll', () => {
    const aboutSection = document.querySelector('.gallery');
    const sectionTop = aboutSection.getBoundingClientRect().top;
    const windowHeight = window.innerHeight;

    if (sectionTop < windowHeight * 0.8) {
        aboutSection.classList.add('slide-in');
    }
});

// scroll animation for the desiner section 
// Scroll animation for images
document.addEventListener('DOMContentLoaded', () => {
    const images = document.querySelectorAll('.scroll-in');

    const scrollAnimation = () => {
        images.forEach(img => {
            const position = img.getBoundingClientRect().top;
            const screenHeight = window.innerHeight;

            if (position < screenHeight - 100) {
                img.classList.add('show');
            }
        });
    };

    window.addEventListener('scroll', scrollAnimation);
    scrollAnimation();  // Trigger on load in case images are already in view
});


// main section 
const mobileMenu = document.getElementById('mobile-menu');
const navList = document.getElementById('nav-list');
const navbar = document.getElementById('navbar');
const languageSelect = document.getElementById('selected-lang');

// Toggle the 'active' class to show/hide the nav menu when hamburger is clicked
mobileMenu.addEventListener('click', () => {
    navList.classList.toggle('active');
});

// Close the menu if a click occurs outside the menu (excluding the language select)
navList.addEventListener('click', (event) => {
  // Check if the clicked element is not the translation dropdown
  if (event.target !== languageSelect) {
      navList.classList.remove('active');
  }
});

// Add a class when scrolling to change navbar style
window.addEventListener('scroll', () => {
  if (window.scrollY > 0) {
      navbar.classList.add('scrolled');
  } else {
      navbar.classList.remove('scrolled');
  }
});


// -----nav ends----


// nav ends----



// Open the popup
function contactOpenPopup() {
    document.getElementById('contactpopup').style.display = 'flex';
}

// Handle form submission (store the redirection URL in sessionStorage)
function contactHandleSubmit(_event) {
    // Prevent the form from submitting normally

    // Store the initial redirection URL in sessionStorage


    // Show the thank you message
    document.getElementById('contactThankYouMessage').style.display = 'block';

    // Simulate form submission after a delay (to show the "Thank you" message)
    setTimeout(function () {
        document.getElementById('contactForm').submit();
    }, 2000); // Delay for showing the thank you message before submission
}

// Handle form submission and redirection override


// Close popup
function contactClosePopup() {
    document.getElementById('contactpopup').style.display = 'none';
}


// Get today's date in YYYY-MM-DD format
const today = new Date().toISOString().split('T')[0];

// Initialize the Flatpickr calendar on the hidden input with minDate set to today's date
flatpickr("#appointmentDate", {
    minDate: today, // Prevent selecting past dates
    onChange: function (selectedDates, dateStr, instance) {
        // Update the hidden input field with the selected date
        let appointmentDateField = document.getElementById('appointmentDateField');
        appointmentDateField.value = dateStr;

        // Update the email content in the textarea with the selected appointment date
        let emailBody = document.getElementById('emailBody');
        emailBody.value = "You have an appointment scheduled on " + dateStr + ".";
    }
});

// Show the calendar when the button is clicked
document.getElementById('datePickerButton').addEventListener('click', function () {
    document.getElementById('appointmentDate').click();
});

// Open the popup
function openPopup() {
    document.getElementById('popup').style.display = 'flex';
}

// Handle form submission
function handleSubmit(_event) {
    // Prevent the default form submission behavior

    // Show the thank you message
    document.getElementById('thankYouMessage').style.display = 'block';

    // Simulate a short delay for showing the thank you message
    setTimeout(function () {
        // Now submit the form manually
        document.getElementById('emailForm').submit(); // Trigger form submission

        // Close the popup after a short delay (to show the thank you message)
        closePopup();
    }, 3000); // Delay for 3 seconds (you can adjust the time)
}

// Close popup
function closePopup() {
    document.getElementById('popup').style.display = 'none';
}


function getTextContentBySelector(selector) {
    const element = document.querySelector(selector);
    if (element) {
        return element.textContent.trim();
    } else {
        console.warn(`Element with selector ${selector} not found.`);
        return ''; // Return an empty string if the element doesn't exist
    }
}

// Function to fetch translations using Google Translate API
async function fetchTranslations(textArray, targetLang) {
    const apiKey = "AIzaSyDaOqfSe9sHH1phL9FINO5AlKPPFfieEgw"; // Replace with your actual API key
    const url = `https://translation.googleapis.com/language/translate/v2?key=${apiKey}`;

    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ q: textArray, target: targetLang }),
    });

    const data = await response.json();
    if (data.error) {
        console.error("Error translating:", data.error);
        return [];
    }

    return data.data.translations.map(t => t.translatedText);
}

// Function to translate page content based on selected language
async function translateContent() {
    const selectedLang = document.getElementById("languageSelect").value;  


    // Collect all navigation items text for translation (no need for IDs)
    const navItems = Array.from(document.querySelectorAll('.nav-link'))
        .map(nav => nav.textContent);

    // Add nav items text to translation
    navItems.forEach(navItem => {
        textElements.push({
            text: navItem
        });
    });

    const textsToTranslate = textElements.map(element => element.text);
    const translatedTexts = await fetchTranslations(textsToTranslate, selectedLang);

    // Update each text element with its translated content
    let translatedIndex = 0;

    // Update text elements (those that have selectors)
    textElements.forEach((element) => {
        if (element.selector) {
            const el = document.querySelector(element.selector);
            if (el) {
                el.textContent = translatedTexts[translatedIndex] || element.text;
                translatedIndex++;
            } else {
                console.warn(`Element with selector ${element.selector} not found.`);
            }
        } else {
            // Update nav items (no selectors)
            const navLinks = document.querySelectorAll('.nav-link');
            if (navLinks[translatedIndex]) {
                navLinks[translatedIndex].textContent = translatedTexts[translatedIndex] || element.text;
            }
            translatedIndex++;
        }
    });
}

// Listen to language selection change
document.getElementById("languageSelect").addEventListener("change", translateContent);

// Set the current year in the footer dynamically
document.getElementById("currentYear").textContent = new Date().getFullYear();

// Function to set the initial content based on the language
async function setInitialContent() {
    const selectedLang = document.getElementById("languageSelect").value;
    translateContent(selectedLang); // Translate the page content initially when the page loads.
}

// Run initial translation when the page is loaded
window.onload = setInitialContent;


    
document.querySelectorAll(".tilt").forEach((item) => {
    item.addEventListener("mousemove", function (e) {
        let xAxis = (window.innerWidth / 2 - e.pageX) / 25;
        let yAxis = (window.innerHeight / 2 - e.pageY) / 25;
        this.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
    });

    item.addEventListener("mouseleave", function () {
        this.style.transform = "rotateY(480deg) rotateX(3600deg)";
    });
});

document.addEventListener("DOMContentLoaded", function () {
    function revealOnScroll() {
        let aboutSection = document.querySelector('.about');
        let sectionPosition = aboutSection.getBoundingClientRect().top;
        let screenPosition = window.innerHeight / 1.3;

        if (sectionPosition < screenPosition) {
            aboutSection.classList.add('visible');
        }
    }

    window.addEventListener("scroll", revealOnScroll);
});


// google translations 

function googleTranslateElementInit() {
    new google.translate.TranslateElement({ pageLanguage: 'en' }, 'google_translate_element');
}

document.addEventListener("DOMContentLoaded", function () {
    document.cookie = "googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
});

function translateLanguage(lang, langName) {
    document.getElementById("selected-lang").textContent = langName;
      var selectField = document.querySelector(".goog-te-combo");
      if (selectField) {
          selectField.value = lang;
          selectField.dispatchEvent(new Event('change'));
      }
  }

function toggleDropdown() {
    var dropdown = document.getElementById("languageDropdown");
    dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
}
