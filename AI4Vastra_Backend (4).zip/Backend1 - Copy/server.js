// Load environment variables
const dotenv = require('dotenv');
dotenv.config();

const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const axios = require('axios');

// AWS S3 imports
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const multer = require('multer');
const multerS3 = require('multer-s3');
const FormData = require('form-data');

// DeepAI
const deepai = require('deepai');
deepai.setApiKey(process.env.DEEPAI_API_KEY);

// Google Generative AI
const { GoogleGenerativeAI } = require('@google/generative-ai');
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const fetch = require('node-fetch');

// Other imports
const Razorpay = require('razorpay');
const crypto = require('crypto');
const nodemailer = require('nodemailer');

const app = express();
const PORT = parseInt(process.env.PORT, 10);

// Store temporary signup data and OTPs
const pendingSignups = new Map();
const forgotPasswordOTPs = new Map();

// Middleware
app.use(cors());
app.use(express.json({ limit: "10mb" })); // Support base64 images

// Initialize Razorpay
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

// PostgreSQL connection configuration
const poolConfig = {
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: parseInt(process.env.DB_PORT, 10),
};

// PostgreSQL connection
const pool = new Pool(poolConfig);

// Test database connection
pool.connect((err, client, release) => {
  if (err) {
    console.error('Database connection error:', err.stack);
  } else {
    console.log('Connected to PostgreSQL database');
    if (release) release();
  }
});

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// AWS properties
// Validate environment variables
const awsRegion = process.env.AWS_REGION;
const awsAccessKeyId = process.env.AWS_ACCESS_KEY_ID;
const awsSecretAccessKey = process.env.AWS_SECRET_ACCESS_KEY;
const bucketName = process.env.BUCKET_NAME;

if (!awsRegion || !awsAccessKeyId || !awsSecretAccessKey) {
  throw new Error('Missing required AWS environment variables: AWS_REGION, AWS_ACCESS_KEY_ID, or AWS_SECRET_ACCESS_KEY');
}

const s3 = new S3Client({
  region: awsRegion,
  credentials: {
    accessKeyId: awsAccessKeyId,
    secretAccessKey: awsSecretAccessKey,
  },
});

if (!bucketName) {
  throw new Error('Missing required environment variable: BUCKET_NAME');
}

const upload = multer({
  storage: multerS3({
    s3: s3,
    bucket: bucketName,
    contentType: (req, file, cb) => {
      cb(null, file.mimetype); // Use the file's mimetype for Content-Type
    },
    metadata: function (_req, _file, cb) {
      cb(null, {
        'Content-Disposition': 'inline',
      });
    },
    key: function (_req, file, cb) {
      const fileName = `user-images/${Date.now()}-${file.originalname}`;
      console.log('Uploading file with key:', fileName);
      cb(null, fileName);
    },
  }),
});

app.post('/api/signup', async (req, res) => {
  const { customer_name, customer_email, phone_no, alternate_no, customer_gender, password } = req.body;

  try {
    // Validate required fields
    if (!customer_name || !customer_email || !phone_no || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please fill in all required fields',
      });
    }

    // Check if email already exists
    const emailCheck = await pool.query(
      'SELECT customer_email FROM smartstyley_dashboard.t_customer_details WHERE customer_email = $1',
      [customer_email.toLowerCase()]
    );

    // Check if phone number already exists
    const phoneCheck = await pool.query(
      'SELECT phone_no FROM smartstyley_dashboard.t_customer_details WHERE phone_no = $1',
      [phone_no.trim()]
    );

    if (phoneCheck.rows.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Phone number is already registered',
      });
    }

    // Check alternate number if provided
    if (alternate_no && alternate_no.trim()) {
      if (alternate_no.trim() === phone_no.trim()) {
        return res.status(400).json({
          success: false,
          message: 'Alternate phone number cannot be same as primary phone number',
        });
      }

      const alternateCheck = await pool.query(
        'SELECT phone_no FROM smartstyley_dashboard.t_customer_details WHERE phone_no = $1 OR alternate_no = $1',
        [alternate_no.trim()]
      );

      if (alternateCheck.rows.length > 0) {
        return res.status(400).json({
          success: false,
          message: 'Alternate phone number is already registered as primary number',
        });
      }
    }

    if (emailCheck.rows.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Email address is already registered',
      });
    }

    // Generate OTP and store signup data
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    pendingSignups.set(customer_email.toLowerCase(), {
      customer_name,
      customer_email,
      phone_no,
      alternate_no,
      customer_gender,
      password,
      otp,
      timestamp: Date.now(),
    });

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: customer_email,
      subject: 'Verify Your Email - SmartStyley',
      html: `
        <h3>Welcome to SmartStyley!</h3>
        <p>Your OTP for email verification is: <strong>${otp}</strong></p>
        <p>This OTP will expire in 10 minutes.</p>
      `,
    });

    res.status(200).json({
      success: true,
      message: 'OTP sent to your email. Please verify to complete registration.',
      email: customer_email,
    });
  } catch (error) {
    console.error('Signup error:', error);
    res.status(500).json({
      success: false,
      message: 'Error creating account. Please try again.',
    });
  }
});

app.get('/api/check-phone/:phoneNumber', async (req, res) => {
  const { phoneNumber } = req.params;

  try {
    const phoneCheck = await pool.query(
      'SELECT phone_no FROM smartstyley_dashboard.t_customer_details WHERE phone_no = $1 OR alternate_no = $1',
      [phoneNumber.trim()]
    );

    res.json({ exists: phoneCheck.rows.length > 0 });
  } catch (error) {
    console.error('Phone check error:', error);
    res.status(500).json({ exists: false });
  }
});

app.post('/api/verify-otp', async (req, res) => {
  const { email, otp } = req.body;

  try {
    const pendingData = pendingSignups.get(email.toLowerCase());

    if (!pendingData) {
      return res.status(400).json({
        success: false,
        message: 'OTP expired or invalid. Please signup again.',
      });
    }

    // Check if OTP is expired (10 minutes)
    if (Date.now() - pendingData.timestamp > 600000) {
      pendingSignups.delete(email.toLowerCase());
      return res.status(400).json({
        success: false,
        message: 'OTP expired. Please signup again.',
      });
    }

    // Verify OTP
    if (pendingData.otp !== otp) {
      return res.status(400).json({
        success: false,
        message: 'Invalid OTP. Please try again.',
      });
    }

    const insertQuery = `
      INSERT INTO smartstyley_dashboard.t_customer_details 
      (customer_name, customer_email, phone_no, alternate_no, customer_gender, password)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING cust_id, customer_name, customer_email
    `;

    const values = [
      pendingData.customer_name.trim(),
      pendingData.customer_email.toLowerCase().trim(),
      pendingData.phone_no.trim(),
      pendingData.alternate_no || null,
      pendingData.customer_gender || 'N',
      pendingData.password,
    ];

    const result = await pool.query(insertQuery, values);

    // Remove from pending signups
    pendingSignups.delete(email.toLowerCase());

    res.status(201).json({
      success: true,
      message: 'Account created successfully!',
      customer: result.rows[0],
    });
  } catch (error) {
    console.error('OTP verification error:', error);
    res.status(500).json({
      success: false,
      message: 'Error verifying OTP. Please try again.',
    });
  }
});

// Profile endpoint
app.get('/api/profile/:cust_id', async (req, res) => {
  const { cust_id } = req.params;

  try {
    // Validate cust_id
    if (!cust_id || cust_id.trim() === '') {
      return res.status(400).json({
        success: false,
        message: 'Invalid customer ID',
      });
    }

    // Query to fetch user profile data
    const userQuery = `
      SELECT cust_id, customer_name, customer_email, phone_no, alternate_no, create_date, customer_gender
      FROM smartstyley_dashboard.t_customer_details 
      WHERE cust_id = $1
    `;

    const userResult = await pool.query(userQuery, [cust_id]);

    if (userResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    const user = userResult.rows[0];

    // Format the response to match what the frontend expects
    const profileData = {
      cust_id: user.cust_id,
      customer_name: user.customer_name,
      customer_email: user.customer_email,
      phone_no: user.phone_no,
      alternate_no: user.alternate_no,
      customer_gender: user.customer_gender,
      created_at: user.create_date ? user.create_date.toISOString() : null,
    };

    res.status(200).json({
      success: true,
      customer: profileData,
    });
  } catch (error) {
    console.error('Profile fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching profile data',
    });
  }
});

// Edit profile endpoint
app.put('/api/profile/:cust_id', async (req, res) => {
  const { cust_id } = req.params;
  const { customer_name, customer_email, phone_no, alternate_no } = req.body;

  try {
    // Validate input
    if (!cust_id || cust_id.trim() === '') {
      return res.status(400).json({
        success: false,
        message: 'Invalid customer ID',
      });
    }

    if (!customer_name || !customer_email || !phone_no) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, and phone number are required',
      });
    }

    // Update query
    const updateQuery = `
      UPDATE smartstyley_dashboard.t_customer_details
      SET customer_name = $1, customer_email = $2, phone_no = $3, alternate_no = $4
      WHERE cust_id = $5
      RETURNING cust_id, customer_name, customer_email, phone_no, alternate_no, create_date, customer_gender
    `;

    const updateResult = await pool.query(updateQuery, [
      customer_name,
      customer_email,
      phone_no,
      alternate_no || null,
      cust_id,
    ]);

    if (updateResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    const updatedUser = updateResult.rows[0];

    // Format response
    const profileData = {
      cust_id: updatedUser.cust_id,
      customer_name: updatedUser.customer_name,
      customer_email: updatedUser.customer_email,
      phone_no: updatedUser.phone_no,
      alternate_no: updatedUser.alternate_no,
      customer_gender: updatedUser.customer_gender,
      created_at: updatedUser.create_date ? updatedUser.create_date.toISOString() : null,
    };

    res.status(200).json({
      success: true,
      customer: profileData,
    });
  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({
      success: false,
      message: 'Error updating profile data',
    });
  }
});

// Signin endpoint
app.post('/api/signin', async (req, res) => {
  const { customer_email, password } = req.body;

  try {
    // Validate required fields
    if (!customer_email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both email and password',
      });
    }

    // Check if user exists and get user details
    const userQuery = `
      SELECT cust_id, customer_name, customer_email, password, phone_no, customer_gender
      FROM smartstyley_dashboard.t_customer_details 
      WHERE customer_email = $1
    `;

    const userResult = await pool.query(userQuery, [customer_email.toLowerCase()]);

    if (userResult.rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password',
      });
    }

    const user = userResult.rows[0];

    console.log('User from database:', {
      cust_id: user.cust_id,
      cust_id_type: typeof user.cust_id,
      customer_name: user.customer_name,
    });

    // Debug logs
    console.log('Raw user data from database:', user);
    console.log('cust_id from database:', user.cust_id, 'type:', typeof user.cust_id);

    // In a production app, you should hash passwords and compare hashes
    // For now, we're doing a direct comparison (NOT SECURE)
    if (user.password !== password) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password',
      });
    }

    // Remove password from response
    const { password: userPassword, ...userWithoutPassword } = user;

    // Debug log
    console.log('User data being sent to frontend:', userWithoutPassword);

    res.status(200).json({
      success: true,
      message: 'Sign in successful!',
      customer: userWithoutPassword,
    });
  } catch (error) {
    console.error('Signin error:', error);
    res.status(500).json({
      success: false,
      message: 'Error signing in. Please try again.',
    });
  }
});

// Forgot Password - Send OTP
app.post('/api/forgot-password', async (req, res) => {
  const { email } = req.body;

  try {
    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email address',
      });
    }

    // Check if user exists
    const userQuery = `
      SELECT customer_email FROM smartstyley_dashboard.t_customer_details 
      WHERE customer_email = $1
    `;
    const userResult = await pool.query(userQuery, [email.toLowerCase()]);

    if (userResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No account found with this email address',
      });
    }

    // Generate OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    // Store OTP with expiration (10 minutes)
    forgotPasswordOTPs.set(email.toLowerCase(), {
      email: email.toLowerCase(),
      otp,
      timestamp: Date.now() + 10 * 60 * 1000,
    });

    // Send OTP email
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Password Reset Code - SmartStyley',
      html: `
        <h2>Password Reset Request</h2>
        <p>Your password reset code is: <strong>${otp}</strong></p>
        <p>This code will expire in 10 minutes.</p>
        <p>If you didn't request this, please ignore this email.</p>
      `,
    };

    await transporter.sendMail(mailOptions);

    res.status(200).json({
      success: true,
      message: 'Reset code sent to your email address',
    });
  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({
      success: false,
      message: 'Error sending reset code. Please try again.',
    });
  }
});

// Verify Forgot Password OTP
app.post('/api/verify-forgot-otp', async (req, res) => {
  const { email, otp } = req.body;

  try {
    if (!email || !otp) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email and OTP',
      });
    }

    const storedOTP = forgotPasswordOTPs.get(email.toLowerCase());

    if (!storedOTP) {
      return res.status(400).json({
        success: false,
        message: 'OTP not found or expired',
      });
    }

    if (Date.now() > storedOTP.timestamp) {
      forgotPasswordOTPs.delete(email.toLowerCase());
      return res.status(400).json({
        success: false,
        message: 'OTP has expired',
      });
    }

    if (storedOTP.otp !== otp) {
      return res.status(400).json({
        success: false,
        message: 'Invalid OTP',
      });
    }

    res.status(200).json({
      success: true,
      message: 'OTP verified successfully',
    });
  } catch (error) {
    console.error('OTP verification error:', error);
    res.status(500).json({
      success: false,
      message: 'Error verifying OTP. Please try again.',
    });
  }
});

// Reset Password
app.post('/api/reset-password', async (req, res) => {
  const { email, newPassword } = req.body;

  try {
    if (!email || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email and new password',
      });
    }

    // Verify OTP was validated (should exist in map)
    const storedOTP = forgotPasswordOTPs.get(email.toLowerCase());
    if (!storedOTP) {
      return res.status(400).json({
        success: false,
        message: 'Please verify OTP first',
      });
    }

    // Update password in database
    const updateQuery = `
      UPDATE smartstyley_dashboard.t_customer_details 
      SET password = $1 
      WHERE customer_email = $2
    `;

    await pool.query(updateQuery, [newPassword, email.toLowerCase()]);

    // Remove OTP from storage
    forgotPasswordOTPs.delete(email.toLowerCase());

    res.status(200).json({
      success: true,
      message: 'Password updated successfully',
    });
  } catch (error) {
    console.error('Password reset error:', error);
    res.status(500).json({
      success: false,
      message: 'Error updating password. Please try again.',
    });
  }
});

// Get all blogs
app.get("/api/blogs", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT id, title, content, author, image_url, created_at FROM smartstyley_dashboard.blogs ORDER BY created_at DESC"
    );
    res.status(200).json(result.rows);
  } catch (error) {
    console.error("Error fetching blogs:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
});


// Previous code from the first artifact (not repeated here for brevity but assumed to be included)

// Admin login endpoint
app.post("/api/admin/login", async (req, res) => {
    const { email, password } = req.body;

    try {
      const result = await pool.query(
        "SELECT * FROM smartstyley_dashboard.admin WHERE email = $1",
        [email]
      );

      if (result.rows.length === 0) {
        res.status(401).json({ success: false, message: "Admin not found" });
        return;
      }

      const admin = result.rows[0];
      
      // Direct password comparison (no bcrypt)
      if (password !== admin.password) {
        res.status(401).json({ success: false, message: "Invalid password" });
        return;
      }

      // Return success without token
      res.status(200).json({ 
        success: true, 
        message: "Login successful",
        admin: {
          id: admin.id,
          email: admin.email,
          name: admin.name
        }
      });
    } catch (error) {
      console.error("Admin login error:", error);
      res.status(500).json({ success: false, message: "Server error" });
    }
});

// Admin stats endpoint
app.get('/api/admin/stats', async (req, res) => {
  try {
    const [blogs, messages, reviews] = await Promise.all([
      pool.query('SELECT COUNT(*) FROM smartstyley_dashboard.blogs'),
      pool.query('SELECT COUNT(*) FROM smartstyley_dashboard.contacts'),
      pool.query('SELECT COUNT(*) FROM smartstyley_dashboard.testimonials'),
    ]);

    res.json({
      blogs: parseInt(blogs.rows[0].count),
      messages: parseInt(messages.rows[0].count),
      reviews: parseInt(reviews.rows[0].count),
    });
  } catch (err) {
    console.error('Error fetching stats:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all blogs endpoint
app.get('/api/blogs', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM smartstyley_dashboard.blogs ORDER BY created_at DESC'
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching blogs:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get a single blog by ID
app.get('/api/blogs/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      'SELECT * FROM smartstyley_dashboard.blogs WHERE id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Blog not found' });
    }

    res.status(200).json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching blog by ID:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Update blog by ID
app.put('/api/blogs/:id', async (req, res) => {
  const { id } = req.params;
  const { title, content, author, imageBase64 } = req.body;

  try {
    const result = await pool.query(
      'SELECT * FROM smartstyley_dashboard.blogs WHERE id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Blog not found' });
    }

    const current = result.rows[0];

    const updatedTitle = title ? title.trim() : current.title;
    const updatedContent = content ? content.trim() : current.content;
    const updatedAuthor = author ? author.trim() : current.author;
    const updatedImage = imageBase64 !== '' ? imageBase64 : current.image_url;

    await pool.query(
      'UPDATE smartstyley_dashboard.blogs SET title = $1, content = $2, author = $3, image_url = $4 WHERE id = $5',
      [updatedTitle, updatedContent, updatedAuthor, updatedImage, id]
    );

    res.status(200).json({ success: true, message: 'Blog updated successfully' });
  } catch (error) {
    console.error('❌ Error updating blog:', error);
    res.status(500).json({ success: false, message: 'Failed to update blog' });
  }
});

// Delete blog
app.delete('/api/blogs/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM smartstyley_dashboard.blogs WHERE id = $1', [
      req.params.id,
    ]);
    res.sendStatus(204);
  } catch (error) {
    console.error('Error deleting blog:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Create blog
app.post('/api/blogs', async (req, res) => {
  const { title, content, author, imageBase64 } = req.body;

  try {
    const result = await pool.query(
      'INSERT INTO smartstyley_dashboard.blogs (title, content, author, image_url) VALUES ($1, $2, $3, $4) RETURNING *',
      [title ? title.trim() : '', content ? content.trim() : '', author ? author.trim() : '', imageBase64]
    );

    res.status(201).json({ success: true, message: 'Blog created successfully', blog: result.rows[0] });
  } catch (error) {
    console.error('Error creating blog:', error);
    res.status(500).json({ success: false, message: 'Failed to create blog' });
  }
});

// Get all contacts
app.get("/api/contacts", async (req, res) => {
  const result = await pool.query("SELECT * FROM smartstyley_dashboard.contacts ORDER BY created_at DESC");
  res.json(result.rows);
});

// Get all reviews
app.get("/api/reviews", async (req, res) => {
  const result = await pool.query("SELECT * FROM smartstyley_dashboard.testimonials ORDER BY created_at DESC");
  res.json(result.rows);
});

// Get occasions endpoint
app.get('/api/occasions', async (req, res) => {
  try {
    const occasionsQuery = 'SELECT * FROM clothing_adminportal.t_occasions ORDER BY occasion_name';
    const result = await pool.query(occasionsQuery);
    
    res.status(200).json({
      success: true,
      occasions: result.rows
    });
  } catch (error) {
    console.error('Error fetching occasions:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching occasions'
    });
  }
});

// User details endpoint
app.post('/api/user-profile', upload.single('user_image'), async (req, res) => {
  const { cust_id, user_height, user_weight, user_skintone } = req.body;
  
  try {
    // Debug logs
    console.log('Received profile data:', { cust_id, user_height, user_weight, user_skintone });
    console.log('cust_id received:', cust_id, 'type:', typeof cust_id);
    console.log('Uploaded file:', req.file);
    
    // Validate required fields
    if (!cust_id || cust_id.trim() === '' || !user_height || !user_weight || !user_skintone) {
      return res.status(400).json({
        success: false,
        message: 'Please fill in all required fields (height, weight, and skin tone)'
      });
    }

    // Check if customer exists
    const customerCheck = await pool.query(
      'SELECT cust_id FROM smartstyley_dashboard.t_customer_details WHERE cust_id = $1',
      [cust_id]
    );
    
    console.log('Customer check result:', customerCheck.rows);

    if (customerCheck.rows.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Customer not found'
      });
    }

    // Get S3 URL from uploaded file or empty string
    const user_image = req.file ? req.file.location : '';

    // Check if user profile already exists
    const existingProfile = await pool.query(
      'SELECT cust_id FROM smartstyley_dashboard.t_user_details WHERE cust_id = $1',
      [cust_id]
    );

    let result;
    if (existingProfile.rows.length > 0) {
      // Update existing profile
      const updateQuery = `
        UPDATE smartstyley_dashboard.t_user_details 
        SET user_height = $2, user_weight = $3, user_skintone = $4, user_image = $5
        WHERE cust_id = $1
        RETURNING *
      `;
      result = await pool.query(updateQuery, [cust_id, user_height, user_weight, user_skintone, user_image]);
    } else {
      // Insert new profile
      const insertQuery = `
        INSERT INTO smartstyley_dashboard.t_user_details 
        (cust_id, user_height, user_weight, user_skintone, user_image)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING *
      `;
      result = await pool.query(insertQuery, [cust_id, user_height, user_weight, user_skintone, user_image]);
    }

    console.log('Profile operation result:', result.rows[0]);

    res.status(200).json({
      success: true,
      message: 'Profile saved successfully!',
      profile: result.rows[0]
    });

  } catch (error) {
    console.error('User profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Error saving profile. Please try again.'
    });
  }
});

// Detect gender endpoint
app.post('/api/detect-gender', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No image file uploaded'
      });
    }

    const file = req.file;
    let imageBase64;
    if (file.location) {
      // Fetch the image from S3 URL
      const response = await fetch(file.location);
      const arrayBuffer = await response.arrayBuffer();
      imageBase64 = Buffer.from(arrayBuffer).toString('base64');
    } else {
      throw new Error('No image data available');
    }

    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    const genderPrompt = `Analyze this image and determine the gender of the person. 
    Respond with only one word: either "male" or "female". 
    If you cannot determine the gender clearly, respond with "unknown".`;

    const response = await model.generateContent([
      {
        text: genderPrompt
      },
      {
        inlineData: {
          mimeType: req.file.mimetype,
          data: imageBase64
        }
      }
    ]);

    const result = await response.response;
    const genderText = result.text().toLowerCase().trim();
    
    let detectedGender = 'unknown';
    if (genderText.includes('male') && !genderText.includes('female')) {
      detectedGender = 'male';
    } else if (genderText.includes('female')) {
      detectedGender = 'female';
    }

    console.log('Detected gender:', detectedGender);

    res.json({
      success: true,
      gender: detectedGender
    });

  } catch (error) {
    console.error('Gender detection error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to detect gender'
    });
  }
});

// Reference image endpoint
app.post('/api/user-reference-image', upload.single('reference_image'), async (req, res) => {
  const { cust_id, image_type } = req.body;

  try {
    // Debug logs
    console.log('Received reference image data:', { cust_id, image_type });
    console.log('cust_id received:', cust_id, 'type:', typeof cust_id);
    console.log('Uploaded reference file:', req.file);

    // Validate required fields
    if (!cust_id) {
      return res.status(400).json({
        success: false,
        message: 'Customer ID is required'
      });
    }

    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No image file uploaded'
      });
    }

    // Check if customer exists
    const customerCheck = await pool.query(
      'SELECT cust_id FROM smartstyley_dashboard.t_customer_details WHERE cust_id = $1',
      [cust_id]
    );

    console.log('Customer check result:', customerCheck.rows);

    if (customerCheck.rows.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Customer not found'
      });
    }

    // Get S3 URL from uploaded file
    const user_image = req.file.location.replace('https://', 'https://');
    const image_name = req.file.key;

    // Check if user reference image already exists
    const existingImageQuery = `
      SELECT cust_id FROM smartstyley_dashboard.t_user_image 
      WHERE cust_id = $1
    `;
    const existingImage = await pool.query(existingImageQuery, [cust_id]);

    let result;
    if (existingImage.rows.length > 0) {
      // Update existing reference image
      const updateQuery = `
        UPDATE smartstyley_dashboard.t_user_image 
        SET user_image = $2
        WHERE cust_id = $1
        RETURNING *
      `;
      result = await pool.query(updateQuery, [cust_id, user_image]);
    } else {
      // Insert new reference image
      const insertQuery = `
        INSERT INTO smartstyley_dashboard.t_user_image 
        (cust_id, user_image)
        VALUES ($1, $2)
        RETURNING *
      `;
      result = await pool.query(insertQuery, [cust_id, user_image]);
    }

    console.log('Reference image stored successfully:', result.rows[0]);

    res.status(200).json({
      success: true,
      message: 'Reference image saved successfully!',
      image: result.rows[0]
    });

  } catch (error) {
    console.error('Reference image upload error:', error);
    res.status(500).json({
      success: false,
      message: 'Error saving reference image. Please try again.'
    });
  }
});

// Fetch image as base64 function
const fetchImageAsBase64 = async (imageUrl) => {
  try {
    const response = await axios.get(imageUrl, {
      responseType: 'arraybuffer',
      timeout: 10000,
      maxRedirects: 5,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Api-Key': '8d803e02-0cb9-4983-af40-52e0ad753757'
      }
    });
    const base64 = Buffer.from(response.data).toString('base64');
    return base64;
  } catch (error) {
    console.error(`Failed to fetch image ${imageUrl}:`, error.message);
    throw new Error(`Image fetch failed: ${error.message}`);
  }
};

// Analyze male image endpoint
app.post('/api/analyze-style-male', async (req, res) => {
  const { cust_id, occasion, preferredColor, dressTypeIndex = 0 } = req.body;

  try {
    // Validate required fields
    if (!cust_id || !occasion) {
      return res.status(400).json({
        success: false,
        message: 'Customer ID and occasion are required',
        styles: [],
        hasReferenceImage: false,
        hasUserImage: false,
        userImageUrl: null,
        preferredColor: null,
        colorSource: 'none',
        personalizationLevel: 'none',
        generatedCount: 0,
        requestedCount: 0,
        isSubscribed: false,
        maxImagesPerGeneration: 0,
        currentDressTypes: [],
        dressTypeIndex: 0,
        totalDressTypes: 0,
        nextDressTypeIndex: 0,
        editingMethod: 'none',
        stylingReferenceUsed: false,
        gender: 'male',
        hasActiveSubscription: false,
        remainingGenerations: 1,
        totalGenerations: 0,
        dailyGenerationCount: 0,
        generationsCount: 0,
        subscriptionEndDate: null,
        subscriptionStartDate: null,
      });
    }

    // Check daily usage limit
    const today = new Date().toISOString().split('T')[0];
    const subscriptionQuery = `
      SELECT has_paid, subscription_end_date, total_generations_in_subscription 
      FROM smartstyley_dashboard.t_user_daily_usage 
      WHERE cust_id = $1 
        AND has_paid = true 
        AND subscription_end_date >= CURRENT_DATE
      ORDER BY subscription_start_date DESC 
      LIMIT 1
    `;
    const usageResult = await pool.query(subscriptionQuery, [cust_id]);

    let canGenerate = true;
    let needsPayment = false;
    let remainingGenerations = 0;

    if (usageResult.rows.length > 0) {
      // Has active subscription
      const subscription = usageResult.rows[0];
      const totalGenerations = subscription.total_generations_in_subscription || 0;
      remainingGenerations = 75 - totalGenerations;
      
      if (remainingGenerations <= 0) {
        canGenerate = false;
        needsPayment = true;
      }
    } else {
      // No active subscription - check daily free limit
    //   const todayQuery = `
    //     SELECT daily_generation_count 
    //     FROM smartstyley_dashboard.t_user_daily_usage 
    //     WHERE cust_id = $1 AND usage_date = $2
    //   `;
    //   const todayResult = await pool.query(todayQuery, [cust_id, today]);
    //   const dailyCount = todayResult.rows[0]?.daily_generation_count || 0;

    const todayQuery = `
      SELECT tudu.daily_generation_count 
      FROM smartstyley_dashboard.t_user_daily_usage AS tudu
      WHERE tudu.cust_id = $1 AND tudu.usage_date = $2
    `;
    const todayResult = await pool.query(todayQuery, [cust_id, today]);
    const dailyCount = todayResult.rows[0]?.daily_generation_count || 0;
      
      remainingGenerations = 1 - dailyCount;
      if (dailyCount >= 1) {
        canGenerate = false;
        needsPayment = true;
      }
    }

    if (!canGenerate) {
      return res.status(403).json({
        success: false,
        message: 'Daily limit reached. Please upgrade to continue.',
        needsPayment: true,
        limitReached: true,
        styles: [],
        hasReferenceImage: false,
        hasUserImage: false,
        userImageUrl: null,
        preferredColor: null,
        colorSource: 'none',
        personalizationLevel: 'none',
        generatedCount: 0,
        requestedCount: 0,
        isSubscribed: false,
        maxImagesPerGeneration: 0,
        currentDressTypes: [],
        dressTypeIndex: 0,
        totalDressTypes: 0,
        nextDressTypeIndex: 0,
        editingMethod: 'none',
        stylingReferenceUsed: false,
        gender: 'male',
        hasActiveSubscription: false,
        remainingGenerations: 1,
        totalGenerations: 0,
        dailyGenerationCount: usageResult.rows.length > 0 ? usageResult.rows[0].daily_generation_count : 0,
        generationsCount: usageResult.rows.length > 0 ? usageResult.rows[0].generations_count : 0,
        subscriptionEndDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_end_date : null,
        subscriptionStartDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_start_date : null,
      });
    }

    if (!process.env.DEEPAI_API_KEY) {
      console.error('DeepAI API key is not configured');
      return res.status(500).json({
        success: false,
        message: 'AI service is not properly configured',
        styles: [],
        hasReferenceImage: false,
        hasUserImage: false,
        userImageUrl: null,
        preferredColor: null,
        colorSource: 'none',
        personalizationLevel: 'none',
        generatedCount: 0,
        requestedCount: 0,
        isSubscribed: false,
        maxImagesPerGeneration: 0,
        currentDressTypes: [],
        dressTypeIndex: 0,
        totalDressTypes: 0,
        nextDressTypeIndex: 0,
        editingMethod: 'none',
        stylingReferenceUsed: false,
        gender: 'male',
        hasActiveSubscription: false,
        remainingGenerations: 1,
        totalGenerations: 0,
        dailyGenerationCount: usageResult.rows.length > 0 ? usageResult.rows[0].daily_generation_count : 0,
        generationsCount: usageResult.rows.length > 0 ? usageResult.rows[0].generations_count : 0,
        subscriptionEndDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_end_date : null,
        subscriptionStartDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_start_date : null,
      });
    }

    // Fetch user details from t_user_details table
    const userDetailsQuery = `
      SELECT user_height, user_weight, user_skintone, user_image
      FROM smartstyley_dashboard.t_user_details 
      WHERE cust_id = $1
    `;
    const userDetailsResult = await pool.query(userDetailsQuery, [cust_id]);
    const userDetails = userDetailsResult.rows[0];

    // Use male-specific dress types query
    const dressTypesQuery = `
      SELECT DISTINCT product_name, product_hashtags 
      FROM clothing_adminportal.t_master_product_details 
      WHERE product_name IS NOT NULL AND product_name != ''
      ORDER BY product_name
    `;
    const dressTypesResult = await pool.query(dressTypesQuery);

    if (dressTypesResult.rows.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No male dress types found in database',
        styles: [],
        hasReferenceImage: false,
        hasUserImage: false,
        userImageUrl: null,
        preferredColor: null,
        colorSource: 'none',
        personalizationLevel: 'none',
        generatedCount: 0,
        requestedCount: 0,
        isSubscribed: false,
        maxImagesPerGeneration: 0,
        currentDressTypes: [],
        dressTypeIndex: 0,
        totalDressTypes: 0,
        nextDressTypeIndex: 0,
        editingMethod: 'none',
        stylingReferenceUsed: false,
        gender: 'male',
        hasActiveSubscription: false,
        remainingGenerations: 1,
        totalGenerations: 0,
        dailyGenerationCount: usageResult.rows.length > 0 ? usageResult.rows[0].daily_generation_count : 0,
        generationsCount: usageResult.rows.length > 0 ? usageResult.rows[0].generations_count : 0,
        subscriptionEndDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_end_date : null,
        subscriptionStartDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_start_date : null,
      });
    }

    // Fetch user profile image - REQUIRED for image editor
    const userImageQuery = `
      SELECT user_image
      FROM smartstyley_dashboard.t_user_details 
      WHERE cust_id = $1 AND user_image IS NOT NULL AND user_image != ''
    `;
    const userImageResult = await pool.query(userImageQuery, [cust_id]);
    const hasUserImage = userImageResult.rows.length > 0;
    const userImageUrl = hasUserImage ? userImageResult.rows[0].user_image : null;

    if (!hasUserImage || !userImageUrl) {
      return res.status(400).json({
        success: false,
        message: 'User profile image is required for style generation. Please upload your photo first.',
        styles: [],
        hasReferenceImage: false,
        hasUserImage: false,
        userImageUrl: null,
        preferredColor: null,
        colorSource: 'none',
        personalizationLevel: 'none',
        generatedCount: 0,
        requestedCount: 0,
        isSubscribed: false,
        maxImagesPerGeneration: 0,
        currentDressTypes: [],
        dressTypeIndex: 0,
        totalDressTypes: 0,
        nextDressTypeIndex: 0,
        editingMethod: 'none',
        stylingReferenceUsed: false,
        gender: 'male',
        hasActiveSubscription: false,
        remainingGenerations: 1,
        totalGenerations: 0,
        dailyGenerationCount: usageResult.rows.length > 0 ? usageResult.rows[0].daily_generation_count : 0,
        generationsCount: usageResult.rows.length > 0 ? usageResult.rows[0].generations_count : 0,
        subscriptionEndDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_end_date : null,
        subscriptionStartDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_start_date : null,
      });
    }

    // Fetch male reference images if any
    const referenceImagesQuery = `
      SELECT user_image
      FROM smartstyley_dashboard.t_user_image 
      WHERE cust_id = $1
      ORDER BY cust_id DESC
      LIMIT 1
    `;
    const referenceImagesResult = await pool.query(referenceImagesQuery, [cust_id]);
    const hasReferenceImage = referenceImagesResult.rows.length > 0;
    const referenceImageUrl = hasReferenceImage ? referenceImagesResult.rows[0].user_image : null;

    const dressTypes = dressTypesResult.rows;
    let imageCount = 2; // Default for free users

    if (usageResult.rows.length > 0) {
      const { has_paid, subscription_end_date } = usageResult.rows[0];
      
      // Check if user has active subscription
      if (has_paid && subscription_end_date && new Date(subscription_end_date) >= new Date()) {
        imageCount = 4; // Premium users get 4 images
      }
    }
    let referenceStyleDescription = '';

    // Analyze reference image for male styling details if available
    if (hasReferenceImage && referenceImageUrl) {
      console.log('\n=== PROCESSING MALE REFERENCE IMAGE FOR OUTFIT DETAILS ONLY ===');
      console.log('Reference Image URL:', referenceImageUrl);
      console.log('========================================================\n');

      try {
        console.log('Analyzing male reference image for outfit details with Google Gemini...');
        
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const referenceImageBase64 = await fetchImageAsBase64(referenceImageUrl);

        const outfitOnlyAnalysisPrompt = `Analyze this male reference image to extract SPECIFIC STYLE ELEMENTS that can be replicated on any male face for ${occasion}:

EXACT STYLE ELEMENTS TO EXTRACT:
- Specific clothing type and exact style name
- Precise color combinations and color placement
- Exact fabric texture and material type
- Specific cut, fit, and silhouette details
- Collar type, sleeve style, and length measurements
- Pattern details (solid/printed/embroidered) and placement
- Traditional elements and embellishment locations
- Bottom wear style and how it's paired
- Accessory types and their positioning

STYLING FORMULA TO REPLICATE:
- How the outfit is worn and styled
- Fabric draping method and fit approach
- Color coordination principles used
- Overall composition and balance

OUTPUT: Provide a detailed STYLE RECIPE that can be applied to recreate this EXACT look on any male face while preserving their identity.`;

        const styleResponse = await model.generateContent([
          {
            text: outfitOnlyAnalysisPrompt
          },
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: referenceImageBase64
            }
          }
        ]);

        const styleResult = await styleResponse.response;
        referenceStyleDescription = styleResult.text();
        
        console.log('=== OUTFIT-ONLY REFERENCE ANALYSIS SUCCESS ===');
        console.log(referenceStyleDescription);
        console.log('=============================================');

      } catch (aiError) {
        console.error('Male reference image outfit analysis error:', aiError);
        
        const colorDesc = preferredColor ? `${preferredColor}` : 'elegant traditional colors';
        referenceStyleDescription = `Traditional Indian male ${dressTypes} in ${colorDesc}, well-fitted traditional cut, appropriate fabric texture, classic collar and sleeve styling, traditional male accessories, cultural ${occasion} appropriate styling`;
        
        console.log('=== OUTFIT-ONLY FALLBACK ===');
        console.log(referenceStyleDescription);
        console.log('===========================');
      }
    }

    const generateMaleImageWithDeepAIEditor = async (userImageUrl, editingPrompt, dressType, index, maxRetries = 3) => {
      for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
          console.log(`Generating male edited image ${index + 1}, attempt ${attempt} with DeepAI Image Editor...`);
          console.log(`User Image URL: ${userImageUrl}`);
          console.log(`Male Editing Prompt: ${editingPrompt}`);
          
          let response;
          
          console.log('Using image-editor generation for male styling...');
          
          response = await deepai.callStandardApi("image-editor", {
            image: userImageUrl,
            text: editingPrompt,
          });

          if (!response || !response.output_url) {
            console.error('Invalid DeepAI response:', response);
            throw new Error('No output URL in DeepAI response');
          }
          
          if (!response.output_url.startsWith('http')) {
            throw new Error('Invalid output URL format from DeepAI');
          }

          const result = {
            data: [{
              url: response.output_url
            }]
          };

          console.log(`✅ Male image ${index + 1} edited successfully on attempt ${attempt}`);
          console.log(`Generated URL: ${response.output_url}`);
          
          return {
            result,
            dressType,
            index,
            success: true
          };

        } catch (error) {
          console.error(`❌ Male image ${index + 1} failed on attempt ${attempt}:`, {
            message: error.message,
            status: error.status,
            code: error.code,
            response: error.response?.data || error.response || 'No response data'
          });

          if (error.code === 'ETIMEDOUT' || error.message.includes('timeout')) {
            console.log(`⏳ Timeout on attempt ${attempt}, extending wait time...`);
            if (attempt < maxRetries) {
              const extendedDelay = 15000 + (attempt * 7000);
              await new Promise(resolve => setTimeout(resolve, extendedDelay));
              continue;
            }
          }

          if (error.response?.data?.err?.includes('content policy') || 
              error.response?.data?.err?.includes('inappropriate')) {
            console.log('Content policy violation detected for male styling, skipping retries');
            return {
              result: null,
              dressType,
              index,
              success: false,
              error: 'Content policy violation - male styling prompt needs adjustment'
            };
          }

          if (attempt === maxRetries) {
            return {
              result: null,
              dressType,
              index,
              success: false,
              error: `Failed after ${maxRetries} attempts: ${error.message}`
            };
          }

          const baseDelay = Math.pow(2, attempt) * 7000;
          const jitter = Math.random() * 3000;
          const delay = baseDelay + jitter;
          
          console.log(`⏳ Waiting ${Math.round(delay)}ms before retry...`);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
      return {
        result: null,
        dressType,
        index,
        success: false,
        error: 'Unexpected error in retry loop'
      };
    };

    const processColorPreference = (colorInput) => {
      if (!colorInput) return 'elegant traditional colors';
      
      const colors = colorInput.split(',').map(c => c.trim()).filter(c => c);
      if (colors.length === 1) {
        return `${colors[0]} color`;
      } else if (colors.length === 2) {
        return `${colors[0]} and ${colors[1]} color combination (${colors[0]} for top/shirt/kurta, ${colors[1]} for bottom/pants/dhoti)`;
      } else {
        return `${colors.join(', ')} color scheme with balanced distribution`;
      }
    };

    const generateOptimizedMaleEditingPrompt = async (styleDescription, dressType, occasion, preferredColor, userDetails, hasReferenceImage) => {
      try {
        console.log('Creating face-preserving male editing prompt with Gemini...');
        
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        
        const processedColor = processColorPreference(preferredColor);
        
        let promptCreationInstruction = '';

        if (hasReferenceImage && styleDescription) {
          promptCreationInstruction = `Create an image editing prompt to EXACTLY REPLICATE the outfit style from reference image:

      TARGET STYLE TO REPLICATE: ${styleDescription}
      PREFERRED COLOR: ${processedColor}
      OCCASION: ${occasion}

      EXACT REPLICATION REQUIREMENTS:
      1. PRESERVE USER'S FACE 100% - same identity, features, skin tone
      2. REPLICATE EXACT OUTFIT STYLE from reference description
      3. Apply ${processedColor} to clothing only, keep background unchanged
      4. Match the exact fit, cut, and styling approach
      5. Include same type of accessories and their placement
      6. Maintain same fabric texture and draping style
      7. Keep same overall composition and styling balance
      8. PRESERVE ORIGINAL BACKGROUND - do not change background color or setting

      COLOR APPLICATION RULES:
      ${preferredColor && preferredColor.includes(',') ? 
        `- Apply first color (${preferredColor.split(',')[0].trim()}) to top garment (shirt/kurta/blazer)
         - Apply second color (${preferredColor.split(',')[1].trim()}) to bottom garment (pants/dhoti/churidar)
         - Ensure colors complement each other and suit the occasion` :
        `- Apply ${processedColor} uniformly across the outfit while maintaining style authenticity`
      }

      TECHNICAL EDITING APPROACH:
      - Edit clothing areas only, preserve face completely
      - Apply the exact style elements from reference
      - Use reference styling approach with user's preferred colors
      - Maintain professional quality and realistic blending

      Create a precise prompt that will generate the EXACT SAME STYLE as reference image but with user's face and preferred colors.`;
        } else {
          promptCreationInstruction = `Create a FACE-PRESERVING image editing prompt for male styling:
      
      MALE OUTFIT: ${dressType}
      OCCASION: ${occasion}
      PREFERRED COLOR: ${processedColor}
      SKIN TONE: ${userDetails.user_skintone}
      
      FACE PRESERVATION RULES (HIGHEST PRIORITY):
      1. KEEP EXACT SAME FACE AND IDENTITY
      2. PRESERVE ALL FACIAL FEATURES COMPLETELY
      3. MAINTAIN ORIGINAL SKIN TONE AND FACE STRUCTURE
      4. NO FACE MODIFICATIONS - CLOTHING EDIT ONLY

      OUTFIT EDITING INSTRUCTIONS:
      1. Transform clothing to elegant ${dressType}
      2. Use ${processedColor} theme
      3. Add appropriate male accessories (watch, traditional jewelry)
      4. Ensure cultural appropriateness for ${occasion}
      5. Maintain masculine fit and traditional styling

      COLOR APPLICATION RULES:
      ${preferredColor && preferredColor.includes(',') ? 
        `- Apply first color (${preferredColor.split(',')[0].trim()}) to top garment
         - Apply second color (${preferredColor.split(',')[1].trim()}) to bottom garment
         - Ensure colors work harmoniously together` :
        `- Apply ${processedColor} appropriately across the ${dressType} outfit`
      }

      TECHNICAL REQUIREMENTS:
      - Edit clothing areas only, preserve face 100%
      - Keep natural lighting and original pose
      - Blend outfit changes realistically
      - Maintain photo quality and realism
      
      Create a precise editing prompt that emphasizes face preservation while transforming the outfit with specified colors.`;
        }

        const response = await model.generateContent([{ text: promptCreationInstruction }]);
        const result = await response.response;  
        let optimizedPrompt = result.text().trim();
        
        const facePreservationPrefix = "PRESERVE ORIGINAL FACE COMPLETELY, SAME IDENTITY, CLOTHING EDIT ONLY: ";
        optimizedPrompt = facePreservationPrefix + optimizedPrompt;
        
        console.log('✅ Face-preserving male editing prompt created successfully');
        console.log('Prompt length:', optimizedPrompt.length);
        
        return optimizedPrompt;
        
      } catch (error) {
        console.error('Gemini male editing prompt optimization error:', error);
        
        let fallbackPrompt = '';

        if (hasReferenceImage && styleDescription) {
          const processedColorForFallback = preferredColor ? processColorPreference(preferredColor) : 'reference colors';
          fallbackPrompt = `PRESERVE ORIGINAL FACE EXACTLY: Apply ${processedColorForFallback} to this exact style: ${styleDescription.substring(0, 200)}..., keep user's face identical, apply this exact outfit style with specified colors to clothing only, preserve original background. Same person, exact reference styling.`;
        } else {
          const processedColorForFallback = preferredColor ? processColorPreference(preferredColor) : 'elegant traditional';
          fallbackPrompt = `PRESERVE ORIGINAL FACE AND IDENTITY: Keep exact same face, change clothing only to ${processedColorForFallback} traditional male ${dressType} for ${occasion}. Same person, same face, new outfit only. Preserve user's appearance 100%.`;
        }
        
        console.log('Using enhanced face-preserving fallback prompt');
        console.log('Fallback prompt length:', fallbackPrompt.length);
        
        return fallbackPrompt;
      }
    };

    console.log('\n=== GENERATING PERSONALIZED MALE STYLES WITH IMAGE EDITOR ===');
    const generatedStyles = [];
    const selectedDressTypes = [];

    for (let i = 0; i < imageCount; i++) {
      const currentDressIndex = (dressTypeIndex + i) % dressTypes.length;
      const selectedDressType = dressTypes[currentDressIndex];
      selectedDressTypes.push(selectedDressType);
      
      console.log(`\n--- Processing Male Image ${i + 1}/${imageCount} ---`);
      console.log(`Male Dress Type: ${selectedDressType.product_name}`);
      console.log(`User Image URL: ${userImageUrl}`);
      console.log(`Has Male Reference Styling: ${hasReferenceImage}`);
      console.log(`Preferred Color: ${preferredColor || 'Default'}`);

      const optimizedMaleEditingPrompt = await generateOptimizedMaleEditingPrompt(
        referenceStyleDescription,
        selectedDressType.product_name,
        occasion,
        preferredColor,
        userDetails,
        hasReferenceImage
      );

      console.log(`Optimized Male Editing Prompt Length: ${optimizedMaleEditingPrompt.length}`);

      let finalPromptForAPI = optimizedMaleEditingPrompt;

      if (optimizedMaleEditingPrompt.length > 500) {
        const facePreservationPart = optimizedMaleEditingPrompt.substring(0, 200);
        const outfitPart = optimizedMaleEditingPrompt.substring(200);
        const truncatedOutfitPart = outfitPart.length > 300 ? 
          outfitPart.substring(0, 300).trim() + '...' : 
          outfitPart;
        finalPromptForAPI = facePreservationPart + truncatedOutfitPart;
      }

      if (preferredColor) {
        const colors = preferredColor.split(',').map(c => c.trim()).filter(c => c);
        let colorEmphasis = '';
        
        if (colors.length === 1) {
          colorEmphasis = `${colors[0]} color theme, `;
        } else if (colors.length === 2) {
          colorEmphasis = `${colors[0]} top and ${colors[1]} bottom color combination, `;
        } else {
          colorEmphasis = `${colors.join(', ')} color scheme, `;
        }
        
        finalPromptForAPI = finalPromptForAPI.replace(
          /(:.*?)(Edit|Transform|Apply)/i, 
          `$1${colorEmphasis}$2`
        );
      }

      const processedColorForPrefix = preferredColor ? 
        (preferredColor.includes(',') ? 
          (() => {
            const colors = preferredColor.split(',').map(c => c.trim());
            return colors.length === 2 ? 
              `${colors[0]} and ${colors[1]} colors` : 
              `${colors.join(', ')} colors`;
          })() : 
          `${preferredColor} colors`) : 
        'original';

      const styleReplicationPrefix = hasReferenceImage ? 
        `Replicate exact reference style with ${processedColorForPrefix} on clothing only, preserve background: ` : 
        `Generate ${processedColorForPrefix} male ${selectedDressType.product_name} outfit only, keep original background: `;

      finalPromptForAPI = styleReplicationPrefix + finalPromptForAPI;

      if (preferredColor && hasReferenceImage) {
        const colors = preferredColor.split(',').map(c => c.trim()).filter(c => c);
        const colorReplacement = colors.length > 1 ? 
          `${colors.join(' and ')} colors` : 
          `${colors[0]} colors`;
          
        finalPromptForAPI = finalPromptForAPI.replace(
          /colors?/gi, 
          colorReplacement
        );
      }

      console.log(`Final API Prompt Length: ${finalPromptForAPI.length}`);
      console.log(`Final API Prompt: ${finalPromptForAPI.substring(0, 100)}...`);

      console.log(`Reference Style Applied: ${hasReferenceImage}`);
      console.log(`Color Preference: ${preferredColor || 'None'}`);
      console.log(`Color Type: ${preferredColor ? (preferredColor.includes(',') ? 'Multiple Colors' : 'Single Color') : 'None'}`);
      console.log(`Processed Colors: ${preferredColor ? preferredColor.split(',').map(c => c.trim()).join(' + ') : 'None'}`);
      console.log(`Style Description Length: ${referenceStyleDescription.length}`);
      console.log(`Final Prompt Preview: ${finalPromptForAPI.substring(0, 150)}...`);

      const imageResult = await generateMaleImageWithDeepAIEditor(userImageUrl, finalPromptForAPI, selectedDressType.product_name, i);

      if (imageResult.success && imageResult.result && imageResult.result.data && imageResult.result.data[0]) {
        generatedStyles.push({
          id: `male_style_${Date.now()}_${dressTypeIndex}_${i + 1}`,
          name: `${imageResult.dressType} Male Style`,
          image: imageResult.result.data[0].url,
          dressType: imageResult.dressType,
          editingMethod: 'male_image_editor',
          baseImage: userImageUrl,
          gender: 'male'
        });
        console.log(`✅ Successfully edited male style: ${imageResult.dressType}`);
      } else {
        console.log(`❌ Failed to edit male style for: ${selectedDressType.product_name}`);
        console.log('Error:', imageResult.error);
      }

      if (i < imageCount - 1) {
        console.log('⏳ Waiting 3 seconds before next male generation...');
        await new Promise(resolve => setTimeout(resolve, 3000));
      }
    }

    if (generatedStyles.length === 0) {
      return res.status(500).json({
        success: false,
        message: 'Failed to generate any male images. This might be due to DeepAI API server issues, rate limits, or content policy restrictions. Please try again in a few minutes.',
        styles: [],
        hasReferenceImage: false,
        hasUserImage: false,
        userImageUrl: null,
        preferredColor: null,
        colorSource: 'none',
        personalizationLevel: 'none',
        generatedCount: 0,
        requestedCount: 0,
        isSubscribed: false,
        maxImagesPerGeneration: 0,
        currentDressTypes: [],
        dressTypeIndex: 0,
        totalDressTypes: 0,
        nextDressTypeIndex: 0,
        editingMethod: 'none',
        stylingReferenceUsed: false,
        gender: 'male',
        hasActiveSubscription: false,
        remainingGenerations: 1,
        totalGenerations: 0,
        dailyGenerationCount: usageResult.rows.length > 0 ? usageResult.rows[0].daily_generation_count : 0,
        generationsCount: usageResult.rows.length > 0 ? usageResult.rows[0].generations_count : 0,
        subscriptionEndDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_end_date : null,
        subscriptionStartDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_start_date : null,
      });
    }

    const successMessage = generatedStyles.length === imageCount 
      ? 'Personalized male styles generated successfully using image editing!' 
      : `${generatedStyles.length} out of ${imageCount} personalized male styles generated successfully. Some images failed due to API issues.`;

    console.log(`\n✅ Male generation complete: ${generatedStyles.length}/${imageCount} images successful`);
    console.log('Generated male types:', generatedStyles.map(style => style.dressType));
    console.log('Male personalization level: Image Editor with', hasReferenceImage ? 'Reference Styling' : 'Basic Styling');

    const actualGeneratedCount = generatedStyles.length;

    // Update usage based on subscription status
    if (usageResult.rows.length > 0) {
      // Update subscription usage
      const updateSubscriptionUsage = `
        UPDATE smartstyley_dashboard.t_user_daily_usage 
        SET total_generations_in_subscription = total_generations_in_subscription + $2
        WHERE cust_id = $1 
          AND has_paid = true 
          AND subscription_end_date >= CURRENT_DATE
      `;
      await pool.query(updateSubscriptionUsage, [cust_id, actualGeneratedCount]);
    } else {
      // Update daily usage for free users
    //   const updateDailyUsage = `
    //     INSERT INTO smartstyley_dashboard.t_user_daily_usage 
    //     (cust_id, usage_date, daily_generation_count, has_paid)
    //     VALUES ($1, $2, $3, false)
    //     ON CONFLICT (cust_id, usage_date)
    //     DO UPDATE SET daily_generation_count = daily_generation_count + $3
    //   `;
    //   await pool.query(updateDailyUsage, [cust_id, today, actualGeneratedCount]);
    const updateDailyUsage = `
      INSERT INTO smartstyley_dashboard.t_user_daily_usage 
      (cust_id, usage_date, daily_generation_count, has_paid)
      VALUES ($1, $2, $3, false)
      ON CONFLICT (cust_id, usage_date)
      DO UPDATE SET daily_generation_count = smartstyley_dashboard.t_user_daily_usage.daily_generation_count + $3
    `;
    await pool.query(updateDailyUsage, [cust_id, today, actualGeneratedCount]);
    }
    console.log('✅ Male usage count updated successfully');

    res.status(200).json({
      success: true,
      message: successMessage,
      styles: generatedStyles,
      hasReferenceImage: hasReferenceImage,
      hasUserImage: true,
      userImageUrl: userImageUrl,
      preferredColor: preferredColor || null,
      colorSource: preferredColor ? 'user_preference' : (hasReferenceImage ? 'reference_image' : 'default'),
      personalizationLevel: hasReferenceImage ? 'male_image_editor_with_reference_styling' : 'male_image_editor_basic_styling',
      generatedCount: generatedStyles.length,
      requestedCount: imageCount,
      isSubscribed: imageCount === 1,
      maxImagesPerGeneration: imageCount,
      currentDressTypes: generatedStyles.map(style => style.dressType),
      dressTypeIndex: dressTypeIndex,
      totalDressTypes: dressTypes.length,
      nextDressTypeIndex: (dressTypeIndex + imageCount) % dressTypes.length,
      editingMethod: 'deepai_male_image_editor',
      stylingReferenceUsed: hasReferenceImage,
      gender: 'male',
      hasActiveSubscription: false,
      remainingGenerations: 1,
      totalGenerations: 0,
      dailyGenerationCount: usageResult.rows.length > 0 ? usageResult.rows[0].daily_generation_count : 0,
      generationsCount: usageResult.rows.length > 0 ? usageResult.rows[0].generations_count : 0,
      subscriptionEndDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_end_date : null,
      subscriptionStartDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_start_date : null,
    });

  } catch (error) {
    console.error('Enhanced male style generation with image editor error:', error);
    
    let errorMessage = 'Error generating personalized male styles. Please try again.';
    
    if (error.status === 403 || error.message?.includes('unauthorized')) {
      errorMessage = 'API access denied. Please check your DeepAI API key and billing status.';
    } else if (error.message && error.message.includes('timeout')) {
      errorMessage = 'Request timed out. Please try again.';
    } else if (error.message && error.message.includes('rate limit')) {
      errorMessage = 'Too many requests. Please wait a moment and try again.';
    } else if (error.status === 429) {
      errorMessage = 'DeepAI rate limit exceeded. Please wait a moment and try again.';
    } else if (error.status >= 500) {
      errorMessage = 'DeepAI server is experiencing issues. Please try again in a few minutes.';
    } else if (error.code === 'ECONNREFUSED' || error.code === 'ENOTFOUND') {
      errorMessage = 'Unable to connect to AI services. Please check your internet connection.';
    } else if (error.message?.includes('Gemini') || error.message?.includes('Google')) {
      errorMessage = 'Male image analysis service temporarily unavailable. Generated with basic personalization.';
    }
    
    res.status(500).json({
      success: false,
      message: errorMessage,
      styles: [],
      hasReferenceImage: false,
      hasUserImage: false,
      userImageUrl: null,
      preferredColor: null,
      colorSource: 'none',
      personalizationLevel: 'none',
      generatedCount: 0,
      requestedCount: 0,
      isSubscribed: false,
      maxImagesPerGeneration: 0,
      currentDressTypes: [],
      dressTypeIndex: 0,
      totalDressTypes: 0,
      nextDressTypeIndex: 0,
      editingMethod: 'none',
      stylingReferenceUsed: false,
      gender: 'male',
      hasActiveSubscription: false,
      remainingGenerations: 1,
      totalGenerations: 0,
      dailyGenerationCount: 0,
      generationsCount: 0,
      subscriptionEndDate: null,
      subscriptionStartDate: null,
    });
  }
});



// Previous code from the previous artifact (not repeated here for brevity but assumed to be included)

// analyze female image end point 
app.post('/api/analyze-style', async (req, res) => {
  const { cust_id, occasion, preferredColor, dressTypeIndex = 0 } = req.body;
  
  try {
    // Validate required fields
    if (!cust_id || !occasion) {
      return res.status(400).json({
        success: false,
        message: 'Customer ID and occasion are required',
        styles: [],
        hasReferenceImage: false,
        hasUserImage: false,
        userImageUrl: null,
        preferredColor: null,
        colorSource: 'none',
        personalizationLevel: 'none',
        generatedCount: 0,
        requestedCount: 0,
        isSubscribed: false,
        maxImagesPerGeneration: 0,
        currentDressTypes: [],
        dressTypeIndex: 0,
        totalDressTypes: 0,
        nextDressTypeIndex: 0,
        editingMethod: 'none',
        stylingReferenceUsed: false,
        hasActiveSubscription: false,
        remainingGenerations: 1,
        totalGenerations: 0,
        dailyGenerationCount: 0,
        generationsCount: 0,
        subscriptionEndDate: null,
        subscriptionStartDate: null,
      });
    }

    // Check daily usage limit
    // Check for active subscription first
    const today = new Date().toISOString().split('T')[0];
    const subscriptionQuery = `
      SELECT has_paid, subscription_end_date, total_generations_in_subscription 
      FROM smartstyley_dashboard.t_user_daily_usage 
      WHERE cust_id = $1 
        AND has_paid = true 
        AND subscription_end_date >= CURRENT_DATE
      ORDER BY subscription_start_date DESC 
      LIMIT 1
    `;
    const usageResult = await pool.query(subscriptionQuery, [cust_id]);

    let canGenerate = true;
    let needsPayment = false;
    let remainingGenerations = 0;

    if (usageResult.rows.length > 0) {
      // Has active subscription
      const subscription = usageResult.rows[0];
      const totalGenerations = subscription.total_generations_in_subscription || 0;
      remainingGenerations = 75 - totalGenerations;
      
      if (remainingGenerations <= 0) {
        canGenerate = false;
        needsPayment = true;
      }
    } else {
      // No active subscription - check daily free limit
    //   const todayQuery = `
    //     SELECT daily_generation_count 
    //     FROM smartstyley_dashboard.t_user_daily_usage 
    //     WHERE cust_id = $1 AND usage_date = $2
    //   `;
    //   const todayResult = await pool.query(todayQuery, [cust_id, today]);
    //   const dailyCount = todayResult.rows[0]?.daily_generation_count || 0;

    const todayQuery = `
      SELECT tudu.daily_generation_count 
      FROM smartstyley_dashboard.t_user_daily_usage AS tudu
      WHERE tudu.cust_id = $1 AND tudu.usage_date = $2
    `;
    const todayResult = await pool.query(todayQuery, [cust_id, today]);
    const dailyCount = todayResult.rows[0]?.daily_generation_count || 0;
      
      remainingGenerations = 1 - dailyCount;
      if (dailyCount >= 1) {
        canGenerate = false;
        needsPayment = true;
      }
    }

    if (!canGenerate) {
      return res.status(403).json({
        success: false,
        message: 'Daily limit reached. Please upgrade to continue.',
        needsPayment: true,
        limitReached: true,
        styles: [],
        hasReferenceImage: false,
        hasUserImage: false,
        userImageUrl: null,
        preferredColor: null,
        colorSource: 'none',
        personalizationLevel: 'none',
        generatedCount: 0,
        requestedCount: 0,
        isSubscribed: false,
        maxImagesPerGeneration: 0,
        currentDressTypes: [],
        dressTypeIndex: 0,
        totalDressTypes: 0,
        nextDressTypeIndex: 0,
        editingMethod: 'none',
        stylingReferenceUsed: false,
        hasActiveSubscription: false,
        remainingGenerations: 1,
        totalGenerations: 0,
        dailyGenerationCount: usageResult.rows.length > 0 ? usageResult.rows[0].daily_generation_count : 0,
        generationsCount: usageResult.rows.length > 0 ? usageResult.rows[0].generations_count : 0,
        subscriptionEndDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_end_date : null,
        subscriptionStartDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_start_date : null,
      });
    }

    if (!process.env.DEEPAI_API_KEY) {
      console.error('DeepAI API key is not configured');
      return res.status(500).json({
        success: false,
        message: 'AI service is not properly configured',
        styles: [],
        hasReferenceImage: false,
        hasUserImage: false,
        userImageUrl: null,
        preferredColor: null,
        colorSource: 'none',
        personalizationLevel: 'none',
        generatedCount: 0,
        requestedCount: 0,
        isSubscribed: false,
        maxImagesPerGeneration: 0,
        currentDressTypes: [],
        dressTypeIndex: 0,
        totalDressTypes: 0,
        nextDressTypeIndex: 0,
        editingMethod: 'none',
        stylingReferenceUsed: false,
        hasActiveSubscription: false,
        remainingGenerations: 1,
        totalGenerations: 0,
        dailyGenerationCount: usageResult.rows.length > 0 ? usageResult.rows[0].daily_generation_count : 0,
        generationsCount: usageResult.rows.length > 0 ? usageResult.rows[0].generations_count : 0,
        subscriptionEndDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_end_date : null,
        subscriptionStartDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_start_date : null,
      });
    }

    const userDetailsQuery = `
      SELECT user_height, user_weight, user_skintone, user_image
      FROM smartstyley_dashboard.t_user_details 
      WHERE cust_id = $1
    `;
    const userDetailsResult = await pool.query(userDetailsQuery, [cust_id]);
    const userDetails = userDetailsResult.rows[0];

    const dressTypesQuery = `
      SELECT DISTINCT product_name, product_hashtags 
      FROM clothing_adminportal.t_master_product_details 
      WHERE product_name IS NOT NULL AND product_name != ''
      ORDER BY product_name
    `;
    const dressTypesResult = await pool.query(dressTypesQuery);

    if (dressTypesResult.rows.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No dress types found in database',
        styles: [],
        hasReferenceImage: false,
        hasUserImage: false,
        userImageUrl: null,
        preferredColor: null,
        colorSource: 'none',
        personalizationLevel: 'none',
        generatedCount: 0,
        requestedCount: 0,
        isSubscribed: false,
        maxImagesPerGeneration: 0,
        currentDressTypes: [],
        dressTypeIndex: 0,
        totalDressTypes: 0,
        nextDressTypeIndex: 0,
        editingMethod: 'none',
        stylingReferenceUsed: false,
        hasActiveSubscription: false,
        remainingGenerations: 1,
        totalGenerations: 0,
        dailyGenerationCount: usageResult.rows.length > 0 ? usageResult.rows[0].daily_generation_count : 0,
        generationsCount: usageResult.rows.length > 0 ? usageResult.rows[0].generations_count : 0,
        subscriptionEndDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_end_date : null,
        subscriptionStartDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_start_date : null,
      });
    }

    const userImageQuery = `
      SELECT user_image
      FROM smartstyley_dashboard.t_user_details 
      WHERE cust_id = $1 AND user_image IS NOT NULL AND user_image != ''
    `;
    const userImageResult = await pool.query(userImageQuery, [cust_id]);
    const hasUserImage = userImageResult.rows.length > 0;
    const userImageUrl = hasUserImage ? userImageResult.rows[0].user_image : null;

    if (!hasUserImage || !userImageUrl) {
      return res.status(400).json({
        success: false,
        message: 'User profile image is required for style generation. Please upload your photo first.',
        styles: [],
        hasReferenceImage: false,
        hasUserImage: false,
        userImageUrl: null,
        preferredColor: null,
        colorSource: 'none',
        personalizationLevel: 'none',
        generatedCount: 0,
        requestedCount: 0,
        isSubscribed: false,
        maxImagesPerGeneration: 0,
        currentDressTypes: [],
        dressTypeIndex: 0,
        totalDressTypes: 0,
        nextDressTypeIndex: 0,
        editingMethod: 'none',
        stylingReferenceUsed: false,
        hasActiveSubscription: false,
        remainingGenerations: 1,
        totalGenerations: 0,
        dailyGenerationCount: usageResult.rows.length > 0 ? usageResult.rows[0].daily_generation_count : 0,
        generationsCount: usageResult.rows.length > 0 ? usageResult.rows[0].generations_count : 0,
        subscriptionEndDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_end_date : null,
        subscriptionStartDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_start_date : null,
      });
    }

    const referenceImagesQuery = `
      SELECT user_image
      FROM smartstyley_dashboard.t_user_image 
      WHERE cust_id = $1
      ORDER BY cust_id DESC
      LIMIT 1
    `;
    const referenceImagesResult = await pool.query(referenceImagesQuery, [cust_id]);
    const hasReferenceImage = referenceImagesResult.rows.length > 0;
    const referenceImageUrl = hasReferenceImage ? referenceImagesResult.rows[0].user_image : null;

    const dressTypes = dressTypesResult.rows;
    let imageCount = 2;

    if (usageResult.rows.length > 0) {
      const { has_paid, subscription_end_date } = usageResult.rows[0];
      
      if (has_paid && subscription_end_date && new Date(subscription_end_date) >= new Date()) {
        imageCount = 4;
      }
    }
    let referenceStyleDescription = '';

    if (hasReferenceImage && referenceImageUrl) {
      console.log('\n=== PROCESSING REFERENCE IMAGE FOR DETAILED STYLING ===');
      console.log('Reference Image URL:', referenceImageUrl);
      console.log('=====================================================\n');

      try {
        console.log('Analyzing reference image styling with Google Gemini...');
        
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const referenceImageBase64 = await fetchImageAsBase64(referenceImageUrl);
        
        const detailedStylePrompt = `Analyze this reference image in detail for ${occasion} styling. Extract:

        OUTFIT DETAILS:
        - Exact dress/outfit style, cut, silhouette
        - Fabric type, texture, and draping style
        - Color palette and color combinations
        - Pattern details (if any)
        - Neckline, sleeve style, length
        - Traditional elements and embellishments

        JEWELRY & ACCESSORIES:
        - Earring style and size
        - Necklace type and layers
        - Bangles, rings, or other jewelry
        - Hair accessories (if any)
        - Any other accessories

        MAKEUP & HAIR:
        - Makeup style and intensity
        - Eye makeup details
        - Lip color and style
        - Hair styling and arrangement
        - Hair accessories

        POSE & COMPOSITION:
        - Body posture and positioning
        - Hand placement and gestures
        - Facial expression and mood
        - Overall composition style

        PHOTOGRAPHY STYLE:
        - Lighting setup and mood
        - Background type and color
        - Photography angle and framing
        - Color grading and tone

        Create a comprehensive styling guide that can be used to recreate this exact look with different facial features. Focus heavily on replicating the outfit, styling, and overall aesthetic.`;

        const styleResponse = await model.generateContent([
          {
            text: detailedStylePrompt
          },
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: referenceImageBase64
            }
          }
        ]);

        const styleResult = await styleResponse.response;
        referenceStyleDescription = styleResult.text();
        
        console.log('=== DETAILED REFERENCE STYLING ANALYSIS SUCCESS ===');
        console.log(referenceStyleDescription);
        console.log('==================================================');

      } catch (aiError) {
        console.error('Reference image detailed analysis error:', aiError);
        
        const colorDesc = preferredColor ? `beautiful ${preferredColor}` : 'elegant traditional colors';
        referenceStyleDescription = `Elegant traditional Indian styling for ${occasion} featuring ${colorDesc} outfit with graceful draping, appropriate traditional jewelry including elegant earrings and necklaces, sophisticated makeup with subtle eye enhancement and complementary lip color, hair styled in a traditional elegant manner, professional portrait photography with soft lighting and cultural aesthetic`;
        
        console.log('=== REFERENCE STYLING FALLBACK ===');
        console.log(referenceStyleDescription);
        console.log('=================================');
      }
    }

    const generateImageWithDeepAIEditor = async (userImageUrl, editingPrompt, dressType, index, maxRetries = 3) => {
      for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
          console.log(`Generating edited image ${index + 1}, attempt ${attempt} with DeepAI Image Editor...`);
          console.log(`User Image URL: ${userImageUrl}`);
          console.log(`Editing Prompt: ${editingPrompt}`);
          
          let response;
          
          console.log('Using image-editor generation...');
          
          response = await deepai.callStandardApi("image-editor", {
            image: userImageUrl,
            text: editingPrompt,
            image_generator_version: "hd"
          });

          if (!response || !response.output_url) {
            console.error('Invalid DeepAI response:', response);
            throw new Error('No output URL in DeepAI response');
          }
          
          if (!response.output_url.startsWith('http')) {
            throw new Error('Invalid output URL format from DeepAI');
          }

          const result = {
            data: [{
              url: response.output_url
            }]
          };

          console.log(`✅ Image ${index + 1} edited successfully on attempt ${attempt}`);
          console.log(`Generated URL: ${response.output_url}`);
          
          return {
            result,
            dressType,
            index,
            success: true
          };

        } catch (error) {
          console.error(`❌ Image ${index + 1} failed on attempt ${attempt}:`, {
            message: error.message,
            status: error.status,
            code: error.code,
            response: error.response?.data || error.response || 'No response data'
          });

          if (error.code === 'ETIMEDOUT' || error.message.includes('timeout')) {
            console.log(`⏳ Timeout on attempt ${attempt}, extending wait time...`);
            if (attempt < maxRetries) {
              const extendedDelay = 10000 + (attempt * 5000);
              await new Promise(resolve => setTimeout(resolve, extendedDelay));
              continue;
            }
          }

          if (error.response?.data?.err?.includes('content policy') || 
              error.response?.data?.err?.includes('inappropriate')) {
            console.log('Content policy violation detected, skipping retries');
            return {
              result: null,
              dressType,
              index,
              success: false,
              error: 'Content policy violation - prompt needs adjustment'
            };
          }

          if (attempt === maxRetries) {
            return {
              result: null,
              dressType,
              index,
              success: false,
              error: `Failed after ${maxRetries} attempts: ${error.message}`
            };
          }

          const baseDelay = Math.pow(2, attempt) * 5000;
          const jitter = Math.random() * 2000;
          const delay = baseDelay + jitter;
          
          console.log(`⏳ Waiting ${Math.round(delay)}ms before retry...`);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
      return {
        result: null,
        dressType,
        index,
        success: false,
        error: 'Unexpected error in retry loop'
      };
    };

    const generateOptimizedEditingPrompt = async (styleDescription, dressType, occasion, preferredColor, userDetails, hasReferenceImage) => {
      try {
        console.log('Creating optimized editing prompt with Gemini...');
        
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        
        let promptCreationInstruction = '';

        if (hasReferenceImage && styleDescription) {
          promptCreationInstruction = `Create an elegant image editing prompt for:

DRESS TYPE: ${dressType}
OCCASION: ${occasion}
PREFERRED COLOR: ${preferredColor || 'elegant traditional'}
REFERENCE STYLE DETAILS: ${styleDescription}

${hasUserImage ? 'IMPORTANT: Use the exact face, body structure, and features from the uploaded user image' : `PERSON DETAILS: ${userDetails.user_skintone} skin tone`}

Create a prompt that:
1. PRESERVE THE EXACT SAME FACE AND BODY from the uploaded user image
2. Apply the reference style with ${preferredColor || 'elegant'} color theme
3. Keep facial features and body proportions identical to uploaded image
4. Transform outfit to match reference style in ${preferredColor || 'elegant'} colors
5. Maintain the person's natural appearance while applying new styling`;
        } else {
          promptCreationInstruction = `Create an elegant image editing prompt for:
          
          DRESS TYPE: ${dressType}
          OCCASION: ${occasion}
          PREFERRED COLOR: ${preferredColor || 'elegant traditional'}
          PERSON DETAILS: ${userDetails.user_skintone} skin tone
          
          Create a prompt that:
          1. Preserves the person's facial features completely
          2. Transforms outfit to elegant ${dressType}
          3. Adds appropriate traditional jewelry
          4. Enhances with suitable makeup and hair styling
          5. Maintains professional photography quality
          6. Ensures cultural appropriateness for ${occasion}
          
          Keep the editing natural and realistic while enhancing the overall appearance.`;
        }

        const response = await model.generateContent([{ text: promptCreationInstruction }]);
        const result = await response.response;  
        const optimizedPrompt = result.text().trim();
        
        console.log('✅ Optimized editing prompt created successfully');
        return optimizedPrompt;
        
      } catch (error) {
        console.error('Gemini editing prompt optimization error:', error);
        
        let fallbackPrompt = '';

        if (hasReferenceImage && styleDescription) {
          const colorPart = preferredColor ? `${preferredColor} colored ` : 'elegant ';
          fallbackPrompt = `Keep exact same face from uploaded image, apply this reference style: ${styleDescription.substring(0, 200)}..., use ${colorPart}colors, preserve facial identity completely`;
        } else {
          const colorPart = preferredColor ? `${preferredColor} colored ` : 'elegant ';
          fallbackPrompt = `Keep same face and body from uploaded image, edit to ${colorPart}${dressType} for ${occasion}, preserve user's appearance completely`;
        }
        
        console.log('Using enhanced fallback editing prompt');
        return fallbackPrompt;
      }
    };

    console.log('\n=== GENERATING PERSONALIZED STYLES WITH IMAGE EDITOR ===');
    const generatedStyles = [];
    const selectedDressTypes = [];

    for (let i = 0; i < imageCount; i++) {
      const currentDressIndex = (dressTypeIndex + i) % dressTypes.length;
      const selectedDressType = dressTypes[currentDressIndex];
      selectedDressTypes.push(selectedDressType);
      
      console.log(`\n--- Processing Image ${i + 1}/${imageCount} ---`);
      console.log(`Dress Type: ${selectedDressType.product_name}`);
      console.log(`User Image URL: ${userImageUrl}`);
      console.log(`Has Reference Styling: ${hasReferenceImage}`);
      console.log(`Preferred Color: ${preferredColor || 'Default'}`);

      const optimizedEditingPrompt = await generateOptimizedEditingPrompt(
        referenceStyleDescription,
        selectedDressType.product_name,
        occasion,
        preferredColor,
        userDetails,
        hasReferenceImage
      );

      console.log(`Optimized Editing Prompt Length: ${optimizedEditingPrompt.length}`);

      let finalPromptForAPI = optimizedEditingPrompt.length > 500 ? 
        optimizedEditingPrompt.substring(0, 500).trim() + '...' : 
        optimizedEditingPrompt;

      if (preferredColor) {
        const colorEmphasis = `Use ${preferredColor} as the dominant color. `;
        finalPromptForAPI = colorEmphasis + finalPromptForAPI;
      }

      const imageResult = await generateImageWithDeepAIEditor(userImageUrl, finalPromptForAPI, selectedDressType.product_name, i);

      if (imageResult.success && imageResult.result && imageResult.result.data && imageResult.result.data[0]) {
        generatedStyles.push({
          id: `style_${Date.now()}_${dressTypeIndex}_${i + 1}`,
          name: `${imageResult.dressType} Style`,
          image: imageResult.result.data[0].url,
          dressType: imageResult.dressType,
          editingMethod: 'image_editor',
          baseImage: userImageUrl
        });
        console.log(`✅ Successfully edited style: ${imageResult.dressType}`);
      } else {
        console.log(`❌ Failed to edit style for: ${selectedDressType.product_name}`);
        console.log('Error:', imageResult.error);
      }

      if (i < imageCount - 1) {
        console.log('⏳ Waiting 3 seconds before next generation...');
        await new Promise(resolve => setTimeout(resolve, 3000));
      }
    }

    if (generatedStyles.length === 0) {
      return res.status(500).json({
        success: false,
        message: 'Failed to generate any images. This might be due to DeepAI API server issues, rate limits, or content policy restrictions. Please try again in a few minutes.',
        styles: [],
        hasReferenceImage: false,
        hasUserImage: false,
        userImageUrl: null,
        preferredColor: null,
        colorSource: 'none',
        personalizationLevel: 'none',
        generatedCount: 0,
        requestedCount: 0,
        isSubscribed: false,
        maxImagesPerGeneration: 0,
        currentDressTypes: [],
        dressTypeIndex: 0,
        totalDressTypes: 0,
        nextDressTypeIndex: 0,
        editingMethod: 'none',
        stylingReferenceUsed: false,
        hasActiveSubscription: false,
        remainingGenerations: 1,
        totalGenerations: 0,
        dailyGenerationCount: usageResult.rows.length > 0 ? usageResult.rows[0].daily_generation_count : 0,
        generationsCount: usageResult.rows.length > 0 ? usageResult.rows[0].generations_count : 0,
        subscriptionEndDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_end_date : null,
        subscriptionStartDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_start_date : null,
      });
    }

    const successMessage = generatedStyles.length === imageCount 
      ? 'Personalized styles generated successfully using image editing!' 
      : `${generatedStyles.length} out of ${imageCount} personalized styles generated successfully. Some images failed due to API issues.`;

    console.log(`\n✅ Generation complete: ${generatedStyles.length}/${imageCount} images successful`);
    console.log('Generated types:', generatedStyles.map(style => style.dressType));
    console.log('Personalization level: Image Editor with', hasReferenceImage ? 'Reference Styling' : 'Basic Styling');

    const actualGeneratedCount = generatedStyles.length;

    // Update usage based on subscription status
    if (usageResult.rows.length > 0) {
      // Update subscription usage
      const updateSubscriptionUsage = `
        UPDATE smartstyley_dashboard.t_user_daily_usage 
        SET total_generations_in_subscription = total_generations_in_subscription + $2
        WHERE cust_id = $1 
          AND has_paid = true 
          AND subscription_end_date >= CURRENT_DATE
      `;
      await pool.query(updateSubscriptionUsage, [cust_id, actualGeneratedCount]);
    } else {
      // Update daily usage for free users
    //   const updateDailyUsage = `
    //     INSERT INTO smartstyley_dashboard.t_user_daily_usage 
    //     (cust_id, usage_date, daily_generation_count, has_paid)
    //     VALUES ($1, $2, $3, false)
    //     ON CONFLICT (cust_id, usage_date)
    //     DO UPDATE SET daily_generation_count = daily_generation_count + $3
    //   `;
    //   await pool.query(updateDailyUsage, [cust_id, today, actualGeneratedCount]);

    const updateDailyUsage = `
      INSERT INTO smartstyley_dashboard.t_user_daily_usage 
      (cust_id, usage_date, daily_generation_count, has_paid)
      VALUES ($1, $2, $3, false)
      ON CONFLICT (cust_id, usage_date)
      DO UPDATE SET daily_generation_count = smartstyley_dashboard.t_user_daily_usage.daily_generation_count + $3
    `;
    await pool.query(updateDailyUsage, [cust_id, today, actualGeneratedCount]);
    }
    console.log('✅ Usage count updated successfully');

    res.status(200).json({
      success: true,
      message: successMessage,
      styles: generatedStyles,
      hasReferenceImage: hasReferenceImage,
      hasUserImage: true,
      userImageUrl: userImageUrl,
      preferredColor: preferredColor || null,
      colorSource: preferredColor ? 'user_preference' : (hasReferenceImage ? 'reference_image' : 'default'),
      personalizationLevel: hasReferenceImage ? 'image_editor_with_reference_styling' : 'image_editor_basic_styling',
      generatedCount: generatedStyles.length,
      requestedCount: imageCount,
      isSubscribed: imageCount === 1,
      maxImagesPerGeneration: imageCount, 
      currentDressTypes: generatedStyles.map(style => style.dressType),
      dressTypeIndex: dressTypeIndex,
      totalDressTypes: dressTypes.length,
      nextDressTypeIndex: (dressTypeIndex + imageCount) % dressTypes.length,
      editingMethod: 'deepai_image_editor',
      stylingReferenceUsed: hasReferenceImage,
      hasActiveSubscription: false,
      remainingGenerations: 1,
      totalGenerations: 0,
      dailyGenerationCount: usageResult.rows.length > 0 ? usageResult.rows[0].daily_generation_count : 0,
      generationsCount: usageResult.rows.length > 0 ? usageResult.rows[0].generations_count : 0,
      subscriptionEndDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_end_date : null,
      subscriptionStartDate: usageResult.rows.length > 0 ? usageResult.rows[0].subscription_start_date : null,
    });

  } catch (error) {
    console.error('Enhanced style generation with image editor error:', error);
    
    let errorMessage = 'Error generating personalized styles. Please try again.';
    
    if (error.status === 403 || error.message?.includes('unauthorized')) {
      errorMessage = 'API access denied. Please check your DeepAI API key and billing status.';
    } else if (error.message && error.message.includes('timeout')) {
      errorMessage = 'Request timed out. Please try again.';
    } else if (error.message && error.message.includes('rate limit')) {
      errorMessage = 'Too many requests. Please wait a moment and try again.';
    } else if (error.status === 429) {
      errorMessage = 'DeepAI rate limit exceeded. Please wait a moment and try again.';
    } else if (error.status >= 500) {
      errorMessage = 'DeepAI server is experiencing issues. Please try again in a few minutes.';
    } else if (error.code === 'ECONNREFUSED' || error.code === 'ENOTFOUND') {
      errorMessage = 'Unable to connect to AI services. Please check your internet connection.';
    } else if (error.message?.includes('Gemini') || error.message?.includes('Google')) {
      errorMessage = 'Image analysis service temporarily unavailable. Generated with basic personalization.';
    }
    
    res.status(500).json({
      success: false,
      message: errorMessage,
      styles: [],
      hasReferenceImage: false,
      hasUserImage: false,
      userImageUrl: null,
      preferredColor: null,
      colorSource: 'none',
      personalizationLevel: 'none',
      generatedCount: 0,
      requestedCount: 0,
      isSubscribed: false,
      maxImagesPerGeneration: 0,
      currentDressTypes: [],
      dressTypeIndex: 0,
      totalDressTypes: 0,
      nextDressTypeIndex: 0,
      editingMethod: 'none',
      stylingReferenceUsed: false,
      hasActiveSubscription: false,
      remainingGenerations: 1,
      totalGenerations: 0,
      dailyGenerationCount: 0,
      generationsCount: 0,
      subscriptionEndDate: null,
      subscriptionStartDate: null,
    });
  }
});
// analyze female image end point 

// checks and resets daily generation count to zero
app.post('/api/reset-daily-generations', async (req, res) => {
  try {
    const query = `
      UPDATE smartstyley_dashboard.t_user_daily_usage 
      SET daily_generation_count = 0 
      WHERE usage_date < CURRENT_DATE
    `;
    await pool.query(query);
    res.json({ success: true, message: 'Daily generation counts reset successfully' });
  } catch (error) {
    console.error('Error resetting daily generation counts:', error);
    res.status(500).json({ success: false, message: 'Failed to reset daily generation counts' });
  }
}); 
// checks and resets daily generation count to zero 

// payment related endpoints 
//*************************** Payment Status Endpoints *************************************

// Check payment status
app.get('/api/check-payment-status/:cust_id', async (req, res) => {
  const { cust_id } = req.params;
  const today = new Date().toISOString().split('T')[0];

  try {
    // Check for active subscription first
    const subscriptionQuery = `
      SELECT has_paid, subscription_end_date, total_generations_in_subscription 
      FROM smartstyley_dashboard.t_user_daily_usage 
      WHERE cust_id = $1 
        AND has_paid = true 
        AND subscription_end_date >= CURRENT_DATE
      ORDER BY subscription_start_date DESC 
      LIMIT 1
    `;
    const subscriptionResult = await pool.query(subscriptionQuery, [cust_id]);

    if (subscriptionResult.rows.length > 0) {
      const subscription = subscriptionResult.rows[0];
      const totalGenerations = subscription.total_generations_in_subscription || 0;
      
      res.json({
        success: true,
        canGenerate: totalGenerations < 75, // Assuming 75 is your subscription limit
        needsPayment: totalGenerations >= 75,
      });
    } else {
      // No active subscription - check daily free limit
      const todayQuery = `
        SELECT daily_generation_count 
        FROM smartstyley_dashboard.t_user_daily_usage 
        WHERE cust_id = $1 AND usage_date = $2
      `;
      const todayResult = await pool.query(todayQuery, [cust_id, today]);
      const dailyCount = todayResult.rows[0]?.daily_generation_count || 0;
      
      res.json({
        success: true,
        canGenerate: dailyCount < 1,
        needsPayment: dailyCount >= 1,
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      canGenerate: false,
      needsPayment: false,
      message: 'Error checking payment status'
    });
  }
});

// Process payment
app.post('/api/process-payment', async (req, res) => {
  const { cust_id, paymentMethod, amount } = req.body;
  const today = new Date().toISOString().split('T')[0];

  try {
    const updateQuery = `
      INSERT INTO smartstyley_dashboard.t_user_daily_usage (cust_id, usage_date, has_paid)
      VALUES ($1, $2, true)
      ON CONFLICT (cust_id, usage_date)
      DO UPDATE SET has_paid = true
    `;
    await pool.query(updateQuery, [cust_id, today]);

    res.json({
      success: true,
      message: 'Payment processed successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Payment processing failed' });
  }
});

//*************************** Razorpay Endpoints *************************************

// Create payment order
app.post('/api/create-payment-order', async (req, res) => {
  const { cust_id, amount = 499 } = req.body; // Default amount 499 INR

  try {
    const options = {
      amount: amount * 100, // Amount in paise
      currency: 'INR',
      receipt: `receipt_${cust_id}_${Date.now()}`,
    };

    const order = await razorpay.orders.create(options);

    const insertOrderQuery = `
      INSERT INTO smartstyley_dashboard.t_payment_transactions 
      (cust_id, razorpay_order_id, amount, currency, payment_status)
      VALUES ($1, $2, $3, $4, 'pending')
      RETURNING payment_id
    `;

    const result = await pool.query(insertOrderQuery, [cust_id, order.id, amount, 'INR']);

    res.json({
      success: true,
      order_id: order.id,
      amount: order.amount,
      currency: order.currency,
      payment_id: result.rows[0].payment_id,
    });
  } catch (error) {
    console.error('Error creating payment order:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create payment order',
    });
  }
});

// Verify Razorpay payment
app.post('/api/verify-payment', async (req, res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature, cust_id } = req.body;

  try {
    const sign = razorpay_order_id + '|' + razorpay_payment_id;
    const expectedSign = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(sign.toString())
      .digest('hex');

    if (razorpay_signature === expectedSign) {
      const today = new Date().toISOString().split('T')[0];

      // Update payment transaction status
      const updatePaymentQuery = `
        UPDATE smartstyley_dashboard.t_payment_transactions 
        SET razorpay_payment_id = $1, razorpay_signature = $2, 
            payment_status = 'completed'
        WHERE razorpay_order_id = $3 AND cust_id = $4
      `;
      await pool.query(updatePaymentQuery, [razorpay_payment_id, razorpay_signature, razorpay_order_id, cust_id]);

      // Check if any record exists for the cust_id
      const insertOrUpdateQuery = `
        INSERT INTO smartstyley_dashboard.t_user_daily_usage 
        (cust_id, usage_date, has_paid, subscription_start_date, subscription_end_date, 
         total_generations_in_subscription, subscription_id, daily_generation_count, generations_count)
        VALUES ($1, CURRENT_DATE, true, CURRENT_DATE, CURRENT_DATE + INTERVAL '30 days', 0, $2, 0, 0)
        ON CONFLICT (cust_id, usage_date)
        DO UPDATE SET 
          has_paid = true,
          subscription_start_date = CURRENT_DATE,
          subscription_end_date = CURRENT_DATE + INTERVAL '30 days',
          total_generations_in_subscription = 0,
          subscription_id = $2
      `;
      await pool.query(insertOrUpdateQuery, [cust_id, razorpay_payment_id]);

      res.json({
        success: true,
        message: 'Payment verified successfully',
      });
    } else {
      const updatePaymentQuery = `
        UPDATE smartstyley_dashboard.t_payment_transactions 
        SET payment_status = 'failed'
        WHERE razorpay_order_id = $1 AND cust_id = $2
      `;
      await pool.query(updatePaymentQuery, [razorpay_order_id, cust_id]);

      res.status(400).json({
        success: false,
        message: 'Payment verification failed',
      });
    }
  } catch (error) {
    console.error('Payment verification error:', error);
    res.status(500).json({
      success: false,
      message: 'Payment verification failed',
    });
  }
});

// Get Razorpay config
app.get('/api/razorpay-config', (req, res) => {
  res.json({
    key: process.env.RAZORPAY_KEY_ID,
  });
});

//*************************** Subscription Status Endpoint *************************************

app.get('/api/subscription-status/:cust_id', async (req, res) => {
  const { cust_id } = req.params;
  console.log('Subscription status requested for cust_id:', cust_id);

  try {
    const query = `
      SELECT 
        has_paid,
        total_generations_in_subscription,
        subscription_start_date,
        subscription_end_date,
        generations_count,
        daily_generation_count 
      FROM smartstyley_dashboard.t_user_daily_usage 
      WHERE cust_id = $1 
        AND has_paid = true
        AND subscription_end_date >= CURRENT_DATE
      ORDER BY subscription_start_date DESC 
      LIMIT 1
    `;

    const todayQuery = `
      SELECT daily_generation_count 
      FROM smartstyley_dashboard.t_user_daily_usage 
      WHERE cust_id = $1 AND usage_date = CURRENT_DATE
    `;
    const todayResult = await pool.query(todayQuery, [cust_id]);
    const dailyGenerationCount = todayResult.rows[0]?.daily_generation_count || 0;

    const result = await pool.query(query, [cust_id]);

    if (result.rows.length === 0) {
      return res.json({
        success: true,
        message: 'Subscription status retrieved successfully',
        hasActiveSubscription: false,
        remainingGenerations: 1, // Free trial
        totalGenerations: 0,
        subscriptionEndDate: null,
        hasReferenceImage: false,
        hasUserImage: false,
        userImageUrl: null,
        preferredColor: null,
        colorSource: 'none',
        personalizationLevel: 'none',
        generatedCount: 0,
        requestedCount: 0,
        isSubscribed: false,
        maxImagesPerGeneration: 0,
        currentDressTypes: [],
        dressTypeIndex: 0,
        totalDressTypes: 0,
        nextDressTypeIndex: 0,
        editingMethod: 'none',
        stylingReferenceUsed: false,
        dailyGenerationCount,
        generationsCount: 0,
        subscriptionStartDate: null,
      });
    }

    const subscription = result.rows[0];
    const remainingGenerations = subscription.has_paid
      ? Math.max(0, 75 - (subscription.total_generations_in_subscription || 0))
      : Math.max(0, 1 - (subscription.daily_generation_count || 0));

    res.json({
      success: true,
      message: 'User not found',
      hasActiveSubscription: subscription.has_paid,
      remainingGenerations,
      totalGenerations: subscription.total_generations_in_subscription || 0,
      dailyGenerationCount,
      generationsCount: subscription.generations_count || 0,
      subscriptionEndDate: subscription.subscription_end_date,
      subscriptionStartDate: subscription.subscription_start_date,
      hasReferenceImage: false,
      hasUserImage: false,
      userImageUrl: null,
      preferredColor: null,
      colorSource: 'none',
      personalizationLevel: 'none',
      generatedCount: 0,
      requestedCount: 0,
      isSubscribed: subscription.has_paid,
      maxImagesPerGeneration: 0,
      currentDressTypes: [],
      dressTypeIndex: 0,
      totalDressTypes: 0,
      nextDressTypeIndex: 0,
      editingMethod: 'none',
      stylingReferenceUsed: false,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching subscription status',
      hasReferenceImage: false,
      hasUserImage: false,
      userImageUrl: null,
      preferredColor: null,
      colorSource: 'none',
      personalizationLevel: 'none',
      generatedCount: 0,
      requestedCount: 0,
      isSubscribed: false,
      maxImagesPerGeneration: 0,
      currentDressTypes: [],
      dressTypeIndex: 0,
      totalDressTypes: 0,
      nextDressTypeIndex: 0,
      editingMethod: 'none',
      stylingReferenceUsed: false,
      hasActiveSubscription: false,
      remainingGenerations: 1,
      totalGenerations: 0,
      dailyGenerationCount: 0,
      generationsCount: 0,
      subscriptionEndDate: null,
      subscriptionStartDate: null,
    });
  }
});
// payment related endpoints 

// wishlist related endpoints 
const saveImageWithExistingUpload = async (imageUrl, custId, styleId) => {
  try {
    // Download image as buffer (not stream)
    const response = await axios.get(imageUrl, { 
      responseType: 'arraybuffer',
      timeout: 45000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    
    // Convert to buffer
    const buffer = Buffer.from(response.data);
    
    // Use your existing S3 client and configuration
    const fileName = `liked-styles/${custId}/${styleId}-${Date.now()}.jpg`;
    
    const uploadParams = {
      Bucket: process.env.BUCKET_NAME,
      Key: fileName,
      Body: buffer,
      ContentType: 'image/jpeg',
      ContentLength: buffer.length,
      Metadata: {
        'Content-Disposition': 'inline'
      }
    };
    
    const command = new PutObjectCommand(uploadParams);
    await s3.send(command);
    
    const s3Url = `https://${process.env.BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${fileName}`;
    return s3Url;
    
  } catch (error) {
    console.error('Error uploading with existing method:', error);
    throw error;
  }
};

app.post('/api/like-style', async (req, res) => {
  const { cust_id, style_id, style_image_url } = req.body;
  
  try {
    // Validate required fields
    if (!cust_id || !style_id || !style_image_url) {
      return res.status(400).json({
        success: false,
        message: 'Customer ID, style ID, and image URL are required'
      });
    }

    // Check if customer exists
    const customerCheck = await pool.query(
      'SELECT cust_id FROM smartstyley_dashboard.t_customer_details WHERE cust_id = $1',
      [cust_id]
    );

    if (customerCheck.rows.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Customer not found'
      });
    }

    // Save image to S3
    console.log('Saving liked image to S3...');
    const storedImageUrl = await saveImageWithExistingUpload(style_image_url, cust_id, style_id);

    // Check if already liked (using stored_image_url pattern)
    const existingLike = await pool.query(
      'SELECT like_id FROM smartstyley_dashboard.t_user_liked_styles WHERE cust_id = $1 AND stored_image_url LIKE $2',
      [cust_id, `%${style_id}%`]
    );

    if (existingLike.rows.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Style already liked'
      });
    }

    // Insert like record
    const insertQuery = `
      INSERT INTO smartstyley_dashboard.t_user_liked_styles 
      (cust_id, stored_image_url)
      VALUES ($1, $2)
      RETURNING *
    `;

    const values = [
      cust_id,
      storedImageUrl
    ];

    const result = await pool.query(insertQuery, values);

    console.log('Style liked successfully:', result.rows[0]);

    res.status(200).json({
      success: true,
      message: 'Style liked successfully!',
      likedStyle: {
        ...result.rows[0],
        style_id: style_id // Include style_id in response for frontend
      }
    });

  } catch (error) {
    console.error('Like style error:', error);
    res.status(500).json({
      success: false,
      message: 'Error liking style. Please try again.'
    });
  }
});

app.delete('/api/unlike-style', async (req, res) => {
  const { cust_id, style_id } = req.body;
  
  console.log('Unlike request received:', { cust_id, style_id });
  
  try {
    // Validate required fields
    if (!cust_id || !style_id) {
      return res.status(400).json({
        success: false,
        message: 'Customer ID and style ID are required'
      });
    }

    // Convert cust_id to proper type
    // const custIdParam = isNaN(cust_id) ? cust_id : parseInt(cust_id);
    const custIdParam = cust_id;

    // Delete using stored_image_url pattern that contains style_id
    const deleteQuery = `
      DELETE FROM smartstyley_dashboard.t_user_liked_styles 
      WHERE cust_id = $1 AND stored_image_url LIKE $2
      RETURNING *
    `;

    const result = await pool.query(deleteQuery, [custIdParam, `%${style_id}%`]);
    console.log('Delete query result:', result.rows);

    if (result.rows.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Style not found in liked list'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Style unliked successfully!',
      unlikedStyle: result.rows[0]
    });

  } catch (error) {
    console.error('Unlike style error:', error);
    res.status(500).json({
      success: false,
      message: 'Error unliking style. Please try again.'
    });
  }
});

app.get('/api/liked-styles/:cust_id', async (req, res) => {
  const { cust_id } = req.params;
  
  console.log('Get liked styles request for customer:', cust_id, 'type:', typeof cust_id);
  
  try {
    // Validate customer ID
    if (!cust_id) {
      return res.status(400).json({
        success: false,
        message: 'Customer ID is required'
      });
    }

    // Convert cust_id to number if it's a string (in case database expects number)
    // const custIdParam = isNaN(cust_id) ? cust_id : parseInt(cust_id);
    const custIdParam = cust_id;
    console.log('Using cust_id parameter:', custIdParam, 'type:', typeof custIdParam);

    // Get all liked styles for the customer
    const likedStylesQuery = `
      SELECT 
        like_id,
        cust_id,
        stored_image_url,
        liked_at
      FROM smartstyley_dashboard.t_user_liked_styles 
      WHERE cust_id = $1
      ORDER BY liked_at DESC
    `;

    const result = await pool.query(likedStylesQuery, [custIdParam]);
    console.log('Database query result:', result.rows.length, 'rows found');

    // Extract style IDs from stored_image_url for frontend compatibility
    const processedResults = result.rows.map(row => {
      // Extract style_id from stored_image_url pattern: /liked-styles/custId/styleId-timestamp.jpg
      const urlParts = row.stored_image_url.split('/');
      const fileName = urlParts[urlParts.length - 1];
      const styleIdMatch = fileName.match(/^(.+)-\d+\.jpg$/);
      const extractedStyleId = styleIdMatch ? styleIdMatch[1] : null;
      
      console.log('Processing row:', {
        like_id: row.like_id,
        stored_image_url: row.stored_image_url,
        extracted_style_id: extractedStyleId
      });
      
      return {
        ...row,
        extracted_style_id: extractedStyleId
      };
    });

    res.status(200).json({
      success: true,
      likedStyles: processedResults,
      count: processedResults.length
    });

  } catch (error) {
    console.error('Get liked styles error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching liked styles. Please try again.'
    });
  }
});

app.get('/api/user-liked-dashboard/:cust_id', async (req, res) => {
  const { cust_id } = req.params;
  
  try {
    const likedStylesQuery = `
      SELECT 
        like_id,
        stored_image_url as image_url,
        liked_at
      FROM smartstyley_dashboard.t_user_liked_styles 
      WHERE cust_id = $1
      ORDER BY liked_at DESC
    `;

    const result = await pool.query(likedStylesQuery, [cust_id]);

    res.status(200).json({
      success: true,
      message: 'Liked styles fetched successfully',
      likedStyles: result.rows,
      totalCount: result.rows.length
    });

  } catch (error) {
    console.error('Get user liked dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching liked styles dashboard. Please try again.'
    });
  }
});

app.post('/api/download-image', async (req, res) => {
  const { imageUrl } = req.body;
  
  try {
    if (!imageUrl) {
      return res.status(400).json({
        success: false,
        message: 'Image URL is required'
      });
    }

    // Fetch the image using axios (same as your existing image handling)
    const response = await axios.get(imageUrl, { 
      responseType: 'arraybuffer',
      timeout: 45000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    
    // Convert to buffer
    const buffer = Buffer.from(response.data);
    
    // Set appropriate headers for download
    res.set({
      'Content-Type': 'image/jpeg',
      'Content-Disposition': 'attachment; filename="style-image.jpg"',
      'Content-Length': buffer.length.toString(),
      'Access-Control-Allow-Origin': '*'  // Allow CORS for download
    });
    
    // Send the image buffer
    res.send(buffer);

  } catch (error) {
    console.error('Error downloading image:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to download image. Please try again.'
    });
  }
});
// wishlist related endpoints


// Previous code from the previous artifact (not repeated here for brevity but assumed to be included)

// find shops related endpoints start 
function calculateDistance(lat2, lon2, userLat, userLng) {
  // Add coordinate validation
  if (!lat2 || !lon2 || !userLat || !userLng) return Infinity;

  const shopLat = parseFloat(lat2);
  const shopLng = parseFloat(lon2);
  const uLat = parseFloat(userLat.toString());
  const uLng = parseFloat(userLng.toString());

  if (isNaN(shopLat) || isNaN(shopLng) || isNaN(uLat) || isNaN(uLng)) {
    return Infinity;
  }

  const R = 6371; // Earth's radius in km
  const dLat = toRad(shopLat - uLat);
  const dLon = toRad(shopLng - uLng);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(uLat)) * Math.cos(toRad(shopLat)) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Math.round((R * c) * 100) / 100;
}

function toRad(degrees) {
  return (degrees * Math.PI) / 180;
}

const generateKeywordsFromImages = async (imageUrls) => {
  const allKeywords = new Set();
  const allPhrases = new Set();

  const PROCESSING_TIMEOUT = 30000; // 30 seconds per image

  // Get the Gemini model
  const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

  for (const imageUrl of imageUrls) {
    try {
      console.log('Generating keywords from image with Gemini:', imageUrl);

      // Convert image URL to base64 with error handling
      let imageBase64;
      try {
        imageBase64 = await fetchImageAsBase64(imageUrl);
      } catch (fetchError) {
        console.error(`Skipping image ${imageUrl} due to fetch error:`, fetchError.message);
        continue; // Skip this image and move to next one
      }

      // Create the prompt for Gemini
      const keywordPrompt = `Analyze this Indian traditional dress image and extract:
      1. Key dress type phrases (like "silk saree", "cotton lehenga", "georgette kurta")
      2. Design pattern phrases (like "floral embroidery", "golden border", "mirror work")
      3. Style combination phrases (like "red silk saree", "blue embroidered lehenga")
      4. Individual important keywords for dress elements
      
      Return response in this EXACT format:
      PHRASES: [phrase1, phrase2, phrase3]
      KEYWORDS: [keyword1, keyword2, keyword3]
      
      Focus on searchable terms that would appear in Indian clothing product descriptions. Max 10 phrases and 10 keywords.`;

      // Generate content with Gemini
      const response = await model.generateContent([
        {
          text: keywordPrompt,
        },
        {
          inlineData: {
            mimeType: "image/jpeg",
            data: imageBase64,
          },
        },
      ]);

      // Extract the generated text
      const result = await response.response;
      const content = result.text();

      console.log('Gemini keyword response:', content);

      // Extract phrases
      const phrasesMatch = content.match(/PHRASES:\s*\[(.*?)\]/);
      if (phrasesMatch) {
        const phrases = phrasesMatch[1]
          .split(',')
          .map((phrase) => phrase.trim().replace(/['"]/g, '').toLowerCase())
          .filter((phrase) => phrase.length > 3);
        phrases.forEach((phrase) => allPhrases.add(phrase));
        console.log('Extracted phrases:', phrases);
      }

      // Extract keywords
      const keywordsMatch = content.match(/KEYWORDS:\s*\[(.*?)\]/);
      if (keywordsMatch) {
        const keywords = keywordsMatch[1]
          .split(',')
          .map((word) => word.trim().replace(/['"]/g, '').toLowerCase())
          .filter((word) => word.length > 2);
        keywords.forEach((keyword) => allKeywords.add(keyword));
        console.log('Extracted keywords:', keywords);
      }

      // Additional parsing if the format is slightly different
      if (!phrasesMatch && !keywordsMatch) {
        console.log('Standard format not found, trying alternative parsing...');

        // Try to extract any phrases or keywords from the response
        const lines = content.split('\n');
        for (const line of lines) {
          if (line.toLowerCase().includes('phrase') || line.toLowerCase().includes('style')) {
            const matches = line.match(/["']([^"']+)["']/g);
            if (matches) {
              matches.forEach((match) => {
                const phrase = match.replace(/['"]/g, '').toLowerCase();
                if (phrase.length > 3) allPhrases.add(phrase);
              });
            }
          }
          if (line.toLowerCase().includes('keyword') || line.toLowerCase().includes('element')) {
            const matches = line.match(/["']([^"']+)["']/g);
            if (matches) {
              matches.forEach((match) => {
                const keyword = match.replace(/['"]/g, '').toLowerCase();
                if (keyword.length > 2) allKeywords.add(keyword);
              });
            }
          }
        }
      }
    } catch (error) {
      console.error('Error generating keywords with Gemini:', {
        message: error.message,
        status: error.status,
        imageUrl: imageUrl,
      });

      // Enhanced fallback based on error type
      if (error.status === 403 || error.message?.includes('API key')) {
        console.log('Gemini API key issue, using basic fallbacks...');
        allPhrases.add('traditional indian dress');
        allPhrases.add('ethnic wear');
        allKeywords.add('indian');
        allKeywords.add('traditional');
      } else if (error.status === 429) {
        console.log('Gemini rate limit, using fallbacks...');
        allPhrases.add('designer indian wear');
        allPhrases.add('festive outfit');
        allKeywords.add('festive');
        allKeywords.add('designer');
      } else {
        console.log('General Gemini error, using basic fallbacks...');
        allPhrases.add('traditional dress');
        allPhrases.add('indian wear');
        allKeywords.add('dress');
        allKeywords.add('wear');
      }
    }

    // Add a small delay between requests to avoid rate limiting
    if (imageUrls.indexOf(imageUrl) < imageUrls.length - 1) {
      await new Promise((resolve) => setTimeout(resolve, 2000)); // 2 second delay
    }
  }

  console.log('Final extracted phrases:', Array.from(allPhrases));
  console.log('Final extracted keywords:', Array.from(allKeywords));

  // Ensure we have at least some keywords/phrases
  if (allPhrases.size === 0 && allKeywords.size === 0) {
    console.log('No keywords extracted, adding fallback terms...');
    allPhrases.add('traditional indian dress');
    allPhrases.add('ethnic wear');
    allKeywords.add('indian');
    allKeywords.add('traditional');
    allKeywords.add('dress');
  }

  console.log('=== KEYWORD GENERATION START ===');
  console.log('Image URLs received:', imageUrls);
  console.log('Process start time:', new Date().toISOString());

  return {
    phrases: Array.from(allPhrases),
    keywords: Array.from(allKeywords),
  };
};

const isGenderAppropriate = (descriptions, detectedGender) => {
  const descriptionText = descriptions.join(' ').toLowerCase();

  const maleKeywords = ['kurta', 'shirt', 'dhoti', 'pajama', 'men', 'boys', 'gents'];
  const femaleKeywords = ['saree', 'lehenga', 'salwar', 'kurti', 'women', 'girls', 'ladies'];

  const maleMatches = maleKeywords.filter((keyword) => descriptionText.includes(keyword)).length;
  const femaleMatches = femaleKeywords.filter((keyword) => descriptionText.includes(keyword)).length;

  if (detectedGender === 'male') {
    return maleMatches >= femaleMatches;
  } else {
    return femaleMatches >= maleMatches;
  }
};

const checkDescriptionMatch = (descriptions, extractedData) => {
  if (!descriptions || descriptions.length === 0 || !extractedData) {
    return { isMatch: false, matchScore: 0, matchedPatterns: [], phraseMatches: 0, keywordMatches: 0, semanticMatches: 0 };
  }

  const { phrases, keywords } = extractedData;
  if ((!phrases || phrases.length === 0) && (!keywords || keywords.length === 0)) {
    return { isMatch: false, matchScore: 0, matchedPatterns: [], phraseMatches: 0, keywordMatches: 0, semanticMatches: 0 };
  }

  const descriptionText = descriptions.join(' ').toLowerCase();
  const matchedPatterns = [];
  let totalScore = 0;

  // Phase 1: Check for phrase patterns (higher priority)
  let phraseMatches = 0;
  if (phrases && phrases.length > 0) {
    phrases.forEach((phrase) => {
      if (phrase.length > 3) {
        // Direct phrase matching
        if (descriptionText.includes(phrase)) {
          phraseMatches++;
          matchedPatterns.push(phrase);
          totalScore += 3;
        } else {
          // Partial phrase matching - MAKE THIS MORE STRICT
          const phraseWords = phrase.split(' ').filter((word) => word.length > 2);
          const matchingWordsInPhrase = phraseWords.filter((word) => descriptionText.includes(word));

          // Change from 60% to 80% word match requirement
          if (matchingWordsInPhrase.length >= Math.ceil(phraseWords.length * 0.5)) {
            phraseMatches += 0.5;
            matchedPatterns.push(`${phrase} (partial)`);
            totalScore += 1.5;
          }
        }
      }
    });
  }

  // Phase 2: Minimal keyword validation (only for critical dress-specific terms)
  let keywordMatches = 0;
  const criticalKeywords = ['saree', 'lehenga', 'kurta', 'salwar', 'anarkali', 'dress', 'wear', 'fabric', 'silk', 'cotton'];
  if (keywords && keywords.length > 0) {
    keywords.forEach((keyword) => {
      if (criticalKeywords.includes(keyword.toLowerCase())) {
        if (descriptionText.includes(keyword)) {
          keywordMatches++;
          totalScore += 1;
        }
      }
    });
  }

  // Phase 3: Check for semantic dress type matching
  const dressTypes = ['saree', 'lehenga', 'salwar', 'kurta', 'kurti', 'churidar', 'anarkali', 'sharara', 'palazzo', 'dupatta'];
  const fabricTypes = ['silk', 'cotton', 'georgette', 'chiffon', 'net', 'velvet', 'satin', 'crepe'];
  const designTypes = ['embroidered', 'printed', 'plain', 'border', 'floral', 'geometric', 'traditional'];

  let semanticMatches = 0;

  // Check if there's a meaningful combination of dress type + fabric/design
  const foundDressTypes = dressTypes.filter((type) => descriptionText.includes(type));
  const foundFabrics = fabricTypes.filter((fabric) => descriptionText.includes(fabric));
  const foundDesigns = designTypes.filter((design) => descriptionText.includes(design));

  if (foundDressTypes.length > 0 && (foundFabrics.length > 0 || foundDesigns.length > 0)) {
    semanticMatches = foundDressTypes.length;
    totalScore += semanticMatches * 2; // Bonus for meaningful combinations
    matchedPatterns.push(`${foundDressTypes.join(', ')} with ${[...foundFabrics, ...foundDesigns].join(', ')}`);
  }

  // Calculate match score and determine if it's a valid match
  const totalPossibleScore = (phrases?.length || 0) * 3 + criticalKeywords.length * 1 + 6; // Increased semantic weight
  const matchScore = totalPossibleScore > 0 ? (totalScore / totalPossibleScore) * 100 : 0;

  const isStrongMatch =
    phraseMatches >= 2 ||
    (phraseMatches >= 1.5 && semanticMatches >= 2) ||
    semanticMatches >= 3 ||
    matchScore >= 10;

  console.log('=== PATTERN MATCHING ANALYSIS ===');
  console.log('Description:', descriptionText.substring(0, 100) + '...');
  console.log('Phrase matches:', phraseMatches);
  console.log('Keyword matches:', keywordMatches);
  console.log('Semantic matches:', semanticMatches);
  console.log('Total score:', totalScore);
  console.log('Match percentage:', matchScore.toFixed(1) + '%');
  console.log('Is strong match:', isStrongMatch);
  console.log('Matched patterns:', matchedPatterns);
  console.log('=====================================');

  return {
    isMatch: isStrongMatch,
    matchScore: matchScore,
    matchedPatterns: matchedPatterns,
    phraseMatches: phraseMatches,
    keywordMatches: keywordMatches,
    semanticMatches: semanticMatches,
  };
};

app.post('/api/find-nearby-shops', async (req, res) => {
  console.log('API endpoint hit with:', req.body);
  const { location, selectedStyleImages, detectedGender } = req.body;

  try {
    // Validate input
    if (!location || (!location.pincode && (!location.lat || !location.lng))) {
      return res.status(400).json({ success: false, shops: [], message: 'Invalid location input.' });
    }

    // Validate selected styles
    if (!selectedStyleImages || selectedStyleImages.length === 0) {
      return res.status(400).json({
        success: false,
        shops: [],
        message: 'Please select at least one style to find matching shops.',
      });
    }

    let userLat, userLng;

    // Case 1: Search by Pincode
    if (location.pincode) {
      // First, get shops in the specified pincode to find center coordinates
      const pincodeQuery = `
        SELECT shop_longitude, shop_latitude
        FROM clothing_adminportal.t_shop_owner 
        WHERE shop_zipcode = $1 
        AND shop_longitude IS NOT NULL 
        AND shop_latitude IS NOT NULL
      `;
      const pincodeResult = await pool.query(pincodeQuery, [location.pincode]);

      if (pincodeResult.rows.length === 0) {
        return res.json({ success: true, shops: [], message: 'No shops found in this pincode area' });
      }

      // Calculate center point of the pincode area
      const validCoords = pincodeResult.rows.filter(
        (shop) => !isNaN(parseFloat(shop.shop_latitude)) && !isNaN(parseFloat(shop.shop_longitude))
      );

      const centerLat = validCoords.reduce((sum, shop) => sum + parseFloat(shop.shop_latitude), 0) / validCoords.length;
      const centerLng = validCoords.reduce((sum, shop) => sum + parseFloat(shop.shop_longitude), 0) / validCoords.length;

      // Enhanced query to include product descriptions
      const allShopsQuery = `
        SELECT DISTINCT so.shop_longitude, so.shop_latitude, so.shop_area, so.shop_state, 
               so.shop_address, so.shop_zipcode, so.owner_phone, so.owner_email, 
               so.owner_name, so.shop_name, so.shop_owner_id,
               array_agg(DISTINCT mpd.product_description) as product_descriptions
        FROM clothing_adminportal.t_shop_owner so
        LEFT JOIN clothing_adminportal.t_master_product_details mpd ON so.shop_owner_id = mpd.shop_owner_id
        WHERE so.shop_longitude IS NOT NULL AND so.shop_latitude IS NOT NULL
        GROUP BY so.shop_owner_id, so.shop_longitude, so.shop_latitude, so.shop_area, 
                 so.shop_state, so.shop_address, so.shop_zipcode, so.owner_phone, 
                 so.owner_email, so.owner_name, so.shop_name
      `;

      const allShopsResult = await pool.query(allShopsQuery);

      // Generate keywords from selected style images
      console.log('Generating keywords from selected style images...');
      const styleKeywords = await generateKeywordsFromImages(selectedStyleImages);
      console.log('Generated keywords:', styleKeywords);

      // Process shops with style matching
      const shopsWithDistance = [];

      for (const shop of allShopsResult.rows) {
        const shopLat = parseFloat(shop.shop_latitude);
        const shopLng = parseFloat(shop.shop_longitude);

        // Validate coordinates
        if (
          isNaN(shopLat) ||
          isNaN(shopLng) ||
          shopLat < -90 ||
          shopLat > 90 ||
          shopLng < -180 ||
          shopLng > 180
        ) {
          console.log(`Invalid coordinates for shop ${shop.shop_name}`);
          continue;
        }

        const distance = calculateDistance(shop.shop_latitude, shop.shop_longitude, centerLat, centerLng);
        if (distance > 10) continue; // Skip if beyond 10km radius

        const productDescriptions = shop.product_descriptions || [];
        const matchingImages = [];

        const hasStyleMatch = checkDescriptionMatch(shop.product_descriptions, styleKeywords);
        const isGenderMatch = isGenderAppropriate(shop.product_descriptions, detectedGender);

        console.log('=== COMPARISON FOR SHOP:', shop.shop_name, '===');
        console.log('Selected Image Keywords:', styleKeywords);
        console.log('Shop Product Descriptions:', shop.product_descriptions);
        console.log('Match Result:', hasStyleMatch);
        console.log('---');

        if (hasStyleMatch.isMatch && isGenderMatch) {
          // Check if this shop already exists in our array
          const existingShopIndex = shopsWithDistance.findIndex(
            (existingShop) =>
              existingShop.name === shop.shop_name &&
              existingShop.owner === shop.owner_name &&
              existingShop.phone === shop.owner_phone
          );

          if (existingShopIndex >= 0) {
            // Shop already exists, just add matching images
            shopsWithDistance[existingShopIndex].matchingImages = [
              ...new Set([...shopsWithDistance[existingShopIndex].matchingImages, ...matchingImages]),
            ];
          } else {
            // New shop, add it
            shopsWithDistance.push({
              id: `shop_${shop.shop_owner_id || Date.now()}_${Math.random()}`,
              name: shop.shop_name,
              address: `${shop.shop_address}, ${shop.shop_area}, ${shop.shop_state}`,
              owner: shop.owner_name,
              phone: shop.owner_phone,
              email: shop.owner_email,
              latitude: shopLat,
              longitude: shopLng,
              rating: (4.0 + Math.random()).toFixed(1),
              distance: `${distance.toFixed(1)} km`,
              distanceValue: distance,
              zipcode: shop.shop_zipcode,
              matchingImages: matchingImages,
              hasStyleMatch: true,
            });
          }
        }
      }

      // Remove duplicates
      const uniqueShops = [];
      const seenShops = new Set();

      for (const shop of shopsWithDistance) {
        const shopKey = `${shop.name}_${shop.owner}_${shop.phone}`;
        if (!seenShops.has(shopKey)) {
          seenShops.add(shopKey);
          uniqueShops.push(shop);
        }
      }

      const sortedShops = uniqueShops.sort((a, b) => a.distanceValue - b.distanceValue).slice(0, 10);

      // Check if any matches found
      if (sortedShops.length === 0) {
        return res.json({
          success: true,
          shops: [],
          message: 'No shops found with matching styles in your area. Please select different styles or try a different location.',
        });
      }

      return res.json({
        success: true,
        shops: sortedShops,
        message: `Found ${sortedShops.length} shop(s) with matching styles within 10km radius.`,
      });
    }

    // Case 2: Search by Coordinates
    if (location.lat && location.lng) {
      userLat = parseFloat(location.lat);
      userLng = parseFloat(location.lng);

      // Enhanced query to include product descriptions
      const query = `
        SELECT DISTINCT so.shop_longitude, so.shop_latitude, so.shop_area, so.shop_state, 
               so.shop_address, so.shop_zipcode, so.owner_phone, so.owner_email, 
               so.owner_name, so.shop_name, so.shop_owner_id,
               array_agg(DISTINCT mpd.product_description) as product_descriptions
        FROM clothing_adminportal.t_shop_owner so
        LEFT JOIN clothing_adminportal.t_master_product_details mpd ON so.shop_owner_id = mpd.shop_owner_id
        WHERE so.shop_longitude IS NOT NULL 
        AND so.shop_latitude IS NOT NULL 
        AND so.shop_longitude != '' 
        AND so.shop_latitude != ''
        AND so.shop_longitude::text ~ '^-?[0-9]+\.?[0-9]*$'
        AND so.shop_latitude::text ~ '^-?[0-9]+\.?[0-9]*$'
        GROUP BY so.shop_owner_id, so.shop_longitude, so.shop_latitude, so.shop_area, 
                 so.shop_state, so.shop_address, so.shop_zipcode, so.owner_phone, 
                 so.owner_email, so.owner_name, so.shop_name
      `;

      const result = await pool.query(query);

      // Generate keywords from selected style images
      console.log('Generating keywords from selected style images...');
      const styleKeywords = await generateKeywordsFromImages(selectedStyleImages);
      console.log('Generated keywords:', styleKeywords);

      // Process shops with style matching
      const shopsWithDistance = [];

      for (const shop of result.rows) {
        const shopLat = parseFloat(shop.shop_latitude);
        const shopLng = parseFloat(shop.shop_longitude);

        // Skip shops with invalid coordinates
        if (isNaN(shopLat) || isNaN(shopLng)) {
          continue;
        }

        const distance = calculateDistance(shop.shop_latitude, shop.shop_longitude, userLat, userLng);
        if (distance > 10) continue; // Skip if beyond 10km radius

        const productDescriptions = shop.product_descriptions || [];
        const matchingImages = [];

        const hasStyleMatch = checkDescriptionMatch(shop.product_descriptions, styleKeywords);
        const isGenderMatch = isGenderAppropriate(shop.product_descriptions, detectedGender);

        console.log('=== COMPARISON FOR SHOP:', shop.shop_name, '===');
        console.log('Selected Image Keywords:', styleKeywords);
        console.log('Shop Product Descriptions:', shop.product_descriptions);
        console.log('Match Result:', hasStyleMatch);
        console.log('---');

        if (hasStyleMatch.isMatch && isGenderMatch) {
          // Check if this shop already exists in our array
          const existingShopIndex = shopsWithDistance.findIndex(
            (existingShop) =>
              existingShop.name === shop.shop_name &&
              existingShop.owner === shop.owner_name &&
              existingShop.phone === shop.owner_phone
          );

          if (existingShopIndex >= 0) {
            // Shop already exists, just add matching images
            shopsWithDistance[existingShopIndex].matchingImages = [
              ...new Set([...shopsWithDistance[existingShopIndex].matchingImages, ...matchingImages]),
            ];
          } else {
            // New shop, add it
            shopsWithDistance.push({
              id: `shop_${shop.shop_owner_id || Date.now()}_${Math.random()}`,
              name: shop.shop_name,
              address: `${shop.shop_address}, ${shop.shop_area}, ${shop.shop_state}`,
              owner: shop.owner_name,
              phone: shop.owner_phone,
              email: shop.owner_email,
              latitude: shopLat,
              longitude: shopLng,
              rating: (4.0 + Math.random()).toFixed(1),
              distance: `${distance.toFixed(1)} km`,
              distanceValue: distance,
              zipcode: shop.shop_zipcode,
              matchingImages: matchingImages,
              hasStyleMatch: true,
            });
          }
        }
      }

      // Remove duplicates
      const uniqueShops = [];
      const seenShops = new Set();

      for (const shop of shopsWithDistance) {
        const shopKey = `${shop.name}_${shop.address}`;
        if (!seenShops.has(shopKey)) {
          seenShops.add(shopKey);
          uniqueShops.push(shop);
        }
      }

      // Sort by distance and limit results
      const sortedShops = uniqueShops.sort((a, b) => a.distanceValue - b.distanceValue).slice(0, 10);

      // Check if any matches found
      if (sortedShops.length === 0) {
        return res.json({
          success: true,
          shops: [],
          message: 'No shops found with matching styles in your area. Please select different styles or try a different location.',
        });
      }

      return res.json({
        success: true,
        shops: sortedShops,
        message: `Found ${sortedShops.length} shop(s) with matching styles within 10km radius.`,
      });
    }
  } catch (error) {
    console.error('Find shops with style matching error:', error);
    res.status(500).json({
      success: false,
      shops: [],
      message: 'Error finding shops with matching styles. Please try again.',
    });
  }
});

// find shops related endpoints end 

// submit feedback related endpoint
app.post('/api/submit-feedback', async (req, res) => {
  const { cust_id, testimonial_text, customer_ratings } = req.body;
  console.log('Received feedback:', { cust_id, testimonial_text, customer_ratings }); // Debug log
  
  try {
    // Validate required fields
    if (!cust_id || !testimonial_text || !customer_ratings) {
      return res.status(400).json({
        success: false,
        message: 'Customer ID, feedback text, and rating are required'
      });
    }

    // Validate rating range
    if (customer_ratings < 1 || customer_ratings > 5) {
      return res.status(400).json({
        success: false,
        message: 'Rating must be between 1 and 5'
      });
    }

    // Check if customer exists
    const customerCheck = await pool.query(
      'SELECT cust_id FROM smartstyley_dashboard.t_customer_details WHERE cust_id = $1',
      [cust_id]
    );

    if (customerCheck.rows.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Customer not found'
      });
    }

    // Check if feedback already exists for this customer
    const existingFeedback = await pool.query(
      'SELECT testimonial_id FROM smartstyley_dashboard.t_customer_testimonials WHERE cust_id = $1',
      [cust_id]
    );

    let result;

    if (existingFeedback.rows.length > 0) {
      // Update existing feedback
      const updateQuery = `
        UPDATE smartstyley_dashboard.t_customer_testimonials 
        SET testimonial_text = $2, customer_ratings = $3, created_at = CURRENT_TIMESTAMP
        WHERE cust_id = $1
        RETURNING *
      `;
      result = await pool.query(updateQuery, [cust_id, testimonial_text, customer_ratings]);
      console.log('Feedback updated:', result.rows[0]); // Debug log
    } else {
      // Insert new feedback
      const insertQuery = `
        INSERT INTO smartstyley_dashboard.t_customer_testimonials 
        (cust_id, testimonial_text, customer_ratings)
        VALUES ($1, $2, $3)
        RETURNING *
      `;
      result = await pool.query(insertQuery, [cust_id, testimonial_text, customer_ratings]);
      console.log('Feedback inserted:', result.rows[0]); // Debug log
    }

    res.status(200).json({
      success: true,
      message: 'Feedback submitted successfully!',
      testimonial: result.rows[0]
    });
  } catch (error) {
    console.error('Feedback submission error:', error);
    res.status(500).json({
      success: false,
      message: 'Error submitting feedback. Please try again.'
    });
  }
});

app.post('/api/submit-feedback-form', async (req, res) => {
  const { cust_id, feedbackType, occasion, rating, styleAccuracy, comments, email } = req.body;
  console.log('Received feedback form:', req.body);
  
  try {
    // Validate required fields
    if (!feedbackType || !rating || !comments) {
      return res.status(400).json({
        success: false,
        message: 'Feedback type, rating, and comments are required'
      });
    }

    // Validate rating range
    if (rating < 1 || rating > 5) {
      return res.status(400).json({
        success: false,
        message: 'Rating must be between 1 and 5'
      });
    }

    // Validate style accuracy if provided
    if (styleAccuracy && (styleAccuracy < 1 || styleAccuracy > 5)) {
      return res.status(400).json({
        success: false,
        message: 'Style accuracy rating must be between 1 and 5'
      });
    }

    const insertQuery = `
        INSERT INTO smartstyley_dashboard.t_customer_Feedback 
        (feedback_type, occasion, rating, style_accuracy, comments, email)
        VALUES ($1, $2, $3, $4, $5, $6)
        RETURNING *
    `;
    
    // Prepare feedback text with additional details
    let feedbackText = comments;
    if (occasion) {
      feedbackText += `\n\nOccasion: ${occasion}`;
    }
    if (styleAccuracy) {
      feedbackText += `\nStyle Accuracy Rating: ${styleAccuracy}/5`;
    }

    const result = await pool.query(insertQuery, [
        feedbackType,
        occasion || null,
        rating,
        styleAccuracy || null,
        comments,
        email || null
    ]);
    
    console.log('Feedback form submitted:', result.rows[0]);

    res.status(200).json({
      success: true,
      message: 'Feedback submitted successfully!',
      feedback: result.rows[0]
    });
  } catch (error) {
    console.error('Feedback form submission error:', error);
    res.status(500).json({
      success: false,
      message: 'Error submitting feedback. Please try again.'
    });
  }
});
// submit feedback related endpoint 

// Admin portal related endpoint 
app.post('/api/registration', async (req, res) => {
  const { user_name, user_email, password, phone_no, user_role = "user" } = req.body;

  try {
    // Validate required fields
    if (!user_name || !user_email || !password || !phone_no) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields: name, email, password, and phone number',
      });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(user_email)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid email format',
      });
    }

    // Validate phone number (must be numeric and 10 digits)
    if (!/^\d{10}$/.test(phone_no)) {
      return res.status(400).json({
        success: false,
        message: 'Phone number must be 10 digits',
      });
    }

    // Check if email already exists
    const existing = await pool.query(
      'SELECT * FROM clothing_adminportal.t_users WHERE user_email = $1',
      [user_email.toLowerCase()]
    );
    if (existing.rows.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Email already registered',
      });
    }

    const maxResult = await pool.query(`
        SELECT MAX(CAST(SUBSTRING(superadmin_id, 8) AS INTEGER)) AS max_id
        FROM clothing_adminportal.t_users
        WHERE superadmin_id ~ '^S_Cust[0-9]+'
    `);
    const nextId = (maxResult.rows[0].max_id || 0) + 1;
    const superadmin_id = `S_Cust${nextId.toString().padStart(3, '0')}`;

    // Insert user into database
    const result = await pool.query(
      `INSERT INTO clothing_adminportal.t_users 
      (superadmin_id, user_name, user_email, phone_no, password, user_role) 
      VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [superadmin_id, user_name, user_email.toLowerCase(), phone_no, password, user_role]
    );

    const newUser = result.rows[0];

    // Send welcome email with credentials
    const loginLink = process.env.LOGIN_LINK || 'http://localhost:3029/login';

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: user_email,
      subject: 'Welcome to AI4Clothing - Your Account Details',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background-color: #0E2148; color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0;">
            <h2 style="margin: 0;">Welcome to AI4Clothing!</h2>
          </div>
          
          <div style="background-color: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
            <p style="font-size: 16px; color: #333;">Hello <strong>${user_name}</strong>,</p>
            <p style="font-size: 16px; color: #333;">Your account has been created successfully! Here are your login details:</p>
            
            <div style="background-color: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #0E2148;">
              <p style="margin: 10px 0; color: #333;"><strong>User ID:</strong> ${superadmin_id}</p>
              <p style="margin: 10px 0; color: #333;"><strong>Username:</strong> ${user_name}</p>
              <p style="margin: 10px 0; color: #333;"><strong>Email:</strong> ${user_email}</p>
              <p style="margin: 10px 0; color: #333;"><strong>Password:</strong> ${password}</p>
              <p style="margin: 10px 0; color: #333;"><strong>Role:</strong> ${user_role}</p>
            </div>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="${loginLink}" style="background-color: #0E2148; color: white; padding: 12px 30px; text-decoration: none; border-radius: 25px; font-weight: bold; display: inline-block;">
                Login to Your Account
              </a>
            </div>
            
            <p style="font-size: 14px; color: #666; margin-top: 30px;">
              Please keep this information secure and do not share your credentials with anyone.
            </p>
            
            <p style="font-size: 14px; color: #666;">
              If you have any questions, please contact our support team.
            </p>
            
            <p style="font-size: 16px; color: #333; margin-top: 20px;">
              Thank you for joining AI4Clothing!
            </p>
          </div>
        </div>
      `,
    };

    try {
      await transporter.sendMail(mailOptions);
      console.log('Welcome email sent successfully to:', user_email);
    } catch (emailError) {
      console.error('Email sending failed:', emailError);
      // Continue with success response even if email fails
    }

    // Send success response
    res.status(201).json({
      success: true,
      message: 'Registration successful. Please check your email for login details.',
      customer: {
        superadmin_id: newUser.superadmin_id,
        customer_name: newUser.customer_name,
        customer_email: newUser.customer_email,
        phone_no: newUser.phone_no,
        user_role: newUser.user_role,
      },
    });
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({
      success: false,
      message: 'Error registering. Please try again.',
    });
  }
});
// Admin portal related endpoint 

// Start server
app.listen(PORT, "0.0.0.0", () => {
  console.log(`✅ Server is running on http://0.0.0.0:${PORT}`);
});

module.exports = app;
module.exports.pool = pool;
module.exports.pendingSignups = pendingSignups;
module.exports.forgotPasswordOTPs = forgotPasswordOTPs;