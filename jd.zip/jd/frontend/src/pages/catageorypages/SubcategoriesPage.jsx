
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import JustDialNavbar from '../../components/Navbar';
import Footer from '../../components/Footer';
import api from '../../config'; // Import the centralized API config

const SubcategoriesPage = () => {
  const { category } = useParams();
  const navigate = useNavigate();
  const [subcategories, setSubcategories] = useState([]);
  const [bannerImage, setBannerImage] = useState('https://picsum.photos/1200/400?random=0');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchSubcategories = async () => {
      try {
        setLoading(true);
        console.log('[SubcategoriesPage] Fetching category:', category);
        const categoryResponse = await api.get(`/categories?name=${encodeURIComponent(category)}`);
        if (!categoryResponse.data || categoryResponse.data.length === 0) {
          throw new Error('Category not found in the database.');
        }
        const { category_id: categoryId, image_url: categoryBanner } = categoryResponse.data[0];

        // Set the category's image_url as the banner
        setBannerImage(categoryBanner || 'https://picsum.photos/1200/400?random=0');

        console.log('[SubcategoriesPage] Fetching subcategories for categoryId:', categoryId);
        const subcategoriesResponse = await api.get(`/subcategories/${categoryId}`);

        if (subcategoriesResponse.data.length === 0) {
          setSubcategories([]);
          setError('No subcategories found for this category.');
        } else {
          const transformedSubcategories = subcategoriesResponse.data.map((sub) => ({
            id: sub.category_id,
            label: sub.category_name,
            description: sub.description || 'No description available',
            icon: sub.icon_url || `https://picsum.photos/48/48?random=${sub.category_id}`,
            path: sub.category_name.toLowerCase().replace(/\s+/g, '-'),
          }));
          setSubcategories(transformedSubcategories);
        }
        setLoading(false);
      } catch (err) {
        console.error('[SubcategoriesPage] Error:', {
          message: err.message,
          response: err.response?.data,
          status: err.response?.status,
        });
        setError(err.message || 'Failed to fetch subcategories. Please try again later.');
        setLoading(false);
      }
    };

    fetchSubcategories();
  }, [category]);

  const handleNavigate = (subPath) => {
    navigate(`/categories/${category}/${subPath}`);
  };

  return (
    <>
      <JustDialNavbar />
      <div className="w-full">
        {/* Category Banner */}
        <img
          src={bannerImage}
          alt={`${category} banner`}
          className="w-full h-48 sm:h-64 md:h-180 object-cover rounded-b-lg shadow"
          loading="lazy"
          onError={(e) => {
            e.target.src = 'https://picsum.photos/1200/400?random=0';
          }}
        />
        <div className="text-center py-4 bg-gray-100">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold capitalize">
            {category.replace('-', ' ')} Subcategories
          </h1>
        </div>

        {loading && (
          <div className="text-center py-8 text-gray-600">Loading subcategories...</div>
        )}
        {error && <div className="text-center py-8 text-red-500">{error}</div>}

        {!loading && !error && subcategories.length === 0 && (
          <div className="text-center py-8 text-gray-600">
            No subcategories available for this category.
          </div>
        )}

        {!loading && !error && subcategories.length > 0 && (
          <div className="max-w-7xl mx-auto px-4 py-8">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
              {subcategories.map((sub) => (
                <button
                  key={sub.id}
                  onClick={() => handleNavigate(sub.path)}
                  className="flex flex-col items-center text-center gap-2 p-4 rounded-lg shadow-md hover:shadow-lg hover:bg-gray-50 transition duration-200 bg-white"
                >
                  <img
                    src={sub.icon}
                    alt={sub.label}
                    className="w-12 h-12 sm:w-14 sm:h-14 rounded-full border p-1"
                    loading="lazy"
                    onError={(e) => {
                      e.target.src = 'https://picsum.photos/48/48?random=0';
                    }}
                  />
                  <span className="font-semibold text-base sm:text-lg">{sub.label}</span>
                  <p className="text-xs sm:text-sm text-gray-500 line-clamp-2">{sub.description}</p>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
      <Footer />
    </>
  );
};

export default SubcategoriesPage;
