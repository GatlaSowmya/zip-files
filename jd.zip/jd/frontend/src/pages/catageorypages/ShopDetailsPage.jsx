import React, { useState, useEffect } from "react";
import { useParams, useLocation, Link, useNavigate } from "react-router-dom";
import JustDialNavbar from "../../components/Navbar";
import Footer from "../../components/Footer";
import api from "../../config";
import { useUser } from "../../components/Login/UserContext";
import { toast } from "react-toastify";

const ShopDetailsPage = () => {
  const { category, subcategory, shopId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { userId, userName, logout } = useUser();
  const [shop, setShop] = useState(
    location.state?.shop || JSON.parse(localStorage.getItem(`shop_${shopId}`)) || null
  );
  const [services, setServices] = useState([]);
  const [images, setImages] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(!shop);
  const [servicesLoading, setServicesLoading] = useState(true);
  const [imagesLoading, setImagesLoading] = useState(true);
  const [reviewsLoading, setReviewsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [servicesError, setServicesError] = useState(null);
  const [imagesError, setImagesError] = useState(null);
  const [reviewsError, setReviewsError] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [showFullDescription, setShowFullDescription] = useState(false);
  const [showAllServices, setShowAllServices] = useState(false);
  const [currentImageModal, setCurrentImageModal] = useState(false);
  const [enquiryForm, setEnquiryForm] = useState({
    name: "",
    phone: "",
    email: "",
    message: "",
  });
  const [showEnquiryForm, setShowEnquiryForm] = useState(false);
  const [showFullServiceDescription, setShowFullServiceDescription] = useState({});
  const [reviewForm, setReviewForm] = useState({
    rating: 0,
    comment: "",
  });
  const [showReviewForm, setShowReviewForm] = useState(false);
  const selectedLocation = localStorage.getItem("selectedLocation") || "Kukatpally";

  const fallbackImage = "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg";

  const mockShopData = {
    id: shopId,
    name: "Elite Salon",
    category: category?.replace("-", " ") || "Beauty",
    subcategory: subcategory?.replace("-", " ") || "Hair Salon",
    rating: "4.5",
    totalRatings: 418,
    address: `${selectedLocation}, Hyderabad`,
    phone: "9948987278",
    email: "contact@elitesalon.com",
    website: "www.elitesalon.com",
    description:
      "Elite Salon is a premier beauty salon offering professional hair styling, makeup, skincare, and nail care services.",
    established: "2018",
    closing_time: "21:00",
    videos: [
      "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4",
    ],
    features: [
      "Air Conditioned",
      "Credit Card Accepted",
      "Parking Available",
      "Wheelchair Accessible",
      "WiFi Available",
      "Online Booking",
      "Home Service Available",
      "Experienced Staff",
    ],
    nearbyLandmarks: [
      "Kukatpally Metro Station - 500m",
      "KPHB Colony - 1.2km",
      "Kukatpally Housing Board - 800m",
      "Balanagar - 2km",
      "Moosapet - 1.5km",
    ],
    certifications: [
      "Government Registered",
      "ISO Certified",
      "Skilled Staff Certified",
      "Health & Safety Compliant",
    ],
  };

  useEffect(() => {
    console.log(`[ShopDetailsPage] Processing shopId: ${shopId}`);

    if (!shop) {
      const fetchShopDetails = async () => {
        try {
          setLoading(true);
          const response = await api.get(`/shops/shop/${shopId}`);
          const shopData = {
            ...response.data,
            id: shopId,
            name: response.data.shop_name || "Unnamed Shop",
            category: category?.replace("-", " ") || "Beauty",
            subcategory: subcategory?.replace("-", " ") || "Hair Salon",
            address: response.data.address || `${selectedLocation}, Hyderabad`,
            phone: response.data.phone || "9948987278",
            email: response.data.email || "contact@elitesalon.com",
            website: response.data.website || "www.elitesalon.com",
            description: response.data.description || mockShopData.description,
            established: response.data.created_at
              ? new Date(response.data.created_at).getFullYear().toString()
              : "2018",
            closing_time: response.data.closing_time || "21:00",
            rating: response.data.rating?.toString() || "4.5",
            totalRatings: response.data.review_count || 418,
            verified: response.data.is_approved || false,
          };
          setShop(shopData);
          localStorage.setItem(`shop_${shopId}`, JSON.stringify(shopData));
          setError(null);
        } catch (err) {
          console.error(`[ShopDetailsPage] Error fetching shop details:`, err.response?.data || err.message);
          setShop(mockShopData);
          setError(
            err.response?.status === 404
              ? "This shop could not be found. Showing sample data instead."
              : "Unable to load shop details at this time. Showing sample data instead."
          );
        } finally {
          setLoading(false);
        }
      };
      fetchShopDetails();
    } else {
      localStorage.setItem(`shop_${shopId}`, JSON.stringify(shop));
      setLoading(false);
      setError(null);
    }
  }, [shopId, shop, category, subcategory]);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        setServicesLoading(true);
        const response = await api.get(`/shops/shop/${shopId}/services`);
        setServices(response.data);
        setServicesError(null);
        setShowFullServiceDescription(
          response.data.reduce((acc, service) => ({
            ...acc,
            [service.service_id || service.name]: false,
          }), {})
        );
      } catch (err) {
        console.error(`[ShopDetailsPage] Error fetching services:`, err.response?.data || err.message);
        setServices([]);
        setServicesError(
          err.response?.status === 404
            ? "No services found for this shop."
            : "Unable to load services at this time. Please try again later."
        );
      } finally {
        setServicesLoading(false);
      }
    };
    fetchServices();
  }, [shopId]);

  useEffect(() => {
    const fetchImages = async () => {
      try {
        setImagesLoading(true);
        const response = await api.get(`/shops/shop/${shopId}/images`);
        setImages(response.data.map((img) => img.image_url));
        setImagesError(null);
      } catch (err) {
        console.error(`[ShopDetailsPage] Error fetching images:`, err.response?.data || err.message);
        setImages([]);
        setImagesError(
          err.response?.status === 404
            ? "No images found for this shop."
            : "Unable to load images at this time."
        );
      } finally {
        setImagesLoading(false);
      }
    };
    fetchImages();
  }, [shopId]);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        setReviewsLoading(true);
        const response = await api.get(`/shops/shop/${shopId}/reviews`);
        setReviews(response.data);
        setReviewsError(null);
      } catch (err) {
        console.error(`[ShopDetailsPage] Error fetching reviews:`, err.response?.data || err.message);
        setReviews([]);
        setReviewsError(
          err.response?.status === 404
            ? "No reviews found for this shop."
            : "Unable to load reviews at this time."
        );
      } finally {
        setReviewsLoading(false);
      }
    };
    fetchReviews();
  }, [shopId]);

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    console.log('[handleReviewSubmit] Submitting review with:', { userId });
    if (!userId) {
      toast.error("Please log in to submit a review");
      navigate("/login");
      return;
    }
    if (!reviewForm.rating || reviewForm.rating < 1 || reviewForm.rating > 5) {
      toast.error("Please select a rating between 1 and 5 stars");
      return;
    }
    if (reviewForm.comment && reviewForm.comment.length > 1000) {
      toast.error("Comment must be 1000 characters or less");
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await api.post(
        `/shops/shop/${shopId}/reviews`,
        {
          rating: reviewForm.rating,
          comment: reviewForm.comment,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setReviews((prev) => [response.data.review, ...prev]);
      setReviewForm({ rating: 0, comment: "" });
      setShowReviewForm(false);
      toast.success("Review submitted successfully");
    } catch (err) {
      console.error('[ShopDetailsPage] Error submitting review:', err.response?.data || err.message);
      if (err.response?.status === 401) {
        toast.error("Session expired. Please log in again.");
        logout();
      } else {
        toast.error(err.response?.data?.error || "Failed to submit review. Please try again.");
      }
    }
  };

  const handleEnquirySubmit = (e) => {
    e.preventDefault();
    console.log("[ShopDetailsPage] Enquiry submitted:", enquiryForm);
    toast.success("Thank you for your enquiry! We will contact you soon.");
    setEnquiryForm({ name: "", phone: "", email: "", message: "" });
    setShowEnquiryForm(false);
  };

  const handleCall = () => {
    window.open(`tel:${shop?.phone || "9948987278"}`, "_self");
  };

  const handleWhatsApp = () => {
    const phone = (shop?.phone || "9948987278").replace(/\D/g, "");
    const message = encodeURIComponent(
      `Hi, I'm interested in your services at ${shop?.name}. Please provide more details.`
    );
    window.open(`https://wa.me/${phone}?text=${message}`, "_blank");
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: shop?.name,
        text: `Check out ${shop?.name} - ${shop?.description}`,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success("Link copied to clipboard!");
    }
  };

  if (loading) {
    return (
      <>
        <JustDialNavbar />
        <div className="flex justify-center items-center h-64">
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-6 w-6 sm:h-8 sm:w-8 border-b-2 border-blue-600"></div>
            <p className="mt-2 text-gray-600 text-sm sm:text-base">Loading shop details...</p>
          </div>
        </div>
      </>
    );
  }

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <span
        key={i}
        className={`text-base sm:text-lg ${i < Math.floor(parseFloat(rating)) ? "text-yellow-400" : "text-gray-300"}`}
      >
        ★
      </span>
    ));
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "overview":
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg sm:text-xl font-semibold mb-3">About {shop?.name}</h3>
              <div className="text-gray-700 text-sm sm:text-base">
                <p className={`${showFullDescription ? "" : "line-clamp-3"}`}>
                  {shop?.description}
                </p>
                <button
                  onClick={() => setShowFullDescription(!showFullDescription)}
                  className="text-blue-600 hover:underline text-sm mt-2"
                >
                  {showFullDescription ? "Show Less" : "Read More"}
                </button>
              </div>
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-semibold mb-3">Year of Establishment</h3>
              <p className="text-gray-700 text-sm sm:text-base">{shop?.established}</p>
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-semibold mb-3">Professional Achievements</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {mockShopData.certifications.map((cert, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <span className="text-green-600">✓</span>
                    <span className="text-gray-700 text-sm sm:text-base">{cert}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-semibold mb-3">Facilities & Features</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {mockShopData.features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <span className="text-green-600">✓</span>
                    <span className="text-gray-700 text-sm sm:text-base">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-semibold mb-3">Nearby Landmarks</h3>
              <div className="space-y-2">
                {mockShopData.nearbyLandmarks.map((landmark, index) => (
                  <div
                    key={index}
                    className="flex items-center space-x-2 text-sm sm:text-base text-gray-700"
                  >
                    <span>📍</span>
                    <span>{landmark}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      case "catalogue":
        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-lg sm:text-xl font-semibold">Our Services</h3>
              <button
                onClick={() => setShowAllServices(!showAllServices)}
                className="text-blue-600 hover:underline text-sm sm:text-base"
              >
                {showAllServices ? "Show Less" : "View All Services"}
              </button>
            </div>
            {servicesLoading && (
              <div className="text-center py-8">
                <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <p className="mt-2 text-gray-600">Loading services...</p>
              </div>
            )}
            {servicesError && (
              <div className="text-center py-8 text-red-500">
                {servicesError}
              </div>
            )}
            {!servicesLoading && !servicesError && services.length === 0 && (
              <div className="text-center py-8 text-gray-600">
                No services available for this shop.
              </div>
            )}
            {!servicesLoading && services.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                {services
                  .slice(0, showAllServices ? services.length : 6)
                  .map((service, index) => (
                    <div
                      key={service.service_id || index}
                      className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                    >
                      <h4 className="font-semibold text-base sm:text-lg mb-2">{service.name}</h4>
                      <p className="text-blue-600 font-medium mb-1 text-sm sm:text-base">
                        {service.price}
                      </p>
                      <div className="text-gray-600 text-xs sm:text-sm mb-3">
                        <p className={`${showFullServiceDescription[service.service_id || service.name] ? "" : "line-clamp-4"}`}>
                          {service.description}
                        </p>
                        <button
                          onClick={() =>
                            setShowFullServiceDescription((prev) => ({
                              ...prev,
                              [service.service_id || service.name]: !prev[service.service_id || service.name],
                            }))
                          }
                          className="text-blue-600 hover:underline text-xs sm:text-sm mt-1"
                        >
                          {showFullServiceDescription[service.service_id || service.name] ? "See Less" : "See More"}
                        </button>
                      </div>
                      {service.image_url && (
                        <img
                          src={service.image_url}
                          alt={service.name}
                          className="w-full h-32 object-cover rounded-lg mb-3"
                          loading="lazy"
                          onError={(e) => {
                            e.target.src = fallbackImage;
                          }}
                        />
                      )}
                      <button
                        onClick={() => setShowEnquiryForm(true)}
                        className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition-colors text-sm sm:text-base"
                      >
                        Book Now
                      </button>
                    </div>
                  ))}
              </div>
            )}
            {services.length > 6 && !showAllServices && (
              <div className="text-center">
                <button
                  onClick={() => setShowAllServices(true)}
                  className="bg-gray-100 text-gray-700 px-4 sm:px-6 py-2 rounded hover:bg-gray-200 transition-colors text-sm sm:text-base"
                >
                  View All {services.length} Services
                </button>
              </div>
            )}
          </div>
        );
      case "photos":
        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-lg sm:text-xl font-semibold">Gallery</h3>
              <span className="text-gray-600 text-sm sm:text-base">
                {images.length} Photos
              </span>
            </div>
            {imagesLoading && (
              <div className="text-center py-8">
                <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <p className="mt-2 text-gray-600">Loading images...</p>
              </div>
            )}
            {imagesError && (
              <div className="text-center py-8 text-red-500">
                {imagesError}
              </div>
            )}
            {!imagesLoading && !imagesError && images.length === 0 && (
              <div className="text-center py-8 text-gray-600">
                No images available for this shop.
              </div>
            )}
            {!imagesLoading && images.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {images.map((image, index) => (
                  <div
                    key={index}
                    className="cursor-pointer group"
                    onClick={() => {
                      setSelectedImageIndex(index);
                      setCurrentImageModal(true);
                    }}
                  >
                    <img
                      src={image}
                      alt={`Gallery ${index + 1}`}
                      className="w-full h-24 sm:h-32 lg:h-40 object-cover rounded-lg group-hover:opacity-80 transition-opacity"
                      onError={(e) => {
                        e.target.src = fallbackImage;
                      }}
                    />
                  </div>
                ))}
              </div>
            )}
            {currentImageModal && images.length > 0 && (
              <div
                className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50"
                onClick={() => setCurrentImageModal(false)}
              >
                <div className="relative max-w-full sm:max-w-4xl max-h-[80vh] p-4">
                  <img
                    src={images[selectedImageIndex]}
                    alt={`Gallery ${selectedImageIndex + 1}`}
                    className="max-w-full max-h-[80vh] object-contain"
                    onError={(e) => {
                      e.target.src = fallbackImage;
                    }}
                  />
                  <button
                    onClick={() => setCurrentImageModal(false)}
                    className="absolute top-2 right-2 text-white text-xl sm:text-2xl hover:text-gray-300"
                  >
                    ×
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedImageIndex((prev) =>
                        prev > 0 ? prev - 1 : images.length - 1
                      );
                    }}
                    className="absolute left-2 top-1/2 transform -translate-y-1/2 text-white text-xl sm:text-2xl hover:text-gray-300"
                  >
                    ‹
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedImageIndex((prev) =>
                        prev < images.length - 1 ? prev + 1 : 0
                      );
                    }}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white text-xl sm:text-2xl hover:text-gray-300"
                  >
                    ›
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      case "reviews":
        return (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-green-50 to-blue-50 p-4 sm:p-6 rounded-lg">
              <div className="flex items-center space-x-4 mb-4">
                <div className="bg-green-600 text-white px-3 sm:px-4 py-2 rounded-lg font-bold text-lg sm:text-2xl">
                  {shop?.rating || "4.5"}
                </div>
                <div>
                  <div className="flex items-center space-x-1 mb-1">
                    {renderStars(shop?.rating || "4.5")}
                  </div>
                  <p className="font-semibold text-sm sm:text-base">
                    {shop?.totalRatings || "418"} Reviews
                  </p>
                  <p className="text-gray-600 text-xs sm:text-sm">Based on customer experiences</p>
                </div>
              </div>
              <div className="mt-4">
                <h4 className="font-semibold text-sm sm:text-base mb-2">Rate this business</h4>
                <div className="flex space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() =>
                        setReviewForm((prev) => ({ ...prev, rating: star }))
                      }
                      className={`text-lg sm:text-2xl ${
                        star <= reviewForm.rating ? "text-yellow-400" : "text-gray-300"
                      } hover:text-yellow-400 transition-colors`}
                    >
                      ★
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setShowReviewForm(true)}
                  className="mt-2 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors text-sm sm:text-base"
                >
                  Write a Review
                </button>
              </div>
            </div>
            {showReviewForm && (
              <div className="bg-white p-4 sm:p-6 rounded-lg shadow-sm mb-6">
                <h4 className="font-semibold text-lg mb-4">Write Your Review</h4>
                <form onSubmit={handleReviewSubmit}>
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Your Rating
                    </label>
                    <div className="flex space-x-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          type="button"
                          key={star}
                          onClick={() =>
                            setReviewForm((prev) => ({ ...prev, rating: star }))
                          }
                          className={`text-lg sm:text-2xl ${
                            star <= reviewForm.rating ? "text-yellow-400" : "text-gray-300"
                          } hover:text-yellow-400 transition-colors`}
                        >
                          ★
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Your Review
                    </label>
                    <textarea
                      rows={4}
                      value={reviewForm.comment}
                      onChange={(e) =>
                        setReviewForm((prev) => ({ ...prev, comment: e.target.value }))
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
                      placeholder="Share your experience..."
                    />
                  </div>
                  <div className="flex space-x-3">
                    <button
                      type="button"
                      onClick={() => setShowReviewForm(false)}
                      className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 text-sm sm:text-base"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm sm:text-base"
                    >
                      Submit Review
                    </button>
                  </div>
                </form>
              </div>
            )}
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h4 className="font-semibold text-sm sm:text-base">Customer Reviews</h4>
                <div className="flex flex-wrap gap-2 sm:gap-4 text-xs sm:text-sm">
                  <button className="px-3 py-1 bg-blue-600 text-white rounded">
                    Most Relevant
                  </button>
                  <button className="px-3 py-1 text-gray-600 hover:bg-gray-100 rounded">
                    Latest
                  </button>
                  <button className="px-3 py-1 text-gray-600 hover:bg-gray-100 rounded">
                    Highest Rating
                  </button>
                </div>
              </div>
              {reviewsLoading && (
                <div className="text-center py-8">
                  <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                  <p className="mt-2 text-gray-600">Loading reviews...</p>
                </div>
              )}
              {reviewsError && (
                <div className="text-center py-8 text-red-500">
                  {reviewsError}
                </div>
              )}
              {!reviewsLoading && !reviewsError && reviews.length === 0 && (
                <div className="text-center py-8 text-gray-600">
                  No reviews available for this shop.
                </div>
              )}
              {!reviewsLoading && reviews.length > 0 && (
                reviews.map((review) => (
                  <div key={review.review_id} className="border-b pb-4 last:border-b-0">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 sm:w-10 h-8 sm:h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm sm:text-base">
                          {review.user_name ? review.user_name[0] : "A"}
                        </div>
                        <div>
                          <p className="font-semibold text-sm sm:text-base">
                            {review.user_name || "Anonymous"}
                          </p>
                          <div className="flex items-center space-x-2">
                            <div className="flex items-center">{renderStars(review.rating)}</div>
                          </div>
                        </div>
                      </div>
                      <span className="text-gray-500 text-xs sm:text-sm">
                        {new Date(review.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-gray-700 text-sm sm:text-base">
                      {review.comment || "No comment provided."}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <>
      <JustDialNavbar />
      <div className="relative w-full h-48 sm:h-64 md:h-80 bg-gray-200">
        {imagesLoading ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              <p className="mt-2 text-white text-sm sm:text-base">Loading banner...</p>
            </div>
          </div>
        ) : imagesError || images.length === 0 ? (
          <img
            src={fallbackImage}
            alt={`${shop?.name} banner`}
            className="w-full h-full object-cover"
          />
        ) : (
          <img
            src={images[0]}
            alt={`${shop?.name} banner`}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.target.src = fallbackImage;
            }}
          />
        )}
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <div className="text-center px-4">
            <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-2 sm:mb-4">
              Discover {shop?.name} in {selectedLocation}
            </h2>
            <button
              onClick={() => window.scrollTo({ top: window.innerHeight, behavior: "smooth" })}
              className="bg-orange-500 hover:bg-orange-600 text-white px-4 sm:px-6 py-2 rounded-full text-sm sm:text-base font-medium"
            >
              Explore Services
            </button>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6">
        {error && (
          <div className="mb-4 text-red-500 text-sm sm:text-base bg-red-50 p-3 rounded flex items-center justify-between">
            <span>{error}</span>
            <Link
              to={`/categories/${category}/${subcategory}`}
              className="text-blue-600 hover:underline text-sm sm:text-base"
            >
              Back to Listings
            </Link>
          </div>
        )}
        <nav className="mb-4 sm:mb-6 text-xs sm:text-sm text-gray-600">
          <div className="flex flex-wrap items-center gap-2">
            <Link to="/" className="hover:text-blue-600">
              Home
            </Link>
            <span>›</span>
            <Link to={`/categories/${category}`} className="hover:text-blue-600 capitalize">
              {category?.replace("-", " ") || "Beauty"}
            </Link>
            <span>›</span>
            <Link
              to={`/categories/${category}/${subcategory}`}
              className="hover:text-blue-600 capitalize"
            >
              {subcategory?.replace("-", " ") || "Hair Salon"}
            </Link>
            <span>›</span>
            <span className="font-medium text-gray-900 text-sm sm:text-base">{shop?.name}</span>
          </div>
        </nav>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
          <div className="lg:col-span-2 space-y-4 sm:space-y-6">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="relative">
                {imagesLoading ? (
                  <div className="w-full h-64 sm:h-80 lg:h-96 flex items-center justify-center bg-gray-200">
                    <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                  </div>
                ) : imagesError || images.length === 0 ? (
                  <img
                    src={fallbackImage}
                    alt={shop?.name}
                    className="w-full h-64 sm:h-80 lg:h-96 object-cover"
                  />
                ) : (
                  <img
                    src={images[selectedImageIndex]}
                    alt={shop?.name}
                    className="w-full h-64 sm:h-80 lg:h-96 object-cover"
                    onError={(e) => {
                      e.target.src = fallbackImage;
                    }}
                  />
                )}
                {images.length > 0 && (
                  <div className="absolute top-2 sm:top-4 right-2 sm:right-4 bg-black bg-opacity-50 text-white px-2 sm:px-3 py-1 rounded-full text-xs sm:text-sm">
                    {selectedImageIndex + 1} / {images.length}
                  </div>
                )}
                <button
                  onClick={handleShare}
                  className="absolute top-2 sm:top-4 left-2 sm:left-4 bg-white bg-opacity-90 p-1 sm:p-2 rounded-full hover:bg-opacity-100 transition-all"
                >
                  <svg
                    className="w-4 sm:w-5 h-4 sm:h-5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z"
                    />
                  </svg>
                </button>
              </div>
              <div className="p-4">
                {imagesLoading ? (
                  <div className="text-center py-4 text-gray-600">Loading images...</div>
                ) : imagesError || images.length === 0 ? (
                  <div className="text-center py-4 text-gray-600">No images available.</div>
                ) : (
                  <div className="flex space-x-2 overflow-x-auto snap-x snap-mandatory pb-2">
                    {images.map((image, index) => (
                      <img
                        key={index}
                        src={image}
                        alt={`Gallery ${index + 1}`}
                        className={`w-12 sm:w-16 lg:w-20 h-12 sm:h-16 lg:h-20 object-cover rounded cursor-pointer border-2 transition-all snap-center ${
                          selectedImageIndex === index ? "border-blue-500" : "border-gray-200"
                        }`}
                        onClick={() => setSelectedImageIndex(index)}
                        onError={(e) => {
                          e.target.src = fallbackImage;
                        }}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-sm">
              <div className="border-b border-gray-200">
                <nav className="flex flex-wrap gap-2 sm:gap-4 px-4 sm:px-6">
                  {["overview", "catalogue", "photos", "reviews"].map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setActiveTab(tab)}
                      className={`py-2 sm:py-4 px-1 sm:px-2 border-b-2 font-medium text-xs sm:text-sm capitalize transition-colors ${
                        activeTab === tab
                          ? "border-blue-500 text-blue-600"
                          : "border-transparent text-gray-500 hover:text-gray-700"
                      }`}
                    >
                      {tab.replace("-", " ")}
                    </button>
                  ))}
                </nav>
              </div>
              <div className="p-4 sm:p-6">{renderTabContent()}</div>
            </div>
          </div>
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm p-4 sm:p-6 sticky top-6 sm:top-8">
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900 mb-2">
                {shop?.name}
              </h1>
              <p className="text-gray-600 text-sm sm:text-base mb-4">
                {shop?.category} • {shop?.subcategory}
              </p>
              <div className="flex items-center space-x-2 mb-4">
                <div className="flex items-center space-x-1">
                  {renderStars(shop?.rating || "4.5")}
                </div>
                <span className="font-semibold text-sm sm:text-base">{shop?.rating || "4.5"}</span>
                <span className="text-gray-600 text-sm sm:text-base">
                  ({shop?.totalRatings || "418"} reviews)
                </span>
              </div>
              <div className="space-y-3 mb-4 sm:mb-6">
                <div className="flex items-center space-x-2">
                  <span className="text-gray-600">📍</span>
                  <span className="text-gray-700 text-sm sm:text-base">
                    {shop?.address || `${selectedLocation}, Hyderabad`}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-gray-600">📞</span>
                  <span className="text-gray-700 text-sm sm:text-base">
                    {shop?.phone || "9948987278"}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-gray-600">⏰</span>
                  <span className="text-gray-700 text-sm sm:text-base">
                    Open • Closes {shop?.closing_time || "9:00 PM"}
                  </span>
                </div>
              </div>
              <div className="space-y-3">
                <button
                  onClick={handleCall}
                  className="w-full bg-blue-600 text-white py-2 sm:py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2 text-sm sm:text-base"
                >
                  <span>📞</span>
                  <span>Call Now</span>
                </button>
                <button
                  onClick={handleWhatsApp}
                  className="w-full bg-green-600 text-white py-2 sm:py-3 rounded-lg font-medium hover:bg-green-700 transition-colors flex items-center justify-center space-x-2 text-sm sm:text-base"
                >
                  <span>💬</span>
                  <span>WhatsApp</span>
                </button>
                <button
                  onClick={() => setShowEnquiryForm(true)}
                  className="w-full bg-orange-600 text-white py-2 sm:py-3 rounded-lg font-medium hover:bg-orange-700 transition-colors flex items-center justify-center space-x-2 text-sm sm:text-base"
                >
                  <span>✉️</span>
                  <span>Send Enquiry</span>
                </button>
              </div>
              <div className="mt-4 sm:mt-6 pt-4 sm:pt-6 border-t">
                <h3 className="font-semibold text-sm sm:text-base mb-3">Quick Info</h3>
                <div className="space-y-2 text-xs sm:text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Established:</span>
                    <span>{shop?.established || "2018"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Payment:</span>
                    <span>Cash, Cards, UPI</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Parking:</span>
                    <span>Available</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {showEnquiryForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
              <h3 className="text-lg font-semibold mb-4">Send Enquiry</h3>
              <form onSubmit={handleEnquirySubmit}>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                  <input
                    type="text"
                    value={enquiryForm.name}
                    onChange={(e) => setEnquiryForm({ ...enquiryForm, name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
                    placeholder="Your Name"
                    required
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                  <input
                    type="tel"
                    value={enquiryForm.phone}
                    onChange={(e) => setEnquiryForm({ ...enquiryForm, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
                    placeholder="Your Phone Number"
                    required
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input
                    type="email"
                    value={enquiryForm.email}
                    onChange={(e) => setEnquiryForm({ ...enquiryForm, email: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
                    placeholder="Your Email"
                    required
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                  <textarea
                    rows={4}
                    value={enquiryForm.message}
                    onChange={(e) => setEnquiryForm({ ...enquiryForm, message: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
                    placeholder="Your Message"
                    required
                  />
                </div>
                <div className="flex space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowEnquiryForm(false)}
                    className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 text-sm sm:text-base"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm sm:text-base"
                  >
                    Send Enquiry
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
      <Footer />
    </>
  );
};

export default ShopDetailsPage;