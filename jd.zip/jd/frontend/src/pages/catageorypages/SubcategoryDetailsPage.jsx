import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Menu, X } from "lucide-react";
import JustDialNavbar from "../../components/Navbar";
import Footer from "../../components/Footer";
import api from "../../config";

const SubcategoryDetailsPage = () => {
  const { category, subcategory } = useParams();
  const [shops, setShops] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [displayedShops, setDisplayedShops] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [filters, setFilters] = useState({
    sortBy: "relevance",
    type: "all",
    openNow: false,
    topRated: false,
    quickResponse: false,
    SHVerified: false,
    ratings: "all",
    SHTrust: false,
  });
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const navigate = useNavigate();
  const selectedLocation = localStorage.getItem("selectedLocation") || "Kukatpally";

  const ITEMS_PER_PAGE = 10;

  useEffect(() => {
    let isMounted = true;

    const fetchShopsAndReviews = async () => {
      try {
        setLoading(true);
        setError(null);
        const normalizedSubcategory = decodeURIComponent(subcategory).replace(/-/g, " ");
        console.log(`[SubcategoryDetailsPage] Fetching shops for subcategory: ${normalizedSubcategory}, location: ${selectedLocation}`);

        // Fetch subcategory ID
        const subcategoryResponse = await api.get(
          `/categories?name=${encodeURIComponent(normalizedSubcategory)}`
        );

        if (!subcategoryResponse.data?.length) {
          throw new Error(`Subcategory "${normalizedSubcategory}" not found.`);
        }

        const { category_id: subcategoryId } = subcategoryResponse.data[0];
        const shopsResponse = await api.get(`/shops/${subcategoryId}?location=${encodeURIComponent(selectedLocation)}`);

        console.log(`[SubcategoryDetailsPage] Received ${shopsResponse.data.length} shops from API:`, 
          shopsResponse.data.map(shop => ({
            shop_id: shop.shop_id,
            shop_name: shop.shop_name,
            location: shop.location,
            created_at: shop.created_at,
            closing_time: shop.closing_time
          })));

        // Check for duplicate shop_ids
        const shopIds = shopsResponse.data.map(shop => shop.shop_id);
        const uniqueShopIds = new Set(shopIds);
        if (uniqueShopIds.size < shopIds.length) {
          console.warn(`[SubcategoryDetailsPage] Duplicate shop_ids detected:`, shopIds);
        }

        // Transform shops and fetch reviews
        const transformedShops = await Promise.all(
          shopsResponse.data.map(async (shop) => {
            console.log(`[SubcategoryDetailsPage] Processing shop_id: ${shop.shop_id}, shop_name: ${shop.shop_name}`);

            // Fetch reviews for the shop
            let rating = "0.0";
            let totalRatings = 0;
            try {
              const reviewsResponse = await api.get(`/shops/shop/${shop.shop_id}/reviews`);
              const reviews = reviewsResponse.data;
              if (reviews.length > 0) {
                const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
                rating = (totalRating / reviews.length).toFixed(1);
                totalRatings = reviews.length;
              }
              console.log(`[SubcategoryDetailsPage] Fetched ${totalRatings} reviews for shop_id: ${shop.shop_id}, average rating: ${rating}`);
            } catch (err) {
              console.warn(`[SubcategoryDetailsPage] Failed to fetch reviews for shop_id: ${shop.shop_id}`, err.message);
            }

            // Validate required fields
            if (!shop.shop_name) {
              console.warn(`[SubcategoryDetailsPage] Missing shop_name for shop_id: ${shop.shop_id}`);
              shop.shop_name = "Unnamed Shop";
            }
            if (!shop.created_at) {
              console.warn(`[SubcategoryDetailsPage] Missing created_at for shop_id: ${shop.shop_id}`);
              shop.created_at = new Date().toISOString();
            }
            if (!shop.closing_time) {
              console.warn(`[SubcategoryDetailsPage] Missing closing_time for shop_id: ${shop.shop_id}`);
              shop.closing_time = "21:00";
            }

            const shopData = {
              id: shop.shop_id, // Use original shop_id
              name: shop.shop_name || "Unnamed Shop",
              rating,
              totalRatings,
              verified: shop.is_approved || false,
              location: shop.location || "Not specified",
              openUntil: shop.closing_time
                ? new Date(`1970-01-01T${shop.closing_time}`).toLocaleTimeString([], {
                    hour: "numeric",
                    minute: "2-digit",
                  })
                : "Not specified",
              yearsInBusiness: shop.created_at
                ? new Date().getFullYear() - new Date(shop.created_at).getFullYear()
                : 1,
              tags: shop.tags || ["Service Provider"],
              phone: shop.phone || "Not specified",
              image: shop.image_url || "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg",
              description: shop.description || "No description available.",
              established: shop.created_at
                ? new Date(shop.created_at).getFullYear()
                : new Date().getFullYear(),
              address: shop.address || `${selectedLocation}, Hyderabad`,
              email: shop.email || "",
              website: shop.website || "",
              opening_time: shop.opening_time || "09:00",
              closing_time: shop.closing_time || "21:00",
              social_media: shop.social_media || {},
              owner_name: shop.owner_name || "",
              category_name: shop.category_name || subcategory,
              trending: parseFloat(rating) > 4.5,
              popular: totalRatings > 100,
              quickResponse: shop.is_approved,
              SHTrust: shop.is_approved && parseFloat(rating) > 4.0,
              isOpen: shop.closing_time
                ? new Date(`1970-01-01T${shop.closing_time}`).getHours() >= new Date().getHours()
                : true,
            };
            localStorage.setItem(`shop_${shop.shop_id}`, JSON.stringify(shopData));
            return shopData;
          })
        );

        // Filter out null entries
        const validShops = transformedShops.filter(shop => shop !== null);

        console.log(
          `[SubcategoryDetailsPage] Transformed ${validShops.length} shops:`,
          validShops.map((s) => ({ id: s.id, name: s.name }))
        );

        if (isMounted) {
          if (validShops.length === 0) {
            setError(`No valid shops found in ${selectedLocation} for this subcategory. Try a different location or category.`);
          }
          setShops(validShops);
          setError(validShops.length === 0 ? `No valid shops found in ${selectedLocation} for this subcategory. Try a different location or category.` : null);
        }
      } catch (err) {
        if (isMounted) {
          console.error(`[SubcategoryDetailsPage] Error fetching shops or reviews:`, err);
          setError(
            err.response?.status === 404
              ? `Subcategory "${decodeURIComponent(subcategory).replace(/-/g, " ")}" not found.`
              : err.response?.data?.error || err.message || "Failed to load shops. Please try again."
          );
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchShopsAndReviews();

    return () => {
      isMounted = false;
    };
  }, [subcategory, selectedLocation]);

  // Filter and sort shops
  const filteredShops = useMemo(() => {
    let filtered = [...shops];

    console.log(`[SubcategoryDetailsPage] Applying filters to ${filtered.length} shops`, filters);

    if (filters.openNow) {
      filtered = filtered.filter((shop) => {
        const isOpen = shop.isOpen;
        if (!isOpen) console.log(`[SubcategoryDetailsPage] Filtered out shop_id: ${shop.id} (not open)`);
        return isOpen;
      });
    }
    if (filters.topRated) {
      filtered = filtered.filter((shop) => {
        const isTopRated = parseFloat(shop.rating) >= 4.0;
        if (!isTopRated) console.log(`[SubcategoryDetailsPage] Filtered out shop_id: ${shop.id} (rating ${shop.rating} < 4.0)`);
        return isTopRated;
      });
    }
    if (filters.quickResponse) {
      filtered = filtered.filter((shop) => {
        const isQuickResponse = shop.quickResponse;
        if (!isQuickResponse) console.log(`[SubcategoryDetailsPage] Filtered out shop_id: ${shop.id} (not quick response)`);
        return isQuickResponse;
      });
    }
    if (filters.SHVerified) {
      filtered = filtered.filter((shop) => {
        const isVerified = shop.verified;
        if (!isVerified) console.log(`[SubcategoryDetailsPage] Filtered out shop_id: ${shop.id} (not verified)`);
        return isVerified;
      });
    }
    if (filters.SHTrust) {
      filtered = filtered.filter((shop) => {
        const hasSHTrust = shop.SHTrust;
        if (!hasSHTrust) console.log(`[SubcategoryDetailsPage] Filtered out shop_id: ${shop.id} (no SH Trust)`);
        return hasSHTrust;
      });
    }
    if (filters.ratings !== "all") {
      const minRating = parseFloat(filters.ratings);
      filtered = filtered.filter((shop) => {
        const meetsRating = parseFloat(shop.rating) >= minRating;
        if (!meetsRating) console.log(`[SubcategoryDetailsPage] Filtered out shop_id: ${shop.id} (rating ${shop.rating} < ${minRating})`);
        return meetsRating;
      });
    }
    if (filters.type !== "all") {
      filtered = filtered.filter((shop) => {
        const matchesType = shop.tags?.map((t) => t.toLowerCase()).includes(filters.type.toLowerCase());
        if (!matchesType) console.log(`[SubcategoryDetailsPage] Filtered out shop_id: ${shop.id} (type ${shop.tags} does not include ${filters.type})`);
        return matchesType;
      });
    }

    switch (filters.sortBy) {
      case "ratings":
        filtered.sort((a, b) => parseFloat(b.rating) - parseFloat(a.rating));
        break;
      case "popularity":
        filtered.sort((a, b) => b.totalRatings - a.totalRatings);
        break;
      case "newest":
        filtered.sort((a, b) => b.established - a.established);
        break;
      default:
        break;
    }

    console.log(`[SubcategoryDetailsPage] After filters, ${filtered.length} shops remain:`, 
      filtered.map((s) => ({ id: s.id, name: s.name })));

    return filtered;
  }, [shops, filters]);

  // Load more shops for pagination
  const loadMoreShops = useCallback(() => {
    if (isLoadingMore || !hasMore) return;

    setIsLoadingMore(true);

    setTimeout(() => {
      const nextPage = currentPage + 1;
      const startIndex = (nextPage - 1) * ITEMS_PER_PAGE;
      const endIndex = startIndex + ITEMS_PER_PAGE;

      const newShops = filteredShops.slice(startIndex, endIndex);

      console.log(`[SubcategoryDetailsPage] Loading more shops, page ${nextPage}, adding ${newShops.length} shops`);

      if (newShops.length > 0) {
        setDisplayedShops((prev) => [...prev, ...newShops]);
        setCurrentPage(nextPage);
        setHasMore(endIndex < filteredShops.length);
      } else {
        setHasMore(false);
      }

      setIsLoadingMore(false);
    }, 500);
  }, [currentPage, filteredShops, isLoadingMore, hasMore]);

  // Initialize displayed shops
  useEffect(() => {
    const initialShops = filteredShops.slice(0, ITEMS_PER_PAGE);
    setDisplayedShops(initialShops);
    setCurrentPage(1);
    setHasMore(filteredShops.length > ITEMS_PER_PAGE);
    console.log(`[SubcategoryDetailsPage] Initialized with ${initialShops.length} shops for display`);
  }, [filteredShops]);

  // Infinite scroll handler
  useEffect(() => {
    const handleScroll = () => {
      if (
        window.innerHeight + document.documentElement.scrollTop + 1000 >=
        document.documentElement.scrollHeight &&
        !isLoadingMore &&
        hasMore
      ) {
        loadMoreShops();
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [loadMoreShops, isLoadingMore, hasMore]);

  const handleShopClick = (shop) => {
    console.log(`[SubcategoryDetailsPage] Navigating to shop: id=${shop.id}`, shop);
    navigate(`/categories/${category}/${subcategory}/${shop.id}`, {
      state: {
        shop: {
          ...shop,
          category,
          subcategory,
          viewedAt: new Date().toISOString(),
          source: "subcategory_listing",
        },
      },
    });
  };

  const handleFilterChange = (filterType, value) => {
    setFilters((prev) => ({
      ...prev,
      [filterType]: value,
    }));
  };

  const toggleFilterMenu = () => {
    setIsFilterOpen((prev) => !prev);
  };

  const ShopCard = ({ shop }) => (
    <div className="bg-white border-b border-gray-200 hover:shadow-md transition-shadow duration-200">
      <div className="flex flex-col sm:flex-row p-4">
        <div className="w-full sm:w-24 sm:h-24 md:w-32 md:h-32 flex-shrink-0 sm:mr-4 mb-4 sm:mb-0">
          <img
            src={shop.image}
            alt={shop.name}
            className="w-full h-full object-cover rounded-lg cursor-pointer"
            loading="lazy"
            onClick={() => handleShopClick(shop)}
            onError={(e) => {
              e.target.src = "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg";
            }}
          />
        </div>
        <div className="flex-1">
          <div className="flex flex-col">
            <div className="flex items-center flex-wrap gap-2 mb-2">
              <h3
                className="text-base sm:text-lg md:text-xl font-semibold text-blue-600 hover:text-blue-800 cursor-pointer"
                onClick={() => handleShopClick(shop)}
              >
                {shop.name}
              </h3>
              {shop.SHTrust && (
                <span className="bg-orange-100 text-orange-600 px-2 py-1 rounded-full text-xs font-medium">
                  SH Trust
                </span>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2 sm:gap-4 mb-2">
              <div className="flex items-center gap-1">
                <span className="bg-green-600 text-white px-2 py-1 rounded text-xs sm:text-sm font-medium">
                  {shop.rating} ★
                </span>
                <span className="text-gray-600 text-xs sm:text-sm">{shop.totalRatings} Ratings</span>
              </div>
              {shop.verified && (
                <span className="text-blue-600 text-xs sm:text-sm font-medium">✓ Verified</span>
              )}
              {shop.trending && (
                <span className="bg-orange-100 text-orange-600 px-2 py-1 rounded text-xs font-medium">
                  🔥 Trending
                </span>
              )}
              {shop.popular && (
                <span className="bg-purple-100 text-purple-600 px-2 py-1 rounded text-xs font-medium">
                  Popular
                </span>
              )}
            </div>
            <p className="text-gray-600 text-xs sm:text-sm mb-2">
              📍 {shop.address || shop.location}
            </p>
            <p className="text-gray-600 text-xs sm:text-sm mb-3 line-clamp-2">
              {shop.description}
            </p>
            <div className="text-xs sm:text-sm text-gray-600 mb-3">
              <div className="flex flex-wrap items-center gap-2 sm:gap-4">
                <span>🕒 Open until {shop.openUntil}</span>
                <span>📅 {shop.yearsInBusiness} Years in Business</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <a
                href={`tel:${shop.phone}`}
                className="bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded text-xs sm:text-sm font-medium inline-flex items-center gap-1"
                onClick={(e) => e.stopPropagation()}
              >
                📞 {shop.phone}
              </a>
              <a
                href={`https://wa.me/${shop.phone.replace(/\D/g, "")}`}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-green-500 hover:bg-green-600 text-white px-3 py-1.5 rounded text-xs sm:text-sm font-medium"
                onClick={(e) => e.stopPropagation()}
              >
                WhatsApp
              </a>
              <button
                className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded text-xs sm:text-sm font-medium"
                onClick={(e) => {
                  e.stopPropagation();
                  alert("Enquiry sent! We'll get back to you soon.");
                }}
              >
                Send Enquiry
              </button>
              <button
                className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded text-xs sm:text-sm font-medium"
                onClick={() => handleShopClick(shop)}
              >
                View Details
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <JustDialNavbar />
      <div className="relative w-full h-48 sm:h-64 md:h-80 bg-gray-200">
        <img
          src="https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg"
          alt={`${subcategory} banner`}
          className="w-full h-full object-cover"
          onError={(e) => {
            e.target.src = "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg";
          }}
        />
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <div className="text-center px-4">
            <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-white capitalize mb-2 sm:mb-4">
              Explore Top {subcategory.replace("-", " ")} Services in {selectedLocation}
            </h2>
            <button
              onClick={() => window.scrollTo({ top: window.innerHeight, behavior: "smooth" })}
              className="bg-orange-500 hover:bg-orange-600 text-white px-4 sm:px-6 py-2 rounded-full text-sm sm:text-base font-medium"
            >
              Find Now
            </button>
          </div>
        </div>
      </div>
      <div className="bg-white py-3 sm:py-4 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold capitalize mb-1 sm:mb-2">
            Popular {subcategory.replace("-", " ")} Services in {selectedLocation}
          </h1>
          <p className="text-gray-600 text-sm sm:text-base">
            Find the best {subcategory.replace("-", " ")} services near you
          </p>
        </div>
      </div>
      <div className="bg-white py-3 sm:py-4 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="sm:hidden flex items-center">
            <button
              onClick={toggleFilterMenu}
              className="p-2 text-gray-600 hover:text-blue-600 focus:outline-none"
              aria-label="Toggle filters"
            >
              {isFilterOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            <span className="text-sm font-medium ml-2">Filters</span>
          </div>
          {isFilterOpen && (
            <div className="sm:hidden mt-4 p-4 bg-gray-50 rounded-lg shadow-sm">
              <div className="space-y-4">
                <div className="flex flex-col gap-2">
                  <span className="text-sm font-medium">Sort by:</span>
                  <select
                    value={filters.sortBy}
                    onChange={(e) => handleFilterChange("sortBy", e.target.value)}
                    className="border rounded px-3 py-2 text-sm w-full"
                  >
                    <option value="relevance">Relevance</option>
                    <option value="ratings">Top Rated</option>
                    <option value="popularity">Most Popular</option>
                    <option value="newest">Newest</option>
                  </select>
                </div>
                <div className="flex flex-col gap-2">
                  <span className="text-sm font-medium">Type:</span>
                  <select
                    value={filters.type}
                    onChange={(e) => handleFilterChange("type", e.target.value)}
                    className="border rounded px-3 py-2 text-sm w-full"
                  >
                    <option value="all">All</option>
                    <option value="salon">Salon</option>
                    <option value="spa">Spa</option>
                  </select>
                </div>
                <div className="flex flex-col gap-2">
                  <span className="text-sm font-medium">Ratings:</span>
                  <select
                    value={filters.ratings}
                    onChange={(e) => handleFilterChange("ratings", e.target.value)}
                    className="border rounded px-3 py-2 text-sm w-full"
                  >
                    <option value="all">All</option>
                    <option value="4.0">4.0 & above</option>
                    <option value="3.5">3.5 & above</option>
                    <option value="3.0">3.0 & above</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={filters.openNow}
                      onChange={(e) => handleFilterChange("openNow", e.target.checked)}
                      className="rounded h-5 w-5"
                    />
                    <span className="text-sm">Open Now</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={filters.topRated}
                      onChange={(e) => handleFilterChange("topRated", e.target.checked)}
                      className="rounded h-5 w-5"
                    />
                    <span className="text-sm">⭐ Top Rated</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={filters.quickResponse}
                      onChange={(e) => handleFilterChange("quickResponse", e.target.checked)}
                      className="rounded h-5 w-5"
                    />
                    <span className="text-sm">⚡ Quick Response</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={filters.SHVerified}
                      onChange={(e) => handleFilterChange("SHVerified", e.target.checked)}
                      className="rounded h-5 w-5"
                    />
                    <span className="text-sm">✓ SH Verified</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={filters.SHTrust}
                      onChange={(e) => handleFilterChange("SHTrust", e.target.checked)}
                      className="rounded h-5 w-5"
                    />
                    <span className="text-sm">🛡️ SH Trust</span>
                  </label>
                </div>
                <button
                  onClick={toggleFilterMenu}
                  className="bg-blue-600 text-white px-4 py-2 rounded text-sm font-medium w-full"
                >
                  Apply Filters
                </button>
              </div>
            </div>
          )}
          <div className="hidden sm:flex sm:flex-row sm:flex-wrap items-center gap-4 mt-4">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Sort by:</span>
              <select
                value={filters.sortBy}
                onChange={(e) => handleFilterChange("sortBy", e.target.value)}
                className="border rounded px-3 py-1 text-sm"
              >
                <option value="relevance">Relevance</option>
                <option value="ratings">Top Rated</option>
                <option value="popularity">Most Popular</option>
                <option value="newest">Newest</option>
              </select>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Type:</span>
              <select
                value={filters.type}
                onChange={(e) => handleFilterChange("type", e.target.value)}
                className="border rounded px-3 py-1 text-sm"
              >
                <option value="all">All</option>
                <option value="salon">Salon</option>
                <option value="spa">Spa</option>
              </select>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Ratings:</span>
              <select
                value={filters.ratings}
                onChange={(e) => handleFilterChange("ratings", e.target.value)}
                className="border rounded px-3 py-1 text-sm"
              >
                <option value="all">All</option>
                <option value="4.0">4.0 & above</option>
                <option value="3.5">3.5 & above</option>
                <option value="3.0">3.0 & above</option>
              </select>
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.openNow}
                onChange={(e) => handleFilterChange("openNow", e.target.checked)}
                className="rounded h-5 w-5"
              />
              <span className="text-sm">Open Now</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.topRated}
                onChange={(e) => handleFilterChange("topRated", e.target.checked)}
                className="rounded h-5 w-5"
              />
              <span className="text-sm">⭐ Top Rated</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.quickResponse}
                onChange={(e) => handleFilterChange("quickResponse", e.target.checked)}
                className="rounded h-5 w-5"
              />
              <span className="text-sm">⚡ Quick Response</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.SHVerified}
                onChange={(e) => handleFilterChange("SHVerified", e.target.checked)}
                className="rounded h-5 w-5"
              />
              <span className="text-sm">✓ SH Verified</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.SHTrust}
                onChange={(e) => handleFilterChange("SHTrust", e.target.checked)}
                className="rounded h-5 w-5"
              />
              <span className="text-sm">🛡️ SH Trust</span>
            </label>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6">
        {loading && (
          <div className="text-center py-8">
            <div className="inline-block animate-spin rounded-full h-6 w-6 sm:h-8 sm:w-8 border-b-2 border-blue-600"></div>
            <p className="mt-2 text-gray-600 text-sm sm:text-base">Loading shops...</p>
          </div>
        )}
        {error && (
          <div className="text-center py-8 text-red-500 text-sm sm:text-base">
            {error}
            <br />
            <button
              onClick={() => navigate(`/categories/${category}`)}
              className="text-blue-600 hover:underline mt-2 text-sm sm:text-base"
            >
              Back to Categories
            </button>
          </div>
        )}
        {!loading && !error && filteredShops.length === 0 && (
          <div className="text-center py-8 text-gray-600 text-sm sm:text-base">
            No shops found in {selectedLocation} for this subcategory. Try a different location or category.
            <br />
            <button
              onClick={() => navigate(`/categories/${category}`)}
              className="text-blue-600 hover:underline mt-2 text-sm sm:text-base"
            >
              Back to Categories
            </button>
            <br />
            <button
              onClick={() => setFilters({
                sortBy: "relevance",
                type: "all",
                openNow: false,
                topRated: false,
                quickResponse: false,
                SHVerified: false,
                ratings: "all",
                SHTrust: false,
              })}
              className="text-blue-600 hover:underline mt-2 text-sm sm:text-base"
            >
              Reset Filters
            </button>
          </div>
        )}
        {!loading && !error && displayedShops.length > 0 && (
          <div className="bg-white">
            <div className="p-4">
              <h2 className="text-base sm:text-lg font-semibold">
                {filteredShops.length} {subcategory.replace("-", " ")} services found
              </h2>
            </div>
            {displayedShops.map((shop) => (
              <ShopCard key={shop.id} shop={shop} />
            ))}
          </div>
        )}
        {isLoadingMore && (
          <div className="text-center py-4">
            <div className="inline-block animate-spin rounded-full h-5 w-5 sm:h-6 sm:w-6 border-b-2 border-blue-600"></div>
            <p className="mt-2 text-gray-600 text-sm">Loading more shops...</p>
          </div>
        )}
        {!hasMore && displayedShops.length > 0 && (
          <div className="text-center py-4 text-gray-600 text-sm sm:text-base">
            No more shops to load.
          </div>
        )}
      </div>
      <Footer />
    </>
  );
};

export default SubcategoryDetailsPage;