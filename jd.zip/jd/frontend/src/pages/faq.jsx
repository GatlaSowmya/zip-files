import React, { useState } from "react";

const faqs = [
  {
    question: "What is Search Hyderabad?",
    answer:
      "Search Hyderabad is a local business directory and service search platform dedicated to helping people in Hyderabad find reliable businesses and professionals.",
  },
  {
    question: "Is Search Hyderabad free to use?",
    answer:
      "Yes, using our platform to search for services and businesses is completely free for users.",
  },
  {
    question: "How do I find a service near me?",
    answer:
      "Simply type the service you’re looking for (e.g., 'plumber', 'salon') into the search bar and enter your location or let the site auto-detect it.",
  },
  {
    question: "What types of services are listed?",
    answer:
      "We list everything from electricians, home services, doctors, restaurants, event planners, tutors, and more — all based in Hyderabad.",
  },
  {
    question: "How can I get my business listed?",
    answer:
      "Click on the “Add Business” button and fill in your business details. After verification, we’ll publish it on the platform.",
  },
  {
    question: "Are the businesses verified?",
    answer:
      "We strive to verify all listings, but we recommend users also check reviews and ratings before making any decisions.",
  },
  {
    question: "Can I leave a review for a business?",
    answer:
      "Yes, after using a service, you can rate and review the business to help others in the community.",
  },
  {
    question: "Is my personal data safe?",
    answer:
      "Absolutely. We follow strict privacy practices and do not sell your personal data to third parties. Read our Privacy Policy for more.",
  },
  {
    question: "Do you offer customer support?",
    answer:
      "Yes, if you need help or have an issue with a listing, you can contact us through the support form or email us at support@searchhyderabad.com.",
  },
  {
    question: "Is Search Hyderabad available as a mobile app?",
    answer:
      "We’re currently working on our mobile app. Until then, you can access the full site from your phone browser.",
  },
];

const FAQSection = () => {
  const [openIndex, setOpenIndex] = useState(null);

  const toggle = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <h2 className="text-3xl font-bold text-center mb-10">Frequently Asked Questions</h2>
      <div className="space-y-4">
        {faqs.map((faq, index) => (
          <div key={index} className="border border-gray-200 rounded-lg overflow-hidden">
            <button
              className="w-full flex justify-between items-center text-left p-4 bg-gray-100 hover:bg-gray-200 transition"
              onClick={() => toggle(index)}
            >
              <span className="font-medium text-gray-800">{faq.question}</span>
              <span className="text-lg">{openIndex === index ? "-" : "+"}</span>
            </button>
            {openIndex === index && (
              <div className="p-4 text-gray-700 bg-white border-t">{faq.answer}</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default FAQSection;
