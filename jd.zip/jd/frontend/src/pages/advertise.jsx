import React, { useState } from "react";
import Footer from "../components/Footer";
import JustDialNavbar from "../components/Navbar";

const AdvertisePage = () => {
  const [activeFAQ, setActiveFAQ] = useState(null);

  const toggleFAQ = (index) => {
    setActiveFAQ(activeFAQ === index ? null : index);
  };

  return (
    <>
    <JustDialNavbar />
    <div className="font-sans text-gray-800">
      {/* HERO SECTION */}
      <section className="bg-white py-10 px-5 md:px-20 flex flex-col-reverse md:flex-row items-center justify-between">
        {/* Left Content */}
        <div className="flex-1 space-y-5">
          <h1 className="text-3xl md:text-8xl font-bold text-gray-900">
            <span className="text-blue-600">GROW</span> Your Business
          </h1>
          <p className="text-gray-700 text-xl">
            Advertise with Search Hyderabad- India’s No.1 Local Search Engine
          </p>
          <div className="flex flex-col sm:flex-row items-center space-y-3 sm:space-y-0 sm:space-x-7">
            <div className="flex border rounded-lg overflow-hidden w-full sm:w-auto">
              <span className="flex items-center px-9 bg-gray-100 border-r">
                +91
              </span>
              <input
                type="text"
                placeholder="Enter Mobile No"
                className="outline-none px-3 py-2 w-full"
              />
            </div>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 w-full sm:w-auto">
              Get Started →
            </button>
          </div>
          <ul className="mt-5 space-y-2 text-gray-700 text-xl">
            <li>✅ Rank Ahead of Your Competition</li>
            <li>✅ Find Ready to Buy Customers Instantly</li>
            <li>✅ Track Leads & Competition Trends</li>
          </ul>
        </div>
        {/* Right Image */}
        <div className="flex-1 flex justify-center mb-5 md:mb-0">
          <img
            src="https://webneel.com/daily/sites/default/files/images/daily/06-2016/18-lg-washing-machine-print-ads-by-david-pinilla.jpg"
            alt="Phone Mockup"
            className="w-64 md:w-100 rounded"
          />
        </div>
      </section>

      {/* SUCCESS STORIES */}
      <section className="bg-gray-50 py-10 px-5 md:px-20">
        <h2 className="text-2xl md:text-3xl font-bold mb-5">Success Stories</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
          {[
            {
              name: "Rajesh Chhabria",
              company: "Chhabria and Sons",
              years: "13 years",
            },
            { name: "Varshini", company: "V2 Makeover", years: "3 years" },
            {
              name: "Gourab Neogi",
              company: "Tally Academy",
              years: "7 years",
            },
          ].map((story, index) => (
            <div
              key={index}
              className="bg-white rounded-lg shadow p-5 text-center"
            >
              <img
                src="https://wallpapercave.com/wp/wp10257499.jpg"
                alt={story.name}
                className="w-20 h-20 mx-auto rounded-full mb-3"
              />
              <h3 className="font-semibold">{story.name}</h3>
              <p className="text-gray-500">{story.company}</p>
              <p className="text-sm text-gray-400">
                Customer since {story.years}
              </p>
              <a
                href="#"
                className="text-blue-600 mt-2 inline-block hover:underline"
              >
                Visit Business →
              </a>
            </div>
          ))}
        </div>
        <div className="flex justify-center mt-5">
          <button className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
            See All Stories
          </button>
        </div>
      </section>

      {/* GOALS SECTION */}
      <section className="py-10 px-5 md:px-20 bg-white">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-8">
          Search Hyderabad Ads Help You Achieve Your Goals
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          {[
            { title: "Market Your Business to New Users" },
            { title: "Grow Your Revenue" },
            { title: "Get More Walk-in Customers" },
          ].map((goal, index) => (
            <div key={index} className="space-y-3">
              <img
                src="https://wallpapercave.com/wp/wp10257499.jpg"
                alt={goal.title}
                className="mx-auto"
              />
              <p className="font-medium">{goal.title}</p>
            </div>
          ))}
        </div>
      </section>

      {/* PLANS SECTION */}
      <section className="py-10 px-5 md:px-20 bg-gray-50">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-8">
          Plans
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
          {[
            { name: "Standard", price: "₹99", desc: "25% Off" },
            { name: "2 Year Standard", price: "₹75", desc: "44% Off" },
            { name: "Pro", price: "₹199", desc: "25% Off" },
            { name: "Growth", price: "Top 5", desc: "Max Exposure" },
          ].map((plan, index) => (
            <div
              key={index}
              className="bg-white rounded-lg shadow p-5 text-center"
            >
              <h3 className="font-semibold text-lg">{plan.name}</h3>
              <p className="text-blue-600 text-2xl font-bold">{plan.price}</p>
              <p className="text-gray-500">{plan.desc}</p>
              <ul className="mt-3 text-gray-700 space-y-1">
                <li>✔ Search Visibility</li>
                <li>✔ Online Catalogue</li>
                <li>✔ Payment Solutions</li>
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ SECTION */}
      <section className="py-10 px-5 md:px-20 bg-white">
        <h2 className="text-2xl md:text-3xl font-bold mb-5">
          Got a question?
        </h2>
        {[
          "What benefits will I get from a paid listing on Search Hyderabad?",
          "How can I choose the best paid plan for me?",
          "Can I receive leads only from specific areas?",
        ].map((faq, index) => (
          <div
            key={index}
            onClick={() => toggleFAQ(index)}
            className="border-b py-3 cursor-pointer"
          >
            <div className="flex justify-between items-center">
              <p className="font-medium">{faq}</p>
              <span>{activeFAQ === index ? "▲" : "▼"}</span>
            </div>
            {activeFAQ === index && (
              <p className="text-gray-600 mt-2">
                This is a sample answer for: {faq}
              </p>
            )}
          </div>
        ))}
      </section>
    </div>
    <Footer />
    </>
  );
};

export default AdvertisePage;
