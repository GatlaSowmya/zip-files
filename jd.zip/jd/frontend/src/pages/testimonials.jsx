import React from "react";

const testimonials = [
  {
    name: "Aarti Sharma",
    message: "I discovered a great salon in Banjara Hills through this site. Super helpful!",
  },
  {
    name: "Ravi Teja",
    message: "This platform makes it easy to find trusted professionals in Hyderabad.",
  },
  {
    name: "Meena Patel",
    message: "As a small business, being listed here has improved my visibility. Highly recommend!",
  },
  {
    name: "Vinod Kumar",
    message: "Great experience using this to find reliable electricians near me.",
  },
  {
    name: "Lakshmi Rao",
    message: "The user interface is clean and simple. Found what I needed in seconds.",
  },
  {
    name: "Kiran Reddy",
    message: "Listing my business here helped me gain new local customers. Thank you!",
  },
  {
    name: "Sneha Das",
    message: "I love how location-based the search is. Makes it very useful for locals.",
  },
  {
    name: "Ajay Varma",
    message: "One of the best platforms for local service discovery in Hyderabad.",
  },
  {
    name: "Divya Iyer",
    message: "Highly recommend to anyone looking for verified professionals in their area.",
  },
  {
    name: "Mahesh Babu",
    message: "Using this site saved me time and helped me connect with quality vendors fast.",
  },
];

const TestimonialsPage = () => {
  return (
    <div>
      {/* Banner with background image */}
      <section
        className="bg-cover bg-center text-white py-20 px-4 text-center"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1607746882042-944635dfe10e?auto=format&fit=crop&w=1600&q=80')",
        }}
      >
        <div className="bg-black bg-opacity-50 py-10 px-4 rounded-md">
          <h1 className="text-3xl sm:text-4xl font-bold">Testimonials</h1>
          <p className="mt-2 text-lg sm:text-xl">Hear from real users across Hyderabad</p>
        </div>
      </section>

      {/* Testimonials Grid */}
      <div className="max-w-6xl mx-auto px-4 py-12 grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-3">
        {testimonials.map((t, index) => (
          <div
            key={index}
            className="bg-white border border-gray-200 shadow-sm p-6 rounded-lg hover:shadow-md transition duration-200"
          >
            <p className="italic text-gray-600 mb-4">"{t.message}"</p>
            <p className="font-semibold text-indigo-700 text-right">— {t.name}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TestimonialsPage;
