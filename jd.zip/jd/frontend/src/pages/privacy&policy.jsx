import React from "react";

const PrivacyPage = () => {
  return (
    <div>
      {/* Banner with background image */}
      <section
        className="bg-cover bg-center text-white py-20 px-4 text-center"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1601597111047-4ffba5a97b47?auto=format&fit=crop&w=1600&q=80')",
        }}
      >
        <div className="bg-black bg-opacity-50 py-10 px-4 rounded-md">
          <h1 className="text-3xl sm:text-4xl font-bold">Privacy Policy</h1>
          <p className="mt-2 text-lg sm:text-xl">We respect your privacy and protect your personal information</p>
        </div>
      </section>

      {/* Privacy Policy Content */}
      <div className="max-w-4xl mx-auto px-4 py-10 text-gray-800 space-y-6">
        <h2 className="text-xl font-semibold">1. Information We Collect</h2>
        <p>We collect personal information like name, email, phone number, and service preferences.</p>

        <h2 className="text-xl font-semibold">2. How We Use Your Data</h2>
        <p>Your data is used to enhance your experience, show relevant results, and contact you when necessary.</p>

        <h2 className="text-xl font-semibold">3. Cookies & Tracking</h2>
        <p>We use cookies to improve functionality and gather anonymous usage statistics.</p>

        <h2 className="text-xl font-semibold">4. Location Access</h2>
        <p>If granted, we use your device’s location to show nearby services. This is optional.</p>

        <h2 className="text-xl font-semibold">5. Sharing Information</h2>
        <p>We do not sell your information. We may share it with trusted vendors for functionality.</p>

        <h2 className="text-xl font-semibold">6. Data Retention</h2>
        <p>We retain your data as long as necessary to provide our services and comply with legal obligations.</p>

        <h2 className="text-xl font-semibold">7. Your Rights</h2>
        <p>You can request access, correction, or deletion of your personal data at any time.</p>

        <h2 className="text-xl font-semibold">8. Data Security</h2>
        <p>We use encryption and secure servers to protect your information from unauthorized access.</p>

        <h2 className="text-xl font-semibold">9. Children’s Privacy</h2>
        <p>Our platform is not intended for children under the age of 13. We do not knowingly collect their data.</p>

        <h2 className="text-xl font-semibold">10. Third-Party Links</h2>
        <p>We are not responsible for the privacy practices of third-party sites linked from our platform.</p>

        <h2 className="text-xl font-semibold">11. Consent</h2>
        <p>By using our site, you consent to our privacy policy and data handling practices.</p>

        <h2 className="text-xl font-semibold">12. Changes to This Policy</h2>
        <p>We may update this policy periodically. Updates will be posted here with a revision date.</p>

        <h2 className="text-xl font-semibold">13. Contact Us</h2>
        <p>If you have questions, email us at privacy@searchhyderabad.com or use the contact form on our website.</p>
      </div>
    </div>
  );
};

export default PrivacyPage;
