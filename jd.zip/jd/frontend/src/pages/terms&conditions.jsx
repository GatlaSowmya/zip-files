import React from "react";

const TermsPage = () => {
  return (
    <div>
      {/* Banner with background image */}
      <section
        className="bg-cover bg-center text-white py-20 px-4 text-center"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1556742031-c6961e8560b0?auto=format&fit=crop&w=1600&q=80')",
        }}
      >
        <div className="bg-black bg-opacity-50 py-10 px-4 rounded-md">
          <h1 className="text-3xl sm:text-4xl font-bold">Terms and Conditions</h1>
          <p className="mt-2 text-lg sm:text-xl">Understand how our platform works and your responsibilities</p>
        </div>
      </section>

      {/* Terms and Conditions Content */}
      <div className="max-w-4xl mx-auto px-4 py-10 text-gray-800 space-y-6">
        <h2 className="text-xl font-semibold">1. Acceptance of Terms</h2>
        <p>By using this website, you agree to be legally bound by our terms.</p>

        <h2 className="text-xl font-semibold">2. Services Overview</h2>
        <p>We provide a platform to connect users with local businesses across Hyderabad.</p>

        <h2 className="text-xl font-semibold">3. User Responsibilities</h2>
        <p>Users must not misuse listings or submit false or misleading information.</p>

        <h2 className="text-xl font-semibold">4. Account Creation</h2>
        <p>If you create an account, you are responsible for maintaining its confidentiality.</p>

        <h2 className="text-xl font-semibold">5. Business Listings</h2>
        <p>Businesses must provide accurate and up-to-date information in their listings.</p>

        <h2 className="text-xl font-semibold">6. Reviews and Ratings</h2>
        <p>Users must post honest and fair reviews. Fake or abusive reviews may be removed.</p>

        <h2 className="text-xl font-semibold">7. Intellectual Property</h2>
        <p>All website content is owned or licensed by us. Do not copy or redistribute without permission.</p>

        <h2 className="text-xl font-semibold">8. Privacy and Data</h2>
        <p>We collect and handle personal data in accordance with our Privacy Policy.</p>

        <h2 className="text-xl font-semibold">9. Termination</h2>
        <p>We reserve the right to suspend or terminate access for policy violations.</p>

        <h2 className="text-xl font-semibold">10. Third-Party Links</h2>
        <p>We are not responsible for the content or practices of external websites linked from our platform.</p>

        <h2 className="text-xl font-semibold">11. Limitation of Liability</h2>
        <p>We are not liable for damages or losses from the use of this platform or third-party services listed.</p>

        <h2 className="text-xl font-semibold">12. Modifications</h2>
        <p>We may update these Terms and will notify users via the site or email when changes occur.</p>

        <h2 className="text-xl font-semibold">13. Governing Law</h2>
        <p>These Terms are governed by the laws of India and disputes shall be handled in Hyderabad courts.</p>
      </div>
    </div>
  );
};

export default TermsPage;
