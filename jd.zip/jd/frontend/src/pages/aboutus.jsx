import React from "react";
import JustDialNavbar from "../components/Navbar";

const AboutUs = () => {
  return (
    <div className="font-sans">
        <JustDialNavbar />
      {/* Banner Section */}
      <div className="w-full h-48 sm:h-64 md:h-180 object-cover rounded-b-lg shadow">
        <img
          src="https://wallpapercave.com/wp/wp10257499.jpg"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Welcome Section */}
      <section className="max-w-5xl mx-auto p-6">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">
          Welcome to Explore Hyderabad
        </h1>
        <p className="text-gray-700 text-lg leading-relaxed">
          We are passionate about uncovering the vibrant culture, rich history,
          and modern marvels of Hyderabad, the City of Pearls. Whether you're a
          curious traveler, a food lover, or a heritage enthusiast, our platform
          brings you closer to the heart of Hyderabad.
        </p>
        <p className="text-gray-700 text-lg mt-2 leading-relaxed">
          From historical monuments to buzzing IT hubs, from aromatic biryanis
          to colorful bazaars — we’re here to guide you through it all.
        </p>
      </section>

      {/* Mission Section */}
      <section className="bg-gray-100 py-10">
        <div className="max-w-5xl mx-auto px-6">
          <h2 className="text-3xl font-semibold text-gray-800 mb-4">
            Our Mission
          </h2>
          <p className="text-gray-700 text-lg">
            To provide engaging, reliable, and up-to-date information about
            Hyderabad’s hidden gems, popular attractions, and local culture — so
            every visitor and resident can explore the city like never before.
          </p>
          <p className="text-gray-700 text-lg mt-2">
            We believe Hyderabad is more than just a destination — it's an
            experience. Our goal is to connect people with the essence of the
            city through curated guides, local insights, and cultural highlights.
          </p>
        </div>
      </section>

      {/* Facts Section */}
      <section className="py-10">
        <div className="max-w-5xl mx-auto px-6">
          <h2 className="text-3xl font-semibold text-gray-800 mb-6">
            Hyderabad at a Glance
          </h2>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-lg text-gray-700">
            <li>📍 <strong>Location:</strong> Capital of Telangana, India</li>
            <li>🏛️ <strong>Founded:</strong> 1591 by Muhammad Quli Qutb Shah</li>
            <li>🕌 <strong>Famous For:</strong> Charminar, Golconda Fort, Biryani</li>
            <li>🗣️ <strong>Languages:</strong> Telugu, Urdu, Hindi, English</li>
            <li>🌆 <strong>Nickname:</strong> City of Pearls, Cyberabad</li>
            <li>💼 <strong>Industries:</strong> IT, Biotech, Tourism</li>
            <li>✈️ <strong>Airport:</strong> Rajiv Gandhi International Airport</li>
          </ul>
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-indigo-600 text-white py-10">
        <div className="max-w-5xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold mb-2">
            Join Us on the Journey
          </h2>
          <p className="text-lg mb-4">
            Whether you're planning your first visit or rediscovering your hometown,
            <strong> Explore Hyderabad</strong> is your trusted companion.
          </p>
          <button className="bg-white text-indigo-600 font-semibold px-6 py-2 rounded hover:bg-gray-100 transition">
            Explore Now
          </button>
        </div>
      </section>
    </div>
  );
};

export default AboutUs;
