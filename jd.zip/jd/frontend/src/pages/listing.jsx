import React, { useState } from "react";
import JustDialNavbar from "../components/Navbar";

const ListYourShopPage = () => {
  const [activeFAQ, setActiveFAQ] = useState(null);

  const toggleFAQ = (index) => {
    setActiveFAQ(activeFAQ === index ? null : index);
  };

  return (
    <>
    <JustDialNavbar />
    
    <div className="font-sans text-gray-800">
      {/* HERO SECTION */}
      <section className="bg-gradient-to-r from-blue-50 to-blue-100 py-12 px-5 md:px-20 flex flex-col-reverse md:flex-row items-center justify-between">
        {/* Left Content */}
        <div className="flex-1 space-y-5">
          <h1 className="text-3xl md:text-5xl font-bold text-gray-900">
            <span className="text-blue-600">List Your Shop</span> and Grow Your Business
          </h1>
          <p className="text-gray-700 text-lg">
            Get discovered by millions of customers. Showcase your products and services online.
          </p>
          <button className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
            Get Started Today →
          </button>
          <ul className="mt-5 space-y-2 text-gray-700">
            <li>✅ Increase Your Online Visibility</li>
            <li>✅ Attract More Walk-in Customers</li>
            <li>✅ Build Trust with Verified Listings</li>
          </ul>
        </div>
        {/* Right Image */}
        <div className="flex-1 flex justify-center mb-5 md:mb-0">
          <img
            src="https://webneel.com/daily/sites/default/files/images/daily/06-2016/18-lg-washing-machine-print-ads-by-david-pinilla.jpg"
            alt="Shop Listing"
            className="w-64 md:w-80 rounded shadow"
          />
        </div>
      </section>

      {/* WHY LIST SECTION */}
      <section className="py-12 px-5 md:px-20 bg-white text-center">
        <h2 className="text-2xl md:text-3xl font-bold mb-6">
          Why List Your Shop on Our Platform?
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          {[
            {
              title: "Reach Millions",
              desc: "Showcase your business to a vast audience across India.",
            },
            {
              title: "Get Verified Leads",
              desc: "Connect with customers who are ready to buy.",
            },
            {
              title: "24x7 Visibility",
              desc: "Your shop is always online, even when you're closed.",
            },
          ].map((item, index) => (
            <div
              key={index}
              className="p-5 bg-blue-50 rounded-lg hover:shadow-md transition"
            >
              <img
                src="https://wallpapercave.com/wp/wp10257499.jpg"
                alt={item.title}
                className="mx-auto mb-3"
              />
              <h3 className="font-semibold text-lg">{item.title}</h3>
              <p className="text-gray-600">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* PLANS SECTION */}
      <section className="py-12 px-5 md:px-20 bg-gray-50 text-center">
        <h2 className="text-2xl md:text-3xl font-bold mb-6">
          Plans to Suit Every Business
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {[
            {
              name: "Starter",
              price: "₹99/mo",
              features: ["Basic Listing", "Customer Support", "Visibility Boost"],
            },
            {
              name: "Pro",
              price: "₹199/mo",
              features: ["Featured Listing", "Verified Badge", "Top Rankings"],
            },
            {
              name: "Premium",
              price: "₹399/mo",
              features: ["Priority Support", "Banner Ads", "Social Media Boost"],
            },
            {
              name: "Enterprise",
              price: "Custom",
              features: ["Tailored Solutions", "Dedicated Manager", "Max Reach"],
            },
          ].map((plan, index) => (
            <div
              key={index}
              className="p-6 bg-white rounded-lg shadow hover:shadow-lg transition"
            >
              <h3 className="text-xl font-semibold text-blue-600">{plan.name}</h3>
              <p className="text-2xl font-bold my-2">{plan.price}</p>
              <ul className="text-gray-600 space-y-1 mb-3">
                {plan.features.map((f, i) => (
                  <li key={i}>✔ {f}</li>
                ))}
              </ul>
              <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                Choose Plan
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-12 px-5 md:px-20 bg-white text-center">
        <h2 className="text-2xl md:text-3xl font-bold mb-6">
          Hear From Our Shop Owners
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {[
            {
              name: "Ramesh Kumar",
              shop: "Ramesh Electronics",
              quote:
                "Listing on this platform increased my sales by 50% in 3 months!",
            },
            {
              name: "Sunita Verma",
              shop: "Sunita’s Boutique",
              quote:
                "Now I get calls daily from customers in my city. Highly recommended!",
            },
            {
              name: "Ali Khan",
              shop: "Khan’s Bakery",
              quote:
                "My shop became the top search result in my area. Amazing service!",
            },
          ].map((t, index) => (
            <div
              key={index}
              className="p-5 border rounded-lg hover:shadow-md transition"
            >
              <p className="text-gray-600 italic mb-3">“{t.quote}”</p>
              <h4 className="font-semibold">{t.name}</h4>
              <p className="text-sm text-gray-500">{t.shop}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="py-12 px-5 md:px-20 bg-gray-50">
        <h2 className="text-2xl md:text-3xl font-bold mb-5 text-center">
          Frequently Asked Questions
        </h2>
        <div className="max-w-2xl mx-auto">
          {[
            "What is the benefit of listing my shop?",
            "How long does it take to get approved?",
            "Can I update my shop details later?",
          ].map((faq, index) => (
            <div
              key={index}
              onClick={() => toggleFAQ(index)}
              className="border-b py-3 cursor-pointer"
            >
              <div className="flex justify-between items-center">
                <p className="font-medium">{faq}</p>
                <span>{activeFAQ === index ? "▲" : "▼"}</span>
              </div>
              {activeFAQ === index && (
                <p className="text-gray-600 mt-2">
                  Yes! You can easily manage and update your shop details anytime.
                </p>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* CALL TO ACTION */}
      <section className="py-10 px-5 md:px-20 bg-blue-600 text-center text-white">
        <h2 className="text-2xl md:text-3xl font-bold mb-3">
          Ready to Grow Your Shop?
        </h2>
        <p className="mb-5">Join thousands of successful business owners today.</p>
        <button className="bg-white text-blue-600 font-semibold px-6 py-3 rounded hover:bg-gray-100">
          Start Listing Now →
        </button>
      </section>
    </div>
    </>
  );
};

export default ListYourShopPage;
