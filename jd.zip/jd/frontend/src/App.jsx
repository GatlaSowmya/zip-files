import reactLogo from './assets/react.svg';
import viteLogo from '/vite.svg';
import './App.css';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import UserProvider from './components/Login/UserContext';
import Login from './components/Login/Login';
import Signup from './components/Login/Signup';
import ForgotPassword from './components/Login/ForgotPassword';
import ResetPassword from './components/Login/ResetPassword';
import Home from './components/Home/home';
import { ToastContainer } from 'react-toastify';
import Profile from './components/Home/Profile';


import AdvertisePage from './pages/advertise';
import ListYourShop from './pages/listing';
import FAQSection from './pages/faq';

// Renamed for consistency
import TestimonialsPage from './pages/testimonials';
import AboutUs from './pages/aboutus';
import PopupAd from './components/popupad';
import SubcategoriesPage from './pages/catageorypages/SubcategoriesPage';
import SubcategoryDetailsPage from './pages/catageorypages/SubcategoryDetailsPage';
import CategoryPage from './components/Home/catageory';
import TermsPage from './pages/terms&conditions';
import PrivacyPage from './pages/privacy&policy';
import ShopDetailsPage from './pages/catageorypages/ShopDetailsPage.jsx';


function App() {
  return (
    <UserProvider>
      {/* <Navbar /> */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/categories" element={<CategoryPage />} />
        <Route path="/categories/:category" element={<SubcategoriesPage />} />
        <Route path="/categories/:category/:subcategory" element={<SubcategoryDetailsPage />} />
        <Route path="/categories/:category/:subcategory/:shopId" element={<ShopDetailsPage />} />
        <Route path="/advertise" element={<AdvertisePage />} />
        <Route path="/listing" element={<ListYourShop />} />
        <Route path="/faq" element={<FAQSection />} />
        <Route path="/terms" element={<TermsPage />} />
        <Route path="/privacy" element={<PrivacyPage />} />
        <Route path="/testimonials" element={<TestimonialsPage />} />
        <Route path="/about-us" element={<AboutUs />} />
        
      </Routes>
      <ToastContainer />
      <PopupAd />
      {/* <Footer /> */}
    </UserProvider>
  );
}

export default App;