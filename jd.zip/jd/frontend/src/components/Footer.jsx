import React from "react";
import { Link } from "react-router-dom";
import {
  FaFacebookF,
  FaYoutube,
  FaInstagram,
  FaLinkedinIn,
  FaXTwitter,
} from "react-icons/fa6";

const Footer = () => {
  const quickLinks = [
    { label: "About us", path: "/about-us" },
    { label: "We’re hiring", path: "/hiring" },
    { label: "Customer Care", path: "/customer-care" },
    { label: "Free Listing", path: "/listing" },
    { label: "What’s New", path: "/whats-new" },
    { label: "Report a Bug", path: "/report-bug" },
    { label: "B2B Sitemap", path: "/b2b-sitemap" },
    { label: "Sitemap", path: "/sitemap" },
  ];

  const moreLinks = [
    { label: "Advertise", path: "/advertise" },
    { label: "Testimonials", path: "/testimonials" },
    { label: "Feedback", path: "/feedback" },
    { label: "Jd Collection", path: "/jd-collection" },
    { label: "Terms & Conditions", path: "/terms" },
    { label: "Privacy & Policy", path: "/privacy" },
    { label: "FAQ'S", path: "/faq" },
  ];

  const verticals = [
    "B2B",
    "Advertising & Pr",
    "Business & Legal",
    "Energy",
    "Health & Medical",
    "Lights & Lighting",
    "Public",
    "Toys & Games",
    "All India",
    "Agriculture",
    "Chemicals",
    "Engineering",
    "Home & Garden",
    "Luggage Bags & Cases",
    "Restaurant",
    "Transportation & Shipping",
    "Doctors",
    "Apparel",
    "Construction & Real Estate",
    "Entertainment",
    "Housekeeping & Facility Mgmt",
    "Office & School Supplies",
    "Rubber & Plastics",
    "Travel",
    "Bills & Recharge",
    "Astrology",
    "Education",
    "Events & Wedding",
    "Industrial Plants & Machinery",
    "Packaging & Printing",
    "Security & Protection",
    "Watches & Eyewear",
    "Cricket",
    "Automobiles & Two Wheelers",
    "Electronic Component",
    "Food & Beverage",
    "It Components",
    "Pet & Pet Supplies",
    "Sports & Entertainment",
    "Accommodation",
    "Beauty & Personal Care",
    "Electronics",
    "Furniture",
    "Jewellery",
    "Placements",
    "Textile & Leather",
  ];

  // Create URL-friendly paths for verticals:
  const verticalToPath = (name) =>
    "/vertical/" + encodeURIComponent(name.toLowerCase().replace(/\s+/g, "-"));

  return (
    <footer className="bg-white text-sm text-gray-700 pt-8 border-t">
      {/* Social + App Row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between px-6 py-4 border-b gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
          <span className="font-medium">Follow us on</span>
          <div className="flex gap-3 text-xl">
            <FaFacebookF className="text-[#3b5998]" />
            <FaYoutube className="text-[#ff0000]" />
            <FaInstagram className="text-[#e4405f]" />
            <FaLinkedinIn className="text-[#0077b5]" />
            <FaXTwitter className="text-black" />
          </div>
        </div>
        <div className="flex gap-3">
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/78/Google_Play_Store_badge_EN.svg/512px-Google_Play_Store_badge_EN.svg.png"
            alt="Google Play"
            className="h-10"
          />
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/96/Download_on_the_App_Store_Badge.svg/512px-Download_on_the_App_Store_Badge.svg.png"
            alt="App Store"
            className="h-10"
          />
        </div>
      </div>

      {/* Links & Verticals */}
      <div className="px-6 py-10 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
        <div>
          <h3 className="font-semibold mb-2">Quick Links</h3>
          <ul className="space-y-1">
            {quickLinks.map(({ label, path }, i) => (
              <li key={i}>
                <Link to={path} className="hover:underline">
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-semibold mb-2">More Links</h3>
          <ul className="space-y-1">
            {moreLinks.map(({ label, path }, i) => (
              <li key={i}>
                <Link to={path} className="hover:underline">
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* JD Verticals */}
        <div className="sm:col-span-2 md:col-span-3 lg:col-span-4">
          <h3 className="font-semibold mb-2">JD Verticals</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {verticals.map((item, i) => (
              <Link
                key={i}
                to={verticalToPath(item)}
                className="hover:underline cursor-pointer block"
              >
                {item}
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Footer Bottom */}
      <div className="border-t text-center text-xs text-gray-500 py-4 px-6">
        Copyright © 2008–25. All Rights Reserved.{" "}
        <Link to="/privacy" className="underline">
          Privacy
        </Link>{" "}
        |{" "}
        <Link to="/terms" className="underline">
          Terms
        </Link>{" "}
        |{" "}
        <Link to="/infringement" className="underline">
          Infringement
        </Link>
      </div>
    </footer>
  );
};

export default Footer;
