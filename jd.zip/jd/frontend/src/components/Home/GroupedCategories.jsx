import React from "react";
import { useNavigate } from "react-router-dom";

const groupedCategories = [
  {
    title: "Wedding Requisites",
    items: [
      {
        name: "Banquet Halls",
        image:
          "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
        path: "banquet-halls",
      },
      {
        name: "Bridal Requisite",
        image:
          "https://images.unsplash.com/photo-1525610553991-2bede1a236e2?auto=format&fit=crop&w=800&q=80",
        path: "bridal-requisite",
      },
      {
        name: "Caterers",
        image:
          "https://images.unsplash.com/photo-1525610553991-2bede1a236e2?auto=format&fit=crop&w=800&q=80",
        path: "caterers",
      },
    ],
  },
  {
    title: "Beauty & Spa",
    items: [
      {
        name: "Beauty Parlours",
        image:
          "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=800&q=80",
        path: "beauty-parlours",
      },
      {
        name: "Spa & Massages",
        image:
          "https://images.unsplash.com/photo-1540206395-68808572332f?auto=format&fit=crop&w=800&q=80",
        path: "spa-massages",
      },
      {
        name: "Salons",
        image:
          "https://c8.alamy.com/comp/B25JFY/interior-view-of-hair-saloon-shop-B25JFY.jpg",
        path: "categories/beauty-and-spa/hair-styling-and-color",
      },
    ],
  },
  {
    title: "Repairs & Services",
    items: [
      {
        name: "AC Service",
        image:
          "https://minutemanheatingandac.com/wp-content/uploads/2019/08/Air-Conditioning-Service-in-Arlington-TX.jpg",
        path: "ac-service",
      },
      {
        name: "Car Service",
        image:
          "https://images.unsplash.com/photo-1502877338535-766e1452684a?auto=format&fit=crop&w=800&q=80",
        path: "car-service",
      },
      {
        name: "Bike Service",
        image:
          "https://images.unsplash.com/photo-1504215680853-026ed2a45def?auto=format&fit=crop&w=800&q=80",
        path: "bike-service",
      },
    ],
  },
  {
    title: "Daily Needs",
    items: [
      {
        name: "Movies",
        image:
          "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80",
        path: "movies",
      },
      {
        name: "Grocery",
        image:
          "https://images.unsplash.com/photo-1504610926078-a1611febcad3?auto=format&fit=crop&w=800&q=80",
        path: "grocery",
      },
      {
        name: "Electricians",
        image:
          "https://images.unsplash.com/photo-1556745753-b2904692b3cd?auto=format&fit=crop&w=800&q=80",
        path: "electricians",
      },
    ],
  },
];

const GroupedCategories = () => {
  const navigate = useNavigate();

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8">
      {/* Two groups per row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {groupedCategories.map((group, index) => (
          <div
            key={index}
            className="md:border rounded-xl p-4 md:p-6 shadow-sm hover:shadow-md transition"
          >
            <h2 className="text-lg md:text-xl font-semibold mb-4">{group.title}</h2>

            {/* Scrollable on small screens */}
            <div className="flex md:grid md:grid-cols-3 gap-4 overflow-x-auto scrollbar-hide">
              {group.items.map((item, idx) => (
                <div
                  key={idx}
                  className="min-w-[120px] md:min-w-0 text-center flex-shrink-0 cursor-pointer"
                  onClick={() => navigate(`/${item.path}`)}
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="rounded-xl h-24 md:h-28 w-full object-cover"
                  />
                  <p className="mt-2 text-sm md:text-base font-medium">{item.name}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GroupedCategories;
