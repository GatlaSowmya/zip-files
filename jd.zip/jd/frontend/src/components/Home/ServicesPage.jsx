import React from "react";
import {
  FaMobileAlt,
  FaBolt,
  FaSatelliteDish,
  FaTint,
  FaGasPump,
  FaUmbrella,
  FaPlane,
  FaBus,
  FaTrain,
  FaHotel,
  FaCar,
} from "react-icons/fa";
import "./ServicesPage.css"; // Import the CSS file

// Services data with icons
const services = [
  {
    category: "Bills & Recharge",
    description: "Pay your bills & recharge instantly with Justdial",
    items: [
      { name: "Mobile", icon: <FaMobileAlt /> },
      { name: "Electricity", icon: <FaBolt /> },
      { name: "DTH", icon: <FaSatelliteDish /> },
      { name: "Water", icon: <FaTint /> },
      { name: "Gas", icon: <FaGasPump /> },
      { name: "Insurance", icon: <FaUmbrella /> },
    ],
  },
  {
    category: "Travel Bookings",
    description: "Instant ticket bookings for your best travel experience",
    items: [
      { name: "Flight", subtitle: "Powered By Easemytrip.com", icon: <FaPlane /> },
      { name: "Bus", subtitle: "Affordable Rides", icon: <FaBus /> },
      { name: "Train", icon: <FaTrain /> },
      { name: "Hotel", subtitle: "Budget-friendly Stay", icon: <FaHotel /> },
      { name: "Car Rentals", subtitle: "Drive Easy Anywhere", icon: <FaCar /> },
    ],
  },
];

// Trending section with reliable image URLs and fallbacks
const trending = [
  {
    name: "Tiffin Services",
    image: "https://picsum.photos/200/100?random=1",
    fallback: "https://indofast.in/uploaded_files/product_gallery/greaternoidaweb_Tiffin-Services-in-Greater_Noida_f15267c3-a_14-07-2016111521gWEE.jpg",
  },  
  {
    name: "Archery Classes",
    image: "https://picsum.photos/200/100?random=2",
    fallback: "https://images.squarespace-cdn.com/content/v1/5be74e88fcf7fdb5fe800d5c/1570659307147-3VYR5QW9ROTWY5Y2FKNW/IMG_1435.jpg",
  },
  {
    name: "Yoga Classes",
    image: "https://picsum.photos/200/100?random=3",
    fallback: "https://static.nike.com/a/images/f_auto/dpr_1.0,cs_srgb/w_1824,c_limit/e0e019e5-1900-4f93-af74-5022f281cf0c/the-7-best-yoga-poses-for-beginners-according-to-yoga-instructors.jpg",
  },
  {
    name: "Coffee Shops",
    image: "https://picsum.photos/200/100?random=4",
    fallback: "https://tse2.mm.bing.net/th/id/OIP.x-pxLtmbATf5hS2xd_ozqwHaFi?rs=1&pid=ImgDetMain&o=7&rm=3",
  },
];

export default function ServicesPage() {
  return (
    <div className="p-4 space-y-10">
      {/* Services section */}
      {services.map((section, index) => (
        <div key={index} className="bg-white shadow rounded-xl p-6">
          <h2 className="text-2xl font-bold mb-2">{section.category}</h2>
          <p className="text-sm text-gray-600 mb-4">{section.description}</p>
          <div className="overflow-x-auto hide-scrollbar">
            <div className="flex sm:grid sm:grid-cols-3 md:grid-cols-6 gap-4 w-max sm:w-auto">
              {section.items.map((item, idx) => (
                <div key={idx} className="flex flex-col items-center text-center min-w-[80px]">
                  <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center shadow text-xl">
                    {item.icon}
                  </div>
                  <span className="mt-2 font-medium text-sm">{item.name}</span>
                  {item.subtitle && (
                    <span className="text-xs text-green-600 text-center">
                      {item.subtitle}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}

      {/* Trending section */}
      <div className="bg-white shadow rounded-xl p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">Trending Searches Near You</h2>
          <span className="text-xs text-white bg-red-600 px-2 py-0.5 rounded">NEW</span>
        </div>
        <p className="text-sm text-gray-600 mb-4">
          Stay updated with the latest local trends.
        </p>
        <div className="overflow-x-auto hide-scrollbar">
          <div className="flex gap-4 w-max sm:w-auto sm:grid sm:grid-cols-2 md:grid-cols-4">
            {trending.map((item, index) => (
              <div
                key={index}
                className="bg-gray-100 p-4 rounded-lg shadow hover:shadow-md transition duration-300 min-w-[180px] sm:min-w-0"
              >
                <div className="h-28 rounded mb-2 flex items-center justify-center">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="h-30 w-full object-contain"
                    onError={(e) => {
                      e.target.src = item.fallback; // Use fallback image on error
                    }}
                  />
                </div>
                <div className="font-medium text-lg">{item.name}</div>
                <a className="text-blue-600 text-sm" href="#">
                  Explore ›
                </a>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}