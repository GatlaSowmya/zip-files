// src/components/Home.jsx
import React from 'react';

import JustDialNavbar from '../Navbar';
import GroupedCategories from './GroupedCategories';
import MovieAndTourist from './movie';
import Footer from '../Footer';
import CategoriesPage from './catageory';
import ServicesPage from './ServicesPage';

const Home = () => {
  return (
    <div >
        <JustDialNavbar/>
      <CategoriesPage />
      <GroupedCategories/>
      <ServicesPage />
      <MovieAndTourist/>
      <Footer/>
    </div>
  );
};

export default Home;
