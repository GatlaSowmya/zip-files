import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import JustDialNavbar from "../../components/Navbar";
import Footer from "../../components/Footer";
import { FaAngleDown } from "react-icons/fa";
import { MdArrowForwardIos, MdArrowBackIos } from "react-icons/md";
import api from "../../config"; // ✅ Use custom API instance

const CategoryPage = () => {
  const navigate = useNavigate();
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true); 
  const [error, setError] = useState(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showAllMobile, setShowAllMobile] = useState(false);

  const sliderImages = [
    "https://picsum.photos/600/400?random=1",
    "https://picsum.photos/600/400?random=2",
    "https://picsum.photos/600/400?random=3",
    "https://picsum.photos/600/400?random=4",
    "https://picsum.photos/600/400?random=5",
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % sliderImages.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [sliderImages.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % sliderImages.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + sliderImages.length) % sliderImages.length);
  };

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        setLoading(true);
        const response = await api.get("/categories"); // ✅ Use custom API instance here
        const transformedCategories = response.data.map((cat) => ({
          id: cat.category_id,
          label: cat.category_name,
          icon: cat.icon_url || `https://picsum.photos/48/48?random=${cat.category_id}`,
          path: cat.category_name.toLowerCase().replace(/\s+/g, "-"),
        }));
        setCategories(transformedCategories);
        setLoading(false);
      } catch (err) {
        setError(err.message || "Failed to fetch categories. Please try again later.");
        setLoading(false);
      }
    };

    fetchCategories();
  }, []);

  const handleNavigate = (path) => {
    navigate(`/categories/${path}`);
  };

  return (
    <>
      {/* <JustDialNavbar /> */}
      <div className="w-full">
        <div className="max-w-7xl mx-auto px-4 py-8">
          {/* Hero Slider and Ads */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="relative col-span-2 h-64 sm:h-80 md:h-96 rounded-xl overflow-hidden">
              <img
                src={sliderImages[currentSlide]}
                alt="Slider"
                className="w-full h-full object-cover transition duration-700 ease-in-out"
                onError={(e) => {
                  e.target.src = "https://picsum.photos/600/400?random=0";
                }}
              />
              <button
                onClick={prevSlide}
                className="absolute top-1/2 left-2 transform -translate-y-1/2 bg-gray-100 text-gray-800 rounded-full p-1 shadow hover:bg-gray-200"
              >
                <MdArrowBackIos size={20} />
              </button>
              <button
                onClick={nextSlide}
                className="absolute top-1/2 right-2 transform -translate-y-1/2 bg-gray-100 text-gray-800 rounded-full p-1 shadow hover:bg-gray-200"
              >
                <MdArrowForwardIos size={20} />
              </button>
            </div>
            <div className="flex flex-col gap-4">
              <div className="h-24 sm:h-36 md:h-48 bg-gray-200 rounded-xl flex items-center justify-center text-lg font-bold text-gray-500">
                AD
              </div>
              <div className="h-24 sm:h-36 md:h-48 bg-gray-200 rounded-xl flex items-center justify-center text-lg font-bold text-gray-500">
                AD
              </div>
            </div>
          </div>

          {/* Loading/Error States */}
          {loading && (
            <div className="text-center py-8 text-gray-600">Loading categories...</div>
          )}
          {error && (
            <div className="text-center py-8 text-red-500">{error}</div>
          )}
          {!loading && !error && categories.length === 0 && (
            <div className="text-center py-8 text-gray-600">No categories available.</div>
          )}

          {/* ✅ Desktop Category Grid */}
          {!loading && !error && categories.length > 0 && (
            <div className="hidden sm:grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => handleNavigate(cat.path)}
                  className="flex flex-col items-center text-center gap-2 p-4 rounded-lg shadow-md hover:shadow-lg hover:bg-gray-50 transition duration-200 bg-white"
                >
                  <img
                    src={cat.icon}
                    alt={cat.label}
                    className="w-12 h-12 sm:w-14 sm:h-14 rounded-full border p-1"
                    loading="lazy"
                    onError={(e) => {
                      e.target.src = "https://picsum.photos/48/48?random=0";
                    }}
                  />
                  <span className="font-semibold text-base sm:text-lg">{cat.label}</span>
                </button>
              ))}
            </div>
          )}

          {/* ✅ Mobile Category Grid */}
          {!loading && !error && (
            <div className="sm:hidden mt-4 px-4 grid grid-cols-4 gap-3">
              {!showAllMobile && categories.length > 7
                ? [
                    ...categories.slice(0, 6).map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => handleNavigate(cat.path)}
                        className="flex flex-col items-center gap-1 text-xs"
                      >
                        <img
                          src={cat.icon}
                          alt={cat.label}
                          className="w-10 h-10 rounded-full border p-1"
                          loading="lazy"
                          onError={(e) => {
                            e.target.src = "https://picsum.photos/48/48?random=0";
                          }}
                        />
                        <span>{cat.label}</span>
                      </button>
                    )),
                    <button
                      key="show-more"
                      onClick={() => setShowAllMobile(true)}
                      className="flex flex-col items-center gap-1 text-xs text-blue-600"
                    >
                      <div className="w-10 h-10 rounded-full border flex items-center justify-center">
                        <FaAngleDown size={16} />
                      </div>
                      <span>Show More</span>
                    </button>,
                  ]
                : categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => handleNavigate(cat.path)}
                      className="flex flex-col items-center gap-1 text-xs"
                    >
                      <img
                        src={cat.icon}
                        alt={cat.label}
                        className="w-10 h-10 rounded-full border p-1"
                        loading="lazy"
                        onError={(e) => {
                          e.target.src = "https://picsum.photos/48/48?random=0";
                        }}
                      />
                      <span>{cat.label}</span>
                    </button>
                  ))}
            </div>
          )}
        </div>
      </div>
      {/* <Footer /> */}
    </>
  );
};

export default CategoryPage;
