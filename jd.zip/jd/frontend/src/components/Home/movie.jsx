import React from 'react';

// Sample Data
const movies = [
  { title: 'RRR', lang: 'Telugu', type: '2D', rating: 89, img: 'https://tse2.mm.bing.net/th/id/OIP.3J_XhLeePKuDY1uTpgEPZAHaLH?cb=thvnextc1&rs=1&pid=ImgDetMain&o=7&rm=3' },
  { title: 'Jurassic World Rebirth', lang: 'English', type: '2D', rating: 74, img: 'https://thenerdstemplar.com/wp-content/uploads/2025/07/jurassic-world-rebirth.jpg' },
  { title: 'Sitaare Zameen Par', lang: 'Hindi', type: '2D', rating: 74, img: 'https://newsd.in/wp-content/uploads/2025/06/Sitaare-Zameen-Par-Box-Office-Day-1.jpg' },
  { title: 'Maa (2025 Film)', lang: 'Hindi', type: '2D', rating: 66, img: 'https://7vegamovies.com.in/wp-content/uploads/2025/06/maa-2025.webp' },
  { title: 'F1', lang: 'English', type: '2D', rating: 90, img: 'https://media.wired.com/photos/62cf4503477359e75adac439/master/w_2560%2Cc_limit/F1-2022-EA-Games.jpg' },
  { title: 'Jarann', lang: 'Marathi', type: '2D', rating: 60, img: 'https://tse1.mm.bing.net/th/id/OIP.0Cbp2p7V-Ua1Hwup9l5caAHaEK?cb=thvnextc1&rs=1&pid=ImgDetMain&o=7&rm=3' },
  { title: 'Kannappa', lang: 'Tamil', type: '2D', rating: 78, img: 'https://assets.telegraphindia.com/telegraph/2025/Jun/1750943682_kannappa.jpg' },
  { title: 'KGF 2', lang: 'Kannada', type: '2D', rating: 88, img: 'https://i.ytimg.com/vi/UumgwY1ZXUk/maxresdefault.jpg' },
  { title: 'Pathaan', lang: 'Hindi', type: '2D', rating: 70, img: 'https://tse1.mm.bing.net/th/id/OIP.3bwnQNtv4t-8Kgi20qsBtQHaNK?cb=thvnextc1&rs=1&pid=ImgDetMain&o=7&rm=3' },
  { title: 'Avatar 2', lang: 'English', type: '3D', rating: 92, img: 'https://tse3.mm.bing.net/th/id/OIP.Dno4H4yht2KGtVh_2UrKawHaLH?cb=thvnextc1&rs=1&pid=ImgDetMain&o=7&rm=3' },
  { title: 'RRR', lang: 'Telugu', type: '2D', rating: 89, img: 'https://tse2.mm.bing.net/th/id/OIP.3J_XhLeePKuDY1uTpgEPZAHaLH?cb=thvnextc1&rs=1&pid=ImgDetMain&o=7&rm=3' },
  { title: 'Dunki', lang: 'Hindi', type: '2D', rating: 76, img: 'https://ibomma.movie/wp-content/uploads/2023/12/dunki-movie.webp' },
  { title: 'Tiger 3', lang: 'Hindi', type: '2D', rating: 69, img: 'https://resizing.flixster.com/EhnZhhnlXPpQk_tXymRE5RpssVs=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2VjMDc3ODZmLTUyOTEtNGE1NC04NzM5LTQyZGJkMjQxMWM1ZC5qcGc=' },
  { title: 'Mission Impossible', lang: 'English', type: '2D', rating: 85, img: 'https://cdnb.artstation.com/p/assets/images/images/063/951/705/large/rahal-nejraoui-mission-impossible-dex-reckoning-part-2-poster-by-rahalarts.jpg?1686752613' },
  { title: 'Spiderman No Way Home', lang: 'English', type: '3D', rating: 94, img: 'https://www.sonypictures.in/sites/india/files/2022-03/SPIDERMANNOWAYHOME_English(US)%20(1).jpg' },
  { title: 'Pushpa 2', lang: 'Telugu', type: '2D', rating: 80, img: 'https://media5.bollywoodhungama.in/wp-content/uploads/2024/10/Pushpa-2-The-Rule.jpg' },
  { title: 'Salaar', lang: 'Kannada', type: '2D', rating: 83, img: 'https://imgeng.jagran.com/images/2025/03/16/article/image/Prabhas-(2)-1742093578188.png' },
  { title: 'Jawan', lang: 'Hindi', type: '2D', rating: 77, img: 'https://www.layar.id/wp-content/uploads/2023/09/322516891_2137178746485050_6822398867233007452_n-1.jpg' },
  { title: 'The Marvels', lang: 'English', type: '2D', rating: 73, img: 'https://www.dolby.com/siteassets/xf-site/content-detail-pages/tm_dc_2x3.jpg' },
  { title: 'Leo', lang: 'Tamil', type: '2D', rating: 82, img: 'https://mir-s3-cdn-cf.behance.net/project_modules/fs/d23f41184733377.65571621a3846.jpg' },
  { title: 'The Batman', lang: 'English', type: '2D', rating: 91, img: 'https://assets-prd.ignimgs.com/2022/01/26/thebatman-newbutton-1643232430643.jpg' },
];

const touristPlaces = [
  {
    name: 'Charminar',
    img: 'https://th.bing.com/th/id/R.1a3fabe9238036a5f16cb4b666874356?rik=TLD87kxDbUVcLw&riu=http%3a%2f%2fdynamic.tourtravelworld.com%2fhotspot-images%2fcharminar-hyderabad-1912.jpg&ehk=Vqi0%2bZBpiySYc4ZvGuZXNCBz1p7DPhAuN7hJFjujzmI%3d&risl=&pid=ImgRaw&r=0'
  },
  {
    name: 'Hussain Sagar Lake',
    img: 'https://static.toiimg.com/photo/62379342/.jpg'
  },
  {
    name: 'Ramoji Film City',
    img: 'https://static2.tripoto.com/media/filter/nl/img/189328/TripDocument/1449996535_dsc_3808.jpg'
  },
  {
    name: 'Golconda Fort',
    img: 'https://th.bing.com/th/id/R.b00a3e5fe81b6b4fd0ffe069b13876d8?rik=p56tYV8pggFuFA&riu=http%3a%2f%2fimage3.mouthshut.com%2fimages%2fimagesp%2f925667402s.jpg&ehk=Gepx51hsFB0R7ViTBGfLtRm2TgTTqP7TaXnkuxiX1vw%3d&risl=1&pid=ImgRaw&r=0'
  },
  {
    name: 'Chowmahalla Palace',
    img: 'https://www.hyderabadtourism.travel/images/v2/header-places/chowmahalla-palace-hyderabad-tourism-entryfee-timings-reviews-header.jpg'
  },
  {
    name: 'Birla Mandir',
    img: 'https://media.tripinvites.com/places/hyderabad/birla-mandir/birla-mandir-hyderabad-featured.jpg'
  }
];

const MovieAndTourist = () => {
  return (
    <div className="p-4 md:p-8 space-y-10">
      {/* Latest Movies Section */}
      <div>
        <h2 className="text-xl font-bold mb-4">Latest Movies & Review</h2>
        <div className="flex overflow-x-auto hide-scrollbar snap-x snap-mandatory space-x-4">
          {movies.map((movie, index) => (
            <div key={index} className="snap-start flex-shrink-0 w-36 md:w-40 space-y-1">
              <img
                src={movie.img}
                alt={movie.title}
                className="rounded-lg h-52 object-cover w-full"
              />
              <p className="text-sm font-medium truncate">{movie.title}</p>
              <p className="text-xs text-gray-500">{movie.lang} • {movie.type}</p>
              {movie.rating && (
                <div className="inline-block text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded">
                  👍 {movie.rating}%
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Tourist Places Section */}
      <div className="bg-white shadow rounded-xl p-6">
        <div className="flex items-center mb-4 gap-2">
          <h2 className="text-xl font-bold">Explore Top Tourist Places</h2>
          <span className="text-xs bg-red-600 text-white px-2 py-0.5 rounded">NEW</span>
        </div>
        <div className="flex overflow-x-auto hide-scrollbar snap-x snap-mandatory space-x-4">
          {touristPlaces.map((place, index) => (
            <div
              key={index}
              className="snap-start flex-shrink-0 w-44 bg-white rounded-xl shadow overflow-hidden hover:shadow-md transition"
            >
              <img
                src={place.img}
                alt={place.name}
                className="h-24 w-full object-cover"
              />
              <div className="p-2">
                <p className="font-semibold text-sm">{place.name}</p>
                <a href="#" className="text-blue-600 text-sm hover:underline">Explore ›</a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MovieAndTourist;
