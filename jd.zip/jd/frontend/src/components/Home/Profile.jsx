import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { useUser } from '../Login/UserContext';
import { User } from 'lucide-react';
import {jwtDecode} from 'jwt-decode';
import api from '../../config'; // Use centralized axios instance

const cartoonIcons = [
  'https://avatars.dicebear.com/api/avataaars/alice.svg',
  'https://avatars.dicebear.com/api/avataaars/bob.svg',
  'https://avatars.dicebear.com/api/avataaars/carol.svg',
];

const Profile = () => {
  const navigate = useNavigate();
  const {
    userName,
    userPhone1,
    userAbout,
    userImage,
    setUserName,
    setUserPhone1,
    setUserAbout,
    setUserImage,
  } = useUser();

  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(userName || '');
  const [phone1, setPhone1] = useState(userPhone1 || '');
  const [about, setAbout] = useState(userAbout || '');
  const [image, setImage] = useState(userImage || null);
  const [error, setError] = useState('');

  // Check if token is expired
  const isTokenExpired = (token) => {
    try {
      const decoded = jwtDecode(token);
      return decoded.exp < Date.now() / 1000;
    } catch {
      return true;
    }
  };

  // Fetch user profile on mount
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token || isTokenExpired(token)) {
      toast.error('Session expired. Please log in.');
      localStorage.removeItem('token');
      localStorage.removeItem('user_name');
      navigate('/login');
      return;
    }

    api
      .get('/user')
      .then((res) => {
        const data = res.data;
        setName(data.user_name || '');
        setPhone1(data.user_phone1 || '');
        setAbout(data.about || '');
        setImage(data.profile_image || null);

        setUserName(data.user_name);
        setUserPhone1(data.user_phone1);
        setUserAbout(data.about);
        setUserImage(data.profile_image || null);
      })
      .catch((err) => {
        toast.error(err.response?.data?.message || 'Failed to load profile');
        if (err.response?.status === 401) {
          localStorage.removeItem('token');
          navigate('/login');
        }
      });
  }, [navigate, setUserName, setUserPhone1, setUserAbout, setUserImage]);

  // Handle image file upload
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        toast.error('Image size must be less than 2MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => setImage(reader.result);
      reader.readAsDataURL(file);
    }
  };

  // Select cartoon icon as profile image
  const handleCartoonSelect = (iconUrl) => setImage(iconUrl);

  // Submit updated profile
  const handleSubmit = async () => {
    setError('');
    if (!name || name.length < 3) {
      return toast.error('Name must be at least 3 characters');
    }
    if (!/^\d{10}$/.test(phone1)) {
      return toast.error('Phone number must be 10 digits');
    }

    try {
      await api.put('/user/update', {
        user_name: name,
        user_phone1: phone1,
        about,
        profile_image: image,
      });

      setUserName(name);
      setUserPhone1(phone1);
      setUserAbout(about);
      setUserImage(image);
      localStorage.setItem('user_name', name);
      toast.success('Profile updated successfully');
      setIsEditing(false);
    } catch (err) {
      const message = err.response?.data?.message || 'Failed to update profile';
      if (err.response?.status === 413) {
        toast.error('Uploaded image is too large. Please use an image under 2MB.');
      } else {
        toast.error(message);
      }
    }
  };

  // Logout user
  const handleLogout = () => {
    if (window.confirm('Are you sure you want to logout?')) {
      localStorage.removeItem('token');
      localStorage.removeItem('user_name');
      setUserName('');
      setUserPhone1('');
      setUserAbout('');
      setUserImage(null);
      toast.success('Logged out successfully');
      navigate('/login');
    } else {
      toast.info('Logout cancelled');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
      <div className="w-full max-w-md bg-white p-8 rounded-lg shadow-md space-y-6">
        <h2 className="text-2xl font-semibold text-center text-gray-800">Profile</h2>
        {error && <p className="text-red-500 text-center text-sm">{error}</p>}

        {isEditing ? (
          <>
            <div className="flex justify-center">
              {image ? (
                <img
                  src={image}
                  alt="Profile"
                  className="w-24 h-24 rounded-full object-cover"
                />
              ) : (
                <User size={96} className="text-gray-600" />
              )}
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium text-gray-600">Select a cartoon icon:</p>
              <div className="flex justify-center gap-2">
                {cartoonIcons.map((icon, i) => (
                  <img
                    key={i}
                    src={icon}
                    alt={`cartoon-${i}`}
                    className={`w-12 h-12 rounded-full cursor-pointer border-2 ${
                      image === icon ? 'border-blue-600' : 'border-transparent'
                    }`}
                    onClick={() => handleCartoonSelect(icon)}
                  />
                ))}
              </div>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="w-full px-4 py-2 border rounded focus:outline-none"
              />
            </div>

            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Name"
              className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
            <input
              type="text"
              value={phone1}
              onChange={(e) => setPhone1(e.target.value)}
              placeholder="Phone Number"
              className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
            <textarea
              value={about}
              onChange={(e) => setAbout(e.target.value)}
              placeholder="About"
              rows={4}
              className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
            />

            <button
              onClick={handleSubmit}
              className="w-full py-2 bg-blue-600 text-white font-semibold rounded hover:bg-blue-700 transition"
            >
              Save Changes
            </button>
            <button
              onClick={() => setIsEditing(false)}
              className="w-full py-2 bg-gray-600 text-white font-semibold rounded hover:bg-gray-700 transition"
            >
              Cancel
            </button>
          </>
        ) : (
          <>
            <div className="flex justify-center">
              {userImage ? (
                <img
                  src={userImage}
                  alt="Profile"
                  className="w-24 h-24 rounded-full object-cover"
                />
              ) : (
                <User size={96} className="text-gray-600" />
              )}
            </div>

            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium text-gray-600">Name</p>
                <p className="text-lg">{userName || 'No name set'}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">Phone Number</p>
                <p className="text-lg">{userPhone1 || 'No phone number'}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">About</p>
                <p className="text-lg">{userAbout || 'No about info'}</p>
              </div>
            </div>

            <button
              onClick={() => setIsEditing(true)}
              className="w-full py-2 bg-blue-600 text-white font-semibold rounded hover:bg-blue-700 transition"
            >
              Edit Profile
            </button>
            <button
              onClick={() => navigate('/')}
              className="w-full py-2 bg-gray-600 text-white font-semibold rounded hover:bg-gray-700 transition"
            >
              Back to Home
            </button>
            <button
              onClick={handleLogout}
              className="w-full py-2 bg-red-600 text-white font-semibold rounded hover:bg-red-700 transition"
            >
              Logout
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default Profile;
