import React, { useState, useEffect } from "react";

const PopupAd = () => {
  const [showAd, setShowAd] = useState(false);

  useEffect(() => {
    const isDesktop = window.innerWidth >= 768;
    if (isDesktop) {
      setShowAd(true);
    }
  }, []);

  if (!showAd) return null;

  return (
    
    <div className="fixed bottom-4 left-280 transform -translate-x-1/2 z-50 w-full max-w-md px-7">
      <div
        className="relative w-full h-54 rounded-lg shadow-lg border border-gray-300 overflow-hidden
        bg-cover bg-center transition-transform duration-500 ease-in-out scale-95 hover:scale-100"
        style={{
          backgroundImage:
            "url('https://wallpapercave.com/wp/wp10257499.jpg')",
        }}
      >
        <button
          onClick={() => setShowAd(false)}
          className="absolute top-2 right-2 text-white text-xl font-bold hover:text-gray-200 transition-transform duration-300 hover:scale-110"
          aria-label="Close"
        >
          &times;
        </button>
      </div>
    </div>
  );
};

export default PopupAd;
