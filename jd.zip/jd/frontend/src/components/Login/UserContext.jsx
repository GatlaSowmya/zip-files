import React, { createContext, useContext, useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import api from '../../config';

const UserContext = createContext({
  userId: null,
  userName: null,
  userPhone1: null,
  userAbout: null,
  userImage: null,
  setUserId: () => {},
  setUserName: () => {},
  setUserPhone1: () => {},
  setUserAbout: () => {},
  setUserImage: () => {},
  logout: () => {},
});

export const UserProvider = ({ children }) => {
  const [userId, setUserId] = useState(localStorage.getItem('user_id') || null);
  const [userName, setUserName] = useState(localStorage.getItem('user_name') || null);
  const [userPhone1, setUserPhone1] = useState(null);
  const [userAbout, setUserAbout] = useState(null);
  const [userImage, setUserImage] = useState(null);
  const location = useLocation();
  const navigate = useNavigate();
  const [hasLoggedNoToken, setHasLoggedNoToken] = useState(false);

  useEffect(() => {
    const verifyToken = async () => {
      const token = localStorage.getItem('token');
      const storedUserId = localStorage.getItem('user_id');
      const storedName = localStorage.getItem('user_name');

      if (location.pathname === '/auth/google/success') {
        const params = new URLSearchParams(location.search);
        const token = params.get('token');
        const user_id = params.get('user_id');
        const user_name = decodeURIComponent(params.get('user_name') || '');
        const user_email = decodeURIComponent(params.get('user_email') || '');
        const profile_image = decodeURIComponent(params.get('profile_image') || '') || null;

        if (token && user_id && user_name && user_email) {
          console.log('[UserContext] Google OAuth success, userId:', user_id, { user_name, user_email });
          localStorage.setItem('token', token);
          localStorage.setItem('user_id', user_id);
          localStorage.setItem('user_name', user_name);
          setUserId(user_id);
          setUserName(user_name);
          setUserImage(profile_image);
          try {
            const res = await api.get('/user', {
              headers: { Authorization: `Bearer ${token}` },
            });
            console.log('[UserContext] Fetched user details, userId:', res.data.user_id, {
              user_phone1: res.data.user_phone1,
              about: res.data.about,
              profile_image: res.data.profile_image,
            });
            setUserPhone1(res.data.user_phone1 || null);
            setUserAbout(res.data.about || null);
            setUserImage(res.data.profile_image || profile_image);
            toast.success('Google login successful');
            navigate('/');
          } catch (err) {
            console.error('[UserContext] Error fetching user details after Google login, userId:', user_id, {
              message: err.message,
              response: err.response?.data,
              status: err.response?.status,
            });
            toast.error('Failed to load user details. Please log in again.');
            localStorage.removeItem('token');
            localStorage.removeItem('user_id');
            localStorage.removeItem('user_name');
            setUserId(null);
            setUserName(null);
            setUserImage(null);
            navigate('/login');
          }
        } else {
          console.error('[UserContext] Invalid Google login data, userId:', user_id, {
            token,
            user_name,
            user_email,
          });
          toast.error('Invalid Google login data');
          navigate('/login');
        }
      } else if (token && storedUserId && storedName) {
        console.log('[UserContext] Verifying token, userId:', storedUserId, { user_name: storedName });
        try {
          await api.get('/auth/verify', {
            headers: { Authorization: `Bearer ${token}` },
          });
          setUserId(storedUserId);
          setUserName(storedName);
          try {
            const userRes = await api.get('/user', {
              headers: { Authorization: `Bearer ${token}` },
            });
            console.log('[UserContext] Fetched user details during verification, userId:', userRes.data.user_id, {
              user_phone1: userRes.data.user_phone1,
              about: userRes.data.about,
              profile_image: userRes.data.profile_image,
            });
            setUserPhone1(userRes.data.user_phone1 || null);
            setUserAbout(userRes.data.about || null);
            setUserImage(userRes.data.profile_image || null);
          } catch (userErr) {
            console.error('[UserContext] Error fetching user details, userId:', storedUserId, {
              message: userErr.message,
              response: userErr.response?.data,
              status: userErr.response?.status,
            });
          }
        } catch (verifyErr) {
          console.error('[UserContext] Token verification failed, userId:', storedUserId, {
            message: verifyErr.message,
            response: verifyErr.response?.data,
            status: verifyErr.response?.status,
          });
          if (verifyErr.response?.status === 401 || verifyErr.response?.status === 403) {
            localStorage.removeItem('token');
            localStorage.removeItem('user_id');
            localStorage.removeItem('user_name');
            setUserId(null);
            setUserName(null);
            setUserPhone1(null);
            setUserAbout(null);
            setUserImage(null);
            toast.error('Session expired. Please log in again.');
            navigate('/login');
          } else {
            console.warn('[UserContext] Non-auth error during token verification, retaining session, userId:', storedUserId);
          }
        }
      } else if (!hasLoggedNoToken) {
        console.log('[UserContext] No token or user data found, userId:', null);
        setHasLoggedNoToken(true);
      }
    };
    verifyToken();
  }, [location, navigate]);

  const logout = () => {
    console.log('[UserContext] Logging out, userId:', userId);
    localStorage.removeItem('token');
    localStorage.removeItem('user_id');
    localStorage.removeItem('user_name');
    setUserId(null);
    setUserName(null);
    setUserPhone1(null);
    setUserAbout(null);
    setUserImage(null);
    setHasLoggedNoToken(false);
    toast.success('Logged out successfully');
    navigate('/');
  };

  return (
    <UserContext.Provider
      value={{
        userId,
        userName,
        userPhone1,
        userAbout,
        userImage,
        setUserId,
        setUserName,
        setUserPhone1,
        setUserAbout,
        setUserImage,
        logout,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    console.error('useUser must be used within a UserProvider');
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

export default UserProvider;