
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import api from '../../config'; // Import the centralized API config

const ForgotPassword = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    setError('');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Invalid email format');
      toast.error('Invalid email format');
      return;
    }
    try {
      console.log('[ForgotPassword] Sending OTP for email:', email);
      await api.post('/forgot-password', { user_email: email });
      toast.success('OTP sent to your email');
      navigate('/reset-password', { state: { email } });
    } catch (err) {
      const message = err.response?.data?.message || 'Failed to send OTP';
      console.error('[ForgotPassword] Error:', {
        message: err.message,
        response: err.response?.data,
        status: err.response?.status,
      });
      setError(message);
      toast.error(message);
    }
  };

  return (
    <div className="min-h-screen flex justify-center items-center bg-gray-100 px-4">
      <div className="bg-white p-6 rounded-lg shadow-md w-full max-w-md space-y-4">
        <h2 className="text-xl font-semibold text-center">Forgot Password</h2>
        {error && <div className="text-red-500 text-sm text-center">{error}</div>}
        <input
          type="email"
          placeholder="Enter your email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
        <button
          onClick={handleSubmit}
          className="w-full py-2 bg-blue-600 text-white font-semibold rounded hover:bg-blue-700 transition"
        >
          Send OTP
        </button>
      </div>
    </div>
  );
};

export default ForgotPassword;
