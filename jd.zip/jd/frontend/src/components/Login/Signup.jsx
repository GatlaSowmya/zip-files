import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { Eye, EyeOff } from 'lucide-react';
import api from '../../config';
import { useUser } from './UserContext';

const Signup = () => {
  const navigate = useNavigate();
  const { setUserId, setUserName, setUserPhone1, setUserAbout, setUserImage } = useUser();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [userName, setFormUserName] = useState(''); // Renamed
  const [phone1, setPhone1] = useState('');
  const [phone2, setPhone2] = useState('');
  const [street, setStreet] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [pincode, setPincode] = useState('');
  const [country, setCountry] = useState('');
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const handleGoogleSignup = () => {
    window.location.href = 'http://localhost:5000/auth/google?prompt=select_account';
  };

  const handleEmailSignup = async () => {
    setError('');
    if (!userName || userName.length < 3) {
      setError('Name must be at least 3 characters');
      toast.error('Name must be at least 3 characters');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Invalid email format');
      toast.error('Invalid email format');
      return;
    }
    if (!/^\d{10}$/.test(phone1)) {
      setError('Primary phone must be 10 digits');
      toast.error('Primary phone must be 10 digits');
      return;
    }
    if (phone2 && !/^\d{10}$/.test(phone2)) {
      setError('Alternate phone must be 10 digits');
      toast.error('Alternate phone must be 10 digits');
      return;
    }
    if (
      !password ||
      password.length < 6 ||
      !/[A-Z]/.test(password) ||
      !/[a-z]/.test(password) ||
      !/\d/.test(password)
    ) {
      setError('Password must be 6+ characters with uppercase, lowercase, and number');
      toast.error('Password must be 6+ characters with uppercase, lowercase, and number');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      toast.error('Passwords do not match');
      return;
    }
    if (!street || !city || !state || !country || !/^\d{6}$/.test(pincode)) {
      setError('All address fields are required, and pincode must be 6 digits');
      toast.error('All address fields are required, and pincode must be 6 digits');
      return;
    }

    const payload = {
      user_name: userName,
      user_email: email,
      password,
      user_phone1: phone1,
      user_phone2: phone2,
      address: { street, city, state, pincode, country },
    };
    console.log('[Signup] Signup payload:', payload);

    try {
      const res = await api.post('/signup', payload);
      localStorage.setItem('token', res.data.token);
      localStorage.setItem('user_id', res.data.user_id);
      localStorage.setItem('user_name', res.data.user_name);
      setUserId(res.data.user_id);
      setUserName(res.data.user_name); // Context function
      setUserPhone1(res.data.user_phone1 || null);
      setUserAbout(res.data.about || null);
      setUserImage(res.data.profile_image || null);
      toast.success('Signup successful');
      navigate('/login');
    } catch (err) {
      const message = err.response?.data?.message || 'Signup failed';
      console.error('[Signup] Error:', {
        message: err.message,
        response: err.response?.data,
        status: err.response?.status,
      });
      setError(message);
      toast.error(message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
      <div className="w-full max-w-md bg-white p-8 rounded-lg shadow-md space-y-6">
        <h2 className="text-2xl font-semibold text-center text-gray-800">Sign Up</h2>
        {error && <div className="text-red-500 text-sm text-center">{error}</div>}
        <button
          onClick={handleGoogleSignup}
          className="w-full flex items-center justify-center gap-3 px-4 py-2 border border-gray-300 rounded hover:bg-gray-100 transition"
        >
          <img
            src="https://www.svgrepo.com/show/475656/google-color.svg"
            alt="Google"
            className="w-5 h-5"
          />
          <span className="text-sm font-medium text-gray-700">Sign up with Google</span>
        </button>
        <div className="flex items-center gap-2">
          <hr className="flex-grow border-gray-300" />
          <span className="text-sm text-gray-400">or</span>
          <hr className="flex-grow border-gray-300" />
        </div>
        <input
          type="text"
          placeholder="Name"
          value={userName}
          onChange={(e) => setFormUserName(e.target.value)}
          className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
        <input
          type="text"
          placeholder="Primary Phone"
          value={phone1}
          onChange={(e) => setPhone1(e.target.value)}
          className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
        <input
          type="text"
          placeholder="Alternate Phone"
          value={phone2}
          onChange={(e) => setPhone2(e.target.value)}
          className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
        <input
          type="text"
          placeholder="Street"
          value={street}
          onChange={(e) => setStreet(e.target.value)}
          className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
        <input
          type="text"
          placeholder="City"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
        <input
          type="text"
          placeholder="State"
          value={state}
          onChange={(e) => setState(e.target.value)}
          className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
        <input
          type="text"
          placeholder="Pincode"
          value={pincode}
          onChange={(e) => setPincode(e.target.value)}
          className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
        <input
          type="text"
          placeholder="Country"
          value={country}
          onChange={(e) => setCountry(e.target.value)}
          className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
        <div className="relative">
          <input
            type={showPassword ? 'text' : 'password'}
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
          <span
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-2.5 cursor-pointer text-gray-500"
          >
            {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
          </span>
        </div>
        <div className="relative">
          <input
            type={showConfirm ? 'text' : 'password'}
            placeholder="Confirm Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
          <span
            onClick={() => setShowConfirm(!showConfirm)}
            className="absolute right-3 top-2.5 cursor-pointer text-gray-500"
          >
            {showConfirm ? <EyeOff size={20} /> : <Eye size={20} />}
          </span>
        </div>
        <button
          onClick={handleEmailSignup}
          className="w-full py-2 bg-blue-600 text-white font-semibold rounded hover:bg-blue-700 transition"
        >
          Sign Up with Email
        </button>
        <p className="text-center text-sm text-gray-600">
          Already have an account?{' '}
          <button
            onClick={() => navigate('/login')}
            className="text-blue-600 hover:underline"
          >
            Login
          </button>
        </p>
      </div>
    </div>
  );
};

export default Signup;
