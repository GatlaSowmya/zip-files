
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mic, Search, Bell, User, MapPin } from 'lucide-react';
import { useUser } from '../components/Login/UserContext';
import api from '../config';

const JustDialNavbar = () => {
  const navigate = useNavigate();
  const { userName, userImage } = useUser();
  const [locations, setLocations] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState(
    localStorage.getItem('selectedLocation') || 'Ameerpet'
  );
  const [searchInput, setSearchInput] = useState('');
  const [locationInput, setLocationInput] = useState('');
  const [error, setError] = useState(null);
  const [showSearchSuggestions, setShowSearchSuggestions] = useState(false);
  const [showLocationSuggestions, setShowLocationSuggestions] = useState(false);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const [searchSuggestions, setSearchSuggestions] = useState([]);

  // Debug logging for user context
  useEffect(() => {
    console.log('[JustDialNavbar] UserContext:', { userName, userImage });
  }, [userName, userImage]);

  // Fetch unique locations from the backend
  useEffect(() => {
    let isMounted = true;
    const fetchLocations = async () => {
      try {
        console.log('[JustDialNavbar] Fetching locations');
        const response = await api.get('/locations');
        if (isMounted) {
          setLocations(response.data);
          setError(null);
        }
      } catch (error) {
        if (isMounted) {
          console.error('[JustDialNavbar] Error fetching locations:', {
            message: error.message,
            response: error.response?.data,
            status: error.response?.status,
          });
          setError('Failed to load locations. Please try again.');
          setLocations([]);
        }
      }
    };
    fetchLocations();
    return () => {
      isMounted = false;
    };
  }, []);

  // Update localStorage when selectedLocation changes
  useEffect(() => {
    if (selectedLocation) {
      localStorage.setItem('selectedLocation', selectedLocation);
    }
  }, [selectedLocation]);

  // Fetch search suggestions for categories, subcategories, and shops
  useEffect(() => {
    let isMounted = true;
    const fetchSuggestions = async () => {
      if (!searchInput.trim()) {
        setSearchSuggestions([]);
        setShowSearchSuggestions(false);
        return;
      }
      try {
        const response = await api.get('/search', {
          params: {
            query: searchInput,
            location: selectedLocation,
          },
        });
        if (isMounted) {
          setSearchSuggestions(response.data);
          setShowSearchSuggestions(true);
        }
      } catch (error) {
        console.error('[JustDialNavbar] Error fetching search suggestions:', error);
        if (isMounted) {
          setSearchSuggestions([]);
          setShowSearchSuggestions(false);
        }
      }
    };
    const debounce = setTimeout(fetchSuggestions, 300);
    return () => {
      clearTimeout(debounce);
      isMounted = false;
    };
  }, [searchInput, selectedLocation]);

  // Handle search input changes
  const handleSearchInputChange = (event) => {
    setSearchInput(event.target.value);
    setShowSearchSuggestions(event.target.value.trim().length > 0);
    setError(null);
  };

  // Handle location input changes
  const handleLocationInputChange = (event) => {
    setLocationInput(event.target.value);
    setShowLocationSuggestions(event.target.value.trim().length > 0);
    setError(null);
  };

  // Handle suggestion click
  const handleSuggestionClick = async (suggestion) => {
    setSearchInput('');
    setShowSearchSuggestions(false);
    setError(null);

    try {
      if (suggestion.type === 'category') {
        navigate(`/categories/${suggestion.path}`);
      } else if (suggestion.type === 'subcategory') {
        const parentResponse = await api.get(`/categories/${suggestion.parent_category_id}`);
        const parentCategory = parentResponse.data;
        const parentPath = parentCategory.category_name.toLowerCase().replace(/\s+/g, '-');
        navigate(`/categories/${parentPath}/${suggestion.path}`);
      } else if (suggestion.type === 'shop') {
        const subcategoryResponse = await api.get(`/categories/${suggestion.category_id}`);
        const subcategory = subcategoryResponse.data;
        const subPath = subcategory.category_name.toLowerCase().replace(/\s+/g, '-');
        const parentResponse = await api.get(`/categories/${subcategory.parent_category_id}`);
        const parentCategory = parentResponse.data;
        const parentPath = parentCategory.category_name.toLowerCase().replace(/\s+/g, '-');
        navigate(`/categories/${parentPath}/${subPath}/${suggestion.id}`, {
          state: {
            shop: {
              id: suggestion.id,
              name: suggestion.name,
              rating: suggestion.rating,
              totalRatings: suggestion.review_count,
              location: suggestion.location,
            },
          },
        });
      }
    } catch (error) {
      console.error('[JustDialNavbar] Error navigating to suggestion:', error);
      setError('Failed to navigate. Please try again.');
    }
  };

  // Handle Enter key press for search
  const handleSearchKeyPress = async (event) => {
    if (event.key === 'Enter') {
      if (!searchInput.trim()) {
        setError('Please enter a search term.');
        return;
      }
      try {
        const response = await api.get('/search', {
          params: {
            query: searchInput,
            location: selectedLocation,
          },
        });
        const results = response.data;
        if (results.length === 0) {
          setError('No results found. Try a different search term.');
          setSearchInput('');
          setShowSearchSuggestions(false);
          return;
        }
        handleSuggestionClick(results[0]);
      } catch (error) {
        console.error('[JustDialNavbar] Search error:', error);
        setError('Failed to perform search. Please try again.');
      }
    }
  };

  // Handle input focus for search
  const handleSearchInputFocus = () => {
    setShowSearchSuggestions(searchInput.trim().length > 0);
  };

  // Handle location search
  const handleLocationSearch = () => {
    if (!locationInput.trim()) {
      setError('Please enter a location to search.');
      setShowLocationSuggestions(false);
      return;
    }
    const matchedLocation = locations.find(
      (location) => location.toLowerCase() === locationInput.trim().toLowerCase()
    );
    if (matchedLocation) {
      setSelectedLocation(matchedLocation);
      setLocationInput('');
      setShowLocationSuggestions(false);
      setError(null);
    } else {
      setError('Area not found. Please try a location from the suggestions.');
      setShowLocationSuggestions(false);
    }
  };

  // Handle Enter key press for location
  const handleLocationKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleLocationSearch();
    }
  };

  // Handle input focus for location
  const handleLocationInputFocus = () => {
    setShowLocationSuggestions(locationInput.trim().length > 0);
  };

  // Handle geolocation
  const handleGetCurrentLocation = async () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      return;
    }

    setIsLoadingLocation(true);
    setError(null);

    try {
      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0,
        });
      });

      const { latitude, longitude } = position.coords;

      const response = await api.get('/locations/reverse', {
        params: { lat: latitude, lon: longitude },
      });

      const { location } = response.data;

      if (location) {
        setSelectedLocation(location);
        setLocationInput('');
        setShowLocationSuggestions(false);
      } else {
        setSelectedLocation('Ameerpet');
        setError('Could not determine your location. Using Ameerpet.');
      }
    } catch (err) {
      console.error('[JustDialNavbar] Geolocation error:', err.message, err.response?.data);
      if (err.code === 1) {
        setError('Location access denied. Please allow location permissions.');
      } else if (err.code === 2) {
        setError('Location unavailable. Please try again or type a location.');
      } else {
        setSelectedLocation('Ameerpet');
        setError('Failed to fetch location. Using Ameerpet.');
      }
    } finally {
      setIsLoadingLocation(false);
    }
  };

  // Clear error after 5 seconds
  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  // Handle profile click
  const handleProfileClick = () => {
    console.log('[JustDialNavbar] Profile clicked, navigating to /profile');
    navigate('/profile');
  };

  return (
    <div className="sticky top-0 z-50 w-full bg-gradient-to-b from-white to-gray-50 shadow-md">
      {error && (
        <div className="fixed top-4 right-4 bg-red-600 text-white px-4 py-2 rounded-lg shadow-xl z-50 animate-[fadeInOut_5s_ease-in-out] text-sm font-medium max-w-xs text-center">
          {error}
        </div>
      )}

      <nav className="flex items-center justify-between px-4 py-2">
        {/* Logo */}
        <div
          className="flex items-center gap-1 cursor-pointer"
          onClick={() => navigate('/')}
        >
          <span className="text-xl font-extrabold text-orange-500 transition-transform duration-200 ease-in-out hover:scale-105 hover:text-orange-600">
            Search
          </span>
          <span className="text-xl font-extrabold text-blue-600 transition-transform duration-200 ease-in-out hover:scale-105 hover:text-blue-700">
            Hyderabad
          </span>
        </div>

        {/* Location Search (Desktop Only) */}
        <div className="hidden lg:flex items-center text-sm text-gray-700 relative px-3">
          <div className="flex items-center border border-gray-300 rounded-lg px-3 py-1.5 bg-white transition-all duration-300 hover:border-blue-500 hover:shadow-lg">
            <input
              type="text"
              value={locationInput}
              onChange={handleLocationInputChange}
              onKeyPress={handleLocationKeyPress}
              onFocus={handleLocationInputFocus}
              placeholder={selectedLocation || 'Search location'}
              className="outline-none text-sm text-gray-700 placeholder-gray-400 w-32 focus:text-gray-900"
            />
            <button
              onClick={handleGetCurrentLocation}
              disabled={isLoadingLocation}
              className={`p-1.5 rounded-full ml-2 transition-all duration-200 ${
                isLoadingLocation
                  ? 'bg-gray-300 cursor-not-allowed opacity-70'
                  : 'bg-green-500 text-white hover:bg-green-600 hover:scale-110'
              }`}
              title="Get Current Location"
            >
              <MapPin size={14} />
            </button>
            <button
              onClick={handleLocationSearch}
              disabled={isLoadingLocation}
              className={`p-1.5 rounded-full ml-2 transition-all duration-200 ${
                isLoadingLocation
                  ? 'bg-gray-300 cursor-not-allowed opacity-70'
                  : 'bg-blue-500 text-white hover:bg-blue-600 hover:scale-110'
              }`}
              title="Search Location"
            >
              <Search size={14} />
            </button>
          </div>
          {showLocationSuggestions && locations.length > 0 && (
            <ul className="absolute top-full left-0 bg-white border border-gray-200 rounded-lg shadow-xl w-32 max-h-40 overflow-y-auto z-10 animate-[slideDown_0.3s_ease]">
              {locations
                .filter((location) =>
                  location.toLowerCase().includes(locationInput.toLowerCase())
                )
                .map((location) => (
                  <li
                    key={location}
                    onClick={() => {
                      setSelectedLocation(location);
                      setLocationInput('');
                      setShowLocationSuggestions(false);
                    }}
                    className="px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900 transition-colors duration-200 cursor-pointer"
                  >
                    {location}
                  </li>
                ))}
            </ul>
          )}
        </div>

        {/* Desktop Search */}
        <div className="hidden lg:flex items-center flex-1 max-w-2xl mx-4">
          <div className="flex items-center w-full border border-gray-300 rounded-full px-4 py-2 bg-white shadow-sm transition-all duration-300 hover:border-blue-500 hover:shadow-lg">
            <input
              type="text"
              placeholder={selectedLocation ? `Search in ${selectedLocation}` : 'Search'}
              value={searchInput}
              onChange={handleSearchInputChange}
              onKeyPress={handleSearchKeyPress}
              onFocus={handleSearchInputFocus}
              className="w-full outline-none text-sm text-gray-700 placeholder-gray-400 focus:text-gray-900"
            />
            <Mic className="text-gray-500 h-5 w-5 mx-2 cursor-pointer transition-transform duration-200 hover:scale-110 hover:text-gray-700" />
            <button
              onClick={() => handleSearchKeyPress({ key: 'Enter' })}
              className="bg-orange-500 p-2 rounded-full text-white transition-all duration-200 hover:bg-orange-600 hover:scale-110"
            >
              <Search size={16} />
            </button>
          </div>
          {showSearchSuggestions && searchSuggestions.length > 0 && (
            <ul className="absolute top-full left-0 right-0 bg-white border border-gray-200 rounded-lg shadow-xl w-full max-w-2xl max-h-60 overflow-y-auto z-10 animate-[slideDown_0.3s_ease]">
              {searchSuggestions.map((suggestion) => (
                <li
                  key={`${suggestion.type}-${suggestion.id}`}
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900 transition-colors duration-200 cursor-pointer flex items-center gap-2"
                >
                  <img
                    src={suggestion.icon}
                    alt={suggestion.name}
                    className="w-6 h-6 rounded-full object-cover"
                    onError={(e) => {
                      e.target.src = 'https://picsum.photos/48/48?random=0';
                    }}
                  />
                  <div>
                    <span className="font-medium">{suggestion.name}</span>
                    <span className="ml-2 text-xs text-gray-500 capitalize">
                      {suggestion.type}
                      {suggestion.type === 'shop' && suggestion.rating && (
                        <span> • {suggestion.rating} ★ ({suggestion.review_count} reviews)</span>
                      )}
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Desktop Right Buttons */}
        <div className="hidden lg:flex items-center gap-3">
          <button
            onClick={() => navigate('/leads')}
            className="flex items-center gap-1 border border-gray-300 rounded-full px-4 py-1.5 bg-white shadow-sm transition-all duration-200 hover:bg-gray-50 hover:border-blue-500 hover:-translate-y-0.5"
          >
            📧 Leads
          </button>
          <button
            onClick={() => navigate('/listing')}
            className="flex items-center gap-1 border border-gray-300 rounded-full px-4 py-1.5 bg-white shadow-sm transition-all duration-200 hover:bg-gray-50 hover:border-blue-500 hover:-translate-y-0.5"
          >
            📊 Listing
          </button>
          <button
            onClick={() => navigate('/advertise')}
            className="flex items-center gap-1 border border-gray-300 rounded-full px-4 py-1.5 bg-white shadow-sm transition-all duration-200 hover:bg-gray-50 hover:border-blue-500 hover:-translate-y-0.5"
          >
            📢 Advertise
          </button>
          <Bell size={20} className="cursor-pointer text-gray-600 transition-transform duration-200 hover:scale-110 hover:text-gray-700" />
          {userName ? (
            <>
              {userImage ? (
                <img
                  src={userImage}
                  alt="Profile"
                  className="w-8 h-8 rounded-full cursor-pointer transition-transform duration-200 hover:scale-110 hover:opacity-80"
                  onError={(e) => {
                    e.target.src = 'https://via.placeholder.com/32x32?text=User';
                  }}
                  onClick={handleProfileClick}
                />
              ) : (
                <User
                  size={28}
                  className="cursor-pointer text-gray-600 transition-transform duration-200 hover:scale-110 hover:text-gray-700"
                  onClick={handleProfileClick}
                />
              )}
            </>
          ) : (
            <button
              onClick={() => navigate('/login')}
              className="bg-blue-600 text-white px-5 py-1.5 rounded-full font-medium transition-all duration-200 hover:bg-blue-700 hover:scale-105"
            >
              Login
            </button>
          )}
        </div>

        {/* Mobile Buttons */}
        <div className="lg:hidden flex items-center gap-3">
          <Bell size={20} className="cursor-pointer text-gray-600 transition-transform duration-200 hover:scale-110 hover:text-gray-700" />
          {userName ? (
            <>
              {userImage ? (
                <img
                  src={userImage}
                  alt="Profile"
                  className="w-8 h-8 rounded-full cursor-pointer transition-transform duration-200 hover:scale-110 hover:opacity-80"
                  onError={(e) => {
                    e.target.src = 'https://via.placeholder.com/32x32?text=User';
                  }}
                  onClick={handleProfileClick}
                />
              ) : (
                <User
                  size={28}
                  className="cursor-pointer text-gray-600 transition-transform duration-200 hover:scale-110 hover:text-gray-700"
                  onClick={handleProfileClick}
                />
              )}
            </>
          ) : (
            <button
              onClick={() => navigate('/login')}
              className="bg-blue-600 text-white px-3 py-1.5 rounded-full transition-all duration-200 hover:bg-blue-700 hover:scale-105"
            >
              <User size={18} />
            </button>
          )}
        </div>
      </nav>

      {/* Mobile Search and Location */}
      <div className="lg:hidden flex flex-col mx-4 mt-3 gap-2">
        <div className="flex items-center border border-gray-300 rounded-full px-3 py-2 bg-white shadow-sm transition-all duration-300 hover:border-blue-500 hover:shadow-lg">
          <Search size={16} className="text-gray-500 mr-2" />
          <input
            type="text"
            placeholder={selectedLocation ? `Search in ${selectedLocation}` : 'Search'}
            value={searchInput}
            onChange={handleSearchInputChange}
            onKeyPress={handleSearchKeyPress}
            onFocus={handleSearchInputFocus}
            className="w-full outline-none text-sm text-gray-700 placeholder-gray-400 focus:text-gray-900"
          />
          <Mic className="text-gray-500 h-5 w-5 ml-2 cursor-pointer transition-transform duration-200 hover:scale-110 hover:text-gray-700" />
        </div>
        {showSearchSuggestions && searchSuggestions.length > 0 && (
          <ul className="bg-white border border-gray-200 rounded-lg shadow-xl w-full max-h-60 overflow-y-auto z-10 animate-[slideDown_0.3s_ease]">
            {searchSuggestions.map((suggestion) => (
              <li
                key={`${suggestion.type}-${suggestion.id}`}
                onClick={() => handleSuggestionClick(suggestion)}
                className="px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900 transition-colors duration-200 cursor-pointer flex items-center gap-2"
              >
                <img
                  src={suggestion.icon}
                  alt={suggestion.name}
                  className="w-6 h-6 rounded-full object-cover"
                  onError={(e) => {
                    e.target.src = 'https://picsum.photos/48/48?random=0';
                  }}
                />
                <div>
                  <span className="font-medium">{suggestion.name}</span>
                  <span className="ml-2 text-xs text-gray-500 capitalize">
                    {suggestion.type}
                    {suggestion.type === 'shop' && suggestion.rating && (
                      <span> • {suggestion.rating} ★ ({suggestion.review_count} reviews)</span>
                    )}
                  </span>
                </div>
              </li>
            ))}
          </ul>
        )}
        <div className="flex items-center border border-gray-300 rounded-lg px-3 py-1.5 bg-white transition-all duration-300 hover:border-blue-500 hover:shadow-lg relative">
          <input
            type="text"
            value={locationInput}
            onChange={handleLocationInputChange}
            onKeyPress={handleLocationKeyPress}
            onFocus={handleLocationInputFocus}
            placeholder={selectedLocation || 'Search location'}
            className="outline-none text-sm text-gray-700 placeholder-gray-400 w-full focus:text-gray-900"
          />
          <button
            onClick={handleGetCurrentLocation}
            disabled={isLoadingLocation}
            className={`p-1.5 rounded-full ml-2 transition-all duration-200 ${
              isLoadingLocation
                ? 'bg-gray-300 cursor-not-allowed opacity-70'
                : 'bg-green-500 text-white hover:bg-green-600 hover:scale-110'
            }`}
            title="Get Current Location"
          >
            <MapPin size={14} />
          </button>
          <button
            onClick={handleLocationSearch}
            disabled={isLoadingLocation}
            className={`p-1.5 rounded-full ml-2 transition-all duration-200 ${
              isLoadingLocation
                ? 'bg-gray-300 cursor-not-allowed opacity-70'
                : 'bg-blue-500 text-white hover:bg-blue-600 hover:scale-110'
            }`}
            title="Search Location"
          >
            <Search size={14} />
          </button>
          {showLocationSuggestions && locations.length > 0 && (
            <ul className="absolute top-full left-0 bg-white border border-gray-200 rounded-lg shadow-xl w-full max-h-40 overflow-y-auto z-10 animate-[slideDown_0.3s_ease]">
              {locations
                .filter((location) =>
                  location.toLowerCase().includes(locationInput.toLowerCase())
                )
                .map((location) => (
                  <li
                    key={location}
                    onClick={() => {
                      setSelectedLocation(location);
                      setLocationInput('');
                      setShowLocationSuggestions(false);
                    }}
                    className="px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900 transition-colors duration-200 cursor-pointer"
                  >
                    {location}
                  </li>
                ))}
            </ul>
          )}
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="lg:hidden flex justify-around px-4 py-2">
        <button
          onClick={() => navigate('/leads')}
          className="flex items-center gap-1 px-2 py-1 text-sm font-medium text-gray-700 transition-colors duration-200 hover:text-blue-600"
        >
          📧 Leads
        </button>
        <button
          onClick={() => navigate('/listing')}
          className="flex items-center gap-1 px-2 py-1 text-sm font-medium text-gray-700 transition-colors duration-200 hover:text-blue-600"
        >
          📊 Listing
        </button>
        <button
          onClick={() => navigate('/advertise')}
          className="flex items-center gap-1 px-2 py-1 text-sm font-medium text-gray-700 transition-colors duration-200 hover:text-blue-600"
        >
          📢 Advertise
        </button>
        <button
          onClick={() => navigate('/settings')}
          className="flex items-center gap-1 px-2 py-1 text-sm font-medium text-gray-700 transition-colors duration-200 hover:text-blue-600"
        >
          ⚙️ Settings
        </button>
      </div>
    </div>
  );
};

export default JustDialNavbar;
