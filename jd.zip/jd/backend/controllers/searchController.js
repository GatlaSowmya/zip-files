const pool = require("../db");

exports.search = async (req, res) => {
  try {
    const { query, location } = req.query;
    if (!query) {
      return res.status(400).json({ error: "Search query is required" });
    }

    const normalizedQuery = decodeURIComponent(query).toLowerCase().replace(/-/g, " ");
    const normalizedLocation = location ? decodeURIComponent(location).toLowerCase() : null;

    const categoriesQuery = `
      SELECT category_id, category_name, 'category' as type, image_url, icon_url, parent_category_id
      FROM search_hyderabad.categories
      WHERE category_name ILIKE $1
        AND (parent_category_id IS NULL)
    `;
    const categoriesResult = await pool.query(categoriesQuery, [`%${normalizedQuery}%`]);

    const subcategoriesQuery = `
      SELECT category_id, category_name, 'subcategory' as type, image_url, icon_url, parent_category_id
      FROM search_hyderabad.categories
      WHERE category_name ILIKE $1
        AND parent_category_id IS NOT NULL
    `;
    const subcategoriesResult = await pool.query(subcategoriesQuery, [`%${normalizedQuery}%`]);

    let shopsQuery = `
      SELECT shop_id, shop_name, category_id, 'shop' as type, description, address, location, rating, review_count
      FROM search_hyderabad.shops
      WHERE shop_name ILIKE $1
        AND is_approved = true
    `;
    const queryParams = [`%${normalizedQuery}%`];
    if (normalizedLocation) {
      shopsQuery += ` AND location ILIKE $2`;
      queryParams.push(`%${normalizedLocation}%`);
    }
    const shopsResult = await pool.query(shopsQuery, queryParams);

    const results = [
      ...categoriesResult.rows.map((row) => ({
        id: row.category_id,
        name: row.category_name,
        type: row.type,
        icon: row.icon_url || `https://picsum.photos/48/48?random=${row.category_id}`,
        path: row.category_name.toLowerCase().replace(/\s+/g, "-"),
        parent_category_id: row.parent_category_id,
      })),
      ...subcategoriesResult.rows.map((row) => ({
        id: row.category_id,
        name: row.category_name,
        type: row.type,
        icon: row.icon_url || `https://picsum.photos/48/48?random=${row.category_id}`,
        path: row.category_name.toLowerCase().replace(/\s+/g, "-"),
        parent_category_id: row.parent_category_id,
      })),
      ...shopsResult.rows.map((row) => ({
        id: row.shop_id,
        name: row.shop_name,
        type: row.type,
        icon: `https://picsum.photos/48/48?random=${row.shop_id}`,
        category_id: row.category_id,
        location: row.location,
        rating: row.rating?.toFixed(1) || "0.0",
        review_count: row.review_count || 0,
      })),
    ];

    res.status(200).json(results);
  } catch (err) {
    console.error(`[searchController] Error: ${err.message}`);
    res.status(500).json({ error: "Internal server error" });
  }
};