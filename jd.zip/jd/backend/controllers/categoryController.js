const pool = require("../db");

exports.getCategories = async (req, res) => {
  try {
    const { name } = req.query;
    let query = "SELECT category_id, category_name, image_url, icon_url, parent_category_id FROM search_hyderabad.categories";
    const values = [];
    
    if (name) {
      const normalizedName = decodeURIComponent(name).replace(/-/g, " ");
      // console.log(`Querying categories with name ILIKE '${normalizedName}'`); // Debug
      query += " WHERE category_name ILIKE $1";
      values.push(normalizedName);
    } else {
      // console.log("Querying categories with parent_category_id IS NULL"); // Debug
      query += " WHERE parent_category_id IS NULL";
    }
    
    const result = await pool.query(query, values);
    // console.log(`Query result: ${JSON.stringify(result.rows)}`); // Debug
    if (result.rows.length === 0 && name) {
      return res.status(404).json({ error: `Category or subcategory "${name}" not found` });
    }
    res.status(200).json(result.rows);
  } catch (err) {
    // console.error(`Error in getCategories: ${err.message}`); // Debug
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.getCategoryById = async (req, res) => {
  try {
    const { id } = req.params;
    // console.log(`Querying category with id = '${id}'`); // Debug
    const result = await pool.query(
      "SELECT category_id, category_name, image_url, icon_url, parent_category_id FROM search_hyderabad.categories WHERE category_id = $1",
      [id]
    );
    
    // console.log(`Query result: ${JSON.stringify(result.rows)}`); // Debug
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Category not found" });
    }
    
    res.status(200).json(result.rows[0]);
  } catch (err) {
    // console.error(`Error in getCategoryById: ${err.message}`); // Debug
    res.status(500).json({ error: "Internal server error" });
  }
};