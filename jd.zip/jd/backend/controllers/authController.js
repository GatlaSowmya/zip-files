const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const pool = require('../db');
require('dotenv').config();

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

const generateOtp = () => Math.floor(100000 + Math.random() * 900000).toString();

exports.signup = async (req, res) => {
  const { user_name, user_email, password, user_phone1, user_phone2, address } = req.body;
  // console.log('[POST /api/signup] Signup request, user_email:', user_email);
  try {
    const existing = await pool.query(
      'SELECT user_id FROM search_hyderabad.c_users WHERE user_email = $1 OR user_phone1 = $2',
      [user_email, user_phone1]
    );
    if (existing.rows.length > 0) {
      // console.log('[POST /api/signup] Email or phone already in use, user_email:', user_email, 'user_phone1:', user_phone1);
      return res.status(400).json({ message: 'Email or phone number already in use' });
    }

    const password_hash = await bcrypt.hash(password, 10);
    const result = await pool.query(
      `INSERT INTO search_hyderabad.c_users 
        (user_name, user_email, password_hash, user_phone1, user_phone2, address, provider)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING user_id, user_name, user_phone1, about, profile_image`,
      [user_name, user_email, password_hash, user_phone1, user_phone2 || null, address, 'email']
    );
    const user = result.rows[0];
    const token = jwt.sign({ user_id: user.user_id, user_email }, process.env.JWT_SECRET, { expiresIn: '2h' });
    console.log('[POST /api/signup] User created, userId:', user.user_id, {
      user_name,
      user_email,
      user_phone1,
    });
    return res.status(201).json({
      message: 'Signup successful',
      token,
      user_id: user.user_id,
      user_name,
      user_phone1: user.user_phone1,
      about: user.about || null,
      profile_image: user.profile_image || null,
    });
  } catch (err) {
    console.error('[POST /api/signup] Error, user_email:', user_email, {
      message: err.message,
      code: err.code,
      detail: err.detail,
    });
    if (err.code === '23505') {
      return res.status(400).json({ message: 'Email or phone number already in use' });
    }
    if (err.code === '22P02') {
      return res.status(400).json({ message: 'Invalid address format for JSONB field' });
    }
    res.status(500).json({ message: 'Server error', details: err.message });
  }
};

exports.login = async (req, res) => {
  const { user_email, password } = req.body;
  // console.log('[POST /api/login] Login attempt, user_email:', user_email);
  try {
    const result = await pool.query('SELECT * FROM search_hyderabad.c_users WHERE user_email = $1', [user_email]);
    if (result.rows.length === 0) {
      // console.log('[POST /api/login] User not found, user_email:', user_email);
      return res.status(400).json({ message: 'User not found' });
    }
    const user = result.rows[0];
    if (user.provider === 'google' && !user.password_hash) {
      // console.log('[POST /api/login] Google-only user, userId:', user.user_id, 'user_email:', user_email);
      return res.status(400).json({ message: 'Use Google login or reset password to set an email login' });
    }
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      // console.log('[POST /api/login] Invalid password, userId:', user.user_id, 'user_email:', user_email);
      return res.status(400).json({ message: 'Invalid password' });
    }
    const token = jwt.sign({ user_id: user.user_id, user_email: user.user_email }, process.env.JWT_SECRET, { expiresIn: '2h' });
    console.log('[POST /api/login] Login successful, userId:', user.user_id, {
      user_name: user.user_name,
      user_email,
    });
    res.json({
      message: 'Login successful',
      token,
      user_id: user.user_id,
      user_name: user.user_name,
      user_phone1: user.user_phone1,
      about: user.about || null,
      profile_image: user.profile_image || null,
    });
  } catch (err) {
    console.error('[POST /api/login] Error, user_email:', user_email, {
      message: err.message,
    });
    res.status(500).json({ message: 'Server error' });
  }
};

exports.sendOtp = async (req, res) => {
  const { email } = req.body;
  // console.log('[POST /api/send-otp] Sending OTP, user_email:', email);
  if (!email) {
    // console.log('[POST /api/send-otp] Email required');
    return res.status(400).json({ message: 'Email required' });
  }
  const otp = generateOtp();
  const expiry = new Date(Date.now() + 5 * 60 * 1000);
  try {
    const existing = await pool.query('SELECT user_id FROM search_hyderabad.c_users WHERE user_email = $1', [email]);
    if (existing.rows.length === 0) {
      // console.log('[POST /api/send-otp] Creating new user for OTP, user_email:', email);
      await pool.query(
        'INSERT INTO search_hyderabad.c_users (user_email, otp, otp_expiry) VALUES ($1, $2, $3) RETURNING user_id',
        [email, otp, expiry]
      );
    } else {
      const userId = existing.rows[0].user_id;
      // console.log('[POST /api/send-otp] Updating OTP, userId:', userId, 'user_email:', email);
      await pool.query(
        'UPDATE search_hyderabad.c_users SET otp = $1, otp_expiry = $2 WHERE user_email = $3',
        [otp, expiry, email]
      );
    }
    await transporter.sendMail({
      from: `"App" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: 'Your OTP',
      html: `<p>Your OTP is: <b>${otp}</b> (valid for 5 minutes)</p>`,
    });
    // console.log('[POST /api/send-otp] OTP sent, user_email:', email);
    res.status(200).json({ message: 'OTP sent successfully' });
  } catch (err) {
    console.error('[POST /api/send-otp] Error, user_email:', email, {
      message: err.message,
    });
    res.status(500).json({ message: 'Failed to send OTP' });
  }
};

exports.verifyOtp = async (req, res) => {
  const { email, otp } = req.body;
  // console.log('[POST /api/verify-otp] Verifying OTP, user_email:', email);
  try {
    const result = await pool.query(
      'SELECT user_id, otp, otp_expiry FROM search_hyderabad.c_users WHERE user_email = $1',
      [email]
    );
    if (result.rows.length === 0) {
      // console.log('[POST /api/verify-otp] Invalid email, user_email:', email);
      return res.status(400).json({ message: 'Invalid email' });
    }
    const { user_id, otp: storedOtp, otp_expiry } = result.rows[0];
    if (storedOtp !== otp || new Date() > new Date(otp_expiry)) {
      // console.log('[POST /api/verify-otp] Invalid or expired OTP, userId:', user_id, 'user_email:', email);
      return res.status(400).json({ message: 'Invalid or expired OTP' });
    }
    // console.log('[POST /api/verify-otp] OTP verified, userId:', user_id, 'user_email:', email);
    await pool.query(
      'UPDATE search_hyderabad.c_users SET otp = NULL, otp_expiry = NULL WHERE user_email = $1',
      [email]
    );
    res.json({ message: 'OTP verified' });
  } catch (err) {
    console.error('[POST /api/verify-otp] Error, user_email:', email, {
      message: err.message,
    });
    res.status(500).json({ message: 'Error verifying OTP' });
  }
};

exports.forgotPassword = async (req, res) => {
  const { user_email } = req.body;
  // console.log('[POST /api/forgot-password] Sending OTP, user_email:', user_email);
  try {
    const result = await pool.query('SELECT user_id FROM search_hyderabad.c_users WHERE user_email = $1', [user_email]);
    if (result.rows.length === 0) {
      // console.log('[POST /api/forgot-password] Email not registered, user_email:', user_email);
      return res.status(400).json({ message: 'Email not registered' });
    }
    const userId = result.rows[0].user_id;
    const otp = generateOtp();
    const expiry = new Date(Date.now() + 5 * 60 * 1000);
    await pool.query(
      'UPDATE search_hyderabad.c_users SET otp = $1, otp_expiry = $2 WHERE user_email = $3',
      [otp, expiry, user_email]
    );
    await transporter.sendMail({
      from: `"App" <${process.env.EMAIL_USER}>`,
      to: user_email,
      subject: 'OTP for Password Reset',
      html: `<p>Your OTP is: <b>${otp}</b> (valid for 5 minutes)</p>`,
    });
    // console.log('[POST /api/forgot-password] OTP sent, userId:', userId, 'user_email:', user_email);
    res.json({ message: 'OTP sent to your email' });
  } catch (err) {
    console.error('[POST /api/forgot-password] Error, user_email:', user_email, {
      message: err.message,
    });
    res.status(500).json({ message: 'Error generating OTP' });
  }
};

exports.resetPassword = async (req, res) => {
  const { user_email, otp, new_password } = req.body;
  // console.log('[POST /api/reset-password] Password reset attempt, user_email:', user_email);
  try {
    const result = await pool.query(
      'SELECT user_id, otp, otp_expiry, provider FROM search_hyderabad.c_users WHERE user_email = $1',
      [user_email]
    );
    if (result.rows.length === 0) {
      // console.log('[POST /api/reset-password] Invalid email, user_email:', user_email);
      return res.status(400).json({ message: 'Invalid email' });
    }
    const { user_id, otp: storedOtp, otp_expiry, provider } = result.rows[0];
    if (storedOtp !== otp || new Date() > new Date(otp_expiry)) {
      // console.log('[POST /api/reset-password] Invalid or expired OTP, userId:', user_id, 'user_email:', user_email);
      return res.status(400).json({ message: 'Invalid or expired OTP' });
    }
    const password_hash = await bcrypt.hash(new_password, 10);
    const newProvider = provider === 'google' ? 'google,email' : provider;
    await pool.query(
      `UPDATE search_hyderabad.c_users
       SET password_hash = $1, otp = NULL, otp_expiry = NULL, provider = $2
       WHERE user_email = $3`,
      [password_hash, newProvider, user_email]
    );
    // console.log('[POST /api/reset-password] Password reset successful, userId:', user_id, 'user_email:', user_email);
    res.json({ message: 'Password reset successful' });
  } catch (err) {
    console.error('[POST /api/reset-password] Error, user_email:', user_email, {
      message: err.message,
    });
    res.status(500).json({ message: 'Error resetting password' });
  }
};

exports.getUser = async (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    // console.log('[GET /api/user] No token provided');
    return res.status(401).json({ message: 'No token provided' });
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    // console.log('[GET /api/user] Token verified, userId:', decoded.user_id, 'user_email:', decoded.user_email);
    const result = await pool.query(
      'SELECT user_id, user_name, user_phone1, about, profile_image FROM search_hyderabad.c_users WHERE user_email = $1',
      [decoded.user_email]
    );
    if (result.rows.length === 0) {
      // console.log('[GET /api/user] User not found, user_email:', decoded.user_email);
      return res.status(404).json({ message: 'User not found' });
    }
    // console.log('[GET /api/user] User data retrieved, userId:', result.rows[0].user_id, {
      // user_name: result.rows[0].user_name,
      // user_phone1: result.rows[0].user_phone1,
    // });
    res.json(result.rows[0]);
  } catch (err) {
    console.error('[GET /api/user] Error, user_email:', req.headers.authorization ? 'provided' : 'none', {
      message: err.message,
    });
    res.status(401).json({ message: 'Invalid or expired token' });
  }
};

exports.updateUser = async (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  const { user_name, user_phone1, about, profile_image } = req.body;
  if (!token) {
    // console.log('[PUT /api/user/update] No token provided');
    return res.status(401).json({ message: 'No token provided' });
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    // console.log('[PUT /api/user/update] Token verified, userId:', decoded.user_id, 'user_email:', decoded.user_email);
    if (profile_image && profile_image.length > 10 * 1024 * 1024 * 4 / 3) {
      // console.log('[PUT /api/user/update] Profile image too large, userId:', decoded.user_id);
      return res.status(413).json({ message: 'Profile image is too large. Maximum size is 10MB.' });
    }
    await pool.query(
      `UPDATE search_hyderabad.c_users
       SET user_name = $1, user_phone1 = $2, about = $3, profile_image = $4, updated_at = CURRENT_TIMESTAMP
       WHERE user_email = $5`,
      [user_name, user_phone1, about, profile_image || null, decoded.user_email]
    );
    console.log('[PUT /api/user/update] Profile updated, userId:', decoded.user_id, {
      user_name,
      user_phone1,
    });
    res.json({ message: 'Profile updated successfully' });
  } catch (err) {
    console.error('[PUT /api/user/update] Error, user_email:', req.headers.authorization ? 'provided' : 'none', {
      message: err.message,
      code: err.code,
    });
    res.status(500).json({ message: 'Error updating profile', details: err.message });
  }
};

exports.verifyToken = async (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    // console.log('[GET /api/auth/verify] No token provided');
    return res.status(401).json({ message: 'No token provided' });
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    // console.log('[GET /api/auth/verify] Token verified, userId:', decoded.user_id, 'user_email:', decoded.user_email);
    res.status(200).json({ message: 'Token is valid', userId: decoded.user_id });
  } catch (err) {
    console.error('[GET /api/auth/verify] Token verification failed, user_email:', req.headers.authorization ? 'provided' : 'none', {
      message: err.message,
    });
    return res.status(403).json({ message: 'Invalid token' });
  }
};

exports.verifyToken = async (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    // console.log('[GET /api/auth/verify] No token provided');
    return res.status(401).json({ message: 'No token provided' });
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    // console.log('[GET /api/auth/verify] Token verified, userId:', decoded.user_id, 'user_email:', decoded.user_email);
    res.status(200).json({ message: 'Token is valid', userId: decoded.user_id });
  } catch (err) {
    console.error('[GET /api/auth/verify] Token verification failed, user_email:', req.headers.authorization ? 'provided' : 'none', {
      message: err.message,
    });
    return res.status(403).json({ message: 'Invalid token' });
  }
};