const pool = require("../db");

exports.getSubcategoriesByCategoryId = async (req, res) => {
  try {
    const { categoryId } = req.params;
    const result = await pool.query(
      "SELECT category_id, category_name, description, image_url, icon_url FROM search_hyderabad.categories WHERE parent_category_id = $1",
      [categoryId]
    );
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
};