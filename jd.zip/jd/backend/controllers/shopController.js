const pool = require("../db");

exports.getShopsByCategory = async (req, res) => {
  try {
    const { categoryId } = req.params;
    const { location } = req.query;
    console.log(`[getShopsByCategory] Querying shops for category_id = '${categoryId}', location = '${location}'`);

    let query = `
      SELECT shop_id, vendor_id, category_id, shop_name, description, address, location, 
             phone, whatsapp_number, email, website, opening_time, closing_time, rating, 
             review_count, is_approved, created_at
      FROM search_hyderabad.shops 
      WHERE category_id = $1 AND is_approved = true
    `;
    const queryParams = [categoryId];

    if (location) {
      const normalizedLocation = decodeURIComponent(location).toLowerCase();
      query += ` AND LOWER(location) ILIKE $2`;
      queryParams.push(`%${normalizedLocation}%`);
    }

    const result = await pool.query(query, queryParams);

    console.log(`[getShopsByCategory] Found ${result.rows.length} shops`);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "No shops found for this category and location" });
    }

    res.status(200).json(result.rows);
  } catch (err) {
    console.error(`[getShopsByCategory] Error: ${err.message}`);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.getShopById = async (req, res) => {
  try {
    const { shopId } = req.params;
    console.log(`[getShopById] Querying shop with shop_id = '${shopId}'`);

    // Log UUID format for debugging, but don't fail
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(shopId)) {
      console.warn(`[getShopById] Non-UUID shopId: '${shopId}'`);
    }

    const result = await pool.query(
      `SELECT shop_id, vendor_id, category_id, shop_name, description, address, location, 
              phone, whatsapp_number, email, website, opening_time, closing_time, rating, 
              review_count, is_approved, created_at
       FROM search_hyderabad.shops 
       WHERE shop_id = $1 AND is_approved = true`,
      [shopId]
    );

    if (result.rows.length === 0) {
      console.log(`[getShopById] Shop not found for shop_id = '${shopId}'`);
      return res.status(404).json({ error: "Shop not found" });
    }

    res.status(200).json(result.rows[0]);
  } catch (err) {
    console.error(`[getShopById] Error: ${err.message}`);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.getServicesByShopId = async (req, res) => {
  try {
    const { shopId } = req.params;
    console.log(`[getServicesByShopId] Querying services for shop_id = '${shopId}'`);

    // Log UUID format for debugging, but don't fail
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(shopId)) {
      console.warn(`[getServicesByShopId] Non-UUID shopId: '${shopId}'`);
    }

    const result = await pool.query(
      `SELECT service_id, shop_id, title, description, original_price, discount_price, image_url, created_at
       FROM search_hyderabad.catalogue
       WHERE shop_id = $1`,
      [shopId]
    );

    console.log(`[getServicesByShopId] Found ${result.rows.length} services`);
    const services = result.rows.map((service) => ({
      id: service.service_id,
      name: service.title,
      description: service.description || "No description available",
      price: `₹ ${service.discount_price || service.original_price}`,
      original_price: service.original_price,
      discount_price: service.discount_price,
      image_url: service.image_url || "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg",
      created_at: service.created_at,
    }));

    res.status(200).json(services);
  } catch (err) {
    console.error(`[getServicesByShopId] Error: ${err.message}`);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.getShopImagesByShopId = async (req, res) => {
  try {
    const { shopId } = req.params;
    console.log(`[getShopImagesByShopId] Querying images for shop_id = '${shopId}'`);

    // Log UUID format for debugging, but don't fail
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(shopId)) {
      console.warn(`[getShopImagesByShopId] Non-UUID shopId: '${shopId}'`);
    }

    const result = await pool.query(
      `SELECT image_id, shop_id, image_url, created_at
       FROM search_hyderabad.shop_images
       WHERE shop_id = $1
       ORDER BY created_at ASC`,
      [shopId]
    );

    console.log(`[getShopImagesByShopId] Found ${result.rows.length} images`);
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(`[getShopImagesByShopId] Error: ${err.message}`);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.addReview = async (req, res) => {
  const { shopId } = req.params;
  const { rating, comment } = req.body;
  const token = req.headers.authorization?.split(' ')[1];

  if (!token) {
    console.error('[addReview] No token provided');
    return res.status(401).json({ error: 'No token provided' });
  }

  try {
    // Log UUID format for debugging, but don't fail
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(shopId)) {
      console.warn(`[addReview] Non-UUID shopId: '${shopId}'`);
    }

    // Validate rating
    if (!rating || !Number.isInteger(rating) || rating < 1 || rating > 5) {
      console.log(`[addReview] Invalid rating: ${rating}`);
      return res.status(400).json({ error: 'Rating must be an integer between 1 and 5' });
    }

    // Validate comment
    if (comment && comment.length > 1000) {
      console.log(`[addReview] Comment too long: ${comment.length} characters`);
      return res.status(400).json({ error: 'Comment must be 1000 characters or less' });
    }

    // Verify JWT token
    const decoded = require('jsonwebtoken').verify(token, process.env.JWT_SECRET);
    const userId = decoded.user_id;

    // Check if shop exists
    const shopResult = await pool.query(
      'SELECT shop_id FROM search_hyderabad.shops WHERE shop_id = $1 AND is_approved = true',
      [shopId]
    );
    if (shopResult.rows.length === 0) {
      console.log(`[addReview] Shop not found for shop_id = '${shopId}'`);
      return res.status(404).json({ error: 'Shop not found' });
    }

    // Insert review
    const result = await pool.query(
      `INSERT INTO search_hyderabad.reviews (shop_id, user_id, rating, comment)
       VALUES ($1, $2, $3, $4)
       RETURNING review_id, shop_id, user_id, rating, comment, created_at`,
      [shopId, userId, rating, comment || null]
    );

    // Fetch user details
    const userResult = await pool.query(
      'SELECT user_name FROM search_hyderabad.c_users WHERE user_id = $1',
      [userId]
    );
    const userName = userResult.rows[0]?.user_name || 'Anonymous';

    console.log(`[addReview] Review added for shop_id = '${shopId}' by user_id = '${userId}'`);
    res.status(201).json({
      message: 'Review added successfully',
      review: {
        review_id: result.rows[0].review_id,
        shop_id: result.rows[0].shop_id,
        user_id: result.rows[0].user_id,
        user_name: userName,
        rating: result.rows[0].rating,
        comment: result.rows[0].comment,
        created_at: result.rows[0].created_at,
      },
    });
  } catch (err) {
    console.error(`[addReview] Error: ${err.message}`);
    if (err.name === 'JsonWebTokenError') {
      return res.status(401).json({ error: 'Invalid or expired token' });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
};

exports.getReviewsByShopId = async (req, res) => {
  try {
    const { shopId } = req.params;
    console.log(`[getReviewsByShopId] Querying reviews for shop_id = '${shopId}'`);

    // Log UUID format for debugging, but don't fail
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(shopId)) {
      console.warn(`[getReviewsByShopId] Non-UUID shopId: '${shopId}'`);
    }

    const result = await pool.query(
      `SELECT r.review_id, r.shop_id, r.user_id, r.rating, r.comment, r.created_at, u.user_name
       FROM search_hyderabad.reviews r
       LEFT JOIN search_hyderabad.c_users u ON r.user_id = u.user_id
       WHERE r.shop_id = $1
       ORDER BY r.created_at DESC`,
      [shopId]
    );

    console.log(`[getReviewsByShopId] Found ${result.rows.length} reviews`);
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(`[getReviewsByShopId] Error: ${err.message}`);
    res.status(500).json({ error: 'Internal server error' });
  }
};