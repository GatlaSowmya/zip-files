const pool = require("../db");
const axios = require("axios");

// Utility function to retry failed requests with exponential backoff
const retryRequest = async (fn, retries = 3, delay = 1000) => {
  for (let i = 0; i < retries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i === retries - 1) throw error;
      const backoffDelay = delay * Math.pow(2, i);
      console.log(`ℹ️ Retry attempt ${i + 1} failed, retrying in ${backoffDelay}ms...`);
      await new Promise((resolve) => setTimeout(resolve, backoffDelay));
    }
  }
};

// Controller: Fetch unique locations
const getLocations = async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT DISTINCT location FROM search_hyderabad.shops WHERE location IS NOT NULL ORDER BY location"
    );
    const locations = result.rows.map((row) => row.location);
    res.status(200).json(locations);
  } catch (error) {
    console.error('❌ Error fetching locations:', {
      message: error.message,
      stack: error.stack,
    });
    res.status(500).json({ error: 'Failed to fetch locations', details: error.message });
  }
};

// Controller: Reverse geocode coordinates
const reverseGeocode = async (req, res) => {
  const { lat, lon } = req.query;

  if (!lat || !lon) {
    return res.status(400).json({ error: 'Latitude and longitude are required' });
  }

  try {
    // Validate latitude and longitude
    const latitude = parseFloat(lat);
    const longitude = parseFloat(lon);
    if (isNaN(latitude) || isNaN(longitude)) {
      return res.status(400).json({ error: 'Invalid latitude or longitude' });
    }

    // Make request to Nominatim with retry logic
    const response = await retryRequest(() =>
      axios.get(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`,
        {
          headers: {
            'User-Agent': 'SearchHyderabadApp/1.0 (contact: gorantlaashok957@gmail.com)',
          },
          timeout: 10000,
        }
      )
    ).catch((error) => {
      console.error('❌ Nominatim timeout, returning fallback:', { latitude, longitude });
      return { data: { address: { suburb: 'Unknown' } } };
    });

    if (response.data.error) {
      console.error('❌ Nominatim API error:', response.data.error);
      return res.status(500).json({ error: 'Failed to fetch location from Nominatim', details: response.data.error });
    }

    const { address } = response.data;
    const locationName = address.suburb || address.neighbourhood || address.village || address.city || 'Unknown';
    const normalizedLocation = locationName.replace(/[^a-zA-Z\s]/g, '').trim();

    if (!normalizedLocation || normalizedLocation === 'Unknown') {
      console.error('❌ Invalid location name from Nominatim:', { locationName, address });
      return res.status(200).json({ location: 'Ameerpet', isInServiceArea: true });
    }

    console.log('ℹ️ Resolved location from Nominatim:', normalizedLocation);

    // Check if the location exists in the database (for manual searches, not current location)
    const result = await pool.query(
      "SELECT DISTINCT location FROM search_hyderabad.shops WHERE LOWER(location) = LOWER($1)",
      [normalizedLocation]
    );
    const isInServiceArea = result.rows.length > 0;

    // Always return the resolved location for current location requests
    res.status(200).json({
      location: normalizedLocation,
      isInServiceArea,
    });
  } catch (error) {
    console.error('❌ Error in reverse geocoding:', {
      message: error.message,
      stack: error.stack,
      code: error.code,
      response: error.response ? {
        status: error.response.status,
        data: error.response.data,
      } : null,
    });

    if (error.code === 'ECONNREFUSED' || error.code === 'ETIMEDOUT' || error.code === 'ENOTFOUND') {
      return res.status(200).json({
        location: 'Ameerpet',
        isInServiceArea: true,
      });
    }
    if (error.response && (error.response.status === 429 || error.response.status === 403)) {
      return res.status(200).json({
        location: 'Ameerpet',
        isInServiceArea: true,
      });
    }
    res.status(500).json({ error: 'Failed to fetch location', details: error.message || 'Unknown error' });
  }
};

module.exports = {
  getLocations,
  reverseGeocode,
};