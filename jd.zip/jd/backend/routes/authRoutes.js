const express = require('express');
const router = express.Router();
const {
  signup,
  login,
  forgotPassword,
  verifyOtp,
  resetPassword,
  sendOtp,
  getUser,
  updateUser,
  verifyToken,
} = require('../controllers/authController');

router.post('/signup', signup);
router.post('/login', login);
router.post('/forgot-password', forgotPassword);
router.post('/send-otp', sendOtp);
router.post('/verify-otp', verifyOtp);
router.post('/reset-password', resetPassword);
router.get('/user', getUser);
router.put('/user/update', updateUser);
router.get('/auth/verify', verifyToken);

module.exports = router;