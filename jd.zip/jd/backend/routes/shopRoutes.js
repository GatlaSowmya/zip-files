// shoproutes.js
const express = require("express");
const router = express.Router();
const shopController = require("../controllers/shopController");

router.get("/:categoryId", shopController.getShopsByCategory);
router.get("/shop/:shopId", shopController.getShopById);
router.get("/shop/:shopId/services", shopController.getServicesByShopId);
router.get("/shop/:shopId/images", shopController.getShopImagesByShopId);
router.get("/shop/:shopId/reviews", shopController.getReviewsByShopId);
router.post("/shop/:shopId/reviews", shopController.addReview);

module.exports = router;