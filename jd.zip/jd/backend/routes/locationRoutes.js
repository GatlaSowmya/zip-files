const express = require("express");
const router = express.Router();
const { getLocations, reverseGeocode } = require('../controllers/locationController');

// Route: GET /api/locations
router.get("/", getLocations);

// Route: GET /api/locations/reverse
router.get("/reverse", reverseGeocode);

module.exports = router;