require('dotenv').config();
const express = require('express');
const cors = require('cors');
const session = require('express-session');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const jwt = require('jsonwebtoken');
const path = require('path');

const authRoutes = require('./routes/authRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const subcategoryRoutes = require('./routes/subcategoryRoutes');
const shopRoutes = require('./routes/shopRoutes');
const locationRoutes = require('./routes/locationRoutes');
const searchRoutes = require('./routes/searchRoutes');
const pool = require('./db');

const app = express();
const PORT = process.env.PORT || 5000;

// Check required env
['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET', 'GOOGLE_CALLBACK_URL'].forEach(key => {
  if (!process.env[key]) {
    console.warn(`⚠️  Missing env variable: ${key}`);
  }
});

// CORS
app.use(cors({
  origin: 'http://localhost:3009',
  credentials: true,
}));

app.use(express.json({ limit: '10mb' }));

// Session setup
app.use(session({
  secret: process.env.JWT_SECRET,
  resave: false,
  saveUninitialized: true,
  cookie: {
    secure: false,
    httpOnly: true,
    sameSite: 'lax'
  }
}));

app.use(passport.initialize());
app.use(passport.session());

// Serialize/Deserialize
passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj, done) => done(null, obj));

// Google OAuth Strategy
passport.use(new GoogleStrategy({
  clientID: process.env.GOOGLE_CLIENT_ID,
  clientSecret: process.env.GOOGLE_CLIENT_SECRET,
  callbackURL: process.env.GOOGLE_CALLBACK_URL,
}, async (accessToken, refreshToken, profile, done) => {
  try {
    const email = profile.emails?.[0]?.value;
    const name = profile.displayName;
    const image = profile.photos?.[0]?.value || null;

    if (!email) {
      console.error('[Google OAuth] No email found in profile:', profile);
      return done(new Error('No email found in Google profile'), null);
    }

    const { rows } = await pool.query(
      'SELECT * FROM search_hyderabad.c_users WHERE user_email = $1',
      [email]
    );

    let user = rows[0];

    if (!user) {
      const result = await pool.query(
        `INSERT INTO search_hyderabad.c_users 
        (user_email, user_name, provider, profile_image)
        VALUES ($1, $2, 'google', $3)
        RETURNING user_id, user_email, user_name, profile_image`,
        [email, name, image]
      );
      user = result.rows[0];
      console.log('[Google OAuth] New user registered, userId:', user.user_id, 'email:', email);
    } else {
      console.log('[Google OAuth] Existing user, userId:', user.user_id, 'email:', email);
    }

    const token = jwt.sign({
      user_id: user.user_id,
      user_email: user.user_email
    }, process.env.JWT_SECRET, { expiresIn: '2h' });

    user.token = token;
    return done(null, user);
  } catch (err) {
    console.error('[Google OAuth] Error, email:', profile?.emails?.[0]?.value || 'unknown', {
      message: err.message,
    });
    return done(err, null);
  }
}));

// Auth Routes
app.get('/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

app.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/auth/failure' }),
  (req, res) => {
    const { token, user_id, user_name, user_email, profile_image } = req.user;
    console.log('[GET /auth/google/callback] Google login successful, userId:', user_id, {
      user_name,
      user_email,
    });
    const redirectUrl = `http://localhost:3009/auth/google/success?token=${token}&user_id=${user_id}&user_name=${encodeURIComponent(user_name)}&user_email=${encodeURIComponent(user_email)}&profile_image=${encodeURIComponent(profile_image || '')}`;
    return res.redirect(redirectUrl);
  }
);

app.get('/auth/failure', (req, res) => {
  console.log('[GET /auth/failure] Google login failed');
  res.status(401).send('Google Login failed ❌');
});

// API Routes
app.use('/api', authRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/subcategories', subcategoryRoutes);
app.use('/api/shops', shopRoutes);
app.use('/api/locations', locationRoutes);
app.use('/api/search', searchRoutes);

// Large payload error handler
app.use((err, req, res, next) => {
  if (err.type === 'entity.too.large') {
    console.error('❗ Payload too large:', req.path);
    return res.status(413).json({ message: 'Uploaded file is too large. Maximum size is 10MB.' });
  }
  console.error('❗ Server error:', err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});