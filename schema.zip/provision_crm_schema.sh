#!/bin/bash
export COMPANYUNQI_ID=$1
export XXXX_COMPANYUNQI_ID="'"${COMPANYUNQI_ID}"'"

export BASE_DIR="/opt/visys/ai4bazaar/crm01/scripts"
export WORK_DIR="/opt/visys/ai4bazaar/crm01/out"
export PID=$(echo $$)

export TZ="Asia/Kolkata"
export DATE_FORMAT="$(date "+%d_%h_%Y_%Hh_%Mm_%S")"
export LOG_FILE="${LOG_DIR}/main_${COMPANYUNQI_ID}_${DATE_FORMAT}.log"

. /opt/visys/ai4bazaar/crm01/conf/.global_env

[ -z ${COMPANYUNQI_ID} ] && echo "Company Unique ID - should be passed !!" && exit 1

COMPANY_CNT=$(psql -q -h ${PG_HOST} -U ${PG_USER} -d ${PG_DB} -t -A -c \
"select count(1) from vo_benchsales.t_company_registration where companyunqi_id=${XXXX_COMPANYUNQI_ID};")

if [ "${COMPANY_CNT}" = "0" ]
then
    echo "${COMPANYUNQI_ID} does not exist !!"
    psql -q -h ${PG_HOST} -U ${PG_USER} -d ${PG_DB} -t -A -c \
    "INSERT INTO vo_benchsales.t_provision_status(companyunqi_id, provision_date, status)
     VALUES (${XXXX_COMPANYUNQI_ID}, CURRENT_TIMESTAMP, 'X');"
    exit 1
fi

[ ! -d ${WORK_DIR} ] && mkdir -p ${WORK_DIR}

cp ${BASE_DIR}/db_templates.conf ${WORK_DIR}/${COMPANYUNQI_ID}_${PID}_schema.sql
sed -i "s|XXXX_COMPANYUNQI_ID|${COMPANYUNQI_ID}|g" ${WORK_DIR}/${COMPANYUNQI_ID}_${PID}_schema.sql

psql -q -h ${PG_HOST} -U ${PG_USER} -d ${PG_DB} -t -A -c \
"INSERT INTO vo_benchsales.t_provision_status(companyunqi_id, provision_date, status)
 VALUES (${XXXX_COMPANYUNQI_ID}, CURRENT_TIMESTAMP, 'P');"

psql -q -h ${PG_HOST} -U ${PG_USER} -d ${PG_DB} -t -A -f "${WORK_DIR}/${COMPANYUNQI_ID}_${PID}_schema.sql"
RETURN_STATUS="$(echo $?)"

if [ "${RETURN_STATUS}" = "0" ]
then
    psql -q -h ${PG_HOST} -U ${PG_USER} -d ${PG_DB} -t -A -c \
    "UPDATE vo_benchsales.t_provision_status
     SET status='Y' WHERE companyunqi_id=${XXXX_COMPANYUNQI_ID};"
else
    psql -q -h ${PG_HOST} -U ${PG_USER} -d ${PG_DB} -t -A -c \
    "UPDATE vo_benchsales.t_provision_status
     SET status='E' WHERE companyunqi_id=${XXXX_COMPANYUNQI_ID};"
fi

